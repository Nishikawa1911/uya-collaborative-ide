# Бэкэндпен интеграция нүктелері

UI компоненттерін өзгертпей, үш портты ауыстыру жеткілікті. **3-кезеңде REST порты нақты бэкэндке қосылды;** **4-кезеңде нақты уақыт порты (`src/collab`, WebSocket) қосылды;** `runner` әлі demo (mock режимінде `realtime` да demo).

## 1. REST API — `src/api/index.ts` ✅
Қазір: `createHttpApi('/api')` (`api/http/httpApi.ts`), бэкэнд — `server/` ([сипаттама](backend.md)). `public/config.js` ішіндегі `apiMode: 'mock'` тек визуалды сынақ үшін. Сессия HttpOnly кукиде, сондықтан фронтенд пен API бір origin-де болуы керек (немесе `ALLOWED_ORIGINS` + кросс-домен кук баптауы).

`IdeApi` (src/api/contracts.ts) топтары:
- `auth`: login, register, logout, me, updateProfile, changePassword
- `projects`: list, get, create, join, rotateInvite, members, setMemberRole, removeMember, getSettings, updateSettings, remove
- `files`: tree, read, save, create, rename, remove
- `chat`: history

Қателер `ApiError(код, параметрлер, статус)` ретінде лақтырылады; `код` (мысалы `auth.invalid_credentials`) `i18n/kk.ts` ішіндегі қазақша хабарға сәйкес келеді. Бэкэнд ішкі кодтары ағылшынша болуы мүмкін.

**Қауіпсіздік:** шақыру коды бір рет көрсетіледі, сервер тек хэшін сақтайды (Argon2/bcrypt), әрекет санына шектеу қойылады. UI тек `rotateInvite` және `join` шақырады.

## 2. Нақты уақыт — `src/realtime`
`RealtimeClient` / `RealtimeSession` / `CollabBinding` келісімі. `demoClient` (күйі `'demo'`) тек mock режимінде қалды. Нақты режимде `src/collab/client.ts` қолданылады (Yjs орнына өз CRDT — `shared/crdt.ts`); `useFiles` ішіндегі `buffers` — CRDT сессиясының айнасы, ал чат пен presence осы арна арқылы келеді. Толық сипаттама — [realtime.md](realtime.md).

## 3. Кодты іске қосу — `src/runner`
`RunnerClient.start(request, onEvent)` → `{ executionId, cancel }`. Қазір ол әрдайым `ApiError('run.unavailable')` лақтырады, UI мұны «Нәтиже» панелінде адал көрсетеді. Нақты іске асыру: sandbox контейнері, ресурс шектеулері, stdout/stderr оқиғаларын стрим ету.

## Тексеру тізімі
- [x] `api` нақты бэкэндке ауыстырылды; `npm run test:e2e` және `npm run test:server` өтеді
- [ ] Барлық серверлік қате кодтарының аудармасы `kk.ts` ішінде бар
- [x] Бірлескен жұмыс хабарлары нақты режимде алынды; [ ] `terminal.notConnected` кодты іске қосу қосылғанда алынады
