# Кодты оқшауланған ортада орындау (5-кезең)

Пайдаланушы коды **негізгі backend процесінде ешқашан орындалмайды**. Орындау бөлек **runner** қызметінде,
әр іске қосу үшін жеке `runc` (OCI) контейнерінде жүреді.

```
Браузер ──REST (cookie)──▶ Backend (server/)                Runner (runner/, root, бөлек хост/процесс)
  Нәтиже/Stop/SQL/Preview     • рұқсат (editor/owner)          • Bearer-токен (RUNNER_TOKEN)
  300 мс polling              • кезек, шектеулер, runs кестесі  • тілдер: өзін-өзі тексеру (self-test)
                              • runner HTTP клиенті ───────────▶ • JobEnv → runc контейнері (әр фаза)
                              • Web Preview (код орындамайды)    • компиляция фазасы → іске қосу фазасы
```

## Режимдер

| Режим | Қалай жұмыс істейді |
|---|---|
| **Run File** | Таңдалған файл entry болады, **жобаның барлық файлдары** (тәуелділіктер) контейнерге беріледі. |
| **Run Project** | Жоба баптауындағы `entryPoint` + барлық файлдар. |
| **Web Preview** | HTML/CSS/JS серверде **код орындамай** бір құжатқа біріктіріледі; браузерде `iframe sandbox="allow-scripts"` (allow-same-origin жоқ → бөтен origin) және CSP (`default-src 'none'; connect-src 'none'`…) ішінде іске қосылады. Консоль iframe-ден `postMessage` арқылы келеді. |
| **SQL Playground** | `query.sql` оқшауланған контейнердегі `:memory:` SQLite-та орындалады. Әр іске қосу — бос дерекқор. `ATTACH`, `load_extension`, қауіпті `PRAGMA` тыйым салынған; бір сұраныс 5 с; дерекқор көлемі, қатар саны (200) шектелген. Диалект: **SQLite**. |

## Тілдер (әрқайсысының жеке конфигурациясы — `runner/languages.ts`)

| Тіл | Құрал | Фазалар |
|---|---|---|
| Python | `python -X utf8` | run |
| JavaScript | `node` | run |
| TypeScript | `tsc` → `node` | compile (`.uya-out`) → run; түр қатесі = `compile_error` |
| Java | `javac` → `java` | compile → run (JVM жады/ағын шектері) |
| C++ | `g++ -std=c++20` | compile (басқа .cpp тәуелділіктер байланысады) → run |
| Rust | `rustc --edition 2021` | compile → run |
| Go | `go build` (желісіз: `GOPROXY=off`, `CGO_ENABLED=0`) | compile → run |
| PHP | `php -n` (`disable_functions`, `open_basedir`) | run |
| SQL | Python `sqlite3` харнесі | run |
| C# | `dotnet` | **Бұл ортада dotnet жоқ → тіл ӨШІРУЛІ**, интерфейс себебін көрсетеді |
| HTML / CSS | — | тек Web Preview |

**Тілді қосу ережесі:** runner іске қосылғанда әр тіл контейнерде өзін-өзі тексереді (дұрыс бағдарлама → күтілген шығыс;
компиляцияланатын тілдер үшін → компиляция қатесі анықталуы керек). Тексеруден өтпесе тіл `enabled=false` болады,
`GET /api/runtime` себебін қайтарады, ал интерфейс сол тіл үшін түймені өшіріп, себебін жазады.
Әр тіл `runner/tests/languages.test.ts` ішінде бөлек тексеріледі (көп файл, импорт/тәуелділік, компиляция қатесі,
runtime қатесі, шығу коды, stdin, шектер).

## Қауіпсіздік моделі (`runner/sandbox.ts`) — нақты іске асырылған және тесттелген

Әр фаза (компиляция / іске қосу) үшін жеке контейнер:

* **Namespaces:** user, pid, network (тек loopback, сыртқа жол жоқ), ipc, uts, mount, cgroup. Контейнердегі root хостта
  пайдаланушы емес UID-қа (200000+) сәйкес; процесс UID 1000 ретінде жұмыс істейді.
* **Файл жүйесі:** rootfs тек оқуға; хостты `/usr` (және тіл құралдары) тек оқуға bind-mount; `/work` — жеке tmpfs
  (көлемі мен inode саны шектелген, `nosuid,nodev`); `/tmp`, `/dev/shm` — tmpfs. Хост үй қалталары, `/root`, runner файлдары
  контейнерде **жоқ**. Файл жолдары (`..`, абсолютті, symlink-шығу, `.uya-*`) жазылар алдында тексеріледі.
* **Желі:** жалғыз loopback; сыртқы желі де, хост қызметтері (backend, runner, метадеректер) де қолжетімсіз. Go/Rust/Java тәуелділіктері желіден жүктелмейді.
* **Привилегиялар:** барлық capability алынған, `no_new_privileges`, seccomp (қауіпті syscall-дар тыйым: mount, ptrace, bpf, keyctl, kexec, `clone`-дағы `CLONE_NEW*`, `clone3`…), `/proc` бөліктері маскаланған/тек оқу.
* **Шектер:** cgroup жады (swap=жад), CPU квотасы, pids шегі (fork-bomb), rlimit (NOFILE, FSIZE, CORE, CPU), **қабырға уақыты**
  (timeout), **шығыс көлемі** (stdout+stderr), диск квотасы. Асып кетсе — процесс өлтіріледі, статус нақты көрсетіледі
  (`timeout`, `memory_limit`, `output_limit`).
* **Тазалау:** әр орындаудан кейін контейнерлер өшіріледі, tmpfs unmount, жұмыс қалтасы жойылады; клиент ажыраса немесе
  Stop басылса — контейнер `runc kill --all` арқылы өлтіріледі. Тесттер қалдықтардың жоқтығын тексереді.
* **Backend:** runner-мен тек Bearer-токен арқылы сөйлеседі; per-user: бір мезгілде ≤2, минутына ≤30; жалпы concurrency (4) және кезек (50);
  viewer іске қоса алмайды (403); қатысушы емес — 404; басқа қатысушының нәтижесін тек иесі көре алады.

Нәтиже статустары: `ok`, `error` (шығу коды ≠ 0), `compile_error`, `timeout`, `memory_limit`, `output_limit`, `killed` (Stop), `internal_error`.

## Орнату

Runner **root құқығын** (user namespace, cgroup, mount) талап етеді, сондықтан **негізгі backend-тен бөлек хостта/VM-де** іске қосыңыз.

```bash
# runner хосты: runc, python3, node, tsc, JDK, g++, rustc, go, php (қажетті тілдерге қарай) орнатылған болуы керек
export RUNNER_TOKEN=$(openssl rand -hex 24)        # backend-те де сол мән
export RUNNER_HOST=0.0.0.0 RUNNER_PORT=7070        # тек жеке желіде / брандмауэр артында!
sudo -E npm run runner                             # тілдердің self-test нәтижесі консольге шығады

# backend хосты
export RUNNER_URL=http://runner.internal:7070 RUNNER_TOKEN=<сол токен>
npm start
```

Бапталатын айнымалылар: `RUNNER_STATE_DIR`, `RUNNER_JOBS_DIR` (ата-аналық қалталарда `o+x` болуы керек),
`RUNNER_CONCURRENCY`, `RUNNER_MAX_QUEUE`; backend: `RUN_CONCURRENCY`, `RUN_QUEUE_MAX`, `RUN_PER_USER_ACTIVE`,
`RUN_PER_USER_PER_MINUTE`, `RUN_RETENTION_DAYS`, `RUN_STORE_CHARS`. `RUNNER_URL` бос болса — іске қосу өшіріледі және
интерфейс мұны ашық көрсетеді (`/api/runtime → available:false`).

Тесттер: `npm run test:runner` (63 тест, нақты контейнер), `npm run test:server`, `npm run test:e2e:run` (браузер → backend → runner).

## API

| Әдіс | Жол | Сипаттама |
|---|---|---|
| GET | `/api/runtime` | runner қолжетімді ме, әр тілдің `enabled/reason` күйі |
| POST | `/api/projects/:id/runs` | `{mode:'file',fileId}` · `{mode:'project'}` · `{mode:'sql',sql}` (+`stdin`) → 202 |
| GET | `/api/projects/:id/runs/:runId?after=N` | күй + `N`-нен кейінгі шығыс оқиғалары (`stream: build|stdout|stderr`) |
| POST | `/api/projects/:id/runs/:runId/cancel` | орындауды тоқтату |
| GET | `/api/projects/:id/runs` | соңғы орындаулар |
| GET | `/api/projects/:id/preview?path=` | біріктірілген HTML + CSP (код орындалмайды) |

Дерекқор: `003_runs.sql` (`runs` кестесі: статус, шығу коды, stdout/stderr/build, уақыт). Қайта қосылғанда жартылай қалған
`queued/running` жазбалар `internal_error (server_restart)` болады; ескі жазбалар `RUN_RETENTION_DAYS` бойынша өшіріледі.

## Шектеулер (ашық айтамыз)

* Контейнерлер **хост ядросын бөліседі**. Сенімсіз көп пайдаланушылы өндіріс үшін runner-ді бөлек VM-де (немесе gVisor `runsc` / Firecracker астында) іске қосыңыз; user namespace + seccomp + capability drop — қосымша қорғаныс қабаттары, ядро осалдығынан кепіл емес.
* Seccomp — **тізім бойынша тыйым** (denylist), allowlist емес. Өндірісте минималды per-language rootfs кескіндері ұсынылады (қазір хост `/usr` тек оқуға қосылады).
* **C# қосылмаған** (dotnet SDK жоқ). Орнатылса, runner іске қосылғанда self-test өтіп, автоматты қосылады — бірақ бұл конфигурация осы ортада тексерілмеген.
* Веб-алдын ала қарауда: `type="module"` ішіндегі қатысты `import`-тар, сыртқы CDN, `fetch` — CSP бойынша бұғатталады; суреттер тек SVG (жоба файлдары мәтін).
* SQL — тек SQLite диалекті; дерекқор іске қосулар арасында сақталмайды.
* Нәтиже 300 мс polling арқылы жеткізіледі (WebSocket емес); stdin интерактивті емес (іске қосар алдында бір рет беріледі).
