/**
 * Қателер каталогы. `code` — тұрақты (интерфейс осы бойынша `errors.<code>` кілтін іздейді),
 * `message` — қазақша мәтін (API-ды тікелей қолданатындарға). Параметрлер `{атау}` түрінде.
 * ЕСКЕРТУ: мәтіндер src/i18n/kk.ts ішіндегі `errors.*` кілттерімен бірдей болуы керек (тест тексереді).
 */
export const MESSAGES = {
  // жалпы
  'unknown': 'Күтпеген қате пайда болды. Қайталап көріңіз.',
  'server.internal': 'Серверде қате пайда болды. Кейінірек қайталап көріңіз.',
  'request.not_found': 'Сұралған мекенжай табылмады.',
  'request.method_not_allowed': 'Бұл әдіс қолдау таппайды.',
  'request.bad_json': 'Сұраныс форматы қате (JSON күтілген).',
  'request.unsupported_media': 'Тек application/json форматы қабылданады.',
  'request.too_large': 'Сұраныс тым үлкен.',
  'request.forbidden_origin': 'Сұраныс сенімсіз көзден келді.',
  'request.rate_limited': 'Тым көп сұраныс. {minutes} минуттан кейін қайталаңыз.',
  // аутентификация
  'auth.unauthenticated': 'Жүйеге кіру қажет.',
  'auth.invalid_credentials': 'Email/пайдаланушы аты немесе құпия сөз қате.',
  'auth.too_many_attempts': 'Тым көп сәтсіз әрекет. {minutes} минуттан кейін қайталаңыз.',
  'auth.email_taken': 'Бұл email бұрын тіркелген.',
  'auth.username_taken': 'Бұл пайдаланушы аты бос емес.',
  'auth.wrong_password': 'Ағымдағы құпия сөз қате.',
  // валидация
  'validation.display_name_required': 'Аты-жөнін енгізіңіз.',
  'validation.display_name_too_long': 'Аты-жөні ең көбі 60 таңба болуы керек.',
  'validation.username_format': 'Пайдаланушы аты 3–24 таңба: латын әріптері, сандар, _.',
  'validation.email_invalid': 'Email форматы қате.',
  'validation.password_short': 'Құпия сөз кемінде 10 таңба болуы керек.',
  'validation.password_too_long': 'Құпия сөз ең көбі 128 таңба болуы керек.',
  'validation.password_same': 'Жаңа құпия сөз ағымдағыдан өзгеше болуы керек.',
  'validation.color_invalid': 'Түс форматы қате (мысалы, #1fa7b8).',
  'validation.avatar_invalid': 'Аватар PNG, JPEG немесе WebP форматында болуы керек.',
  'validation.avatar_too_large': 'Аватар файлы 2 МБ-тан аспауы керек.',
  'validation.project_name_required': 'Жоба атауын енгізіңіз.',
  'validation.project_name_too_long': 'Жоба атауы ең көбі 60 таңба болуы керек.',
  'validation.description_too_long': 'Сипаттама ең көбі 300 таңба болуы керек.',
  'validation.languages_required': 'Кемінде бір бағдарламалау тілін таңдаңыз.',
  'validation.languages_invalid': 'Бағдарламалау тілі жарамсыз.',
  'validation.entry_point_invalid': 'Негізгі файл жолы жарамсыз.',
  'validation.role_invalid': 'Рөл жарамсыз.',
  'validation.invite_format': 'Код форматы: XXXX-XXXX-XXXX (12 таңба).',
  'validation.field_invalid': 'Өріс мәні жарамсыз.',
  'validation.max_members_invalid': 'Қатысушылар саны 1–500 аралығында болуы керек.',
  // жоба
  'project.not_found': 'Жоба табылмады немесе қолжетімсіз.',
  'project.invalid_invite': 'Шақыру коды қате немесе мерзімі өтіп кеткен.',
  'project.invite_rate_limited': 'Тым көп әрекет жасалды. {minutes} минуттан кейін қайталаңыз.',
  'project.already_member': 'Сіз бұл жобаның қатысушысысыз.',
  'project.member_limit': 'Жобадағы қатысушылар саны шегіне жетті.',
  'project.member_not_found': 'Қатысушы табылмады.',
  'project.owner_immutable': 'Жоба иесінің рөлін өзгертуге немесе оны жоюға болмайды.',
  'project.limit_reached': 'Жобалар санының шегіне жеттіңіз.',
  'project.confirm_mismatch': 'Растау үшін жоба атауын дәл енгізіңіз.',
  'permission.denied': 'Бұл әрекетке рұқсатыңыз жоқ.',
  // файлдар
  'file.exists': 'Мұндай атаулы файл немесе қалта бұрыннан бар.',
  'file.invalid_name': 'Файл атауы жарамсыз.',
  'file.not_found': 'Файл немесе қалта табылмады.',
  'file.not_a_file': 'Бұл — файл емес.',
  'file.parent_invalid': 'Қалта табылмады немесе жарамсыз.',
  'file.too_large': 'Файл мазмұны 1 МБ-тан аспауы керек.',
  'file.invalid_content': 'Файл мазмұнында мәтіндік емес (NUL) таңбалар бар.',
  'file.limit_reached': 'Жобадағы файлдар мен қалталар санының шегіне жеттіңіз.',
  'collab.rate_limited': 'Хабарламалар тым жиі жіберілуде. Біраз күтіңіз.',
  'collab.read_only': 'Сізде бұл файлды өңдеуге рұқсат жоқ (тек оқу).',
  'collab.doc_too_large': 'Файл бірлесіп өңдеуге тым үлкен: тек оқуға ашылды.',
  'collab.invalid_message': 'Нақты уақыт арнасына қате хабарлама жіберілді.',
  'collab.file_not_found': 'Файл табылмады немесе жойылған.',
  'chat.empty': 'Хабарлама бос болмауы керек.',
  'chat.too_long': 'Хабарлама ең көбі 2000 таңба болуы керек.',
  'run.unavailable': 'Орындау қызметі қосылмаған немесе қолжетімсіз.',
  'run.language_unavailable': 'Бұл тілді орындау қолжетімсіз: {language}.',
  'run.unsupported_file': 'Бұл файл түрін іске қосуға болмайды.',
  'run.no_entry': 'Іске қосу файлы (entry point) жобада табылмады.',
  'run.too_many_active': 'Бір мезгілде орындалатын тапсырмалар шегіне жеттіңіз. Біреуі аяқталғанша күтіңіз.',
  'run.rate_limited': 'Тым жиі іске қосу. Біраз күтіңіз.',
  'run.queue_full': 'Орындау кезегі толы. Кейінірек қайталаңыз.',
  'run.project_too_large': 'Жоба орындау үшін тым үлкен.',
  'run.not_found': 'Орындау табылмады.',
  'run.sql_empty': 'SQL сұранысын енгізіңіз.',
  'run.sql_too_long': 'SQL сұранысы тым ұзын.',
  'run.not_web': 'Веб-алдын ала қарау үшін HTML файлы керек.',
  'file.too_deep': 'Қалталардың кірістіру тереңдігі шегінен асты.',
} as const;

export type ErrorCode = keyof typeof MESSAGES;

export class AppError extends Error {
  code: ErrorCode;
  status: number;
  params?: Record<string, string | number>;
  constructor(code: ErrorCode, status = 400, params?: Record<string, string | number>) {
    super(code);
    this.name = 'AppError';
    this.code = code;
    this.status = status;
    this.params = params;
  }
}

export function formatMessage(code: ErrorCode, params?: Record<string, string | number>): string {
  const tpl: string = MESSAGES[code] ?? MESSAGES.unknown;
  return tpl.replace(/\{(\w+)\}/g, (_, k: string) => String(params?.[k] ?? ''));
}
