import { createHash, createHmac, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import type { Config } from './config.ts';

const KEYLEN = 64;
const R = 8;
const P = 1;

function scryptAsync(password: string, salt: Buffer, n: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scrypt(password.normalize('NFKC'), salt, KEYLEN, { N: n, r: R, p: P, maxmem: 256 * n * R }, (err, key) => (err ? reject(err) : resolve(key)));
  });
}

/** Формат: scrypt$N$r$p$<salt b64>$<hash b64>. Параметрлер хэштің ішінде, сондықтан құнды кейін көтеруге болады. */
export async function hashPassword(password: string, cfg: Pick<Config, 'scryptN'>): Promise<string> {
  const salt = randomBytes(16);
  const key = await scryptAsync(password, salt, cfg.scryptN);
  return `scrypt$${cfg.scryptN}$${R}$${P}$${salt.toString('base64')}$${key.toString('base64')}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [alg, n, r, p, salt, hash] = stored.split('$');
  if (alg !== 'scrypt' || Number(r) !== R || Number(p) !== P) return false;
  const expected = Buffer.from(hash, 'base64');
  const actual = await scryptAsync(password, Buffer.from(salt, 'base64'), Number(n));
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

/** Пайдаланушы табылмаса да хэш есептеледі (уақыт арқылы email анықтауды қиындату үшін). */
let dummy: Promise<string> | null = null;
export async function verifyDummy(password: string, cfg: Pick<Config, 'scryptN'>): Promise<void> {
  dummy ??= hashPassword('dummy-password-for-timing', cfg);
  await verifyPassword(password, await dummy);
}

// ── Сессия токендері ──────────────────────────────────────
export const newSessionToken = () => randomBytes(32).toString('base64url');
export const sessionIdOf = (token: string) => createHash('sha256').update(token).digest('hex');

// ── Шақыру кодтары ────────────────────────────────────────
const CROCKFORD = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const INVITE_RE = /^[0-9A-HJKMNP-TV-Z]{12}$/;

export function generateInviteCode(): string {
  const bytes = randomBytes(12);
  const raw = [...bytes].map((b) => CROCKFORD[b % 32]).join(''); // 256 % 32 == 0 → қиғаштық жоқ
  return `${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8)}`;
}

export function normalizeInviteCode(input: string): string {
  return input.toUpperCase().replace(/[\s-]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
}
export const isInviteFormat = (normalized: string) => INVITE_RE.test(normalized);

/** Дерекқорда ашық код сақталмайды: тек кілтті HMAC (pepper сыртқы құпия). */
export function hashInviteCode(code: string, pepper: string): string {
  return createHmac('sha256', pepper).update(normalizeInviteCode(code)).digest('hex');
}
