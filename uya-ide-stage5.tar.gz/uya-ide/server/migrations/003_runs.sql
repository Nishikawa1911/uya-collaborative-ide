-- 5-кезең: кодты оқшауланған ортада орындау тарихы.
CREATE TABLE runs (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id       TEXT REFERENCES users(id) ON DELETE SET NULL,
  mode          TEXT NOT NULL CHECK (mode IN ('file', 'project', 'sql')),
  entry_path    TEXT NOT NULL,
  language      TEXT NOT NULL,
  status        TEXT NOT NULL CHECK (status IN ('queued', 'running', 'ok', 'error', 'compile_error', 'timeout', 'killed', 'memory_limit', 'output_limit', 'internal_error')),
  phase         TEXT,
  exit_code     INTEGER,
  signal        TEXT,
  duration_ms   INTEGER,
  stdout        TEXT NOT NULL DEFAULT '',
  stderr        TEXT NOT NULL DEFAULT '',
  build         TEXT NOT NULL DEFAULT '',
  truncated     INTEGER NOT NULL DEFAULT 0,
  message       TEXT,
  created_at    TEXT NOT NULL,
  started_at    TEXT,
  finished_at   TEXT
);
CREATE INDEX runs_project_idx ON runs(project_id, created_at);
CREATE INDEX runs_user_idx ON runs(user_id, created_at);
CREATE INDEX runs_status_idx ON runs(status);
