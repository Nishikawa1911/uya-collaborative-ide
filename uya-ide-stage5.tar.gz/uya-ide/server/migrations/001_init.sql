-- 001_init: Ұя IDE негізгі схемасы.
-- Дерекқор: SQLite (node:sqlite). Схема PostgreSQL-ге оңай көшіріледі:
--   TEXT-уақыт -> timestamptz, BLOB -> bytea, COLLATE NOCASE -> citext / lower(...) индексі.
-- Барлық кестелерде сыртқы кілттер (FOREIGN KEY) және CHECK шектеулері қосулы.

-- ───────── Пайдаланушылар ─────────
CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL COLLATE NOCASE UNIQUE,
  username      TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT NOT NULL,                       -- scrypt$N$r$p$salt$hash (ашық құпия сөз ешқашан сақталмайды)
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  last_login_at TEXT
);

-- Профиль: көрсетілетін ақпарат пен аватар (users-пен 1:1)
CREATE TABLE profiles (
  user_id        TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  display_name   TEXT NOT NULL CHECK (length(display_name) BETWEEN 1 AND 60),
  avatar_color   TEXT NOT NULL CHECK (avatar_color GLOB '#[0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F]'),
  cursor_color   TEXT NOT NULL,
  avatar_mime    TEXT CHECK (avatar_mime IN ('image/png', 'image/jpeg', 'image/webp')),
  avatar_data    BLOB,
  avatar_version INTEGER NOT NULL DEFAULT 0,
  locale         TEXT NOT NULL DEFAULT 'kk' CHECK (locale IN ('kk')),
  updated_at     TEXT NOT NULL,
  CHECK ((avatar_mime IS NULL) = (avatar_data IS NULL))
);

-- Сессиялар: кукиде кездейсоқ токен, мұнда тек оның SHA-256 хэші
CREATE TABLE sessions (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at   TEXT NOT NULL,
  expires_at   TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  ip           TEXT,
  user_agent   TEXT
);
CREATE INDEX sessions_user_idx ON sessions(user_id);
CREATE INDEX sessions_expires_idx ON sessions(expires_at);

-- Brute-force қорғанысы (кіру және шақыру коды): тұрақты санауыштар
CREATE TABLE auth_attempts (
  key          TEXT PRIMARY KEY,                     -- мысалы: login:ip:1.2.3.4, invite:user:<id>
  failures     INTEGER NOT NULL DEFAULT 0,
  first_failed TEXT,
  locked_until TEXT
);

-- ───────── Жобалар ─────────
CREATE TABLE projects (
  id          TEXT PRIMARY KEY,
  owner_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name        TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 60),
  description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 300),
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE INDEX projects_owner_idx ON projects(owner_id);

CREATE TABLE project_settings (
  project_id     TEXT PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
  languages      TEXT NOT NULL CHECK (json_valid(languages)),   -- JSON массиві: ["python","sql"]
  entry_point    TEXT NOT NULL,
  join_role      TEXT NOT NULL DEFAULT 'editor' CHECK (join_role IN ('editor', 'viewer')),
  invite_enabled INTEGER NOT NULL DEFAULT 1 CHECK (invite_enabled IN (0, 1)),
  max_members    INTEGER NOT NULL DEFAULT 50 CHECK (max_members BETWEEN 1 AND 500),
  updated_at     TEXT NOT NULL
);

CREATE TABLE project_members (
  project_id     TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role           TEXT NOT NULL CHECK (role IN ('owner', 'editor', 'viewer')),
  joined_at      TEXT NOT NULL,
  last_opened_at TEXT,
  PRIMARY KEY (project_id, user_id)
);
CREATE INDEX project_members_user_idx ON project_members(user_id);
-- Әр жобада дәл бір иесі болады
CREATE UNIQUE INDEX project_members_one_owner ON project_members(project_id) WHERE role = 'owner';

-- Шақыру кодтары: код ашық күйде сақталмайды, тек кілтті HMAC хэші
CREATE TABLE project_invitations (
  id         TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  code_hash  TEXT NOT NULL UNIQUE,
  created_by TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT,
  revoked_at TEXT,
  use_count  INTEGER NOT NULL DEFAULT 0
);
-- Бір жобада бір ғана белсенді шақыру
CREATE UNIQUE INDEX project_invitations_one_active ON project_invitations(project_id) WHERE revoked_at IS NULL;

-- ───────── Файл жүйесі ─────────
CREATE TABLE folders (
  id         TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  parent_id  TEXT,
  name       TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 255),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE (id, project_id),
  -- Ата-ана міндетті түрде сол жобада болуы керек
  FOREIGN KEY (parent_id, project_id) REFERENCES folders(id, project_id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX folders_unique_name ON folders(project_id, COALESCE(parent_id, ''), name);

CREATE TABLE files (
  id         TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  folder_id  TEXT,
  name       TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 255),
  content    TEXT NOT NULL DEFAULT '',
  size_bytes INTEGER NOT NULL DEFAULT 0,
  version    INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  updated_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  UNIQUE (id, project_id),
  FOREIGN KEY (folder_id, project_id) REFERENCES folders(id, project_id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX files_unique_name ON files(project_id, COALESCE(folder_id, ''), name);
CREATE INDEX files_project_idx ON files(project_id);
