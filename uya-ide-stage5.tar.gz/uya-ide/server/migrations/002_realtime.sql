-- 4-кезең: нақты уақытта бірлесіп жұмыс істеу.

-- Бірлескен құжат күйі: CRDT операциялары (JSON). Мәтін көшірмесі files.content ішінде де сақталады.
CREATE TABLE file_docs (
  file_id    TEXT PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
  state      TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Жоба чаты. seq — бүкіл жүйедегі өспелі нөмір (беттеу және реттілік үшін).
CREATE TABLE chat_messages (
  seq         INTEGER PRIMARY KEY AUTOINCREMENT,
  id          TEXT NOT NULL UNIQUE,
  project_id  TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id     TEXT REFERENCES users(id) ON DELETE SET NULL,
  author_name TEXT NOT NULL,
  body        TEXT NOT NULL CHECK (length(body) BETWEEN 1 AND 2000),
  created_at  TEXT NOT NULL
);
CREATE INDEX chat_messages_project_idx ON chat_messages(project_id, seq);

-- CRDT клиент идентификаторлары: жоба ішінде бірегей, пайдаланушыға тіркелген.
-- Бір пайдаланушы өз идентификаторларымен ғана операция жаза алады (жалған авторлықтан қорғау).
CREATE TABLE collab_clients (
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  client_id  INTEGER NOT NULL CHECK (client_id BETWEEN 1 AND 4194303),
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  PRIMARY KEY (project_id, client_id)
);
CREATE INDEX collab_clients_user_idx ON collab_clients(project_id, user_id);
