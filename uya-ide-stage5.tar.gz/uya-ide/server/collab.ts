/**
 * Нақты уақыт хабы: жоба бөлмелері, CRDT құжаттар, қатысу (presence), чат, файл жүйесі оқиғалары.
 * Протокол: JSON мәтін кадрлары, `{type, ...}`. Толық сипаттама — docs/kk/realtime.md.
 */
import type { IncomingMessage, Server } from 'node:http';
import type { Duplex } from 'node:stream';
import { CrdtError, MAX_CLIENT_ID, TextCRDT, diffText, validateOp, type Op, type RelPos } from '../shared/crdt.ts';
import { iso, type BusEvent, type Ctx } from './context.ts';
import { AppError, MESSAGES } from './errors.ts';
import { roleOf, type Role } from './services/access.ts';
import * as chat from './services/chat.ts';
import { parseCookies } from './http.ts';
import { sessionIdOf } from './security.ts';
import { handshake, reject, WsConn } from './ws.ts';

const MAX_PAYLOAD = 8 * 1024 * 1024;
const MAX_OPS_PER_MSG = 20_000;
const HEARTBEAT_MS = 20_000;
const DEAD_MS = 60_000;
const REVALIDATE_MS = 30_000;
const MAX_CONNS_PER_USER = 12;
const CHAT_WINDOW_MS = 10_000;
const CHAT_MAX_IN_WINDOW = 10;
const PERSIST_DEBOUNCE_MS = 400;
const PERSIST_MAX_WAIT_MS = 2_000;
const CLIENT_ID_TTL_MS = 30 * 86_400_000;

interface Sel { a: RelPos; h: RelPos }
interface Cursor { fileId: string; sels: Sel[] }

interface Conn {
  ws: WsConn;
  projectId: string;
  userId: string;
  sessionId: string;
  name: string;
  color: string;
  role: Role;
  clientId: number;
  owned: Set<number>;
  activeFileId: string | null;
  cursor: Cursor | null;
  docs: Set<string>;
  chatTimes: number[];
  presenceAt: number;
}

interface Doc {
  fileId: string;
  crdt: TextCRDT;
  subs: Set<Conn>;
  dirty: boolean;
  timer: NodeJS.Timeout | null;
  firstDirtyAt: number;
  lastEditor: string | null;
}

interface Room { projectId: string; conns: Set<Conn>; docs: Map<string, Doc> }

const isRel = (v: unknown): v is RelPos => v === null || (Array.isArray(v) && v.length === 2 && Number.isInteger(v[0]) && Number.isInteger(v[1]) && v[0] >= 1 && v[1] >= 0 && v[1] <= MAX_CLIENT_ID);

export interface Hub {
  shutdown(): void;
  /** Сынақтар үшін: ашық қосылымдар саны */
  connectionCount(projectId?: string): number;
}

export function attachCollab(opts: { ctx: Ctx; server: Server; originAllowed: (req: IncomingMessage) => boolean }): Hub {
  const { ctx, server } = opts;
  const rooms = new Map<string, Room>();
  const maxChars = Math.min(200_000, Math.floor(ctx.cfg.maxFileBytes / 3));
  const now = () => ctx.clock.now();

  const room = (id: string): Room => {
    let r = rooms.get(id);
    if (!r) { r = { projectId: id, conns: new Set(), docs: new Map() }; rooms.set(id, r); }
    return r;
  };

  // ───────── Жіберу көмекшілері ─────────
  const send = (c: Conn, msg: Record<string, unknown>) => { if (!c.ws.closed) c.ws.send(JSON.stringify(msg)); };
  const broadcast = (r: Room, msg: Record<string, unknown>, except?: Conn) => {
    const text = JSON.stringify(msg);
    for (const c of r.conns) if (c !== except && !c.ws.closed) c.ws.send(text);
  };
  const sendError = (c: Conn, code: keyof typeof MESSAGES, extra: Record<string, unknown> = {}) =>
    send(c, { type: 'error', code, message: MESSAGES[code], ...extra });

  const peerOf = (c: Conn) => ({
    clientId: c.clientId, userId: c.userId, name: c.name, color: c.color, role: c.role,
    activeFileId: c.activeFileId, cursor: c.cursor,
  });

  // ───────── Құжаттар ─────────
  const normalize = (s: string) => s.replace(/\r\n?/g, '\n');

  function loadDoc(r: Room, fileId: string): Doc | 'too_large' | null {
    const ex = r.docs.get(fileId);
    if (ex) return ex;
    const f = ctx.db.get('SELECT content FROM files WHERE id = ? AND project_id = ?', fileId, r.projectId);
    if (!f) return null;
    const saved = ctx.db.get('SELECT state FROM file_docs WHERE file_id = ?', fileId);
    let crdt: TextCRDT;
    if (saved) {
      crdt = TextCRDT.fromOps(JSON.parse(saved.state as string) as Op[], 0);
    } else {
      const text = normalize(f.content as string);
      if (text.length > maxChars) return 'too_large';
      crdt = TextCRDT.fromText(text, 0);
    }
    if (crdt.length > maxChars) return 'too_large';
    const d: Doc = { fileId, crdt, subs: new Set(), dirty: false, timer: null, firstDirtyAt: 0, lastEditor: null };
    r.docs.set(fileId, d);
    return d;
  }

  function persist(r: Room, d: Doc) {
    if (d.timer) { clearTimeout(d.timer); d.timer = null; }
    if (!d.dirty) return;
    d.dirty = false;
    const text = d.crdt.text();
    const bytes = Buffer.byteLength(text, 'utf8');
    const t = iso(now());
    try {
      ctx.db.tx(() => {
        const u = ctx.db.run('UPDATE files SET content = ?, size_bytes = ?, version = version + 1, updated_at = ?, updated_by = ? WHERE id = ? AND project_id = ?',
          text, bytes, t, d.lastEditor, d.fileId, r.projectId);
        if (u.changes === 0) return; // файл жойылған
        ctx.db.run('INSERT INTO file_docs (file_id, state, updated_at) VALUES (?, ?, ?) ON CONFLICT(file_id) DO UPDATE SET state = excluded.state, updated_at = excluded.updated_at',
          d.fileId, JSON.stringify(d.crdt.toOps()), t);
        ctx.db.run('UPDATE projects SET updated_at = ? WHERE id = ?', t, r.projectId);
      });
    } catch (e) { console.error('[collab] сақтау қатесі', e); d.dirty = true; }
  }

  function markDirty(r: Room, d: Doc, by: string | null) {
    d.lastEditor = by ?? d.lastEditor;
    if (!d.dirty) { d.dirty = true; d.firstDirtyAt = Date.now(); }
    if (d.timer) clearTimeout(d.timer);
    const wait = Math.max(0, Math.min(PERSIST_DEBOUNCE_MS, PERSIST_MAX_WAIT_MS - (Date.now() - d.firstDirtyAt)));
    d.timer = setTimeout(() => persist(r, d), wait);
    d.timer.unref();
  }

  function dropDocIfIdle(r: Room, d: Doc) {
    if (d.subs.size > 0) return;
    persist(r, d);
    r.docs.delete(d.fileId);
  }

  function unsubscribe(r: Room, c: Conn, fileId: string) {
    c.docs.delete(fileId);
    const d = r.docs.get(fileId);
    if (!d) return;
    d.subs.delete(c);
    dropDocIfIdle(r, d);
  }

  /** Операцияларды тексереді: енгізу тек иесінің идентификаторымен; өшіру — кез келген таңбаға. */
  function checkOps(c: Conn, raw: unknown, docLen: number, lenient?: TextCRDT): Op[] {
    if (!Array.isArray(raw) || raw.length > MAX_OPS_PER_MSG) throw new CrdtError('ops');
    const ops: Op[] = [];
    let added = 0;
    for (const x of raw) {
      const op = validateOp(x, maxChars);
      if (op.t === 'i') {
        if (!c.owned.has(op.k)) {
          // Толық күй жүктеуде (қайта қосылу) басқалардың таңбалары да келеді: белгілі болса елемейміз, белгісізі — қабылданбайды
          if (lenient) continue;
          throw new CrdtError('forged');
        }
        if (op.s.includes('\r') || op.s.includes('\u0000')) throw new CrdtError('chars');
        added += op.s.length;
      }
      ops.push(op);
    }
    if (docLen + added > maxChars) throw new AppError('collab.doc_too_large');
    return ops;
  }

  const canWrite = (c: Conn) => c.role === 'owner' || c.role === 'editor';

  function onDocOpen(r: Room, c: Conn, m: Record<string, unknown>) {
    const fileId = m.fileId;
    if (typeof fileId !== 'string') return sendError(c, 'collab.invalid_message');
    const d = loadDoc(r, fileId);
    if (d === null) return sendError(c, 'collab.file_not_found', { fileId });
    if (d === 'too_large') { send(c, { type: 'doc.too_large', fileId }); return; }
    // Клиенттің жергілікті күйін (офлайн кезінде жасалғандарды) біріктіру — тек жазу құқығы болса
    if (m.ops !== undefined && canWrite(c)) {
      let ops: Op[];
      try { ops = checkOps(c, m.ops, d.crdt.length, d.crdt); } catch (e) { return fail(c, e, { fileId }); }
      // Тек жаңа операцияларды қолданамыз; максимум өлшемді тексереміз
      const before = d.crdt.length;
      const changes = d.crdt.applyOps(ops);
      d.crdt.clearPending();
      if (d.crdt.length > maxChars) { /* шектен асса да деректі жоғалтпаймыз; жаңа енгізу тоқтатылады */ }
      if (changes.length || d.crdt.length !== before) {
        markDirty(r, d, c.userId);
        for (const s of d.subs) if (s !== c) send(s, { type: 'doc.ops', fileId, from: c.clientId, ops });
      }
    }
    d.subs.add(c); c.docs.add(fileId);
    send(c, { type: 'doc.state', fileId, ops: d.crdt.toOps() });
  }

  function onDocOps(r: Room, c: Conn, m: Record<string, unknown>) {
    const fileId = m.fileId;
    if (typeof fileId !== 'string' || !Number.isInteger(m.seq)) return sendError(c, 'collab.invalid_message');
    const d = r.docs.get(fileId);
    if (!d || !d.subs.has(c)) return sendError(c, 'collab.file_not_found', { fileId });
    if (!canWrite(c)) { sendError(c, 'collab.read_only', { fileId }); send(c, { type: 'doc.state', fileId, ops: d.crdt.toOps() }); return; }
    let ops: Op[];
    try { ops = checkOps(c, m.ops, d.crdt.length); } catch (e) { fail(c, e, { fileId }); send(c, { type: 'doc.state', fileId, ops: d.crdt.toOps() }); return; }
    d.crdt.applyOps(ops);
    if (d.crdt.pendingCount > 0) { // тәуелділігі жоқ операция: клиент күйі бұзылған → толық қайта синхрондау
      d.crdt.clearPending();
      send(c, { type: 'doc.resync', fileId, ops: d.crdt.toOps() });
      return;
    }
    markDirty(r, d, c.userId);
    for (const s of d.subs) if (s !== c) send(s, { type: 'doc.ops', fileId, from: c.clientId, ops });
    send(c, { type: 'doc.ack', fileId, seq: m.seq });
  }

  function fail(c: Conn, e: unknown, extra: Record<string, unknown> = {}) {
    if (e instanceof AppError) sendError(c, e.code as keyof typeof MESSAGES, extra);
    else if (e instanceof CrdtError) sendError(c, 'collab.invalid_message', extra);
    else { console.error('[collab]', e); sendError(c, 'server.internal', extra); }
  }

  function onPresence(r: Room, c: Conn, m: Record<string, unknown>) {
    const t = Date.now();
    if (t - c.presenceAt < 30) return; // тым жиі: қалдырамыз (клиент өзі де шектейді)
    c.presenceAt = t;
    let active: string | null = null;
    if (m.activeFileId != null) {
      if (typeof m.activeFileId !== 'string' || m.activeFileId.length > 64) return sendError(c, 'collab.invalid_message');
      active = m.activeFileId;
    }
    let cursor: Cursor | null = null;
    const cu = m.cursor as Record<string, unknown> | null | undefined;
    if (cu) {
      if (typeof cu.fileId !== 'string' || !Array.isArray(cu.sels) || cu.sels.length > 20) return sendError(c, 'collab.invalid_message');
      const sels: Sel[] = [];
      for (const s of cu.sels as Record<string, unknown>[]) {
        if (!s || !isRel(s.a) || !isRel(s.h)) return sendError(c, 'collab.invalid_message');
        sels.push({ a: s.a, h: s.h });
      }
      cursor = { fileId: cu.fileId, sels };
    }
    c.activeFileId = active; c.cursor = cursor;
    broadcast(r, { type: 'presence.update', peer: peerOf(c) }, c);
  }

  function onChat(r: Room, c: Conn, m: Record<string, unknown>) {
    const t = Date.now();
    c.chatTimes = c.chatTimes.filter((x) => t - x < CHAT_WINDOW_MS);
    if (c.chatTimes.length >= CHAT_MAX_IN_WINDOW) return sendError(c, 'collab.rate_limited', { clientMsgId: m.clientMsgId });
    const cid = m.clientMsgId;
    if (typeof cid !== 'string' || !/^[A-Za-z0-9_-]{8,64}$/.test(cid)) return sendError(c, 'collab.invalid_message');
    let body: string;
    try { body = chat.cleanBody(m.text); } catch (e) { return fail(c, e, { clientMsgId: cid }); }
    c.chatTimes.push(t);
    try {
      const { message, fresh } = chat.post(ctx, r.projectId, { id: c.userId, name: c.name }, body, cid);
      if (fresh) broadcast(r, { type: 'chat.message', message, clientMsgId: cid });
      else send(c, { type: 'chat.message', message, clientMsgId: cid });
    } catch (e) { fail(c, e, { clientMsgId: cid }); }
  }

  function onMessage(r: Room, c: Conn, text: string) {
    let m: Record<string, unknown>;
    try { const p = JSON.parse(text); if (!p || typeof p !== 'object' || Array.isArray(p)) throw 0; m = p; } catch { return sendError(c, 'collab.invalid_message'); }
    try {
      switch (m.type) {
        case 'hb': return;
        case 'doc.open': return onDocOpen(r, c, m);
        case 'doc.close': if (typeof m.fileId === 'string') unsubscribe(r, c, m.fileId); return;
        case 'doc.ops': return onDocOps(r, c, m);
        case 'presence': return onPresence(r, c, m);
        case 'chat.send': return onChat(r, c, m);
        default: return sendError(c, 'collab.invalid_message');
      }
    } catch (e) { fail(c, e); }
  }

  // ───────── Қосылу / ажырау ─────────
  function allocClientId(projectId: string, userId: string, want: number | null, r: Room): { id: number; owned: Set<number> } {
    return ctx.db.tx(() => {
      const t = iso(now());
      ctx.db.run('DELETE FROM collab_clients WHERE project_id = ? AND created_at < ?', projectId, iso(now() - CLIENT_ID_TTL_MS));
      let id: number | null = null;
      if (want && want > 0 && want <= MAX_CLIENT_ID) {
        const row = ctx.db.get('SELECT user_id FROM collab_clients WHERE project_id = ? AND client_id = ?', projectId, want);
        const live = [...r.conns].some((x) => x.clientId === want);
        if (row && row.user_id === userId && !live) { id = want; ctx.db.run('UPDATE collab_clients SET created_at = ? WHERE project_id = ? AND client_id = ?', t, projectId, want); }
      }
      if (id === null) {
        const max = Number(ctx.db.get('SELECT COALESCE(MAX(client_id), 0) AS m FROM collab_clients WHERE project_id = ?', projectId)!.m);
        if (max >= MAX_CLIENT_ID) throw new AppError('server.internal', 500);
        id = max + 1;
        ctx.db.run('INSERT INTO collab_clients (project_id, client_id, user_id, created_at) VALUES (?, ?, ?, ?)', projectId, id, userId, t);
      }
      const owned = new Set(ctx.db.all('SELECT client_id FROM collab_clients WHERE project_id = ? AND user_id = ?', projectId, userId).map((x) => Number(x.client_id)));
      return { id, owned };
    });
  }

  function onUpgrade(req: IncomingMessage, socket: Duplex, head: Buffer) {
    const url = new URL(req.url ?? '/', 'http://localhost');
    const m = /^\/ws\/projects\/([^/]+)$/.exec(url.pathname);
    if (!m) return reject(socket, 404, 'Not Found');
    if (!opts.originAllowed(req) || (req.headers.origin == null && req.headers['sec-fetch-site'] === 'cross-site')) return reject(socket, 403, 'Forbidden');
    const token = parseCookies(req.headers.cookie).uya_session;
    if (!token) return reject(socket, 401, 'Unauthorized');
    const sid = sessionIdOf(token);
    const s = ctx.db.get('SELECT user_id, expires_at FROM sessions WHERE id = ?', sid);
    if (!s || Date.parse(s.expires_at as string) <= now()) return reject(socket, 401, 'Unauthorized');
    const projectId = decodeURIComponent(m[1]);
    const userId = s.user_id as string;
    const role = roleOf(ctx, userId, projectId);
    if (!role) return reject(socket, 403, 'Forbidden');
    const prof = ctx.db.get('SELECT display_name, cursor_color FROM profiles WHERE user_id = ?', userId);
    if (!prof) return reject(socket, 401, 'Unauthorized');
    const r = room(projectId);
    if ([...r.conns].filter((x) => x.userId === userId).length >= MAX_CONNS_PER_USER) return reject(socket, 429, 'Too Many Requests');

    const ws = handshake(req, socket, head, MAX_PAYLOAD);
    if (!ws) return;
    const want = Number(url.searchParams.get('cid'));
    let alloc: { id: number; owned: Set<number> };
    try { alloc = allocClientId(projectId, userId, Number.isInteger(want) ? want : null, r); } catch (e) { console.error('[collab]', e); ws.close(1011, 'internal'); return; }

    const c: Conn = {
      ws, projectId, userId, sessionId: sid, name: prof.display_name as string, color: prof.cursor_color as string, role,
      clientId: alloc.id, owned: alloc.owned, activeFileId: null, cursor: null, docs: new Set(), chatTimes: [], presenceAt: 0,
    };
    r.conns.add(c);
    ws.handlers = {
      onMessage: (text) => onMessage(r, c, text),
      onClose: () => {
        if (!r.conns.delete(c)) return;
        for (const f of [...c.docs]) unsubscribe(r, c, f);
        broadcast(r, { type: 'presence.leave', clientId: c.clientId });
        if (r.conns.size === 0 && r.docs.size === 0) rooms.delete(projectId);
      },
    };
    send(c, { type: 'hello', clientId: c.clientId, userId, role, name: c.name, color: c.color, maxChars, heartbeatMs: HEARTBEAT_MS });
    send(c, { type: 'presence.snapshot', peers: [...r.conns].filter((x) => x !== c).map(peerOf) });
    broadcast(r, { type: 'presence.join', peer: peerOf(c) }, c);
  }

  server.on('upgrade', onUpgrade);

  // ───────── Оқиғалар (REST өзгерістері) ─────────
  function closeWhere(r: Room, pred: (c: Conn) => boolean, code: number, reason: string) {
    for (const c of [...r.conns]) if (pred(c)) { send(c, { type: 'kicked', reason }); c.ws.close(code, reason); }
  }

  function onBus(projectId: string, e: BusEvent) {
    const r = rooms.get(projectId);
    if (!r) return;
    switch (e.type) {
      case 'fs.created': case 'fs.renamed':
        broadcast(r, { type: 'fs.event', event: e.type === 'fs.created' ? 'created' : 'renamed', node: e.node, by: e.by }); break;
      case 'fs.deleted':
        for (const fid of e.fileIds) {
          const d = r.docs.get(fid);
          if (d) { if (d.timer) clearTimeout(d.timer); d.dirty = false; for (const s of d.subs) s.docs.delete(fid); r.docs.delete(fid); }
        }
        broadcast(r, { type: 'fs.event', event: 'deleted', id: e.id, kind: e.kind, fileIds: e.fileIds, by: e.by }); break;
      case 'member.role':
        for (const c of r.conns) if (c.userId === e.userId) { c.role = e.role; send(c, { type: 'role.changed', role: e.role }); }
        broadcast(r, { type: 'members.changed' });
        for (const c of r.conns) if (c.userId === e.userId) broadcast(r, { type: 'presence.update', peer: peerOf(c) }, c);
        break;
      case 'member.removed':
        closeWhere(r, (c) => c.userId === e.userId, 4403, 'removed');
        broadcast(r, { type: 'members.changed' }); break;
      case 'members.changed': broadcast(r, { type: 'members.changed' }); break;
      case 'project.updated': broadcast(r, { type: 'project.updated' }); break;
      case 'project.deleted':
        for (const d of r.docs.values()) { if (d.timer) clearTimeout(d.timer); d.dirty = false; }
        r.docs.clear();
        closeWhere(r, () => true, 4404, 'deleted'); break;
      default: break;
    }
  }

  /** REST сақтау: файл бірлескен құжат болса, айырмашылық CRDT операциясы ретінде қолданылады. */
  function mergeRestSave(projectId: string, fileId: string, content: string, userId: string): { version: number } | undefined {
    const r = rooms.get(projectId);
    const inMem = r?.docs.get(fileId);
    const hasRow = !inMem && ctx.db.get('SELECT 1 FROM file_docs WHERE file_id = ?', fileId);
    if (!inMem && !hasRow) return undefined;
    const rm = r ?? room(projectId);
    const d = inMem ?? loadDoc(rm, fileId);
    if (!d || d === 'too_large') return undefined;
    const target = normalize(content);
    const diff = diffText(d.crdt.text(), target);
    if (diff) {
      if (target.length > maxChars) throw new AppError('collab.doc_too_large');
      const ops: Op[] = [...d.crdt.localDelete(diff.offset, diff.deleteCount)];
      const ins = d.crdt.localInsert(diff.offset, diff.insert);
      if (ins) ops.push(ins);
      d.dirty = true; d.lastEditor = userId;
      for (const s of d.subs) send(s, { type: 'doc.ops', fileId, from: 0, ops });
    } else d.dirty = d.dirty; // өзгеріс жоқ
    d.dirty = true; d.lastEditor = userId;
    persist(rm, d);
    if (d.subs.size === 0) rm.docs.delete(fileId);
    if (rm.conns.size === 0 && rm.docs.size === 0) rooms.delete(projectId);
    return { version: Number(ctx.db.get('SELECT version FROM files WHERE id = ?', fileId)?.version ?? 1) };
  }

  function flush(projectId: string) {
    const r = rooms.get(projectId);
    if (r) for (const d of r.docs.values()) persist(r, d);
  }

  ctx.bus = { publish: onBus, mergeRestSave, flush };

  // ───────── Дыбыс беру және тексеру ─────────
  const hb = setInterval(() => {
    for (const r of rooms.values()) for (const c of [...r.conns]) {
      if (c.ws.idleMs > DEAD_MS) { c.ws.terminate(1006); continue; }
      c.ws.ping(); send(c, { type: 'hb', t: Date.now() });
    }
  }, HEARTBEAT_MS);
  hb.unref();

  const reval = setInterval(() => {
    for (const r of rooms.values()) for (const c of [...r.conns]) {
      const s = ctx.db.get('SELECT expires_at FROM sessions WHERE id = ?', c.sessionId);
      if (!s || Date.parse(s.expires_at as string) <= now()) { send(c, { type: 'kicked', reason: 'session' }); c.ws.close(4401, 'session'); continue; }
      const role = roleOf(ctx, c.userId, c.projectId);
      if (!role) { send(c, { type: 'kicked', reason: 'removed' }); c.ws.close(4403, 'removed'); continue; }
      if (role !== c.role) { c.role = role; send(c, { type: 'role.changed', role }); }
    }
  }, REVALIDATE_MS);
  reval.unref();

  return {
    connectionCount: (pid) => pid ? (rooms.get(pid)?.conns.size ?? 0) : [...rooms.values()].reduce((n, r) => n + r.conns.size, 0),
    shutdown() {
      clearInterval(hb); clearInterval(reval);
      server.off('upgrade', onUpgrade);
      for (const r of rooms.values()) {
        for (const d of r.docs.values()) persist(r, d);
        for (const c of [...r.conns]) c.ws.close(1001, 'shutdown');
      }
      rooms.clear();
    },
  };
}
