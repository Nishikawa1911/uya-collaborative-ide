import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { newProject, startEnv, type Env } from './helpers.ts';

let env: Env;
before(async () => { env = await startEnv(); });
after(async () => { await env.close(); });

async function setup(prefix: string) {
  const owner = await env.user(`${prefix}_own`);
  const editor = await env.user(`${prefix}_edi`);
  const viewer = await env.user(`${prefix}_vie`);
  const outsider = await env.user(`${prefix}_out`);
  const p = await owner.c.post('/api/projects', newProject());
  assert.equal(p.status, 201);
  const id = p.json.project.id as string;
  const join = async (u: typeof editor, role: 'editor' | 'viewer') => {
    await owner.c.patch(`/api/projects/${id}/settings`, { joinRole: role });
    const r = await u.c.post('/api/projects/join', { code: p.json.inviteCode });
    assert.equal(r.status, 200, JSON.stringify(r.json));
    return r;
  };
  return { owner, editor, viewer, outsider, id, code: p.json.inviteCode as string, join };
}

describe('жоба құру және оқу', () => {
  it('жоба құрады: иесі, баптаулар, негізгі файл (қалтамен) және шақыру коды қайтады', async () => {
    const { c, id } = await env.user('creator');
    const r = await c.post('/api/projects', newProject());
    assert.equal(r.status, 201);
    assert.match(r.json.inviteCode, /^[0-9A-HJKMNP-TV-Z]{4}-[0-9A-HJKMNP-TV-Z]{4}-[0-9A-HJKMNP-TV-Z]{4}$/);
    const p = r.json.project;
    assert.equal(p.myRole, 'owner'); assert.equal(p.ownerId, id); assert.equal(p.memberCount, 1);
    assert.deepEqual(p.languages, ['python', 'sql']); assert.equal(p.entryPoint, 'src/main.py');
    const tree = (await c.get(`/api/projects/${p.id}/tree`)).json.nodes;
    const src = tree.find((n: any) => n.name === 'src' && n.kind === 'folder');
    const main = tree.find((n: any) => n.name === 'main.py');
    assert.ok(src && main); assert.equal(main.parentId, src.id);
    const content = (await c.get(`/api/projects/${p.id}/files/${main.id}/content`)).json.content;
    assert.equal(content, 'print("Сәлем, әлем!")\n');
  });

  it('бос үлгі бос файл жасайды; шақыру коды ашық күйде сақталмайды (тек HMAC хэш)', async () => {
    const { c } = await env.user('creator2');
    const r = await c.post('/api/projects', newProject({ template: 'empty', entryPoint: 'main.go' }));
    const tree = (await c.get(`/api/projects/${r.json.project.id}/tree`)).json.nodes;
    assert.equal((await c.get(`/api/projects/${r.json.project.id}/files/${tree[0].id}/content`)).json.content, '');
    const rows = env.app.ctx.db.all('SELECT code_hash FROM project_invitations');
    const raw = r.json.inviteCode.replace(/-/g, '');
    for (const row of rows) {
      assert.match(row.code_hash, /^[0-9a-f]{64}$/);
      assert.ok(!row.code_hash.toUpperCase().includes(raw));
    }
    // дерекқор файлында да ашық код болмауы керек
    const dump = JSON.stringify(env.app.ctx.db.all('SELECT * FROM project_invitations'));
    assert.equal(dump.includes(r.json.inviteCode) || dump.includes(raw), false);
  });

  const invalid: Array<[string, Record<string, unknown>, string]> = [
    ['атау жоқ', { name: '  ' }, 'validation.project_name_required'],
    ['атау ұзын', { name: 'a'.repeat(61) }, 'validation.project_name_too_long'],
    ['сипаттама ұзын', { description: 'a'.repeat(301) }, 'validation.description_too_long'],
    ['тіл жоқ', { languages: [] }, 'validation.languages_required'],
    ['тіл жарамсыз', { languages: ['cobol'] }, 'validation.languages_invalid'],
    ['entry абсолютті жол', { entryPoint: '/etc/passwd' }, 'validation.entry_point_invalid'],
    ['entry ".." ', { entryPoint: '../x.py' }, 'validation.entry_point_invalid'],
    ['entry бос сегмент', { entryPoint: 'a//b.py' }, 'validation.entry_point_invalid'],
    ['joinRole owner', { joinRole: 'owner' }, 'validation.role_invalid'],
  ];
  for (const [name, over, code] of invalid) {
    it(`валидация: ${name}`, async () => {
      const { c } = await env.user(`v_${Math.random().toString(36).slice(2, 8)}`);
      const r = await c.post('/api/projects', newProject(over));
      assert.equal(r.status, 400); assert.equal(r.json.error.code, code);
    });
  }

  it('тізім scope: mine / shared / recent; тек өз жобалары көрінеді', async () => {
    const s = await setup('lst');
    await s.join(s.editor, 'editor');
    const mine = (await s.owner.c.get('/api/projects?scope=mine')).json.projects;
    assert.equal(mine.length, 1); assert.equal(mine[0].memberCount, 2);
    assert.equal((await s.editor.c.get('/api/projects?scope=mine')).json.projects.length, 0);
    const shared = (await s.editor.c.get('/api/projects?scope=shared')).json.projects;
    assert.equal(shared.length, 1); assert.equal(shared[0].myRole, 'editor');
    assert.equal((await s.outsider.c.get('/api/projects?scope=shared')).json.projects.length, 0);
    assert.equal((await s.owner.c.get('/api/projects?scope=bogus')).status, 400);
    const recent = (await s.editor.c.get('/api/projects?scope=recent')).json.projects;
    assert.equal(recent.length, 1);
  });

  it('қатысушы емес адам үшін жоба 404 (жоба бар екенін жасырады)', async () => {
    const s = await setup('hid');
    for (const url of [`/api/projects/${s.id}`, `/api/projects/${s.id}/tree`, `/api/projects/${s.id}/members`, `/api/projects/${s.id}/messages`]) {
      const r = await s.outsider.c.get(url);
      assert.equal(r.status, 404, url); assert.equal(r.json.error.code, 'project.not_found');
    }
    assert.equal((await s.outsider.c.get('/api/projects/doesnotexist')).status, 404);
  });

  it('жоба саны шегі (maxProjectsPerUser) сақталады', async () => {
    const e = await startEnv({ maxProjectsPerUser: 2 });
    try {
      const u = await e.user('limited');
      assert.equal((await u.c.post('/api/projects', newProject())).status, 201);
      assert.equal((await u.c.post('/api/projects', newProject())).status, 201);
      assert.equal((await u.c.post('/api/projects', newProject())).json.error.code, 'project.limit_reached');
    } finally { await e.close(); }
  });
});

describe('шақыру кодтары', () => {
  it('код арқылы қосылады, рөл — баптаудағы joinRole; регистр/сызықша/O-0 айырмасы елеусіз', async () => {
    const s = await setup('inv');
    const messy = s.code.toLowerCase().replace(/-/g, ' ').replace(/0/g, 'o').replace(/1/g, 'l');
    const r = await s.editor.c.post('/api/projects/join', { code: messy });
    assert.equal(r.status, 200);
    assert.equal(r.json.role, 'editor');
    assert.equal(r.json.project.id, s.id);
    assert.equal(r.json.project.myRole, 'editor');
  });

  it('қате код: қалған әрекеттер саны, 5-ші қатеде 15 минутқа бұғат; дұрыс код те бұғатта өтпейді', async () => {
    const s = await setup('brt');
    const left: number[] = [];
    for (let i = 0; i < 4; i++) {
      const r = await s.outsider.c.post('/api/projects/join', { code: 'AAAA-BBBB-CCCC' });
      assert.equal(r.status, 404); assert.equal(r.json.error.code, 'project.invalid_invite');
      left.push(r.json.error.params.left);
    }
    assert.deepEqual(left, [4, 3, 2, 1]);
    const fifth = await s.outsider.c.post('/api/projects/join', { code: 'AAAA-BBBB-CCCC' });
    assert.equal(fifth.status, 429); assert.equal(fifth.json.error.code, 'project.invite_rate_limited'); assert.equal(fifth.json.error.params.minutes, 15);
    assert.equal((await s.outsider.c.post('/api/projects/join', { code: s.code })).status, 429);
    env.clock.t += 16 * 60_000;
    assert.equal((await s.outsider.c.post('/api/projects/join', { code: s.code })).status, 200);
  });

  it('жарамсыз формат та сәтсіз әрекет болып саналады', async () => {
    const s = await setup('fmt');
    const r = await s.outsider.c.post('/api/projects/join', { code: 'abc' });
    assert.equal(r.json.error.code, 'project.invalid_invite');
    assert.equal((await s.outsider.c.post('/api/projects/join', {})).json.error.code, 'project.invalid_invite');
    assert.equal((await s.outsider.c.post('/api/projects/join', { code: 12345 })).json.error.code, 'project.invalid_invite');
  });

  it('IP бойынша да шектеледі: әртүрлі пайдаланушылармен brute-force тоқтатылады', async () => {
    const e = await startEnv();
    try {
      let locked = false;
      for (let i = 0; i < 40 && !locked; i++) {
        const u = await e.user(`brute${i}`);
        for (let k = 0; k < 4 && !locked; k++) {
          const r = await u.c.post('/api/projects/join', { code: 'ZZZZ-ZZZZ-ZZZZ' });
          if (r.json.error.code === 'project.invite_rate_limited') locked = true;
        }
      }
      assert.ok(locked, 'IP бұғаты іске қосылмады');
    } finally { await e.close(); }
  });

  it('қатысушы қайта қосыла алмайды (409); иесі өз жобасына қосыла алмайды', async () => {
    const s = await setup('dup');
    await s.join(s.editor, 'editor');
    assert.equal((await s.editor.c.post('/api/projects/join', { code: s.code })).json.error.code, 'project.already_member');
    assert.equal((await s.owner.c.post('/api/projects/join', { code: s.code })).json.error.code, 'project.already_member');
  });

  it('rotate: ескі код жарамсыз, жаңасы жұмыс істейді; тек иесі', async () => {
    const s = await setup('rot');
    await s.join(s.editor, 'editor');
    assert.equal((await s.editor.c.post(`/api/projects/${s.id}/invite/rotate`)).status, 403);
    assert.equal((await s.outsider.c.post(`/api/projects/${s.id}/invite/rotate`)).status, 404);
    const r = await s.owner.c.post(`/api/projects/${s.id}/invite/rotate`);
    assert.equal(r.status, 200); assert.notEqual(r.json.inviteCode, s.code);
    assert.equal((await s.outsider.c.post('/api/projects/join', { code: s.code })).json.error.code, 'project.invalid_invite');
    assert.equal((await s.outsider.c.post('/api/projects/join', { code: r.json.inviteCode })).status, 200);
    const active = env.app.ctx.db.get('SELECT COUNT(*) AS c FROM project_invitations WHERE project_id = ? AND revoked_at IS NULL', s.id)!.c;
    assert.equal(active, 1);
  });

  it('inviteEnabled=false болса, код жұмыс істемейді; maxMembers шегі сақталады', async () => {
    const s = await setup('dis');
    await s.owner.c.patch(`/api/projects/${s.id}/settings`, { inviteEnabled: false });
    assert.equal((await s.editor.c.post('/api/projects/join', { code: s.code })).json.error.code, 'project.invalid_invite');
    await s.owner.c.patch(`/api/projects/${s.id}/settings`, { inviteEnabled: true, maxMembers: 1 });
    assert.equal((await s.viewer.c.post('/api/projects/join', { code: s.code })).json.error.code, 'project.member_limit');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/settings`, { maxMembers: 0 })).json.error.code, 'validation.max_members_invalid');
  });

  it('мерзімі өткен шақыру жарамсыз', async () => {
    const s = await setup('exp');
    env.app.ctx.db.run('UPDATE project_invitations SET expires_at = ? WHERE project_id = ?', new Date(env.clock.t - 1000).toISOString(), s.id);
    assert.equal((await s.editor.c.post('/api/projects/join', { code: s.code })).json.error.code, 'project.invalid_invite');
  });
});

describe('рөлдер және қатысушыларды басқару', () => {
  it('қатысушылар тізімі тек қатысушыларға; иесі бірінші; онлайн=false (нақты уақыт жоқ)', async () => {
    const s = await setup('mem');
    await s.join(s.editor, 'editor'); await s.join(s.viewer, 'viewer');
    const r = await s.viewer.c.get(`/api/projects/${s.id}/members`);
    assert.equal(r.status, 200);
    assert.deepEqual(r.json.members.map((m: any) => m.role), ['owner', 'editor', 'viewer']);
    assert.ok(r.json.members.every((m: any) => m.online === false));
    assert.equal(JSON.stringify(r.json).includes('email'), false, 'email жария етілмеуі керек');
  });

  it('иесі рөлді өзгертеді; editor/viewer өзгерте алмайды; иесінің рөлі өзгермейді', async () => {
    const s = await setup('rol');
    await s.join(s.editor, 'editor'); await s.join(s.viewer, 'viewer');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/members/${s.viewer.id}`, { role: 'editor' })).status, 200);
    assert.equal((await s.viewer.c.get(`/api/projects/${s.id}`)).json.project.myRole, 'editor');
    assert.equal((await s.editor.c.patch(`/api/projects/${s.id}/members/${s.viewer.id}`, { role: 'viewer' })).status, 403);
    assert.equal((await s.outsider.c.patch(`/api/projects/${s.id}/members/${s.viewer.id}`, { role: 'viewer' })).status, 404);
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/members/${s.owner.id}`, { role: 'viewer' })).json.error.code, 'project.owner_immutable');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/members/${s.viewer.id}`, { role: 'owner' })).json.error.code, 'validation.role_invalid');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/members/${s.outsider.id}`, { role: 'viewer' })).json.error.code, 'project.member_not_found');
  });

  it('иесі қатысушыны шығарады; қатысушы өзі шыға алады; басқаны шығара алмайды; иесін шығаруға болмайды', async () => {
    const s = await setup('rem');
    await s.join(s.editor, 'editor'); await s.join(s.viewer, 'viewer');
    assert.equal((await s.editor.c.del(`/api/projects/${s.id}/members/${s.viewer.id}`)).status, 403);
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}/members/${s.owner.id}`)).json.error.code, 'project.owner_immutable');
    assert.equal((await s.editor.c.del(`/api/projects/${s.id}/members/${s.owner.id}`)).json.error.code, 'project.owner_immutable');
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}/members/${s.viewer.id}`)).status, 200);
    assert.equal((await s.viewer.c.get(`/api/projects/${s.id}`)).status, 404, 'шығарылған адам енді қол жеткізе алмайды');
    assert.equal((await s.editor.c.del(`/api/projects/${s.id}/members/${s.editor.id}`)).status, 200);
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/members`)).json.members.length, 1);
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}/members/${s.viewer.id}`)).json.error.code, 'project.member_not_found');
  });

  it('DB деңгейінде: жобада екінші owner болуы мүмкін емес', async () => {
    const s = await setup('own');
    await s.join(s.editor, 'editor');
    assert.throws(() => env.app.ctx.db.run("UPDATE project_members SET role = 'owner' WHERE project_id = ? AND user_id = ?", s.id, s.editor.id), /UNIQUE/);
  });
});

describe('баптаулар және жобаны жою', () => {
  it('баптауларды тек иесі оқиды/өзгертеді; өзгерістер жоба мәліметіне көрінеді', async () => {
    const s = await setup('set');
    await s.join(s.editor, 'editor');
    assert.equal((await s.editor.c.get(`/api/projects/${s.id}/settings`)).status, 403);
    assert.equal((await s.editor.c.patch(`/api/projects/${s.id}/settings`, { name: 'X' })).status, 403);
    const r = await s.owner.c.patch(`/api/projects/${s.id}/settings`, { name: 'Жаңа атау', description: 'Жаңа сипаттама', languages: ['go'], entryPoint: 'main.go', joinRole: 'viewer' });
    assert.equal(r.status, 200);
    assert.deepEqual(r.json.settings, { name: 'Жаңа атау', description: 'Жаңа сипаттама', languages: ['go'], entryPoint: 'main.go', joinRole: 'viewer', inviteEnabled: true, maxMembers: 50 });
    const p = (await s.editor.c.get(`/api/projects/${s.id}`)).json.project;
    assert.equal(p.name, 'Жаңа атау'); assert.deepEqual(p.languages, ['go']);
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/settings`, { languages: ['bogus'] })).status, 400);
  });

  it('жобаны тек иесі жояды және атауын растайды; барлық байланысты деректер жойылады', async () => {
    const s = await setup('del');
    await s.join(s.editor, 'editor');
    assert.equal((await s.editor.c.del(`/api/projects/${s.id}`, { confirmName: 'Алматы сапасы' })).status, 403);
    assert.equal((await s.outsider.c.del(`/api/projects/${s.id}`, { confirmName: 'Алматы сапасы' })).status, 404);
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}`, { confirmName: 'қате' })).json.error.code, 'project.confirm_mismatch');
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}`)).json.error.code, 'project.confirm_mismatch');
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}`, { confirmName: 'Алматы сапасы' })).status, 200);
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}`)).status, 404);
    assert.equal((await s.editor.c.get(`/api/projects/${s.id}/tree`)).status, 404);
    for (const t of ['project_members', 'project_settings', 'project_invitations', 'files', 'folders']) {
      assert.equal(env.app.ctx.db.get(`SELECT COUNT(*) AS c FROM ${t} WHERE project_id = ?`, s.id)!.c, 0, t);
    }
    assert.equal((await s.outsider.c.post('/api/projects/join', { code: s.code })).json.error.code, 'project.invalid_invite');
  });
});
