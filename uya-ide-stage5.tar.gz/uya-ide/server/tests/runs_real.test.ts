/** Backend → HTTP → runner → runc контейнері: толық тізбек, жалған нәрсесіз. Root/runc жоқ ортада өткізіледі. */
import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { chmodSync, existsSync, mkdtempSync, readdirSync, rmSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { Executor } from '../../runner/execute.ts';
import { createRunnerServer } from '../../runner/server.ts';
import { httpRunnerClient } from '../runner-client.ts';
import { newProject, startEnv, type Env } from './helpers.ts';

let can = false;
try { execFileSync('runc', ['--version'], { stdio: 'ignore' }); can = process.getuid?.() === 0; } catch { /* runc жоқ */ }
const d = can ? describe : describe.skip;

d('толық тізбек (нақты контейнер)', () => {
  let env: Env; let srv: ReturnType<typeof createRunnerServer>; const base = mkdtempSync(path.join(tmpdir(), 'uya-real-'));
  before(async () => {
    chmodSync(base, 0o711);
    const ex = new Executor({ stateDir: path.join(base, 's'), jobsDir: path.join(base, 'j'), runc: 'runc' });
    await ex.probe(['python', 'sql']);
    srv = createRunnerServer({ executor: ex, token: 'real-token-0123456789abc' });
    await new Promise<void>((r) => srv.listen(0, '127.0.0.1', r));
    const url = `http://127.0.0.1:${(srv.address() as any).port}`;
    env = await startEnv({}, { runner: httpRunnerClient(url, 'real-token-0123456789abc') });
  });
  after(async () => {
    // runner тазалауы (tmpfs unmount) аяқталғанша күтеміз — бұл да «тазалау» талабының тексеруі
    for (let i = 0; i < 100 && existsSync(path.join(base, 'j')) && readdirSync(path.join(base, 'j')).length; i++) await new Promise((r) => setTimeout(r, 100));
    assert.deepEqual(existsSync(path.join(base, 'j')) ? readdirSync(path.join(base, 'j')) : [], [], 'уақытша орталар тазаланбаған');
    await env.close(); srv.closeAllConnections(); srv.close(); rmSync(base, { recursive: true, force: true }); });

  const finish = async (c: any, pid: string, rid: string) => {
    for (let i = 0; i < 400; i++) { const g = (await c.get(`/api/projects/${pid}/runs/${rid}`)).json; if (!['queued', 'running'].includes(g.run.status)) return g; await new Promise((r) => setTimeout(r, 50)); }
    throw new Error('аяқталмады');
  };
  it('жобадағы Python файлы контейнерде орындалады, сақталмаған (CRDT-сыз) мазмұн да дұрыс', async () => {
    const u = await env.user('real1');
    const p = (await u.c.post('/api/projects', newProject())).json.project.id;
    const tree = (await u.c.get(`/api/projects/${p}/tree`)).json.nodes;
    const main = tree.find((n: any) => n.name === 'main.py');
    await u.c.put(`/api/projects/${p}/files/${main.id}/content`, { content: 'import sys\nprint("нақты:", 6*7)\nprint("err", file=sys.stderr)\nsys.exit(3)\n' });
    const r = await u.c.post(`/api/projects/${p}/runs`, { mode: 'file', fileId: main.id });
    const g = await finish(u.c, p, r.json.run.id);
    assert.equal(g.run.status, 'error'); assert.equal(g.run.exitCode, 3);
    assert.match(g.events.map((e: any) => e.chunk).join(''), /нақты: 42/);
    const saved = (await u.c.get(`/api/projects/${p}/runs/${r.json.run.id}`)).json;
    assert.ok(saved.events.some((e: any) => e.stream === 'stderr' && /err/.test(e.chunk)));
  });
  it('SQL ойын алаңы нақты оқшауланған дерекқорда', async () => {
    const u = await env.user('real2');
    const p = (await u.c.post('/api/projects', newProject())).json.project.id;
    const r = await u.c.post(`/api/projects/${p}/runs`, { mode: 'sql', sql: "CREATE TABLE t(a); INSERT INTO t VALUES (1),(2); SELECT sum(a) AS s FROM t;" });
    const g = await finish(u.c, p, r.json.run.id);
    assert.equal(g.run.status, 'ok'); assert.match(g.events.map((e: any) => e.chunk).join(''), /│ 3/);
  });
  it('шексіз цикл бас тартумен тоқтайды (killed) және runner бос қалады', async () => {
    const u = await env.user('real3');
    const p = (await u.c.post('/api/projects', newProject())).json.project.id;
    const main = (await u.c.get(`/api/projects/${p}/tree`)).json.nodes.find((n: any) => n.name === 'main.py');
    await u.c.put(`/api/projects/${p}/files/${main.id}/content`, { content: 'print("start", flush=True)\nwhile True: pass\n' });
    const r = await u.c.post(`/api/projects/${p}/runs`, { mode: 'project' });
    for (let i = 0; i < 100; i++) { const g = (await u.c.get(`/api/projects/${p}/runs/${r.json.run.id}`)).json; if (g.events.length) break; await new Promise((x) => setTimeout(x, 50)); }
    await u.c.post(`/api/projects/${p}/runs/${r.json.run.id}/cancel`);
    assert.equal((await finish(u.c, p, r.json.run.id)).run.status, 'killed');
  });
});
