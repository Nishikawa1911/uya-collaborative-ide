import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createApp, type App } from '../app.ts';
import type { Config } from '../config.ts';
import type { RunnerClient } from '../runner-client.ts';

export interface Res<T = any> { status: number; json: T; headers: Headers }

export class Client {
  cookie = '';
  base: string;
  constructor(base: string) { this.base = base; }

  async req<T = any>(method: string, url: string, body?: unknown, headers: Record<string, string> = {}): Promise<Res<T>> {
    const h: Record<string, string> = { ...headers };
    if (body !== undefined) h['content-type'] ??= 'application/json';
    if (this.cookie) h.cookie = this.cookie;
    const r = await fetch(this.base + url, { method, headers: h, body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body) });
    const set = r.headers.get('set-cookie');
    if (set) {
      const m = /^uya_session=([^;]*)/.exec(set);
      this.cookie = m && m[1] ? `uya_session=${m[1]}` : '';
    }
    const text = await r.text();
    let json: any = null;
    try { json = text ? JSON.parse(text) : null; } catch { json = text; }
    return { status: r.status, json, headers: r.headers };
  }
  get = <T = any>(u: string) => this.req<T>('GET', u);
  post = <T = any>(u: string, b: unknown = {}) => this.req<T>('POST', u, b);
  patch = <T = any>(u: string, b: unknown) => this.req<T>('PATCH', u, b);
  put = <T = any>(u: string, b: unknown) => this.req<T>('PUT', u, b);
  del = <T = any>(u: string, b?: unknown) => this.req<T>('DELETE', u, b);
}

export interface Env {
  app: App;
  base: string;
  clock: { t: number; now(): number };
  client(): Client;
  /** Тіркелген және кірген клиент. */
  user(name: string): Promise<{ c: Client; id: string; name: string }>;
  close(): Promise<void>;
  dir: string;
}

export const PASSWORD = 'Uya-demo-2026';

export async function startEnv(over: Partial<Config> = {}, opts: { dir?: string; runner?: RunnerClient | null } = {}): Promise<Env> {
  const dir = opts.dir ?? mkdtempSync(path.join(tmpdir(), 'uya-test-'));
  const clock = { t: Date.parse('2026-11-08T10:00:00Z'), now() { return this.t; } };
  const app = createApp({ clock, runner: opts.runner ?? null, config: { dbPath: path.join(dir, 'test.sqlite'), scryptN: 1024, registerPerHour: 100_000, logRequests: false, staticDir: path.join(dir, 'nodist'), ...over } });
  const port = await app.listen(0, '127.0.0.1');
  const base = `http://127.0.0.1:${port}`;
  const env: Env = {
    app, base, clock, dir,
    client: () => new Client(base),
    async user(name) {
      const c = new Client(base);
      const r = await c.post('/api/auth/register', { displayName: `Тест ${name}`, username: name, email: `${name}@example.kz`, password: PASSWORD });
      if (r.status !== 201) throw new Error(`тіркелу сәтсіз: ${JSON.stringify(r.json)}`);
      return { c, id: r.json.user.id, name };
    },
    async close() { await app.close(); if (!opts.dir) rmSync(dir, { recursive: true, force: true }); },
  };
  return env;
}

export const newProject = (overrides: Record<string, unknown> = {}) => ({
  name: 'Алматы сапасы', description: 'Сынақ жобасы', languages: ['python', 'sql'], entryPoint: 'src/main.py', joinRole: 'editor', template: 'hello', ...overrides,
});
