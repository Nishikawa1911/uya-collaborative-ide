import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { newProject, startEnv, type Client, type Env } from './helpers.ts';
import type { RunnerClient, RunnerEvent, RunnerLang } from '../runner-client.ts';

/** Басқарылатын жалған runner: нақты контейнерсіз кезек/рұқсат/күй логикасын тексеру үшін. */
class FakeRunner implements RunnerClient {
  langs: RunnerLang[] = [
    { id: 'python', label: 'Python', enabled: true }, { id: 'sql', label: 'SQL', enabled: true }, { id: 'javascript', label: 'JavaScript', enabled: true },
    { id: 'csharp', label: 'C#', enabled: false, reason: 'құрал-сайман орнатылмаған: dotnet' },
  ];
  calls: any[] = [];
  cancelled: string[] = [];
  /** id → шешуші: тест run-ды қолмен аяқтайды */
  gates = new Map<string, (e: RunnerEvent | Error) => void>();
  hold = false;
  fail = false;
  async languages() { return this.langs; }
  async run(req: any, onEvent: (e: RunnerEvent) => void, signal: AbortSignal) {
    this.calls.push(req);
    if (this.fail) throw new Error('boom');
    onEvent({ type: 'started' });
    if (!this.hold) {
      onEvent({ type: 'phase', phase: 'run' });
      onEvent({ type: 'output', stream: 'stdout', chunk: `ok:${req.entry}\n` });
      onEvent({ type: 'output', stream: 'stderr', chunk: 'warn\n' });
      onEvent({ type: 'finished', status: 'ok', exitCode: 0, signal: null, durationMs: 12, phase: 'run' });
      return;
    }
    await new Promise<void>((resolve, reject) => {
      signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true });
      this.gates.set(req.id, (e) => { if (e instanceof Error) reject(e); else { onEvent(e); resolve(); } });
    });
  }
  async cancel(id: string) { this.cancelled.push(id); }
}

const wait = async (fn: () => Promise<boolean> | boolean, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return; await new Promise((r) => setTimeout(r, 15)); } throw new Error('күту уақыты өтті'); };
async function finalRun(c: Client, pid: string, rid: string) {
  let last: any;
  await wait(async () => { last = (await c.get(`/api/projects/${pid}/runs/${rid}`)).json; return !['queued', 'running'].includes(last.run.status); });
  return last;
}

const fake = new FakeRunner();
let env: Env;
before(async () => { env = await startEnv({ runPerUserActive: 2, runConcurrency: 1, runQueueMax: 3, runPerUserPerMinute: 1000 }, { runner: fake }); });
after(async () => { await env.close(); });

async function setup(prefix: string) {
  const owner = await env.user(`${prefix}_own`);
  const editor = await env.user(`${prefix}_edi`);
  const viewer = await env.user(`${prefix}_vie`);
  const outsider = await env.user(`${prefix}_out`);
  const p = await owner.c.post('/api/projects', newProject());
  const id = p.json.project.id as string;
  for (const [u, role] of [[editor, 'editor'], [viewer, 'viewer']] as const) {
    await owner.c.patch(`/api/projects/${id}/settings`, { joinRole: role });
    assert.equal((await u.c.post('/api/projects/join', { code: p.json.inviteCode })).status, 200);
  }
  const tree = (await owner.c.get(`/api/projects/${id}/tree`)).json.nodes;
  const main = tree.find((n: any) => n.name === 'main.py');
  return { owner, editor, viewer, outsider, id, mainId: main.id as string, tree };
}

describe('орындау: рұқсаттар және сұраныс тексеру', () => {
  it('/api/runtime тіркелгенді талап етеді, тілдердің күйін көрсетеді', async () => {
    assert.equal((await env.client().get('/api/runtime')).status, 401);
    const u = await env.user('rt1');
    const r = (await u.c.get('/api/runtime')).json;
    assert.equal(r.available, true); assert.equal(r.web, true);
    assert.equal(r.languages.find((l: any) => l.id === 'csharp').enabled, false);
    assert.match(r.languages.find((l: any) => l.id === 'csharp').reason, /dotnet/);
  });
  it('файлды іске қосу: толық жоба файлдары (тәуелділіктер) және дұрыс entry runner-ге жіберіледі', async () => {
    const s = await setup('rf');
    const src = s.tree.find((n: any) => n.name === 'src');
    await s.owner.c.post(`/api/projects/${s.id}/nodes`, { kind: 'file', name: 'util.py', parentId: src.id });
    fake.calls.length = 0;
    const r = await s.editor.c.post(`/api/projects/${s.id}/runs`, { mode: 'file', fileId: s.mainId });
    assert.equal(r.status, 202, JSON.stringify(r.json));
    const fin = await finalRun(s.editor.c, s.id, r.json.run.id);
    assert.equal(fin.run.status, 'ok'); assert.equal(fin.run.exitCode, 0); assert.equal(fin.run.language, 'python');
    assert.equal(fake.calls[0].entry, 'src/main.py');
    assert.ok(fake.calls[0].files.some((f: any) => f.path === 'src/util.py') && fake.calls[0].files.some((f: any) => f.path === 'src/main.py'));
    assert.deepEqual(fin.events.map((e: any) => e.stream), ['stdout', 'stderr']);
    // polling: after өлшемі
    const part = (await s.editor.c.get(`/api/projects/${s.id}/runs/${r.json.run.id}?after=1`)).json;
    assert.equal(part.events.length, 1); assert.equal(part.events[0].stream, 'stderr');
  });
  it('жобаны іске қосу: параметрлердегі entryPoint қолданылады; entry жоқ болса — қате', async () => {
    const s = await setup('rp');
    const r = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
    assert.equal(r.status, 202);
    assert.equal((await finalRun(s.owner.c, s.id, r.json.run.id)).run.entryPath, 'src/main.py');
    await s.owner.c.patch(`/api/projects/${s.id}/settings`, { entryPoint: 'nope.py' });
    const bad = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
    assert.equal(bad.status, 400); assert.equal(bad.json.error.code, 'run.no_entry');
  });
  it('viewer іске қоса алмайды (403), қатысушы емес — 404, аутентификациясыз — 401', async () => {
    const s = await setup('rv');
    assert.equal((await s.viewer.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' })).status, 403);
    assert.equal((await s.outsider.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' })).status, 404);
    assert.equal((await env.client().post(`/api/projects/${s.id}/runs`, { mode: 'project' })).status, 401);
  });
  it('басқа қатысушының орындауын көру/тоқтату мүмкін емес; иесі көре алады', async () => {
    const s = await setup('rx');
    const r = await s.editor.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
    const rid = r.json.run.id; await finalRun(s.editor.c, s.id, rid);
    assert.equal((await s.viewer.c.get(`/api/projects/${s.id}/runs/${rid}`)).status, 404);
    assert.equal((await s.outsider.c.get(`/api/projects/${s.id}/runs/${rid}`)).status, 404);
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/runs/${rid}`)).status, 200);
    assert.equal((await s.viewer.c.get(`/api/projects/${s.id}/runs`)).json.runs.length, 0);
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/runs`)).json.runs.length, 1);
  });
  it('қолжетімсіз тіл (C#) — 409; веб файл — 400; қолдау жоқ кеңейтім — 400; жарамсыз mode — 400', async () => {
    const s = await setup('rl');
    for (const [name, code, status] of [['Program.cs', 'run.language_unavailable', 409], ['index.html', 'run.unsupported_file', 400], ['notes.txt', 'run.unsupported_file', 400]] as const) {
      const n = await s.owner.c.post(`/api/projects/${s.id}/nodes`, { kind: 'file', name });
      const r = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'file', fileId: n.json.node.id });
      assert.equal(r.status, status, name); assert.equal(r.json.error.code, code);
    }
    assert.equal((await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'hack' })).status, 400);
    assert.equal((await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'file', fileId: 'x' })).status, 404);
  });
  it('SQL ойын алаңы: ұзындық/бос тексеру, query.sql ретінде жіберіледі', async () => {
    const s = await setup('rs');
    assert.equal((await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'sql', sql: '  ' })).json.error.code, 'run.sql_empty');
    assert.equal((await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'sql', sql: 'x'.repeat(100_001) })).status, 413);
    fake.calls.length = 0;
    const r = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'sql', sql: 'SELECT 1;' });
    assert.equal(r.status, 202); await finalRun(s.owner.c, s.id, r.json.run.id);
    assert.equal(fake.calls[0].entry, 'query.sql'); assert.deepEqual(fake.calls[0].files, [{ path: 'query.sql', content: 'SELECT 1;' }]);
    assert.equal(r.json.run.mode, 'sql'); assert.equal(r.json.run.language, 'sql');
  });
});

describe('орындау: кезек, шектеулер, бас тарту', () => {
  it('concurrency=1: екінші тапсырма кезекте (queuePosition), біріншісі біткенде басталады; per-user шегі', async () => {
    const s = await setup('rq');
    fake.hold = true; fake.gates.clear();
    try {
      const a = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
      const b = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
      const c3 = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
      assert.equal(c3.status, 429); assert.equal(c3.json.error.code, 'run.too_many_active');
      await wait(() => fake.gates.has(a.json.run.id));
      const bView = (await s.owner.c.get(`/api/projects/${s.id}/runs/${b.json.run.id}`)).json.run;
      assert.equal(bView.status, 'queued'); assert.equal(bView.queuePosition, 1);
      assert.equal((await s.owner.c.get(`/api/projects/${s.id}/runs/${a.json.run.id}`)).json.run.status, 'running');
      fake.gates.get(a.json.run.id)!({ type: 'finished', status: 'ok', exitCode: 0, signal: null, durationMs: 5, phase: 'run' });
      await wait(() => fake.gates.has(b.json.run.id));
      fake.gates.get(b.json.run.id)!({ type: 'finished', status: 'error', exitCode: 3, signal: null, durationMs: 5, phase: 'run' });
      assert.equal((await finalRun(s.owner.c, s.id, b.json.run.id)).run.exitCode, 3);
    } finally { fake.hold = false; }
  });
  it('бас тарту: кезектегі — бірден killed; орындалып жатқан — runner-ге cancel + killed', async () => {
    const s = await setup('rc');
    fake.hold = true; fake.gates.clear(); fake.cancelled.length = 0;
    try {
      const a = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
      const b = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
      await wait(() => fake.gates.has(a.json.run.id));
      const cb = await s.owner.c.post(`/api/projects/${s.id}/runs/${b.json.run.id}/cancel`);
      assert.equal(cb.json.run.status, 'killed');
      assert.equal((await s.viewer?.c?.post(`/api/projects/${s.id}/runs/${a.json.run.id}/cancel`))?.status ?? 403, 404); // viewer: орындауды көрмейді
      assert.equal((await s.outsider.c.post(`/api/projects/${s.id}/runs/${a.json.run.id}/cancel`)).status, 404);
      const ca = await s.owner.c.post(`/api/projects/${s.id}/runs/${a.json.run.id}/cancel`);
      assert.ok(ca.status === 200);
      const fin = await finalRun(s.owner.c, s.id, a.json.run.id);
      assert.equal(fin.run.status, 'killed'); assert.ok(fake.cancelled.includes(a.json.run.id));
      assert.ok(!fake.gates.has(b.json.run.id), 'кезектегі тапсырма runner-ге жіберілмеуі керек');
    } finally { fake.hold = false; }
  });
  it('runner қолжетімсіз болса: internal_error (runner_unreachable), жүйе құламайды', async () => {
    const s = await setup('rz');
    fake.fail = true;
    try {
      const r = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
      const fin = await finalRun(s.owner.c, s.id, r.json.run.id);
      assert.equal(fin.run.status, 'internal_error'); assert.equal(fin.run.message, 'runner_unreachable');
    } finally { fake.fail = false; }
    const ok = await s.owner.c.post(`/api/projects/${s.id}/runs`, { mode: 'project' });
    assert.equal((await finalRun(s.owner.c, s.id, ok.json.run.id)).run.status, 'ok');
  });
  it('жиілік шегі: минутына N', async () => {
    const e2 = await startEnv({ runPerUserPerMinute: 2, runConcurrency: 4, runPerUserActive: 10 }, { runner: new FakeRunner() });
    try {
      const u = await e2.user('rate1');
      const p = (await u.c.post('/api/projects', newProject())).json.project.id;
      assert.equal((await u.c.post(`/api/projects/${p}/runs`, { mode: 'project' })).status, 202);
      assert.equal((await u.c.post(`/api/projects/${p}/runs`, { mode: 'project' })).status, 202);
      const r = await u.c.post(`/api/projects/${p}/runs`, { mode: 'project' });
      assert.equal(r.status, 429); assert.equal(r.json.error.code, 'run.rate_limited');
    } finally { await e2.close(); }
  });
  it('runner жоқ (RUNNER_URL бос): runtime.available=false, іске қосу 503 — өтірік «қосылған» жоқ', async () => {
    const e2 = await startEnv({}, { runner: null });
    try {
      const u = await e2.user('norun');
      assert.equal((await u.c.get('/api/runtime')).json.available, false);
      const p = (await u.c.post('/api/projects', newProject())).json.project.id;
      const r = await u.c.post(`/api/projects/${p}/runs`, { mode: 'project' });
      assert.equal(r.status, 503); assert.equal(r.json.error.code, 'run.unavailable');
    } finally { await e2.close(); }
  });
  it('қайта қосылғанда «жетім» queued/running тапсырмалар internal_error болады', async () => {
    const dir = (await import('node:fs')).mkdtempSync((await import('node:path')).join((await import('node:os')).tmpdir(), 'uya-orph-'));
    const f = new FakeRunner(); f.hold = true;
    const e1 = await startEnv({}, { dir, runner: f });
    const u = await e1.user('orph'); const p = (await u.c.post('/api/projects', newProject())).json.project.id;
    const r = await u.c.post(`/api/projects/${p}/runs`, { mode: 'project' });
    await wait(() => f.gates.size === 1);
    await e1.close();
    // Процесс құлағанын модельдеу: жабылғанда «killed» болып қалмауы үшін күйді қолмен «running» қыламыз
    const { DatabaseSync } = await import('node:sqlite');
    const raw = new DatabaseSync((await import('node:path')).join(dir, 'test.sqlite'));
    raw.exec(`UPDATE runs SET status = 'running', message = NULL`); raw.close();
    const e2 = await startEnv({}, { dir, runner: new FakeRunner() });
    try {
      const c = e2.client(); const l = await c.post('/api/auth/login', { identifier: 'orph@example.kz', password: 'Uya-demo-2026' });
      assert.equal(l.status, 200, JSON.stringify(l.json));
      const g = (await c.get(`/api/projects/${p}/runs/${r.json.run.id}`)).json.run;
      assert.equal(g.status, 'internal_error'); assert.equal(g.message, 'server_restart');
    } finally { await e2.close(); (await import('node:fs')).rmSync(dir, { recursive: true, force: true }); }
  });
});

describe('веб-алдын ала қарау (код орындамайды)', () => {
  let wp = 0;
  async function webProject() {
    const s = await setup('pv' + wp++);
    const p = await s.owner.c.post('/api/projects', newProject({ name: 'Веб', languages: ['html', 'css', 'javascript'], entryPoint: 'index.html', template: 'empty' }));
    const id = p.json.project.id as string;
    const mk = async (name: string, content: string, parentId: string | null = null) => {
      const n = await s.owner.c.post(`/api/projects/${id}/nodes`, { kind: 'file', name, parentId });
      if (n.status !== 201) return n.json;
      await s.owner.c.put(`/api/projects/${id}/files/${n.json.node.id}/content`, { content }); return n.json.node;
    };
    return { ...s, id, mk, projJson: p.json };
  }
  it('HTML + CSS + JS бір құжатқа біріктіріледі, CSP мен консоль көпірі енгізіледі', async () => {
    const w = await webProject();
    const tree = (await w.owner.c.get(`/api/projects/${w.id}/tree`)).json.nodes;
    const idx = tree.find((n: any) => n.name === 'index.html');
    const html = '<!doctype html><html><head><link rel="stylesheet" href="style.css"></head><body><h1>Сәлем</h1><script src="app.js"></script><script src="https://evil.example/x.js"></script></body></html>';
    if (idx) await w.owner.c.put(`/api/projects/${w.id}/files/${idx.id}/content`, { content: html }); else await w.mk('index.html', html);
    await w.mk('style.css', 'h1{color:red}');
    await w.mk('app.js', 'console.log("hi </script> x")');
    const r = await w.viewer.c.get(`/api/projects/${w.id}/preview`);
    assert.equal(r.status, 404, 'viewer басқа жоба мүшесі емес');
    await w.owner.c.patch(`/api/projects/${w.id}/settings`, { joinRole: 'viewer' });
    const out = (await w.owner.c.get(`/api/projects/${w.id}/preview`)).json;
    assert.match(out.html, /<style data-src="style.css">h1\{color:red\}<\/style>/);
    assert.match(out.html, /<script data-src="app.js">console.log\("hi <\\\/script> x"\)<\/script>/);
    assert.match(out.html, /http-equiv="Content-Security-Policy"/);
    assert.match(out.csp, /default-src 'none'/); assert.match(out.csp, /connect-src 'none'/);
    assert.deepEqual(out.external, ['https://evil.example/x.js']);
    assert.ok(out.html.indexOf('Content-Security-Policy') < out.html.indexOf('<h1>'), 'CSP құжат мазмұнынан бұрын тұруы керек');
  });
  it('қатысушы емес — 404; HTML жоқ жоба — 400; ../ арқылы шығу тыйым', async () => {
    const w = await webProject();
    assert.equal((await w.outsider.c.get(`/api/projects/${w.id}/preview`)).status, 404);
    const noHtml = await setup('pn' + wp++);
    const nf = await noHtml.owner.c.get(`/api/projects/${noHtml.id}/preview`);
    assert.equal(nf.status, 400); assert.equal(nf.json.error.code, 'run.not_web');
    const { buildPreview } = await import('../services/preview.ts');
    const out = buildPreview([{ path: 'a/index.html', content: '<html><head><link rel="stylesheet" href="../../secret.css"></head></html>' }, { path: 'secret.css', content: 'SECRET' }], 'a/index.html');
    assert.ok(!out.html.includes('SECRET'));
  });
});
