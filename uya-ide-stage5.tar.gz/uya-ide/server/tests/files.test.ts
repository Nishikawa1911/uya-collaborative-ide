import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { Client, newProject, startEnv, type Env } from './helpers.ts';

let env: Env;
before(async () => { env = await startEnv(); });
after(async () => { await env.close(); });

async function setup(prefix: string) {
  const owner = await env.user(`${prefix}_own`);
  const editor = await env.user(`${prefix}_edi`);
  const viewer = await env.user(`${prefix}_vie`);
  const outsider = await env.user(`${prefix}_out`);
  const p = await owner.c.post('/api/projects', newProject({ template: 'empty', entryPoint: 'main.py' }));
  const id = p.json.project.id as string;
  await owner.c.patch(`/api/projects/${id}/settings`, { joinRole: 'editor' });
  await editor.c.post('/api/projects/join', { code: p.json.inviteCode });
  await owner.c.patch(`/api/projects/${id}/settings`, { joinRole: 'viewer' });
  await viewer.c.post('/api/projects/join', { code: (await owner.c.post(`/api/projects/${id}/invite/rotate`)).json.inviteCode });
  const node = (c: Client, body: Record<string, unknown>) => c.post(`/api/projects/${id}/nodes`, body);
  return { owner, editor, viewer, outsider, id, node };
}

describe('файл және қалта құру', () => {
  it('қалта мен файлды (ішкі деңгейде) құрады және ағашта көрсетеді', async () => {
    const s = await setup('crt');
    const dir = await s.node(s.editor.c, { parentId: null, name: 'сынақ_қалта', kind: 'folder' });
    assert.equal(dir.status, 201);
    const file = await s.node(s.editor.c, { parentId: dir.json.node.id, name: 'Әліпби.py', kind: 'file' });
    assert.equal(file.status, 201);
    assert.equal(file.json.node.parentId, dir.json.node.id);
    const nodes = (await s.owner.c.get(`/api/projects/${s.id}/tree`)).json.nodes;
    assert.ok(nodes.some((n: any) => n.id === file.json.node.id && n.kind === 'file' && n.name === 'Әліпби.py'));
    assert.ok(nodes.some((n: any) => n.id === dir.json.node.id && n.kind === 'folder'));
  });

  it('қазақ әріптері дұрыс сақталады; атау NFC-ке келтіріледі (ұқсас таңбалар қайталанбайды)', async () => {
    const s = await setup('kaz');
    const r = await s.node(s.owner.c, { parentId: null, name: 'ӘҒҚҢӨҰҮҺІ.txt', kind: 'file' });
    assert.equal(r.json.node.name, 'ӘҒҚҢӨҰҮҺІ.txt');
    const decomposed = 'Й.txt'.normalize('NFD'), composed = 'Й.txt'.normalize('NFC');
    assert.equal((await s.node(s.owner.c, { parentId: null, name: composed, kind: 'file' })).status, 201);
    assert.equal((await s.node(s.owner.c, { parentId: null, name: decomposed, kind: 'file' })).json.error.code, 'file.exists');
  });

  it('қайталанатын атау (файл/қалта аралас) бір қалтада 409; басқа қалтада рұқсат', async () => {
    const s = await setup('dup');
    await s.node(s.owner.c, { parentId: null, name: 'a', kind: 'folder' });
    assert.equal((await s.node(s.owner.c, { parentId: null, name: 'a', kind: 'file' })).json.error.code, 'file.exists');
    assert.equal((await s.node(s.owner.c, { parentId: null, name: 'a', kind: 'folder' })).status, 409);
    const d = await s.node(s.owner.c, { parentId: null, name: 'b', kind: 'folder' });
    assert.equal((await s.node(s.owner.c, { parentId: d.json.node.id, name: 'a', kind: 'file' })).status, 201);
    assert.equal((await s.node(s.owner.c, { parentId: null, name: 'main.py', kind: 'file' })).json.error.code, 'file.exists', 'негізгі файл бұрыннан бар');
  });

  const badNames = ['', '   ', '.', '..', 'a/b', 'a\\b', 'a:b', 'a*b', 'a?b', 'a"b', 'a<b', 'a>b', 'a|b', 'a\u0000b', 'a\nb', 'x'.repeat(256), 'Ә'.repeat(128)];
  it('жарамсыз атаулар қабылданбайды (жол бөлгіштер, басқару таңбалары, ұзындық)', async () => {
    const s = await setup('nam');
    for (const name of badNames) {
      const r = await s.node(s.owner.c, { parentId: null, name, kind: 'file' });
      assert.equal(r.status, 400, JSON.stringify(name));
      assert.equal(r.json.error.code, 'file.invalid_name', JSON.stringify(name));
    }
    assert.equal((await s.node(s.owner.c, { parentId: null, name: 123, kind: 'file' })).json.error.code, 'file.invalid_name');
    assert.equal((await s.node(s.owner.c, { parentId: null, name: 'ok', kind: 'socket' })).json.error.code, 'validation.field_invalid');
    assert.equal((await s.node(s.owner.c, { parentId: null, name: 'Ә'.repeat(127), kind: 'file' })).status, 201, '254 байт — рұқсат');
  });

  it('жарамсыз ата-ана: жоқ ID, файл, басқа жобаның қалтасы', async () => {
    const s = await setup('par');
    const other = await setup('par2');
    const otherDir = (await other.node(other.owner.c, { parentId: null, name: 'secret', kind: 'folder' })).json.node.id;
    const f = (await s.node(s.owner.c, { parentId: null, name: 'f.txt', kind: 'file' })).json.node.id;
    for (const parentId of ['nonexistent', f, otherDir]) {
      const r = await s.node(s.owner.c, { parentId, name: 'x', kind: 'file' });
      assert.equal(r.status, 400, String(parentId)); assert.equal(r.json.error.code, 'file.parent_invalid');
    }
    assert.equal((await s.node(s.owner.c, { parentId: 5, name: 'x', kind: 'file' })).json.error.code, 'file.parent_invalid');
  });

  it('қалта тереңдігі және түйін саны шектелген', async () => {
    const e = await startEnv({ maxFolderDepth: 3, maxNodesPerProject: 6 });
    try {
      const u = await e.user('deep');
      const p = (await u.c.post('/api/projects', newProject({ template: 'empty', entryPoint: 'main.py' }))).json.project.id;
      let parent: string | null = null;
      const codes: number[] = [];
      for (let i = 0; i < 4; i++) {
        const r: any = await u.c.post(`/api/projects/${p}/nodes`, { parentId: parent, name: `d${i}`, kind: 'folder' });
        codes.push(r.status);
        if (r.status === 201) parent = r.json.node.id; else assert.equal(r.json.error.code, 'file.too_deep');
      }
      assert.deepEqual(codes, [201, 201, 201, 400]);
      // қазір: main.py + 3 қалта = 4; тағы 2 файл — 6, жетінші — шектен асады
      assert.equal((await u.c.post(`/api/projects/${p}/nodes`, { parentId: null, name: 'a.txt', kind: 'file' })).status, 201);
      assert.equal((await u.c.post(`/api/projects/${p}/nodes`, { parentId: null, name: 'b.txt', kind: 'file' })).status, 201);
      assert.equal((await u.c.post(`/api/projects/${p}/nodes`, { parentId: null, name: 'c.txt', kind: 'file' })).json.error.code, 'file.limit_reached');
    } finally { await e.close(); }
  });
});

describe('мазмұнды оқу және сақтау', () => {
  it('мазмұн сақталады, нұсқа артады, жоба updatedAt жаңарады; Unicode/жаңа жол сақталады', async () => {
    const s = await setup('sav');
    const f = (await s.node(s.editor.c, { parentId: null, name: 'a.py', kind: 'file' })).json.node.id;
    const before = (await s.owner.c.get(`/api/projects/${s.id}`)).json.project.updatedAt;
    env.clock.t += 60_000;
    const text = 'print("Сәлем, әлем!")\r\n# ӘҒҚҢӨҰҮҺІ 😀\n\tтаб\n';
    const r = await s.editor.c.put(`/api/projects/${s.id}/files/${f}/content`, { content: text });
    assert.equal(r.status, 200); assert.equal(r.json.version, 2);
    const got = await s.owner.c.get(`/api/projects/${s.id}/files/${f}/content`);
    assert.equal(got.json.content, text); assert.equal(got.json.version, 2);
    assert.ok((await s.owner.c.get(`/api/projects/${s.id}`)).json.project.updatedAt > before);
    assert.equal((await s.owner.c.put(`/api/projects/${s.id}/files/${f}/content`, { content: '' })).json.version, 3, 'бос мазмұн рұқсат');
  });

  it('1 МБ шегі (байтпен), NUL таңба, дұрыс емес түр', async () => {
    const e = await startEnv({ maxFileBytes: 100 });
    try {
      const u = await e.user('big');
      const p = (await u.c.post('/api/projects', newProject({ template: 'empty', entryPoint: 'm.py' }))).json.project.id;
      const f = (await u.c.get(`/api/projects/${p}/tree`)).json.nodes[0].id;
      assert.equal((await u.c.put(`/api/projects/${p}/files/${f}/content`, { content: 'a'.repeat(100) })).status, 200);
      const big = await u.c.put(`/api/projects/${p}/files/${f}/content`, { content: 'a'.repeat(101) });
      assert.equal(big.status, 413); assert.equal(big.json.error.code, 'file.too_large');
      assert.equal((await u.c.put(`/api/projects/${p}/files/${f}/content`, { content: 'ә'.repeat(51) })).json.error.code, 'file.too_large', 'ә = 2 байт');
      assert.equal((await u.c.put(`/api/projects/${p}/files/${f}/content`, { content: 'a\u0000b' })).json.error.code, 'file.invalid_content');
      assert.equal((await u.c.put(`/api/projects/${p}/files/${f}/content`, { content: 42 })).json.error.code, 'validation.field_invalid');
      assert.equal((await u.c.put(`/api/projects/${p}/files/${f}/content`, {})).status, 400);
      assert.equal((await u.c.get(`/api/projects/${p}/files/${f}/content`)).json.content, 'ә'.repeat(0) + 'a'.repeat(100), 'сәтсіз сақтау ескі мазмұнды бұзбайды');
    } finally { await e.close(); }
  });

  it('қалтаның мазмұнын оқу/жазу — қате; жоқ файл — 404', async () => {
    const s = await setup('dir');
    const d = (await s.node(s.owner.c, { parentId: null, name: 'd', kind: 'folder' })).json.node.id;
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/files/${d}/content`)).json.error.code, 'file.not_a_file');
    assert.equal((await s.owner.c.put(`/api/projects/${s.id}/files/${d}/content`, { content: 'x' })).json.error.code, 'file.not_a_file');
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/files/nope/content`)).status, 404);
    assert.equal((await s.owner.c.put(`/api/projects/${s.id}/files/nope/content`, { content: 'x' })).json.error.code, 'file.not_found');
  });
});

describe('атауын өзгерту және жою', () => {
  it('файл мен қалтаның атауы өзгереді; қайталану және жарамсыз ат тексеріледі; мазмұн сақталады', async () => {
    const s = await setup('ren');
    const f = (await s.node(s.owner.c, { parentId: null, name: 'old.txt', kind: 'file' })).json.node.id;
    await s.owner.c.put(`/api/projects/${s.id}/files/${f}/content`, { content: 'сақталған' });
    await s.node(s.owner.c, { parentId: null, name: 'taken.txt', kind: 'file' });
    const d = (await s.node(s.owner.c, { parentId: null, name: 'dir', kind: 'folder' })).json.node.id;
    const ok = await s.editor.c.patch(`/api/projects/${s.id}/nodes/${f}`, { name: 'new.txt' });
    assert.equal(ok.status, 200); assert.equal(ok.json.node.name, 'new.txt'); assert.equal(ok.json.node.kind, 'file');
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/files/${f}/content`)).json.content, 'сақталған');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/nodes/${f}`, { name: 'taken.txt' })).json.error.code, 'file.exists');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/nodes/${f}`, { name: 'a/b' })).json.error.code, 'file.invalid_name');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/nodes/${f}`, { name: 'new.txt' })).status, 200, 'өз атына қайта ауыстыру — қате емес');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/nodes/${d}`, { name: 'dir2' })).json.node.kind, 'folder');
    assert.equal((await s.owner.c.patch(`/api/projects/${s.id}/nodes/nope`, { name: 'x' })).status, 404);
  });

  it('қалтаны жою ішіндегі барлығын жояды (каскад), ағаштан жоғалады', async () => {
    const s = await setup('cas');
    const a = (await s.node(s.owner.c, { parentId: null, name: 'a', kind: 'folder' })).json.node.id;
    const b = (await s.node(s.owner.c, { parentId: a, name: 'b', kind: 'folder' })).json.node.id;
    const f = (await s.node(s.owner.c, { parentId: b, name: 'f.txt', kind: 'file' })).json.node.id;
    assert.equal((await s.editor.c.del(`/api/projects/${s.id}/nodes/${a}`)).status, 200);
    const names = (await s.owner.c.get(`/api/projects/${s.id}/tree`)).json.nodes.map((n: any) => n.name);
    assert.deepEqual(names, ['main.py']);
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/files/${f}/content`)).status, 404);
    assert.equal(env.app.ctx.db.get('SELECT COUNT(*) AS c FROM files WHERE id = ?', f)!.c, 0);
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}/nodes/${a}`)).status, 404, 'қайта жою — 404');
  });
});

describe('рұқсаттар', () => {
  it('viewer тек оқиды: жазу, құру, атын өзгерту, жою — 403', async () => {
    const s = await setup('vie');
    const f = (await s.node(s.owner.c, { parentId: null, name: 'f.txt', kind: 'file' })).json.node.id;
    assert.equal((await s.viewer.c.get(`/api/projects/${s.id}/tree`)).status, 200);
    assert.equal((await s.viewer.c.get(`/api/projects/${s.id}/files/${f}/content`)).status, 200);
    assert.equal((await s.viewer.c.put(`/api/projects/${s.id}/files/${f}/content`, { content: 'x' })).status, 403);
    assert.equal((await s.node(s.viewer.c, { parentId: null, name: 'n', kind: 'file' })).status, 403);
    assert.equal((await s.viewer.c.patch(`/api/projects/${s.id}/nodes/${f}`, { name: 'z' })).status, 403);
    assert.equal((await s.viewer.c.del(`/api/projects/${s.id}/nodes/${f}`)).json.error.code, 'permission.denied');
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/files/${f}/content`)).json.content, '', 'мазмұн өзгермеді');
  });

  it('қатысушы емес адам ештеңе істей алмайды (404), қатысушы рөлі төмендетілсе, құқық бірден өзгереді', async () => {
    const s = await setup('out');
    const f = (await s.node(s.owner.c, { parentId: null, name: 'f.txt', kind: 'file' })).json.node.id;
    const o = s.outsider.c;
    assert.equal((await o.get(`/api/projects/${s.id}/files/${f}/content`)).status, 404);
    assert.equal((await o.put(`/api/projects/${s.id}/files/${f}/content`, { content: 'x' })).status, 404);
    assert.equal((await s.node(o, { parentId: null, name: 'n', kind: 'file' })).status, 404);
    assert.equal((await o.patch(`/api/projects/${s.id}/nodes/${f}`, { name: 'z' })).status, 404);
    assert.equal((await o.del(`/api/projects/${s.id}/nodes/${f}`)).status, 404);
    assert.equal((await s.editor.c.put(`/api/projects/${s.id}/files/${f}/content`, { content: 'ok' })).status, 200);
    await s.owner.c.patch(`/api/projects/${s.id}/members/${s.editor.id}`, { role: 'viewer' });
    assert.equal((await s.editor.c.put(`/api/projects/${s.id}/files/${f}/content`, { content: 'late' })).status, 403);
  });

  it('жобалар арасындағы изоляция: бір жобаның node ID-і екіншісінің URL-інде жұмыс істемейді', async () => {
    const a = await setup('isoa');
    const b = await setup('isob');
    const fa = (await a.node(a.owner.c, { parentId: null, name: 'secret.txt', kind: 'file' })).json.node.id;
    await a.owner.c.put(`/api/projects/${a.id}/files/${fa}/content`, { content: 'құпия' });
    // b иесі өз жобасының URL-імен a файлына қол жеткізуге тырысады
    assert.equal((await b.owner.c.get(`/api/projects/${b.id}/files/${fa}/content`)).status, 404);
    assert.equal((await b.owner.c.put(`/api/projects/${b.id}/files/${fa}/content`, { content: 'hack' })).status, 404);
    assert.equal((await b.owner.c.patch(`/api/projects/${b.id}/nodes/${fa}`, { name: 'hacked' })).status, 404);
    assert.equal((await b.owner.c.del(`/api/projects/${b.id}/nodes/${fa}`)).status, 404);
    assert.equal((await a.owner.c.get(`/api/projects/${a.id}/files/${fa}/content`)).json.content, 'құпия');
  });

  it('DB деңгейінде: басқа жобаның қалтасына файл қосу сыртқы кілтпен тыйым салынған', async () => {
    const a = await setup('fka');
    const b = await setup('fkb');
    const dir = (await a.node(a.owner.c, { parentId: null, name: 'd', kind: 'folder' })).json.node.id;
    assert.throws(() => env.app.ctx.db.run(
      "INSERT INTO files (id, project_id, folder_id, name, created_at, updated_at) VALUES ('x', ?, ?, 'x', 'n', 'n')", b.id, dir), /FOREIGN KEY/);
  });

  it('SQL injection және ерекше таңбалар қауіпсіз өңделеді', async () => {
    const s = await setup('sql');
    const evil = "'; DROP TABLE files; --";
    const r = await s.node(s.owner.c, { parentId: null, name: evil, kind: 'file' });
    assert.equal(r.status, 201);
    assert.equal(r.json.node.name, evil);
    assert.equal((await s.owner.c.get(`/api/projects/${s.id}/tree`)).status, 200);
    assert.equal((await s.owner.c.get(`/api/projects/${encodeURIComponent("x' OR '1'='1")}`)).status, 404);
    assert.equal((await s.owner.c.get("/api/projects?scope=mine'%20OR%201=1")).status, 400);
  });
});
