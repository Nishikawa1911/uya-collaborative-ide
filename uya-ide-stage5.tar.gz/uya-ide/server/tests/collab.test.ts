import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { startEnv, newProject, type Env } from './helpers.ts';
import { connectWs, type TestWs } from './wsclient.ts';

let env: Env;
before(async () => { env = await startEnv(); });
after(async () => { await env.close(); });

let n = 0;
const uniq = () => `u${Date.now().toString(36)}${n++}`;

async function setup() {
  const owner = await env.user(uniq());
  const editor = await env.user(uniq());
  const viewer = await env.user(uniq());
  const outsider = await env.user(uniq());
  const p = await owner.c.post('/api/projects', newProject());
  assert.equal(p.status, 201);
  const id = p.json.project.id as string;
  const join = async (u: typeof editor, role: 'editor' | 'viewer') => {
    await owner.c.patch(`/api/projects/${id}/settings`, { joinRole: role });
    assert.equal((await u.c.post('/api/projects/join', { code: p.json.inviteCode })).status, 200);
  };
  await join(editor, 'editor'); await join(viewer, 'viewer');
  const tree = (await owner.c.get(`/api/projects/${id}/tree`)).json.nodes as any[];
  const file = tree.find((x) => x.kind === 'file')!;
  return { owner, editor, viewer, outsider, id, fileId: file.id as string, fileName: file.name as string };
}

const connect = async (base: string, id: string, u: { c: { cookie: string } }, extra: { origin?: string; cid?: number } = {}): Promise<TestWs> => {
  const r = await connectWs(base, id, { cookie: u.c.cookie, ...extra });
  assert.ok(r.ok, `қосылу сәтсіз: ${JSON.stringify(r)}`);
  return r.ws;
};
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

describe('WS: рұқсат', () => {
  it('cookie жоқ — 401; қатысушы емес — 403; бөтен Origin — 403; жоба жоқ — 403; қатысушы — 101', async () => {
    const s = await setup();
    assert.deepEqual(await connectWs(env.base, s.id, {}), { ok: false, status: 401 });
    assert.deepEqual(await connectWs(env.base, s.id, { cookie: 'uya_session=bad' }), { ok: false, status: 401 });
    assert.deepEqual(await connectWs(env.base, s.id, { cookie: s.outsider.c.cookie }), { ok: false, status: 403 });
    assert.deepEqual(await connectWs(env.base, 'no-such', { cookie: s.owner.c.cookie }), { ok: false, status: 403 });
    assert.deepEqual(await connectWs(env.base, s.id, { cookie: s.owner.c.cookie, origin: 'https://evil.example' }), { ok: false, status: 403 });
    const ok = await connectWs(env.base, s.id, { cookie: s.owner.c.cookie, origin: env.base });
    assert.ok(ok.ok); ok.ok && ok.ws.close();
  });

  it('шығарылған қатысушының сессиясы бұрынғы жоба үшін қосыла алмайды; шығарылғанда қосылым 4403-пен жабылады', async () => {
    const s = await setup();
    const ws = await connect(env.base, s.id, s.editor);
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}/members/${s.editor.id}`)).status, 200);
    assert.equal(await ws.waitClosed(), 4403);
    assert.deepEqual(await connectWs(env.base, s.id, { cookie: s.editor.c.cookie }), { ok: false, status: 403 });
  });

  it('қате хабарламалар қосылымды құлатпайды; бинарлық кадр — 1003', async () => {
    const s = await setup();
    const ws = await connect(env.base, s.id, s.owner);
    ws.socket.write(Buffer.from([0x81, 0x80 | 3, 0, 0, 0, 0, 0x7b, 0x7d, 0x00])); // мәтін емес JSON
    await ws.waitFor((m) => m.type === 'error' && m.code === 'collab.invalid_message');
    ws.send({ type: 'unknown' });
    ws.send({ type: 'doc.open', fileId: 5 });
    ws.send({ type: 'doc.ops', fileId: s.fileId, seq: 1, ops: [{ t: 'x' }] });
    await sleep(100);
    ws.send({ type: 'hb' });
    await ws.open(s.fileId); // әлі жұмыс істейді
    ws.sendRaw(2, Buffer.from('x'));
    assert.equal(await ws.waitClosed(), 1003);
  });
});

describe('WS: құжаттарды бірлесіп өңдеу', () => {
  it('3 қолданушы: параллель теру — ешкімнің өзгерісі өшпейді, бәрі бірдей мәтінге келеді', async () => {
    const s = await setup();
    const [a, b, v] = await Promise.all([connect(env.base, s.id, s.owner), connect(env.base, s.id, s.editor), connect(env.base, s.id, s.viewer)]);
    const base = (await a.open(s.fileId)).text();
    await b.open(s.fileId); await v.open(s.fileId);
    // Бір мезетте, бір күйден: екеуі де басына және соңына жазады
    await Promise.all([
      a.edit(s.fileId, 0, 0, 'A1|', true), b.edit(s.fileId, 0, 0, 'B1|', true),
    ]);
    await Promise.all([
      a.edit(s.fileId, a.docs.get(s.fileId)!.length, 0, '|A2', true), b.edit(s.fileId, b.docs.get(s.fileId)!.length, 0, '|B2', true),
    ]);
    await sleep(100);
    const ta = a.text(s.fileId), tb = b.text(s.fileId), tv = v.text(s.fileId);
    assert.equal(ta, tb); assert.equal(ta, tv);
    for (const x of ['A1|', 'B1|', '|A2', '|B2']) assert.ok(ta.includes(x), x);
    assert.ok(ta.includes(base));
  });

  it('viewer жаза алмайды: read_only қатесі, күй өзгермейді; viewer құжатты көре алады', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    const v = await connect(env.base, s.id, s.viewer);
    await a.open(s.fileId); const vd = await v.open(s.fileId);
    const before = vd.text();
    const ops = vd.localInsert(0, 'HACK')!;
    v.send({ type: 'doc.ops', fileId: s.fileId, seq: 1, ops: [ops] });
    await v.waitFor((m) => m.type === 'error' && m.code === 'collab.read_only');
    await sleep(100);
    assert.equal(a.text(s.fileId), before);
    // viewer офлайн жергілікті ops-ты doc.open арқылы да енгізе алмайды
    const v2 = await connect(env.base, s.id, s.viewer);
    const d2 = await v2.open(s.fileId, [ops]);
    assert.equal(d2.text().includes('HACK'), false); // viewer-дің жүктегені елеусіз қалады
    await sleep(100);
    assert.equal(a.text(s.fileId), before);
  });

  it('жалған авторлық: басқа пайдаланушының clientId-імен енгізу қабылданбайды', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    const b = await connect(env.base, s.id, s.editor);
    await a.open(s.fileId); await b.open(s.fileId);
    const before = b.text(s.fileId);
    a.send({ type: 'doc.ops', fileId: s.fileId, seq: 1, ops: [{ t: 'i', c: 9999, k: b.hello.clientId, rc: 0, rk: 0, s: 'FORGED' }] });
    await a.waitFor((m) => m.type === 'error' && m.code === 'collab.invalid_message');
    await sleep(100);
    assert.equal(b.text(s.fileId), before);
    // \r және NUL таңбалары қабылданбайды
    a.send({ type: 'doc.ops', fileId: s.fileId, seq: 2, ops: [{ t: 'i', c: 9999, k: a.hello.clientId, rc: 0, rk: 0, s: 'a\rb' }] });
    await a.waitFor((m) => m.type === 'error' && m.code === 'collab.invalid_message', 3000, 3);
  });

  it('ref-і жоқ операция (бұзылған клиент): doc.resync, сервер құжаты зақымданбайды', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    await a.open(s.fileId);
    a.send({ type: 'doc.ops', fileId: s.fileId, seq: 1, ops: [{ t: 'i', c: 5000, k: a.hello.clientId, rc: 4999, rk: 77, s: 'x' }] });
    const r = await a.of('doc.resync');
    assert.ok(Array.isArray(r.ops));
  });

  it('деректер дерекқорға түседі: files.content, file_docs; REST арқылы оқуға болады', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.editor);
    const d = await a.open(s.fileId);
    await a.edit(s.fileId, d.length, 0, '\n# қазақша 😀 жол');
    await sleep(900);
    const r = await s.owner.c.get(`/api/projects/${s.id}/files/${s.fileId}/content`);
    assert.ok(r.json.content.endsWith('# қазақша 😀 жол'));
    const row = env.app.ctx.db.get('SELECT state FROM file_docs WHERE file_id = ?', s.fileId);
    assert.ok(row);
  });

  it('REST сақтау ашық құжатты ЖОҒАЛТПАЙДЫ: ағымдағы CRDT-мен біріктіріледі және таратылады', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.editor);
    const d = await a.open(s.fileId);
    await a.edit(s.fileId, 0, 0, 'LIVE|');
    const rest = (await s.owner.c.get(`/api/projects/${s.id}/files/${s.fileId}/content`)).json.content as string; // ескі көшірме (LIVE| жоқ болуы мүмкін)
    // Біреу ескі көшірмені REST-пен сақтайды, ал a әлі 'LIVE|' енгізген
    const stale = rest.replace('LIVE|', '') + '\n# rest';
    const w = await s.owner.c.put(`/api/projects/${s.id}/files/${s.fileId}/content`, { content: stale });
    assert.equal(w.status, 200);
    // CRDT диффі: тек айырмашылық қолданылады, 'LIVE|' енгізуі, ол ескі көшірмеде болмаса да, ... (diff оны өшіреді, себебі REST күйі «мақсат»)
    await sleep(100);
    const t = a.text(s.fileId);
    assert.equal(t, stale);
    assert.equal(d.text(), stale);
  });

  it('сервер қайта қосылғанда құжат күйі сақталады', async () => {
    const dir = (await import('node:fs')).mkdtempSync((await import('node:path')).join((await import('node:os')).tmpdir(), 'uya-restart-'));
    let e2 = await startEnv({}, { dir });
    const owner = await e2.user(uniq());
    const p = await owner.c.post('/api/projects', newProject());
    const id = p.json.project.id;
    const fileId = ((await owner.c.get(`/api/projects/${id}/tree`)).json.nodes as any[]).find((x) => x.kind === 'file').id;
    const ws = await connect(e2.base, id, owner);
    await ws.open(fileId);
    await ws.edit(fileId, 0, 0, 'PERSIST|');
    const clientId = ws.hello.clientId;
    await e2.app.close(); // shutdown() flush жасайды
    const e3 = await startEnv({}, { dir });
    const o2 = e3.client();
    assert.equal((await o2.post('/api/auth/login', { identifier: `${owner.name}@example.kz`, password: 'Uya-demo-2026' })).status, 200);
    const ws2 = await connect(e3.base, id, { c: o2 }, { cid: clientId });
    assert.equal(ws2.hello.clientId, clientId); // клиент идентификаторы қалпына келді
    const d = await ws2.open(fileId);
    assert.ok(d.text().startsWith('PERSIST|'));
    await e3.app.close();
  });
});

describe('WS: қайта қосылу', () => {
  it('офлайн жасалған өзгерістер қайта қосылғанда біріктіріледі; басқалардікі сақталады', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    const b = await connect(env.base, s.id, s.editor);
    await a.open(s.fileId); const bd = await b.open(s.fileId);
    // b ажырайды, офлайн өңдейді
    const cid = b.hello.clientId;
    b.kill();
    await sleep(150);
    const offline = bd.localReplace(0, 0, 'OFFLINE|');
    // осы уақытта a өңдейді
    await a.edit(s.fileId, a.docs.get(s.fileId)!.length, 0, '|ONLINE');
    // b қайта қосылады (бірдей clientId), жергілікті күйін жібереді
    const b2 = await connect(env.base, s.id, s.editor, { cid });
    assert.equal(b2.hello.clientId, cid);
    b2.docs.set(s.fileId, bd);
    const merged = await b2.open(s.fileId, bd.toOps());
    void offline;
    await sleep(100);
    const ta = a.text(s.fileId);
    assert.equal(merged.text(), ta);
    assert.ok(ta.startsWith('OFFLINE|') && ta.endsWith('|ONLINE'));
  });

  it('бірдей clientId-ді екі қосылым қолдана алмайды; басқа пайдаланушының id-ін алу мүмкін емес', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    const a2 = await connect(env.base, s.id, s.owner, { cid: a.hello.clientId });
    assert.notEqual(a2.hello.clientId, a.hello.clientId);
    const e = await connect(env.base, s.id, s.editor, { cid: a.hello.clientId });
    assert.notEqual(e.hello.clientId, a.hello.clientId);
  });
});

describe('WS: presence', () => {
  it('snapshot, белсенді файл, курсор, шығу', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    const b = await connect(env.base, s.id, s.editor);
    const snap = await b.of('presence.snapshot');
    assert.equal(snap.peers.length, 1); assert.equal(snap.peers[0].userId, s.owner.id);
    await a.of('presence.join');
    b.send({ type: 'presence', activeFileId: s.fileId, cursor: { fileId: s.fileId, sels: [{ a: [3, 1], h: [5, 1] }] } });
    const up = await a.waitFor((m) => m.type === 'presence.update' && m.peer.activeFileId === s.fileId);
    assert.deepEqual(up.peer.cursor.sels[0], { a: [3, 1], h: [5, 1] });
    assert.equal(up.peer.userId, s.editor.id);
    await sleep(60);
    b.send({ type: 'presence', activeFileId: 'x'.repeat(100) });
    await b.waitFor((m) => m.type === 'error');
    b.kill();
    const left = await a.of('presence.leave');
    assert.equal(left.clientId, b.hello.clientId);
  });
});

describe('WS: чат', () => {
  it('хабарлама дерекқорға жазылады және бәріне таралады; тарих беттеледі', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    const v = await connect(env.base, s.id, s.viewer); // viewer де жаза алады
    for (let i = 1; i <= 5; i++) a.send({ type: 'chat.send', text: ` Сәлем ${i} `, clientMsgId: `msg-aaaa-000${i}` });
    const got = await v.waitFor((m) => m.type === 'chat.message' && m.message.body === 'Сәлем 5');
    assert.equal(got.message.userId, s.owner.id);
    v.send({ type: 'chat.send', text: 'Viewer жазды', clientMsgId: 'viewer-msg-0001' });
    await a.waitFor((m) => m.type === 'chat.message' && m.message.body === 'Viewer жазды');
    const rows = env.app.ctx.db.all('SELECT body FROM chat_messages WHERE project_id = ? ORDER BY seq', s.id);
    assert.equal(rows.length, 6);
    const h1 = (await s.editor.c.get(`/api/projects/${s.id}/messages?limit=4`)).json;
    assert.equal(h1.messages.length, 4); assert.equal(h1.hasMore, true);
    assert.equal(h1.messages[3].body, 'Viewer жазды');
    const h2 = (await s.editor.c.get(`/api/projects/${s.id}/messages?limit=4&before=${h1.messages[0].seq}`)).json;
    assert.equal(h2.messages.length, 2); assert.equal(h2.hasMore, false);
    assert.deepEqual(h2.messages.map((m: any) => m.body), ['Сәлем 1', 'Сәлем 2']);
    // қатысушы емес тарихты көре алмайды
    assert.equal((await s.outsider.c.get(`/api/projects/${s.id}/messages`)).status, 404);
  });

  it('қайта жіберу (бірдей clientMsgId) қайталамайды; бос/ұзын/жиі хабарлама қабылданбайды', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    a.send({ type: 'chat.send', text: 'бір рет', clientMsgId: 'dedupe-0001' });
    await a.of('chat.message');
    a.send({ type: 'chat.send', text: 'бір рет', clientMsgId: 'dedupe-0001' });
    await sleep(150);
    assert.equal(env.app.ctx.db.get('SELECT COUNT(*) AS c FROM chat_messages WHERE project_id = ?', s.id)!.c, 1);
    a.send({ type: 'chat.send', text: '   ', clientMsgId: 'empty-00001' });
    await a.waitFor((m) => m.type === 'error' && m.code === 'chat.empty');
    a.send({ type: 'chat.send', text: 'ә'.repeat(2001), clientMsgId: 'long-000001' });
    await a.waitFor((m) => m.type === 'error' && m.code === 'chat.too_long');
    for (let i = 0; i < 12; i++) a.send({ type: 'chat.send', text: `x${i}`, clientMsgId: `flood-${i}-0000` });
    await a.waitFor((m) => m.type === 'error' && m.code === 'collab.rate_limited');
  });
});

describe('WS: файл жүйесі синхроны', () => {
  it('құру, атын өзгерту, жою — барлық қатысушыға дереу жетеді; жойылған құжат жабылады', async () => {
    const s = await setup();
    const a = await connect(env.base, s.id, s.owner);
    const b = await connect(env.base, s.id, s.viewer);
    const created = (await s.owner.c.post(`/api/projects/${s.id}/nodes`, { kind: 'file', name: 'new.py', parentId: null })).json.node;
    const ev = await b.waitFor((m) => m.type === 'fs.event' && m.event === 'created');
    assert.equal(ev.node.id, created.id); assert.equal(ev.node.name, 'new.py');
    await s.owner.c.patch(`/api/projects/${s.id}/nodes/${created.id}`, { name: 'renamed.py' });
    const rn = await b.waitFor((m) => m.type === 'fs.event' && m.event === 'renamed');
    assert.equal(rn.node.name, 'renamed.py');
    await b.open(created.id); await a.open(created.id);
    await a.edit(created.id, 0, 0, 'print(1)');
    await s.owner.c.del(`/api/projects/${s.id}/nodes/${created.id}`);
    const del = await b.waitFor((m) => m.type === 'fs.event' && m.event === 'deleted');
    assert.deepEqual(del.fileIds, [created.id]);
    // Қалтаны жою: ішіндегі файлдар тізімі
    const folder = (await s.owner.c.post(`/api/projects/${s.id}/nodes`, { kind: 'folder', name: 'pkg', parentId: null })).json.node;
    const f1 = (await s.owner.c.post(`/api/projects/${s.id}/nodes`, { kind: 'file', name: 'a.py', parentId: folder.id })).json.node;
    await s.owner.c.del(`/api/projects/${s.id}/nodes/${folder.id}`);
    const del2 = await b.waitFor((m) => m.type === 'fs.event' && m.event === 'deleted' && m.id === folder.id);
    assert.deepEqual(del2.fileIds, [f1.id]);
    // жойылған файлды ашу — қате
    b.send({ type: 'doc.open', fileId: created.id });
    await b.waitFor((m) => m.type === 'error' && m.code === 'collab.file_not_found');
    // viewer REST арқылы файл құра алмайды — оқиға жоқ
    const before = b.log.length;
    assert.equal((await s.viewer.c.post(`/api/projects/${s.id}/nodes`, { kind: 'file', name: 'v.py', parentId: null })).status, 403);
    await sleep(100); assert.equal(b.log.slice(before).filter((m) => m.type === 'fs.event').length, 0);
  });

  it('рөл өзгерсе — role.changed, жазу бірден тоқтайды; жоба жойылса — 4404', async () => {
    const s = await setup();
    const e = await connect(env.base, s.id, s.editor);
    const d = await e.open(s.fileId);
    await e.edit(s.fileId, 0, 0, 'ok|');
    await s.owner.c.patch(`/api/projects/${s.id}/members/${s.editor.id}`, { role: 'viewer' });
    const rc = await e.of('role.changed'); assert.equal(rc.role, 'viewer');
    const ops = d.localInsert(0, 'no|')!;
    e.send({ type: 'doc.ops', fileId: s.fileId, seq: 99, ops: [ops] });
    await e.waitFor((m) => m.type === 'error' && m.code === 'collab.read_only');
    const name = (await s.owner.c.get(`/api/projects/${s.id}`)).json.project.name;
    assert.equal((await s.owner.c.del(`/api/projects/${s.id}`, { confirmName: name })).status, 200);
    assert.equal(await e.waitClosed(), 4404);
  });
});
