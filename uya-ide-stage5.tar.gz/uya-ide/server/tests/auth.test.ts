import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { PASSWORD, startEnv, type Env } from './helpers.ts';

let env: Env;
before(async () => { env = await startEnv(); });
after(async () => { await env.close(); });

const reg = (over: Record<string, unknown> = {}) => ({ displayName: 'Айгерім Сейтқазы', username: 'aigerim_s', email: 'aigerim.s@example.kz', password: PASSWORD, ...over });

describe('тіркелу', () => {
  it('жарамды деректермен тіркеледі, сессия кукиін қояды және құпия сөзді қайтармайды', async () => {
    const c = env.client();
    const r = await c.post('/api/auth/register', reg());
    assert.equal(r.status, 201);
    assert.equal(r.json.user.username, 'aigerim_s');
    assert.equal(r.json.user.displayName, 'Айгерім Сейтқазы');
    assert.equal(r.json.user.locale, 'kk');
    assert.equal(JSON.stringify(r.json).includes('password'), false);
    const cookie = r.headers.get('set-cookie')!;
    assert.match(cookie, /HttpOnly/);
    assert.match(cookie, /SameSite=Lax/);
    const me = await c.get('/api/me');
    assert.equal(me.status, 200);
    assert.equal(me.json.user.email, 'aigerim.s@example.kz');
  });

  it('құпия сөз хэші scrypt форматында сақталады, ашық мәтін жоқ', () => {
    const row = env.app.ctx.db.get('SELECT password_hash FROM users WHERE username = ?', 'aigerim_s')!;
    assert.match(row.password_hash, /^scrypt\$\d+\$8\$1\$/);
    assert.equal(row.password_hash.includes(PASSWORD), false);
  });

  it('қайталанатын email мен username қабылданбайды (регистрге тәуелсіз)', async () => {
    const a = await env.client().post('/api/auth/register', reg({ username: 'other_user' }));
    assert.equal(a.status, 409);
    assert.equal(a.json.error.code, 'auth.email_taken');
    assert.equal(a.json.error.message, 'Бұл email бұрын тіркелген.');
    const b = await env.client().post('/api/auth/register', reg({ email: 'new@example.kz', username: 'AIGERIM_S' }));
    assert.equal(b.status, 409);
    assert.equal(b.json.error.code, 'auth.username_taken');
    const c = await env.client().post('/api/auth/register', reg({ email: 'AIGERIM.S@EXAMPLE.KZ', username: 'zzz_1' }));
    assert.equal(c.json.error.code, 'auth.email_taken');
  });

  const bad: Array<[string, Record<string, unknown>, string]> = [
    ['аты жоқ', { displayName: '  ' }, 'validation.display_name_required'],
    ['аты тым ұзын', { displayName: 'Ә'.repeat(61) }, 'validation.display_name_too_long'],
    ['username қысқа', { username: 'ab' }, 'validation.username_format'],
    ['username-де кирилл', { username: 'айгерім' }, 'validation.username_format'],
    ['email қате', { email: 'not-an-email' }, 'validation.email_invalid'],
    ['құпия сөз қысқа', { password: 'short' }, 'validation.password_short'],
    ['құпия сөз тым ұзын', { password: 'x'.repeat(129) }, 'validation.password_too_long'],
    ['өріс түрі қате', { email: 123 }, 'validation.email_invalid'],
  ];
  for (const [name, over, code] of bad) {
    it(`валидация: ${name}`, async () => {
      const r = await env.client().post('/api/auth/register', reg({ username: 'valid_user', email: 'valid@example.kz', ...over }));
      assert.equal(r.status, 400);
      assert.equal(r.json.error.code, code);
      assert.ok(/[А-Яа-яӘәҒғҚқҢңӨөҰұҮүҺһІі]/.test(r.json.error.message), 'хабар қазақша болуы керек');
    });
  }

  it('қате JSON және массив денесі 400 қайтарады', async () => {
    const c = env.client();
    assert.equal((await c.req('POST', '/api/auth/register', '{bad json')).json.error.code, 'request.bad_json');
    assert.equal((await c.req('POST', '/api/auth/register', '[1,2]')).json.error.code, 'request.bad_json');
    assert.equal((await c.req('POST', '/api/auth/register', 'a=b', { 'content-type': 'text/plain' })).status, 415);
  });
});

describe('тіркелу шегі', () => {
  it('бір IP-ден тым көп тіркелу әрекеті 429 береді', async () => {
    const e = await startEnv({ registerPerHour: 3 });
    try {
      const codes: number[] = [];
      for (let i = 0; i < 4; i++) codes.push((await e.client().post('/api/auth/register', reg({ username: `lim_${i}`, email: `lim${i}@example.kz` }))).status);
      assert.deepEqual(codes, [201, 201, 201, 429]);
    } finally { await e.close(); }
  });
});

describe('кіру және шығу', () => {
  it('email және username арқылы кіреді, шыққан соң /me 401 береді', async () => {
    const c1 = env.client();
    assert.equal((await c1.post('/api/auth/login', { identifier: 'aigerim.s@example.kz', password: PASSWORD })).status, 200);
    assert.equal((await c1.get('/api/me')).status, 200);
    const c2 = env.client();
    assert.equal((await c2.post('/api/auth/login', { identifier: 'AIGERIM_S', password: PASSWORD })).status, 200);
    await c2.post('/api/auth/logout');
    const me = await c2.get('/api/me');
    assert.equal(me.status, 401);
    assert.equal(me.json.error.code, 'auth.unauthenticated');
    // шыққан сессияның ескі токені жарамсыз
  });

  it('қате құпия сөз: бірдей қате, ақпарат жария етпейді', async () => {
    const a = await env.client().post('/api/auth/login', { identifier: 'aigerim_s', password: 'wrong-password' });
    const b = await env.client().post('/api/auth/login', { identifier: 'no_such_user', password: 'wrong-password' });
    assert.equal(a.status, 401); assert.equal(b.status, 401);
    assert.deepEqual(a.json.error.code, 'auth.invalid_credentials');
    assert.equal(a.json.error.message, b.json.error.message);
  });

  it('5 сәтсіз әрекеттен кейін 15 минутқа бұғатталады, уақыт өткен соң ашылады', async () => {
    await env.user('victim');
    const c = env.client();
    for (let i = 0; i < 4; i++) assert.equal((await c.post('/api/auth/login', { identifier: 'victim', password: 'bad-password-1' })).json.error.code, 'auth.invalid_credentials');
    const fifth = await c.post('/api/auth/login', { identifier: 'victim', password: 'bad-password-1' });
    assert.equal(fifth.status, 429);
    assert.equal(fifth.json.error.code, 'auth.too_many_attempts');
    assert.equal(fifth.json.error.params.minutes, 15);
    // дұрыс құпия сөзбен де бұғатталған кезде кіре алмайды
    assert.equal((await c.post('/api/auth/login', { identifier: 'victim', password: PASSWORD })).status, 429);
    env.clock.t += 16 * 60_000;
    assert.equal((await c.post('/api/auth/login', { identifier: 'victim', password: PASSWORD })).status, 200);
  });

  it('сессия мерзімі өткен соң жарамсыз болады', async () => {
    const { c } = await env.user('expiring');
    assert.equal((await c.get('/api/me')).status, 200);
    env.clock.t += 15 * 86_400_000;
    assert.equal((await c.get('/api/me')).status, 401);
    assert.equal(env.app.ctx.db.get('SELECT COUNT(*) AS c FROM sessions WHERE user_id = (SELECT id FROM users WHERE username = ?)', 'expiring')!.c, 0);
  });

  it('қорғалған маршруттар аутентификациясыз 401 береді', async () => {
    const c = env.client();
    for (const [m, u] of [['GET', '/api/me'], ['GET', '/api/projects'], ['POST', '/api/projects'], ['GET', '/api/projects/x/tree']] as const) {
      const r = await c.req(m, u, m === 'POST' ? {} : undefined);
      assert.equal(r.status, 401, `${m} ${u}`);
    }
  });
});

describe('профиль', () => {
  it('аты, түсі, username және email жаңартылады; тек өз профилі', async () => {
    const { c } = await env.user('profiler');
    const r = await c.patch('/api/me', { displayName: 'Жаңа Ат', avatarColor: '#AABBCC', username: 'profiler2', email: 'p2@example.kz' });
    assert.equal(r.status, 200);
    assert.equal(r.json.user.displayName, 'Жаңа Ат');
    assert.equal(r.json.user.avatarColor, '#aabbcc');
    assert.equal((await c.get('/api/me')).json.user.username, 'profiler2');
  });

  it('бос емес username/email және жарамсыз түс қабылданбайды', async () => {
    const { c } = await env.user('prof3');
    assert.equal((await c.patch('/api/me', { username: 'aigerim_s' })).json.error.code, 'auth.username_taken');
    assert.equal((await c.patch('/api/me', { email: 'aigerim.s@example.kz' })).json.error.code, 'auth.email_taken');
    assert.equal((await c.patch('/api/me', { avatarColor: 'red' })).json.error.code, 'validation.color_invalid');
    assert.equal((await c.patch('/api/me', { displayName: '' })).status, 400);
    // сәтсіз өзгеріс ішінара жазылмауы керек (атомарлық)
    const r = await c.patch('/api/me', { displayName: 'Жартылай', username: 'aigerim_s' });
    assert.equal(r.status, 409);
    assert.notEqual((await c.get('/api/me')).json.user.displayName, 'Жартылай');
  });

  const PNG = 'data:image/png;base64,' + Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(32, 1)]).toString('base64');

  it('аватар жүктеледі, сервер арқылы беріледі, жойылады', async () => {
    const { c, id } = await env.user('avatarer');
    const up = await c.patch('/api/me', { avatarUrl: PNG });
    assert.equal(up.status, 200);
    assert.match(up.json.user.avatarUrl, new RegExp(`^/api/users/${id}/avatar\\?v=1$`));
    const img = await fetch(env.base + up.json.user.avatarUrl, { headers: { cookie: c.cookie } });
    assert.equal(img.status, 200);
    assert.equal(img.headers.get('content-type'), 'image/png');
    assert.equal(img.headers.get('x-content-type-options'), 'nosniff');
    assert.equal((await img.arrayBuffer()).byteLength, 40);
    const del = await c.patch('/api/me', { avatarUrl: null });
    assert.equal(del.json.user.avatarUrl, undefined);
    assert.equal((await c.get(`/api/users/${id}/avatar`)).status, 404);
  });

  it('аватар валидациясы: формат, magic bytes, өлшем', async () => {
    const { c } = await env.user('avatar2');
    assert.equal((await c.patch('/api/me', { avatarUrl: 'data:image/gif;base64,AAAA' })).json.error.code, 'validation.avatar_invalid');
    assert.equal((await c.patch('/api/me', { avatarUrl: 'data:image/png;base64,' + Buffer.from('not a png at all').toString('base64') })).json.error.code, 'validation.avatar_invalid');
    assert.equal((await c.patch('/api/me', { avatarUrl: 'https://evil.example/x.png' })).json.error.code, 'validation.avatar_invalid');
    const big = 'data:image/png;base64,' + Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(2 * 1024 * 1024 + 1)]).toString('base64');
    const r = await c.patch('/api/me', { avatarUrl: big });
    assert.equal(r.status, 413);
    assert.equal(r.json.error.code, 'validation.avatar_too_large');
  });

  it('басқа пайдаланушының аватарын тек ортақ жоба қатысушысы көре алады', async () => {
    const a = await env.user('av_owner');
    const b = await env.user('av_other');
    await a.c.patch('/api/me', { avatarUrl: PNG });
    assert.equal((await b.c.get(`/api/users/${a.id}/avatar`)).status, 404);
    const p = await a.c.post('/api/projects', { name: 'P', description: '', languages: ['python'], entryPoint: 'main.py', joinRole: 'viewer', template: 'empty' });
    await b.c.post('/api/projects/join', { code: p.json.inviteCode });
    assert.equal((await b.c.get(`/api/users/${a.id}/avatar`)).status, 200);
  });

  it('құпия сөзді өзгерту: ағымдағысы тексеріледі, басқа сессиялар жабылады, жаңасымен кіреді', async () => {
    const { c } = await env.user('pwchanger');
    const other = env.client();
    await other.post('/api/auth/login', { identifier: 'pwchanger', password: PASSWORD });
    assert.equal((await c.post('/api/me/password', { current: 'wrong-current-pw', next: 'Yana-qupiya-2027' })).json.error.code, 'auth.wrong_password');
    assert.equal((await c.post('/api/me/password', { current: PASSWORD, next: 'short' })).json.error.code, 'validation.password_short');
    assert.equal((await c.post('/api/me/password', { current: PASSWORD, next: PASSWORD })).json.error.code, 'validation.password_same');
    assert.equal((await c.post('/api/me/password', { current: PASSWORD, next: 'Yana-qupiya-2027' })).status, 200);
    assert.equal((await c.get('/api/me')).status, 200, 'ағымдағы сессия сақталады');
    assert.equal((await other.get('/api/me')).status, 401, 'басқа сессия жабылды');
    assert.equal((await env.client().post('/api/auth/login', { identifier: 'pwchanger', password: PASSWORD })).status, 401);
    assert.equal((await env.client().post('/api/auth/login', { identifier: 'pwchanger', password: 'Yana-qupiya-2027' })).status, 200);
  });
});
