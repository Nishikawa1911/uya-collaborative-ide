import { request } from 'node:http';
import type { Socket } from 'node:net';
import { randomBytes } from 'node:crypto';
import { TextCRDT, type Op } from '../../shared/crdt.ts';
import { acceptKey, closePayload, encodeFrame, FrameParser, OP } from '../wsframe.ts';

export type Msg = Record<string, any>;

export type ConnectResult = { ok: true; ws: TestWs } | { ok: false; status: number };

export class TestWs {
  socket: Socket;
  log: Msg[] = [];
  closeCode: number | null = null;
  private parser = new FrameParser({ maxPayload: 16 * 1024 * 1024, requireMask: false });
  private waiters: Array<() => void> = [];
  hello!: Msg;
  docs = new Map<string, TextCRDT>();
  seq = 0;

  constructor(socket: Socket, head: Buffer) {
    this.socket = socket;
    const feed = (d: Buffer) => {
      for (const f of this.parser.push(d)) {
        if (f.opcode === OP.text) { const m = JSON.parse(f.payload.toString('utf8')); this.log.push(m); }
        else if (f.opcode === OP.ping) socket.write(encodeFrame(OP.pong, f.payload, true));
        else if (f.opcode === OP.close) {
          this.closeCode = f.payload.length >= 2 ? f.payload.readUInt16BE(0) : 1005;
          try { socket.write(encodeFrame(OP.close, closePayload(this.closeCode), true)); } catch { /* ignore */ }
        }
      }
      this.waiters.splice(0).forEach((w) => w());
    };
    if (head.length) feed(head);
    socket.on('data', feed);
    socket.on('close', () => { if (this.closeCode === null) this.closeCode = 1006; this.waiters.splice(0).forEach((w) => w()); });
    socket.on('error', () => {});
  }

  send(m: Msg) { this.socket.write(encodeFrame(OP.text, Buffer.from(JSON.stringify(m)), true)); }
  sendRaw(op: number, payload: Buffer) { this.socket.write(encodeFrame(op, payload, true)); }

  async waitFor<T extends Msg = Msg>(pred: (m: Msg) => boolean, ms = 3000, from = 0): Promise<T> {
    const end = Date.now() + ms;
    for (;;) {
      const m = this.log.slice(from).find(pred);
      if (m) return m as T;
      const left = end - Date.now();
      if (left <= 0) throw new Error(`күтілген хабар келмеді; жүріс: ${JSON.stringify(this.log.map((x) => x.type))}`);
      await new Promise<void>((res) => { const t = setTimeout(res, left); this.waiters.push(() => { clearTimeout(t); res(); }); });
    }
  }
  of = (type: string, ms?: number) => this.waitFor((m) => m.type === type, ms);

  async waitClosed(ms = 3000): Promise<number> {
    const end = Date.now() + ms;
    while (this.closeCode === null) {
      const left = end - Date.now();
      if (left <= 0) throw new Error('қосылым жабылмады');
      await new Promise<void>((res) => { const t = setTimeout(res, left); this.waiters.push(() => { clearTimeout(t); res(); }); });
    }
    return this.closeCode;
  }

  /** Құжатты ашып, жергілікті TextCRDT күйін құрады (клиент ретінде). */
  async open(fileId: string, localOps?: Op[]): Promise<TextCRDT> {
    const from = this.log.length;
    this.send({ type: 'doc.open', fileId, ...(localOps ? { ops: localOps } : {}) });
    const st = await this.waitFor((m) => m.type === 'doc.state' && m.fileId === fileId, 3000, from);
    let doc = this.docs.get(fileId);
    if (!doc) { doc = new TextCRDT(this.hello.clientId); this.docs.set(fileId, doc); }
    doc.applyOps(st.ops);
    return doc;
  }

  /** Жергілікті өзгеріс жасап, серверге жібереді; ack күтеді. */
  async edit(fileId: string, offset: number, del: number, ins: string, waitAck = true): Promise<void> {
    const doc = this.docs.get(fileId)!;
    const ops = doc.localReplace(offset, del, ins);
    const seq = ++this.seq;
    const from = this.log.length;
    this.send({ type: 'doc.ops', fileId, seq, ops });
    if (waitAck) await this.waitFor((m) => m.type === 'doc.ack' && m.seq === seq, 3000, from);
  }

  /** Келген қашықтағы операцияларды жергілікті құжатқа қолданады. */
  pump(fileId?: string) {
    for (const m of this.log) {
      if (m.type === 'doc.ops' && (!fileId || m.fileId === fileId) && !(m as any)._done) {
        (m as any)._done = true;
        this.docs.get(m.fileId)?.applyOps(m.ops);
      }
    }
  }
  text(fileId: string) { this.pump(fileId); return this.docs.get(fileId)!.text(); }

  async waitText(fileId: string, expected: string | ((t: string) => boolean), ms = 3000): Promise<string> {
    const end = Date.now() + ms;
    for (;;) {
      const t = this.text(fileId);
      if (typeof expected === 'string' ? t === expected : expected(t)) return t;
      if (Date.now() > end) throw new Error(`мәтін күтілгенге жетпеді: ${JSON.stringify(t)}`);
      await new Promise((r) => setTimeout(r, 15));
    }
  }

  close() { try { this.socket.write(encodeFrame(OP.close, closePayload(1000), true)); } catch { /* ignore */ } setTimeout(() => this.socket.destroy(), 50); }
  kill() { this.socket.destroy(); }
}

export function connectWs(base: string, projectId: string, opts: { cookie?: string; origin?: string; cid?: number } = {}): Promise<ConnectResult> {
  return new Promise((resolve, reject) => {
    const key = randomBytes(16).toString('base64');
    const u = new URL(base);
    const headers: Record<string, string> = {
      Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Version': '13', 'Sec-WebSocket-Key': key,
    };
    if (opts.cookie) headers.Cookie = opts.cookie;
    if (opts.origin) headers.Origin = opts.origin;
    const req = request({ host: u.hostname, port: u.port, path: `/ws/projects/${projectId}${opts.cid ? `?cid=${opts.cid}` : ''}`, headers });
    req.on('upgrade', (res, socket, head) => {
      if (res.headers['sec-websocket-accept'] !== acceptKey(key)) { socket.destroy(); return reject(new Error('accept key')); }
      const ws = new TestWs(socket as Socket, head);
      ws.of('hello').then((h) => { ws.hello = h; resolve({ ok: true, ws }); }, reject);
    });
    req.on('response', (res) => { res.resume(); resolve({ ok: false, status: res.statusCode ?? 0 }); });
    req.on('error', reject);
    req.end();
  });
}
