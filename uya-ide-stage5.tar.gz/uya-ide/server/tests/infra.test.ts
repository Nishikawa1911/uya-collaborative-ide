import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { after, describe, it } from 'node:test';
import { fileURLToPath } from 'node:url';
import { Db, migrate } from '../db.ts';
import { MESSAGES } from '../errors.ts';
import { loadConfig } from '../config.ts';
import { hashInviteCode, normalizeInviteCode, hashPassword, verifyPassword } from '../security.ts';
import { newProject, startEnv } from './helpers.ts';

const here = path.dirname(fileURLToPath(import.meta.url));
const cleanup: string[] = [];
after(() => { for (const d of cleanup) rmSync(d, { recursive: true, force: true }); });

describe('қазақша хабарлар', () => {
  const kk = readFileSync(path.join(here, '../../src/i18n/kk.ts'), 'utf8');
  it('сервердің әр қате коды үшін фронтендте дәл сондай мәтін бар (errors.<код>)', () => {
    for (const [code, text] of Object.entries(MESSAGES)) {
      const esc = text.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      assert.ok(kk.includes(`'errors.${code}': '${esc}',`), `kk.ts ішінде errors.${code} жоқ немесе мәтіні өзгеше`);
    }
  });
  it('барлық хабарлар қазақ әріптерін/кириллицаны қамтиды (аударылмай қалған жоқ)', () => {
    for (const [code, text] of Object.entries(MESSAGES)) assert.match(text, /[А-Яа-яӘәҒғҚқҢңӨөҰұҮүҺһІі]/, code);
  });
  it('белгісіз маршрут, дұрыс емес әдіс және ішкі қателер қазақша JSON береді', async () => {
    const env = await startEnv();
    try {
      const c = env.client();
      const nf = await c.get('/api/nope');
      assert.equal(nf.status, 404); assert.equal(nf.json.error.code, 'request.not_found');
      const na = await c.req('PUT', '/api/auth/login', {});
      assert.equal(na.status, 405); assert.equal(na.json.error.message, MESSAGES['request.method_not_allowed']);
    } finally { await env.close(); }
  });
});

describe('миграциялар', () => {
  it('қайта іске қосқанда қайталанбайды; чек-сома өзгерсе, қате береді', () => {
    const dir = mkdtempSync(path.join(tmpdir(), 'uya-mig-')); cleanup.push(dir);
    const db = new Db(path.join(dir, 'a.sqlite'));
    const first = migrate(db);
    assert.deepEqual(first.applied, ['001_init.sql', '002_realtime.sql', '003_runs.sql']);
    const again = migrate(db);
    assert.deepEqual(again.applied, []); assert.deepEqual(again.skipped, ['001_init.sql', '002_realtime.sql', '003_runs.sql']);
    const tables = db.all("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").map((r) => r.name);
    for (const t of ['users', 'profiles', 'projects', 'project_members', 'project_invitations', 'files', 'folders', 'project_settings', 'sessions', 'auth_attempts', 'schema_migrations', 'file_docs', 'chat_messages', 'collab_clients']) {
      assert.ok(tables.includes(t), `${t} кестесі жоқ`);
    }
    db.run("UPDATE schema_migrations SET checksum = 'x'");
    assert.throws(() => migrate(db), /өзгертілген/);
    db.close();
  });

  it('келесі миграция бұрынғы деректі сақтап, реті бойынша қолданылады', () => {
    const dir = mkdtempSync(path.join(tmpdir(), 'uya-mig2-')); cleanup.push(dir);
    const mdir = path.join(dir, 'm'); mkdirSync(mdir);
    writeFileSync(path.join(mdir, '001_a.sql'), 'CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT);');
    const db = new Db(path.join(dir, 'b.sqlite'));
    migrate(db, mdir);
    db.run("INSERT INTO t (v) VALUES ('сақталған')");
    writeFileSync(path.join(mdir, '002_b.sql'), 'ALTER TABLE t ADD COLUMN w TEXT DEFAULT \'x\';');
    assert.deepEqual(migrate(db, mdir).applied, ['002_b.sql']);
    assert.deepEqual({ ...db.get('SELECT v, w FROM t') }, { v: 'сақталған', w: 'x' });
    // сәтсіз миграция толық кері қайтарылады
    writeFileSync(path.join(mdir, '003_bad.sql'), 'CREATE TABLE ok1 (a); INSERT INTO nope VALUES (1);');
    assert.throws(() => migrate(db, mdir));
    assert.equal(db.get("SELECT COUNT(*) AS c FROM sqlite_master WHERE name = 'ok1'")!.c, 0);
    db.close();
  });
});

describe('деректердің тұрақтылығы', () => {
  it('сервер қайта іске қосылғанда пайдаланушы, жоба, файл мазмұны және сессия сақталады', async () => {
    const dir = mkdtempSync(path.join(tmpdir(), 'uya-persist-')); cleanup.push(dir);
    let env = await startEnv({}, { dir });
    const u = await env.user('persist');
    const p = await u.c.post('/api/projects', newProject({ template: 'empty', entryPoint: 'main.py' }));
    const pid = p.json.project.id;
    const fileId = (await u.c.get(`/api/projects/${pid}/tree`)).json.nodes[0].id;
    await u.c.put(`/api/projects/${pid}/files/${fileId}/content`, { content: 'print("сақталды")\n' });
    const cookie = u.c.cookie;
    await env.app.close();

    env = await startEnv({}, { dir });
    try {
      const c = env.client(); c.cookie = cookie;
      assert.equal((await c.get('/api/me')).json.user.username, 'persist', 'сессия сақталды');
      assert.equal((await c.get(`/api/projects/${pid}`)).json.project.name, 'Алматы сапасы');
      assert.equal((await c.get(`/api/projects/${pid}/files/${fileId}/content`)).json.content, 'print("сақталды")\n');
      assert.equal((await env.client().post('/api/auth/login', { identifier: 'persist', password: 'Uya-demo-2026' })).status, 200, 'құпия сөз хэші сақталды');
      assert.equal((await c.post('/api/projects/join', { code: p.json.inviteCode })).json.error.code, 'project.already_member', 'шақыру хэші сақталды');
    } finally { await env.app.close(); }
  });

  it('жарыс жағдайы: бір уақытта бірдей email-мен тіркелу — тек біреуі сәтті', async () => {
    const env = await startEnv();
    try {
      const body = { displayName: 'Жарыс', username: 'race_a', email: 'race@example.kz', password: 'Uya-demo-2026' };
      const rs = await Promise.all([0, 1, 2, 3].map((i) => env.client().post('/api/auth/register', { ...body, username: `race_${i}` })));
      assert.equal(rs.filter((r) => r.status === 201).length, 1);
      assert.ok(rs.filter((r) => r.status !== 201).every((r) => r.json.error.code === 'auth.email_taken'));
    } finally { await env.close(); }
  });

  it('жарыс жағдайы: бір уақытта бірдей атпен файл құру — тек біреуі сәтті', async () => {
    const env = await startEnv();
    try {
      const u = await env.user('racer');
      const p = (await u.c.post('/api/projects', newProject({ template: 'empty', entryPoint: 'main.py' }))).json.project.id;
      const rs = await Promise.all([0, 1, 2, 3, 4].map(() => u.c.post(`/api/projects/${p}/nodes`, { parentId: null, name: 'same.txt', kind: 'file' })));
      assert.equal(rs.filter((r) => r.status === 201).length, 1);
      assert.ok(rs.filter((r) => r.status !== 201).every((r) => r.json.error.code === 'file.exists'));
    } finally { await env.close(); }
  });
});

describe('қауіпсіздік қабаты', () => {
  it('CSRF: бөгде Origin-мен жазу сұраулары қабылданбайды; өз Origin-і және Origin-сіз клиент рұқсат', async () => {
    const env = await startEnv();
    try {
      const u = await env.user('csrf');
      const evil = await u.c.req('POST', '/api/projects', newProject(), { origin: 'https://evil.example' });
      assert.equal(evil.status, 403); assert.equal(evil.json.error.code, 'request.forbidden_origin');
      assert.equal((await u.c.req('POST', '/api/projects', newProject(), { 'sec-fetch-site': 'cross-site' })).status, 403);
      assert.equal((await u.c.req('POST', '/api/projects', newProject(), { origin: env.base })).status, 201);
      assert.equal((await u.c.req('GET', '/api/me', undefined, { origin: 'https://evil.example' })).status, 200, 'GET өзгеріс жасамайды');
      const e2 = await startEnv({ allowedOrigins: ['https://app.example.kz'] });
      try {
        const v = await e2.user('csrf2');
        assert.equal((await v.c.req('POST', '/api/projects', newProject(), { origin: 'https://app.example.kz' })).status, 201);
      } finally { await e2.close(); }
    } finally { await env.close(); }
  });

  it('сұраныс денесінің шегі: тым үлкен JSON 413', async () => {
    const env = await startEnv({ maxBodyBytes: 2000 });
    try {
      const r = await env.client().post('/api/auth/login', { identifier: 'x'.repeat(5000), password: 'y' });
      assert.equal(r.status, 413); assert.equal(r.json.error.code, 'request.too_large');
    } finally { await env.close(); }
  });

  it('құпия сөз хэші мен тұздау: бірдей құпия сөз әртүрлі хэш береді; өндірісте INVITE_PEPPER міндетті', async () => {
    const a = await hashPassword('Uya-demo-2026', { scryptN: 1024 });
    const b = await hashPassword('Uya-demo-2026', { scryptN: 1024 });
    assert.notEqual(a, b);
    assert.equal(await verifyPassword('Uya-demo-2026', a), true);
    assert.equal(await verifyPassword('uya-demo-2026', a), false);
    assert.equal(await verifyPassword('x', 'garbage'), false);
    assert.throws(() => loadConfig({ NODE_ENV: 'production' }), /INVITE_PEPPER/);
    assert.equal(loadConfig({ NODE_ENV: 'production', INVITE_PEPPER: 'x'.repeat(32) }).cookieSecure, true);
  });

  it('шақыру коды нормализациясы және pepper-ге тәуелді хэш', () => {
    assert.equal(normalizeInviteCode('a1qx-7m2k-9tbh'), 'A1QX7M2K9TBH');
    assert.equal(normalizeInviteCode('0O1IL'), '00111');
    assert.notEqual(hashInviteCode('A1QX-7M2K-9TBH', 'pepper-one-1234567'), hashInviteCode('A1QX-7M2K-9TBH', 'pepper-two-1234567'));
    assert.equal(hashInviteCode('a1qx 7m2k 9tbh', 'p'.repeat(20)), hashInviteCode('A1QX-7M2K-9TBH', 'p'.repeat(20)));
  });

  it('статикалық файлдар: SPA fallback, path traversal жабық, API емес жолдар JSON емес', async () => {
    const dir = mkdtempSync(path.join(tmpdir(), 'uya-static-')); cleanup.push(dir);
    const dist = path.join(dir, 'dist'); mkdirSync(dist);
    writeFileSync(path.join(dist, 'index.html'), '<!doctype html><title>Ұя</title>');
    writeFileSync(path.join(dist, 'app.js'), 'console.log(1)');
    writeFileSync(path.join(dir, 'secret.txt'), 'SECRET');
    const env = await startEnv({ staticDir: dist });
    try {
      const idx = await fetch(env.base + '/');
      assert.equal(idx.status, 200); assert.match(idx.headers.get('content-type')!, /text\/html; charset=utf-8/);
      assert.match(await idx.text(), /Ұя/);
      const js = await fetch(env.base + '/app.js');
      assert.match(js.headers.get('content-type')!, /javascript/);
      assert.equal(js.headers.get('x-content-type-options'), 'nosniff');
      assert.equal(js.headers.get('x-frame-options'), 'DENY');
      assert.match(await (await fetch(env.base + '/some/spa/route')).text(), /Ұя/);
      assert.equal((await fetch(env.base + '/missing.js')).status, 404);
      for (const evil of ['/../secret.txt', '/%2e%2e/secret.txt', '/..%2fsecret.txt', '/%2e%2e%2fsecret.txt']) {
        const r = await fetch(env.base + evil);
        assert.ok(!(await r.text()).includes('SECRET'), evil);
      }
    } finally { await env.close(); }
  });
});
