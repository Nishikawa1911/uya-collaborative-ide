import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export interface Config {
  port: number;
  host: string;
  /** SQLite файлының жолы (':memory:' — тек тесттер үшін). */
  dbPath: string;
  /** Шақыру кодтарының HMAC кілті. ӨНДІРІСТЕ міндетті түрде өзгертіңіз. */
  invitePepper: string;
  /** Құпия сөз хэшінің scrypt құны (N, 2-нің дәрежесі). */
  scryptN: number;
  sessionTtlDays: number;
  cookieSecure: boolean;
  trustProxy: boolean;
  /** Қосымша рұқсат етілген Origin-дер (бөлек домендегі фронтенд үшін). */
  allowedOrigins: string[];
  /** Жинақталған фронтенд (dist) қалтасы; жоқ болса, тек API жұмыс істейді. */
  staticDir: string;
  maxBodyBytes: number;
  maxFileBytes: number;
  maxNodesPerProject: number;
  maxProjectsPerUser: number;
  maxFolderDepth: number;
  /** Бір IP-ден сағатына тіркелу әрекеттерінің шегі. */
  registerPerHour: number;
  logRequests: boolean;
  /** Оқшауланған runner қызметінің мекенжайы (бос болса — іске қосу өшірулі). */
  runnerUrl: string;
  runnerToken: string;
  /** Бір мезгілде орындалатын тапсырмалар (бүкіл жүйе бойынша). */
  runConcurrency: number;
  runQueueMax: number;
  runPerUserActive: number;
  runPerUserPerMinute: number;
  /** Орындау тарихын сақтау мерзімі (күн). */
  runRetentionDays: number;
  /** Бір орындаудың шығысын сақтау шегі (таңба). */
  runStoreChars: number;
}

const DEV_PEPPER = 'dev-only-invite-pepper-change-me';

function bool(v: string | undefined, d: boolean): boolean {
  if (v == null || v === '') return d;
  return ['1', 'true', 'yes', 'on'].includes(v.toLowerCase());
}
function int(v: string | undefined, d: number): number {
  const n = Number(v);
  return v != null && v !== '' && Number.isFinite(n) ? Math.trunc(n) : d;
}

export function loadConfig(env: Record<string, string | undefined> = process.env, overrides: Partial<Config> = {}): Config {
  const production = env.NODE_ENV === 'production';
  const cfg: Config = {
    port: int(env.PORT, 3000),
    host: env.HOST || '127.0.0.1',
    dbPath: env.DATABASE_PATH || path.join(root, 'data', 'uya.sqlite'),
    invitePepper: env.INVITE_PEPPER || DEV_PEPPER,
    scryptN: int(env.SCRYPT_N, 2 ** 15),
    sessionTtlDays: int(env.SESSION_TTL_DAYS, 14),
    cookieSecure: bool(env.COOKIE_SECURE, production),
    trustProxy: bool(env.TRUST_PROXY, false),
    allowedOrigins: (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
    staticDir: env.STATIC_DIR || path.join(root, 'dist'),
    maxBodyBytes: int(env.MAX_BODY_BYTES, 6 * 1024 * 1024),
    maxFileBytes: int(env.MAX_FILE_BYTES, 1024 * 1024),
    maxNodesPerProject: int(env.MAX_NODES_PER_PROJECT, 1000),
    maxProjectsPerUser: int(env.MAX_PROJECTS_PER_USER, 50),
    maxFolderDepth: int(env.MAX_FOLDER_DEPTH, 16),
    registerPerHour: int(env.REGISTER_PER_HOUR, 20),
    logRequests: bool(env.LOG_REQUESTS, !production),
    runnerUrl: (env.RUNNER_URL || '').replace(/\/+$/, ''),
    runnerToken: env.RUNNER_TOKEN || '',
    runConcurrency: int(env.RUN_CONCURRENCY, 4),
    runQueueMax: int(env.RUN_QUEUE_MAX, 50),
    runPerUserActive: int(env.RUN_PER_USER_ACTIVE, 2),
    runPerUserPerMinute: int(env.RUN_PER_USER_PER_MINUTE, 30),
    runRetentionDays: int(env.RUN_RETENTION_DAYS, 14),
    runStoreChars: int(env.RUN_STORE_CHARS, 200_000),
    ...overrides,
  };
  if (production && cfg.invitePepper === DEV_PEPPER) {
    throw new Error('INVITE_PEPPER өндірісте міндетті: ұзын кездейсоқ жол орнатыңыз (мысалы, `openssl rand -hex 32`).');
  }
  if (cfg.invitePepper.length < 16) throw new Error('INVITE_PEPPER кемінде 16 таңба болуы керек.');
  if (cfg.scryptN < 2 ** 10 || (cfg.scryptN & (cfg.scryptN - 1)) !== 0) throw new Error('SCRYPT_N — 1024-тен кем емес, 2-нің дәрежесі болуы керек.');
  return cfg;
}
