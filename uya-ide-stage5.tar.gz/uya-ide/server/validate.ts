import { AppError } from './errors.ts';

export const LANGUAGES = ['python', 'java', 'go', 'cpp', 'csharp', 'rust', 'php', 'typescript', 'html', 'css', 'javascript', 'sql'] as const;
export type Language = (typeof LANGUAGES)[number];

export const USERNAME_RE = /^[A-Za-z0-9_]{3,24}$/;
export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

export type Json = Record<string, unknown>;

export function asObject(v: unknown): Json {
  if (v == null || typeof v !== 'object' || Array.isArray(v)) throw new AppError('request.bad_json', 400);
  return v as Json;
}

export function str(v: unknown, code: ConstructorParameters<typeof AppError>[0] = 'validation.field_invalid'): string {
  if (typeof v !== 'string') throw new AppError(code, 400);
  return v;
}

export function displayName(v: unknown): string {
  const s = str(v, 'validation.display_name_required').normalize('NFC').trim();
  if (!s) throw new AppError('validation.display_name_required');
  if ([...s].length > 60) throw new AppError('validation.display_name_too_long');
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u001f\u007f]/.test(s)) throw new AppError('validation.display_name_required');
  return s;
}

export function username(v: unknown): string {
  const s = str(v, 'validation.username_format').trim();
  if (!USERNAME_RE.test(s)) throw new AppError('validation.username_format');
  return s;
}

export function email(v: unknown): string {
  const s = str(v, 'validation.email_invalid').trim();
  if (s.length > 254 || !EMAIL_RE.test(s)) throw new AppError('validation.email_invalid');
  return s;
}

export function password(v: unknown): string {
  const s = str(v, 'validation.password_short');
  if ([...s].length < 10) throw new AppError('validation.password_short');
  if (s.length > 128) throw new AppError('validation.password_too_long');
  return s;
}

export function color(v: unknown): string {
  const s = str(v, 'validation.color_invalid');
  if (!COLOR_RE.test(s)) throw new AppError('validation.color_invalid');
  return s.toLowerCase();
}

export function projectName(v: unknown): string {
  const s = str(v, 'validation.project_name_required').normalize('NFC').trim();
  if (!s) throw new AppError('validation.project_name_required');
  if ([...s].length > 60) throw new AppError('validation.project_name_too_long');
  // eslint-disable-next-line no-control-regex
  if (/[\u0000-\u001f\u007f]/.test(s)) throw new AppError('validation.project_name_required');
  return s;
}

export function description(v: unknown): string {
  if (v == null) return '';
  const s = str(v, 'validation.description_too_long').normalize('NFC').trim();
  if ([...s].length > 300) throw new AppError('validation.description_too_long');
  return s;
}

export function languages(v: unknown): Language[] {
  if (!Array.isArray(v) || v.length === 0) throw new AppError('validation.languages_required');
  const out: Language[] = [];
  for (const x of v) {
    if (typeof x !== 'string' || !(LANGUAGES as readonly string[]).includes(x)) throw new AppError('validation.languages_invalid');
    if (!out.includes(x as Language)) out.push(x as Language);
  }
  return out;
}

export function joinRole(v: unknown): 'editor' | 'viewer' {
  if (v !== 'editor' && v !== 'viewer') throw new AppError('validation.role_invalid');
  return v;
}

export function memberRole(v: unknown): 'editor' | 'viewer' {
  return joinRole(v);
}

/** Файл/қалта атауы (спецификация 9.4): жол бөлгіштер, басқару таңбалары, ұзындық (≤255 байт). */
export function isValidFileName(name: string): boolean {
  const t = name.trim();
  if (!t || t === '.' || t === '..') return false;
  if (Buffer.byteLength(t, 'utf8') > 255) return false;
  // eslint-disable-next-line no-control-regex
  return !/[\\/:*?"<>|\u0000-\u001f\u007f]/.test(t);
}

export function nodeName(v: unknown): string {
  const s = str(v, 'file.invalid_name').normalize('NFC').trim();
  if (!isValidFileName(s)) throw new AppError('file.invalid_name');
  return s;
}

/** Жоба негізгі файлының жолы: `main.py` немесе `src/main.py`. */
export function entryPoint(v: unknown, maxDepth: number): string[] {
  const s = str(v, 'validation.entry_point_invalid').normalize('NFC').trim();
  const parts = s.split('/');
  if (!s || s.startsWith('/') || parts.length > maxDepth || !parts.every((p) => isValidFileName(p) && p === p.trim())) {
    throw new AppError('validation.entry_point_invalid');
  }
  return parts;
}

export function maxMembers(v: unknown): number {
  if (typeof v !== 'number' || !Number.isInteger(v) || v < 1 || v > 500) throw new AppError('validation.max_members_invalid');
  return v;
}

export function bool(v: unknown): boolean {
  if (typeof v !== 'boolean') throw new AppError('validation.field_invalid');
  return v;
}
