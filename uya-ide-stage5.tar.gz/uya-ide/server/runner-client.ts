/** Backend → runner HTTP клиенті. Runner-ге тек осы модуль арқылы қол жеткізіледі. */
export interface RunnerLang { id: string; label: string; enabled: boolean; reason?: string }
export type RunnerEvent =
  | { type: 'started' }
  | { type: 'phase'; phase: 'compile' | 'run' }
  | { type: 'output'; stream: 'build' | 'stdout' | 'stderr'; chunk: string }
  | { type: 'finished'; status: string; exitCode: number | null; signal: string | null; durationMs: number; phase: string; message?: string };

export interface RunnerClient {
  languages(): Promise<RunnerLang[]>;
  run(req: { id: string; entry: string; mode: 'file' | 'project'; files: Array<{ path: string; content: string }>; stdin?: string }, onEvent: (e: RunnerEvent) => void, signal: AbortSignal): Promise<void>;
  cancel(id: string): Promise<void>;
}

export class RunnerHttpError extends Error { status: number; constructor(status: number, msg: string) { super(msg); this.status = status; } }

export function httpRunnerClient(baseUrl: string, token: string): RunnerClient {
  const H = { authorization: `Bearer ${token}`, 'content-type': 'application/json' };
  return {
    async languages() {
      const r = await fetch(`${baseUrl}/v1/languages`, { headers: H, signal: AbortSignal.timeout(5000) });
      if (!r.ok) throw new RunnerHttpError(r.status, 'languages');
      return ((await r.json()) as { languages: RunnerLang[] }).languages;
    },
    async run(req, onEvent, signal) {
      const r = await fetch(`${baseUrl}/v1/run`, { method: 'POST', headers: H, body: JSON.stringify(req), signal });
      if (!r.ok || !r.body) throw new RunnerHttpError(r.status, await r.text().catch(() => ''));
      const dec = new TextDecoder();
      let buf = '';
      let finished = false;
      for await (const chunk of r.body as unknown as AsyncIterable<Uint8Array>) {
        buf += dec.decode(chunk, { stream: true });
        let i: number;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i); buf = buf.slice(i + 1);
          if (!line.trim()) continue;
          const ev = JSON.parse(line) as RunnerEvent;
          if (ev.type === 'finished') finished = true;
          onEvent(ev);
        }
      }
      if (!finished) throw new RunnerHttpError(502, 'runner ағыны аяқталмай үзілді');
    },
    async cancel(id) {
      await fetch(`${baseUrl}/v1/cancel/${encodeURIComponent(id)}`, { method: 'POST', headers: H, signal: AbortSignal.timeout(5000) }).catch(() => {});
    },
  };
}
