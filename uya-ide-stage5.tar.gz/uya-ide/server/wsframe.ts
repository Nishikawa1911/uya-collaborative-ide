/** RFC 6455 кадрларын кодтау/декодтау (сервер де, тест клиенті де қолданады). Сыртқы тәуелділіксіз. */
import { createHash, randomBytes } from 'node:crypto';

export const OP = { cont: 0, text: 1, binary: 2, close: 8, ping: 9, pong: 10 } as const;
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

export const acceptKey = (key: string) => createHash('sha1').update(key + GUID).digest('base64');

export function encodeFrame(opcode: number, payload: Buffer, mask = false): Buffer {
  const len = payload.length;
  const hdr: number[] = [0x80 | opcode];
  const m = mask ? 0x80 : 0;
  if (len < 126) hdr.push(m | len);
  else if (len < 65536) hdr.push(m | 126, len >> 8, len & 255);
  else { hdr.push(m | 127, 0, 0, 0, 0, (len >>> 24) & 255, (len >>> 16) & 255, (len >>> 8) & 255, len & 255); }
  if (!mask) return Buffer.concat([Buffer.from(hdr), payload]);
  const key = randomBytes(4);
  const out = Buffer.allocUnsafe(len);
  for (let i = 0; i < len; i++) out[i] = payload[i] ^ key[i & 3];
  return Buffer.concat([Buffer.from(hdr), key, out]);
}

export const closePayload = (code: number, reason = '') => {
  const r = Buffer.from(reason.slice(0, 100), 'utf8');
  const b = Buffer.allocUnsafe(2 + r.length);
  b.writeUInt16BE(code, 0); r.copy(b, 2);
  return b;
};

export interface Frame { opcode: number; payload: Buffer }

export class FrameError extends Error {
  code: number;
  constructor(code: number, msg: string) { super(msg); this.code = code; }
}

/** Ағынды талдаушы: бөліктенген кадрларды (fragmentation) жинайды, маскалауды тексереді, өлшемді шектейді. */
export class FrameParser {
  private buf = Buffer.alloc(0);
  private frags: Buffer[] = [];
  private fragOp = 0;
  private fragSize = 0;
  private opts: { maxPayload: number; requireMask: boolean };
  constructor(opts: { maxPayload: number; requireMask: boolean }) { this.opts = opts; }

  push(chunk: Buffer): Frame[] {
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    const out: Frame[] = [];
    for (;;) {
      const b = this.buf;
      if (b.length < 2) break;
      const fin = (b[0] & 0x80) !== 0;
      if (b[0] & 0x70) throw new FrameError(1002, 'rsv');
      const opcode = b[0] & 0x0f;
      const masked = (b[1] & 0x80) !== 0;
      if (this.opts.requireMask && !masked) throw new FrameError(1002, 'unmasked');
      let len = b[1] & 0x7f;
      let off = 2;
      if (len === 126) { if (b.length < 4) break; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) {
        if (b.length < 10) break;
        if (b.readUInt32BE(2) !== 0) throw new FrameError(1009, 'too big');
        len = b.readUInt32BE(6); off = 10;
      }
      if (len > this.opts.maxPayload) throw new FrameError(1009, 'too big');
      const isControl = opcode >= 8;
      if (isControl && (!fin || len > 125)) throw new FrameError(1002, 'control');
      const need = off + (masked ? 4 : 0) + len;
      if (b.length < need) break;
      let payload: Buffer;
      if (masked) {
        const key = b.subarray(off, off + 4);
        payload = Buffer.allocUnsafe(len);
        const src = b.subarray(off + 4, need);
        for (let i = 0; i < len; i++) payload[i] = src[i] ^ key[i & 3];
      } else payload = Buffer.from(b.subarray(off, need));
      this.buf = b.subarray(need);

      if (isControl) { out.push({ opcode, payload }); continue; }
      if (opcode === OP.cont) {
        if (!this.fragOp) throw new FrameError(1002, 'unexpected continuation');
      } else {
        if (this.fragOp) throw new FrameError(1002, 'expected continuation');
        if (opcode !== OP.text && opcode !== OP.binary) throw new FrameError(1002, 'opcode');
        this.fragOp = opcode;
      }
      this.fragSize += payload.length;
      if (this.fragSize > this.opts.maxPayload) throw new FrameError(1009, 'too big');
      this.frags.push(payload);
      if (fin) {
        out.push({ opcode: this.fragOp, payload: this.frags.length === 1 ? this.frags[0] : Buffer.concat(this.frags) });
        this.frags = []; this.fragOp = 0; this.fragSize = 0;
      }
    }
    return out;
  }
}
