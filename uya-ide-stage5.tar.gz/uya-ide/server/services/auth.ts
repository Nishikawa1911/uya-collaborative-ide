import { randomUUID } from 'node:crypto';
import { checkLock, registerFailure, resetAttempts } from '../attempts.ts';
import { iso, type Ctx } from '../context.ts';
import { AppError } from '../errors.ts';
import { hashPassword, newSessionToken, sessionIdOf, verifyDummy, verifyPassword } from '../security.ts';
import * as v from '../validate.ts';

export interface UserDto {
  id: string; username: string; email: string; displayName: string;
  avatarColor: string; avatarUrl?: string; locale: 'kk'; createdAt: string;
}

const AVATAR_COLORS = ['#1fa7b8', '#7a6ff0', '#e0709a', '#d98c2b', '#4cae7c', '#cf5c4f', '#4a86d8', '#9b6fc4'];
const CURSOR_COLORS = ['#3cc6d6', '#9a8cff', '#ff8fb5', '#f2b84b', '#6fdca0', '#ff8174', '#7fb4ff', '#c79bf0'];

const LOGIN_MAX = 5;
const LOGIN_IP_MAX = 20;
const LOCK_MS = 15 * 60_000;
const REGISTER_WINDOW_MS = 60 * 60_000;
const AVATAR_MAX_BYTES = 2 * 1024 * 1024;

export function toUserDto(row: Record<string, any>): UserDto {
  const dto: UserDto = {
    id: row.id, username: row.username, email: row.email, displayName: row.display_name,
    avatarColor: row.avatar_color, locale: 'kk', createdAt: row.created_at,
  };
  if (row.avatar_mime) dto.avatarUrl = `/api/users/${row.id}/avatar?v=${row.avatar_version}`;
  return dto;
}

const USER_SELECT = `SELECT u.id, u.username, u.email, u.created_at, p.display_name, p.avatar_color, p.avatar_mime, p.avatar_version
                     FROM users u JOIN profiles p ON p.user_id = u.id`;

function createSession(ctx: Ctx, userId: string, ip: string, ua: string): string {
  const token = newSessionToken();
  const now = ctx.clock.now();
  ctx.db.run(
    'INSERT INTO sessions (id, user_id, created_at, expires_at, last_seen_at, ip, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)',
    sessionIdOf(token), userId, iso(now), iso(now + ctx.cfg.sessionTtlDays * 86_400_000), iso(now), ip, ua.slice(0, 200),
  );
  return token;
}

export async function register(ctx: Ctx, body: v.Json, ip: string, ua: string) {
  const ipKey = `register:ip:${ip}`;
  const lock = checkLock(ctx, ipKey);
  if (lock.locked) throw new AppError('request.rate_limited', 429, { minutes: lock.minutes });
  registerFailure(ctx, ipKey, ctx.cfg.registerPerHour, REGISTER_WINDOW_MS); // барлық әрекеттер санайды

  const name = v.displayName(body.displayName);
  const uname = v.username(body.username);
  const mail = v.email(body.email);
  const pass = v.password(body.password);

  const taken = (col: 'email' | 'username', val: string) => !!ctx.db.get(`SELECT 1 FROM users WHERE ${col} = ?`, val);
  if (taken('email', mail)) throw new AppError('auth.email_taken', 409);
  if (taken('username', uname)) throw new AppError('auth.username_taken', 409);

  const hash = await hashPassword(pass, ctx.cfg);
  const id = randomUUID();
  const now = iso(ctx.clock.now());
  const idx = Number.parseInt(id.slice(0, 4), 16);
  try {
    ctx.db.tx(() => {
      ctx.db.run('INSERT INTO users (id, email, username, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)', id, mail, uname, hash, now, now);
      ctx.db.run(
        'INSERT INTO profiles (user_id, display_name, avatar_color, cursor_color, updated_at) VALUES (?, ?, ?, ?, ?)',
        id, name, AVATAR_COLORS[idx % AVATAR_COLORS.length], CURSOR_COLORS[idx % CURSOR_COLORS.length], now,
      );
    });
  } catch (e) {
    mapUniqueError(e); // жарыс жағдайы: екі сұраныс бір уақытта
    throw e;
  }
  const token = createSession(ctx, id, ip, ua);
  return { token, user: getUser(ctx, id)! };
}

function mapUniqueError(e: unknown): void {
  const msg = String((e as Error)?.message ?? '');
  if (/UNIQUE constraint failed: users\.email/.test(msg)) throw new AppError('auth.email_taken', 409);
  if (/UNIQUE constraint failed: users\.username/.test(msg)) throw new AppError('auth.username_taken', 409);
}

export function getUser(ctx: Ctx, id: string): UserDto | null {
  const row = ctx.db.get(`${USER_SELECT} WHERE u.id = ?`, id);
  return row ? toUserDto(row) : null;
}

export async function login(ctx: Ctx, body: v.Json, ip: string, ua: string) {
  const identifier = typeof body.identifier === 'string' ? body.identifier.trim() : '';
  const pass = typeof body.password === 'string' ? body.password : '';
  const idKey = `login:id:${identifier.toLowerCase().slice(0, 254)}`;
  const ipKey = `login:ip:${ip}`;
  for (const k of [idKey, ipKey]) {
    const l = checkLock(ctx, k);
    if (l.locked) throw new AppError('auth.too_many_attempts', 429, { minutes: l.minutes });
  }

  const row = identifier && pass.length <= 128
    ? ctx.db.get('SELECT id, password_hash FROM users WHERE email = ? OR username = ?', identifier, identifier)
    : undefined;
  const ok = row ? await verifyPassword(pass, row.password_hash as string) : (await verifyDummy(pass, ctx.cfg), false);

  if (!ok) {
    const a = registerFailure(ctx, idKey, LOGIN_MAX, LOCK_MS);
    const b = registerFailure(ctx, ipKey, LOGIN_IP_MAX, LOCK_MS);
    if (a.locked || b.locked) throw new AppError('auth.too_many_attempts', 429, { minutes: Math.max(a.minutes, b.minutes) });
    throw new AppError('auth.invalid_credentials', 401);
  }
  resetAttempts(ctx, idKey);
  const userId = row!.id as string;
  ctx.db.run('UPDATE users SET last_login_at = ? WHERE id = ?', iso(ctx.clock.now()), userId);
  const token = createSession(ctx, userId, ip, ua);
  return { token, user: getUser(ctx, userId)! };
}

export function logout(ctx: Ctx, sessionId: string) {
  ctx.db.run('DELETE FROM sessions WHERE id = ?', sessionId);
}

/** Токен бойынша сессияны табады; мерзімі өткен болса жояды. */
export function authenticate(ctx: Ctx, token: string): { sessionId: string; user: UserDto } | null {
  const sid = sessionIdOf(token);
  const s = ctx.db.get('SELECT user_id, expires_at, last_seen_at FROM sessions WHERE id = ?', sid);
  if (!s) return null;
  const now = ctx.clock.now();
  if (Date.parse(s.expires_at as string) <= now) {
    ctx.db.run('DELETE FROM sessions WHERE id = ?', sid);
    return null;
  }
  // last_seen жиі жазылмау үшін 5 минутта бір рет жаңартылады
  if (now - Date.parse(s.last_seen_at as string) > 5 * 60_000) {
    ctx.db.run('UPDATE sessions SET last_seen_at = ? WHERE id = ?', iso(now), sid);
  }
  const user = getUser(ctx, s.user_id as string);
  return user ? { sessionId: sid, user } : null;
}

export function purgeExpiredSessions(ctx: Ctx) {
  ctx.db.run('DELETE FROM sessions WHERE expires_at <= ?', iso(ctx.clock.now()));
}

// ── Профиль ───────────────────────────────────────────────
const MAGIC: Record<string, (b: Buffer) => boolean> = {
  'image/png': (b) => b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])),
  'image/jpeg': (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
  'image/webp': (b) => b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP',
};

function parseAvatar(dataUrl: unknown): { mime: string; data: Buffer } {
  if (typeof dataUrl !== 'string') throw new AppError('validation.avatar_invalid');
  const m = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/]+={0,2})$/.exec(dataUrl);
  if (!m) throw new AppError('validation.avatar_invalid');
  const data = Buffer.from(m[2], 'base64');
  if (data.length > AVATAR_MAX_BYTES) throw new AppError('validation.avatar_too_large', 413);
  if (!MAGIC[m[1]](data)) throw new AppError('validation.avatar_invalid');
  return { mime: m[1], data };
}

export function updateProfile(ctx: Ctx, userId: string, body: v.Json): UserDto {
  const now = iso(ctx.clock.now());
  const fields = new Set(Object.keys(body));
  try {
    ctx.db.tx(() => {
      if (fields.has('username')) {
        const uname = v.username(body.username);
        if (ctx.db.get('SELECT 1 FROM users WHERE username = ? AND id <> ?', uname, userId)) throw new AppError('auth.username_taken', 409);
        ctx.db.run('UPDATE users SET username = ?, updated_at = ? WHERE id = ?', uname, now, userId);
      }
      if (fields.has('email')) {
        const mail = v.email(body.email);
        if (ctx.db.get('SELECT 1 FROM users WHERE email = ? AND id <> ?', mail, userId)) throw new AppError('auth.email_taken', 409);
        ctx.db.run('UPDATE users SET email = ?, updated_at = ? WHERE id = ?', mail, now, userId);
      }
      if (fields.has('displayName')) ctx.db.run('UPDATE profiles SET display_name = ?, updated_at = ? WHERE user_id = ?', v.displayName(body.displayName), now, userId);
      if (fields.has('avatarColor')) ctx.db.run('UPDATE profiles SET avatar_color = ?, updated_at = ? WHERE user_id = ?', v.color(body.avatarColor), now, userId);
      if (fields.has('avatarUrl')) {
        if (body.avatarUrl === null) {
          ctx.db.run('UPDATE profiles SET avatar_mime = NULL, avatar_data = NULL, avatar_version = avatar_version + 1, updated_at = ? WHERE user_id = ?', now, userId);
        } else {
          const { mime, data } = parseAvatar(body.avatarUrl);
          ctx.db.run('UPDATE profiles SET avatar_mime = ?, avatar_data = ?, avatar_version = avatar_version + 1, updated_at = ? WHERE user_id = ?', mime, data, now, userId);
        }
      }
    });
  } catch (e) {
    mapUniqueError(e);
    throw e;
  }
  return getUser(ctx, userId)!;
}

export async function changePassword(ctx: Ctx, userId: string, sessionId: string, body: v.Json) {
  const current = typeof body.current === 'string' ? body.current : '';
  const next = v.password(body.next);
  const row = ctx.db.get('SELECT password_hash FROM users WHERE id = ?', userId);
  const key = `pwchange:user:${userId}`;
  const lock = checkLock(ctx, key);
  if (lock.locked) throw new AppError('auth.too_many_attempts', 429, { minutes: lock.minutes });
  if (!row || current.length > 128 || !(await verifyPassword(current, row.password_hash as string))) {
    const f = registerFailure(ctx, key, LOGIN_MAX, LOCK_MS);
    if (f.locked) throw new AppError('auth.too_many_attempts', 429, { minutes: f.minutes });
    throw new AppError('auth.wrong_password', 400);
  }
  if (current === next) throw new AppError('validation.password_same');
  resetAttempts(ctx, key);
  const hash = await hashPassword(next, ctx.cfg);
  ctx.db.tx(() => {
    ctx.db.run('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?', hash, iso(ctx.clock.now()), userId);
    // Құпия сөз өзгергенде басқа құрылғылардағы сессиялар жабылады
    ctx.db.run('DELETE FROM sessions WHERE user_id = ? AND id <> ?', userId, sessionId);
  });
}

/** Аватарды көруге рұқсат: өзі немесе ортақ жобадағы қатысушы. */
export function getAvatar(ctx: Ctx, viewerId: string, userId: string): { mime: string; data: Buffer } | null {
  if (viewerId !== userId) {
    const shared = ctx.db.get(
      `SELECT 1 FROM project_members a JOIN project_members b ON a.project_id = b.project_id WHERE a.user_id = ? AND b.user_id = ? LIMIT 1`,
      viewerId, userId,
    );
    if (!shared) return null;
  }
  const row = ctx.db.get('SELECT avatar_mime, avatar_data FROM profiles WHERE user_id = ?', userId);
  if (!row?.avatar_mime) return null;
  return { mime: row.avatar_mime as string, data: Buffer.from(row.avatar_data as Uint8Array) };
}
