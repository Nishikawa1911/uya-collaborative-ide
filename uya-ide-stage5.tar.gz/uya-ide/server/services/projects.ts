import { randomBytes, randomUUID } from 'node:crypto';
import { checkLock, registerFailure, resetAttempts } from '../attempts.ts';
import { iso, type Ctx } from '../context.ts';
import { AppError } from '../errors.ts';
import { generateInviteCode, hashInviteCode, isInviteFormat, normalizeInviteCode } from '../security.ts';
import * as v from '../validate.ts';
import { requireMember, requireOwner, roleOf, touchProject, type Role } from './access.ts';

export interface ProjectSummary {
  id: string; name: string; description: string; ownerId: string; ownerName: string; memberCount: number;
  languages: string[]; updatedAt: string; lastOpenedAt?: string; myRole: Role; entryPoint: string;
}
export interface MemberDto {
  userId: string; displayName: string; username: string; avatarColor: string; avatarUrl?: string;
  role: Role; online: boolean; activeFile?: string; cursorColor: string;
}
export interface SettingsDto {
  name: string; description: string; languages: string[]; entryPoint: string;
  joinRole: 'editor' | 'viewer'; inviteEnabled: boolean; maxMembers: number;
}

const INVITE_MAX = 5;
const INVITE_IP_MAX = 30;
const LOCK_MS = 15 * 60_000;

const SUMMARY_SQL = `
  SELECT p.id, p.name, p.description, p.owner_id, p.updated_at, s.languages, s.entry_point,
         m.role AS my_role, m.last_opened_at, pr.display_name AS owner_name,
         (SELECT COUNT(*) FROM project_members x WHERE x.project_id = p.id) AS member_count
  FROM projects p
  JOIN project_settings s ON s.project_id = p.id
  JOIN project_members m ON m.project_id = p.id AND m.user_id = ?
  JOIN profiles pr ON pr.user_id = p.owner_id`;

function toSummary(r: Record<string, any>): ProjectSummary {
  const s: ProjectSummary = {
    id: r.id, name: r.name, description: r.description, ownerId: r.owner_id, ownerName: r.owner_name,
    memberCount: Number(r.member_count), languages: JSON.parse(r.languages), updatedAt: r.updated_at,
    myRole: r.my_role, entryPoint: r.entry_point,
  };
  if (r.last_opened_at) s.lastOpenedAt = r.last_opened_at;
  return s;
}

export function summaryOf(ctx: Ctx, userId: string, projectId: string): ProjectSummary {
  const row = ctx.db.get(`${SUMMARY_SQL} WHERE p.id = ?`, userId, projectId);
  if (!row) throw new AppError('project.not_found', 404);
  return toSummary(row);
}

export function list(ctx: Ctx, userId: string, scope: string): ProjectSummary[] {
  if (!['mine', 'shared', 'recent'].includes(scope)) throw new AppError('validation.field_invalid');
  let where = '';
  let order = 'p.updated_at DESC';
  if (scope === 'mine') where = "WHERE m.role = 'owner'";
  else if (scope === 'shared') where = "WHERE m.role <> 'owner'";
  else { where = 'WHERE m.last_opened_at IS NOT NULL'; order = 'm.last_opened_at DESC'; }
  return ctx.db.all(`${SUMMARY_SQL} ${where} ORDER BY ${order} LIMIT 200`, userId).map(toSummary);
}

/** Жоба ашылғанда «соңғы ашылған» уақыты жаңарады. */
export function open(ctx: Ctx, userId: string, projectId: string): ProjectSummary {
  requireMember(ctx, userId, projectId);
  ctx.db.run('UPDATE project_members SET last_opened_at = ? WHERE project_id = ? AND user_id = ?', iso(ctx.clock.now()), projectId, userId);
  return summaryOf(ctx, userId, projectId);
}

const HELLO: Record<string, string> = {
  py: 'print("Сәлем, әлем!")\n',
  js: 'console.log("Сәлем, әлем!");\n',
  ts: 'const message: string = "Сәлем, әлем!";\nconsole.log(message);\n',
  java: 'public class Main {\n    public static void main(String[] args) {\n        System.out.println("Сәлем, әлем!");\n    }\n}\n',
  go: 'package main\n\nimport "fmt"\n\nfunc main() {\n\tfmt.Println("Сәлем, әлем!")\n}\n',
  cpp: '#include <iostream>\n\nint main() {\n    std::cout << "Сәлем, әлем!" << std::endl;\n    return 0;\n}\n',
  cs: 'Console.WriteLine("Сәлем, әлем!");\n',
  rs: 'fn main() {\n    println!("Сәлем, әлем!");\n}\n',
  php: '<?php\necho "Сәлем, әлем!" . PHP_EOL;\n',
  html: '<!doctype html>\n<html lang="kk">\n  <head><meta charset="utf-8" /><title>Сәлем</title></head>\n  <body><h1>Сәлем, әлем!</h1></body>\n</html>\n',
  css: 'body {\n  font-family: system-ui, sans-serif;\n}\n',
  sql: "SELECT 'Сәлем, әлем!' AS сәлемдесу;\n",
};

const newProjectId = () => randomBytes(8).toString('hex');

function insertInvitation(ctx: Ctx, projectId: string, userId: string): string {
  const code = generateInviteCode();
  ctx.db.run(
    'INSERT INTO project_invitations (id, project_id, code_hash, created_by, created_at) VALUES (?, ?, ?, ?, ?)',
    randomUUID(), projectId, hashInviteCode(code, ctx.cfg.invitePepper), userId, iso(ctx.clock.now()),
  );
  return code;
}

export function create(ctx: Ctx, userId: string, body: v.Json): { project: ProjectSummary; inviteCode: string } {
  const name = v.projectName(body.name);
  const desc = v.description(body.description);
  const langs = v.languages(body.languages);
  const parts = v.entryPoint(body.entryPoint, ctx.cfg.maxFolderDepth);
  const role = v.joinRole(body.joinRole ?? 'editor');
  const template = body.template === 'empty' ? 'empty' : 'hello';
  const now = iso(ctx.clock.now());
  const id = newProjectId();

  let inviteCode = '';
  ctx.db.tx(() => {
    const owned = Number(ctx.db.get('SELECT COUNT(*) AS c FROM projects WHERE owner_id = ?', userId)!.c);
    if (owned >= ctx.cfg.maxProjectsPerUser) throw new AppError('project.limit_reached', 409);
    ctx.db.run('INSERT INTO projects (id, owner_id, name, description, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)', id, userId, name, desc, now, now);
    ctx.db.run(
      'INSERT INTO project_settings (project_id, languages, entry_point, join_role, updated_at) VALUES (?, ?, ?, ?, ?)',
      id, JSON.stringify(langs), parts.join('/'), role, now,
    );
    ctx.db.run('INSERT INTO project_members (project_id, user_id, role, joined_at, last_opened_at) VALUES (?, ?, ?, ?, ?)', id, userId, 'owner', now, now);
    inviteCode = insertInvitation(ctx, id, userId);

    let parent: string | null = null;
    for (const dir of parts.slice(0, -1)) {
      const fid = randomUUID();
      ctx.db.run('INSERT INTO folders (id, project_id, parent_id, name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)', fid, id, parent, dir, now, now);
      parent = fid;
    }
    const fileName = parts[parts.length - 1];
    const ext = fileName.includes('.') ? fileName.split('.').pop()!.toLowerCase() : '';
    const content = template === 'hello' ? (HELLO[ext] ?? '') : '';
    ctx.db.run(
      'INSERT INTO files (id, project_id, folder_id, name, content, size_bytes, version, created_at, updated_at, updated_by) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)',
      randomUUID(), id, parent, fileName, content, Buffer.byteLength(content), now, now, userId,
    );
  });
  return { project: summaryOf(ctx, userId, id), inviteCode };
}

export function remove(ctx: Ctx, userId: string, projectId: string, body: v.Json) {
  requireOwner(ctx, userId, projectId);
  const p = ctx.db.get('SELECT name FROM projects WHERE id = ?', projectId)!;
  if (body.confirmName !== p.name) throw new AppError('project.confirm_mismatch', 400);
  ctx.db.run('DELETE FROM projects WHERE id = ?', projectId); // CASCADE: қатысушылар, шақырулар, файлдар, баптаулар
  ctx.bus.publish(projectId, { type: 'project.deleted' });
}

// ── Баптаулар ─────────────────────────────────────────────
export function getSettings(ctx: Ctx, userId: string, projectId: string): SettingsDto {
  requireOwner(ctx, userId, projectId);
  return settingsOf(ctx, projectId);
}

function settingsOf(ctx: Ctx, projectId: string): SettingsDto {
  const r = ctx.db.get(
    `SELECT p.name, p.description, s.languages, s.entry_point, s.join_role, s.invite_enabled, s.max_members
     FROM projects p JOIN project_settings s ON s.project_id = p.id WHERE p.id = ?`, projectId)!;
  return {
    name: r.name, description: r.description, languages: JSON.parse(r.languages), entryPoint: r.entry_point,
    joinRole: r.join_role, inviteEnabled: !!r.invite_enabled, maxMembers: Number(r.max_members),
  };
}

export function updateSettings(ctx: Ctx, userId: string, projectId: string, body: v.Json): SettingsDto {
  requireOwner(ctx, userId, projectId);
  const now = iso(ctx.clock.now());
  const has = (k: string) => Object.prototype.hasOwnProperty.call(body, k);
  ctx.db.tx(() => {
    if (has('name')) ctx.db.run('UPDATE projects SET name = ? WHERE id = ?', v.projectName(body.name), projectId);
    if (has('description')) ctx.db.run('UPDATE projects SET description = ? WHERE id = ?', v.description(body.description), projectId);
    if (has('languages')) ctx.db.run('UPDATE project_settings SET languages = ? WHERE project_id = ?', JSON.stringify(v.languages(body.languages)), projectId);
    if (has('entryPoint')) ctx.db.run('UPDATE project_settings SET entry_point = ? WHERE project_id = ?', v.entryPoint(body.entryPoint, ctx.cfg.maxFolderDepth).join('/'), projectId);
    if (has('joinRole')) ctx.db.run('UPDATE project_settings SET join_role = ? WHERE project_id = ?', v.joinRole(body.joinRole), projectId);
    if (has('inviteEnabled')) ctx.db.run('UPDATE project_settings SET invite_enabled = ? WHERE project_id = ?', v.bool(body.inviteEnabled) ? 1 : 0, projectId);
    if (has('maxMembers')) {
      const n = v.maxMembers(body.maxMembers);
      const cur = Number(ctx.db.get('SELECT COUNT(*) AS c FROM project_members WHERE project_id = ?', projectId)!.c);
      if (n < cur) throw new AppError('validation.max_members_invalid');
      ctx.db.run('UPDATE project_settings SET max_members = ? WHERE project_id = ?', n, projectId);
    }
    ctx.db.run('UPDATE project_settings SET updated_at = ? WHERE project_id = ?', now, projectId);
    touchProject(ctx, projectId, now);
  });
  ctx.bus.publish(projectId, { type: 'project.updated' });
  return settingsOf(ctx, projectId);
}

// ── Шақыру ────────────────────────────────────────────────
export function rotateInvite(ctx: Ctx, userId: string, projectId: string): { inviteCode: string } {
  requireOwner(ctx, userId, projectId);
  return ctx.db.tx(() => {
    ctx.db.run('UPDATE project_invitations SET revoked_at = ? WHERE project_id = ? AND revoked_at IS NULL', iso(ctx.clock.now()), projectId);
    return { inviteCode: insertInvitation(ctx, projectId, userId) };
  });
}

export function join(ctx: Ctx, userId: string, ip: string, body: v.Json): { project: ProjectSummary; role: Role } {
  const userKey = `invite:user:${userId}`;
  const ipKey = `invite:ip:${ip}`;
  for (const k of [userKey, ipKey]) {
    const l = checkLock(ctx, k);
    if (l.locked) throw new AppError('project.invite_rate_limited', 429, { minutes: l.minutes });
  }
  const raw = typeof body.code === 'string' ? body.code.slice(0, 64) : '';
  const normalized = normalizeInviteCode(raw);

  const fail = (): never => {
    const a = registerFailure(ctx, userKey, INVITE_MAX, LOCK_MS);
    const b = registerFailure(ctx, ipKey, INVITE_IP_MAX, LOCK_MS);
    if (a.locked || b.locked) throw new AppError('project.invite_rate_limited', 429, { minutes: Math.max(a.minutes, b.minutes) });
    throw new AppError('project.invalid_invite', 404, { left: a.left });
  };

  if (!isInviteFormat(normalized)) return fail();
  const hash = hashInviteCode(normalized, ctx.cfg.invitePepper);
  const now = ctx.clock.now();
  const inv = ctx.db.get(
    `SELECT i.id, i.project_id, i.expires_at, s.join_role, s.invite_enabled, s.max_members
     FROM project_invitations i JOIN project_settings s ON s.project_id = i.project_id
     WHERE i.code_hash = ? AND i.revoked_at IS NULL`, hash);
  if (!inv || !inv.invite_enabled || (inv.expires_at && Date.parse(inv.expires_at as string) <= now)) return fail();

  const projectId = inv.project_id as string;
  resetAttempts(ctx, userKey);
  if (roleOf(ctx, userId, projectId)) throw new AppError('project.already_member', 409);

  const role = inv.join_role as 'editor' | 'viewer';
  ctx.db.tx(() => {
    const count = Number(ctx.db.get('SELECT COUNT(*) AS c FROM project_members WHERE project_id = ?', projectId)!.c);
    if (count >= Number(inv.max_members)) throw new AppError('project.member_limit', 409);
    ctx.db.run('INSERT INTO project_members (project_id, user_id, role, joined_at, last_opened_at) VALUES (?, ?, ?, ?, ?)', projectId, userId, role, iso(now), iso(now));
    ctx.db.run('UPDATE project_invitations SET use_count = use_count + 1 WHERE id = ?', inv.id);
  });
  ctx.bus.publish(projectId, { type: 'members.changed' });
  return { project: summaryOf(ctx, userId, projectId), role };
}

// ── Қатысушылар ───────────────────────────────────────────
export function members(ctx: Ctx, userId: string, projectId: string): MemberDto[] {
  requireMember(ctx, userId, projectId);
  const rows = ctx.db.all(
    `SELECT m.user_id, m.role, u.username, p.display_name, p.avatar_color, p.cursor_color, p.avatar_mime, p.avatar_version
     FROM project_members m JOIN users u ON u.id = m.user_id JOIN profiles p ON p.user_id = m.user_id
     WHERE m.project_id = ?
     ORDER BY CASE m.role WHEN 'owner' THEN 0 WHEN 'editor' THEN 1 ELSE 2 END, p.display_name COLLATE NOCASE`, projectId);
  return rows.map((r) => {
    const dto: MemberDto = {
      userId: r.user_id, displayName: r.display_name, username: r.username, avatarColor: r.avatar_color,
      role: r.role, online: false, cursorColor: r.cursor_color,
    };
    if (r.avatar_mime) dto.avatarUrl = `/api/users/${r.user_id}/avatar?v=${r.avatar_version}`;
    return dto;
  });
}

export function setMemberRole(ctx: Ctx, actorId: string, projectId: string, targetId: string, body: v.Json) {
  requireOwner(ctx, actorId, projectId);
  const role = v.memberRole(body.role);
  const target = roleOf(ctx, targetId, projectId);
  if (!target) throw new AppError('project.member_not_found', 404);
  if (target === 'owner') throw new AppError('project.owner_immutable', 409);
  ctx.db.run('UPDATE project_members SET role = ? WHERE project_id = ? AND user_id = ?', role, projectId, targetId);
  ctx.bus.publish(projectId, { type: 'member.role', userId: targetId, role });
}

/** Иесі басқаларды шығара алады; қатысушы өзін шығара алады («жобадан шығу»). Иесін шығаруға болмайды. */
export function removeMember(ctx: Ctx, actorId: string, projectId: string, targetId: string) {
  const actor = requireMember(ctx, actorId, projectId);
  const target = roleOf(ctx, targetId, projectId);
  if (!target) throw new AppError('project.member_not_found', 404);
  if (target === 'owner') throw new AppError('project.owner_immutable', 409);
  if (actor !== 'owner' && actorId !== targetId) throw new AppError('permission.denied', 403);
  ctx.db.run('DELETE FROM project_members WHERE project_id = ? AND user_id = ?', projectId, targetId);
  ctx.bus.publish(projectId, { type: 'member.removed', userId: targetId });
}
