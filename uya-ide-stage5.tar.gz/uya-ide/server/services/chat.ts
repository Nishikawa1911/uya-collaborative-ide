import { iso, type Ctx } from '../context.ts';
import { AppError } from '../errors.ts';
import { requireMember } from './access.ts';

export interface ChatDto { id: string; seq: number; userId: string | null; authorName: string; body: string; createdAt: string }

const toDto = (r: Record<string, any>): ChatDto => ({
  id: r.id, seq: Number(r.seq), userId: r.user_id ?? null, authorName: r.author_name, body: r.body, createdAt: r.created_at,
});

/** Хабарлама мәтінін тексеріп, тазалайды (сыртқы бос орындар, басқару таңбалары). */
export function cleanBody(v: unknown): string {
  if (typeof v !== 'string') throw new AppError('chat.empty');
  // eslint-disable-next-line no-control-regex
  const s = v.normalize('NFC').replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  if (!s) throw new AppError('chat.empty');
  if ([...s].length > 2000) throw new AppError('chat.too_long');
  return s;
}

/** Тарих: ескіден жаңаға қарай ретпен; `before` — осы seq-тен ескілері. */
export function history(ctx: Ctx, userId: string, projectId: string, beforeRaw: string | null, limitRaw: string | null): { messages: ChatDto[]; hasMore: boolean } {
  requireMember(ctx, userId, projectId);
  const limit = Math.min(100, Math.max(1, Number.isFinite(Number(limitRaw)) && limitRaw ? Math.trunc(Number(limitRaw)) : 50));
  const before = beforeRaw && Number.isFinite(Number(beforeRaw)) ? Math.trunc(Number(beforeRaw)) : Number.MAX_SAFE_INTEGER;
  const rows = ctx.db.all('SELECT * FROM chat_messages WHERE project_id = ? AND seq < ? ORDER BY seq DESC LIMIT ?', projectId, before, limit + 1);
  const hasMore = rows.length > limit;
  return { messages: rows.slice(0, limit).reverse().map(toDto), hasMore };
}

/** Хабарламаны сақтайды. Бірдей `clientMsgId` қайта келсе (қайта қосылу), бұрынғы жазба қайтарылады. */
export function post(ctx: Ctx, projectId: string, user: { id: string; name: string }, body: string, clientMsgId: string): { message: ChatDto; fresh: boolean } {
  const id = `${user.id}.${clientMsgId}`;
  return ctx.db.tx(() => {
    const ex = ctx.db.get('SELECT * FROM chat_messages WHERE id = ?', id);
    if (ex) return { message: toDto(ex), fresh: false };
    ctx.db.run('INSERT INTO chat_messages (id, project_id, user_id, author_name, body, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      id, projectId, user.id, user.name, body, iso(ctx.clock.now()));
    return { message: toDto(ctx.db.get('SELECT * FROM chat_messages WHERE id = ?', id)!), fresh: true };
  });
}
