/** Веб-алдын ала қарау: HTML/CSS/JS жобасын ЕШҚАНДАЙ код орындамай, бір қауіпсіз құжатқа біріктіреді.
 *  Орындау браузерде, оқшауланған iframe ішінде (sandbox="allow-scripts", allow-same-origin жоқ → бөтен «origin»)
 *  және CSP арқылы желіге шығу тыйым салынған. */
import type { Ctx } from '../context.ts';
import { AppError } from '../errors.ts';
import { requireMember } from './access.ts';

export const PREVIEW_CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; media-src data: blob:; connect-src 'none'; form-action 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'";
const MAX_HTML_BYTES = 2 * 1024 * 1024;

export interface PreviewResult { html: string; entry: string; csp: string; external: string[]; missing: string[] }

interface FileRow { path: string; content: string }

export function projectFiles(ctx: Ctx, projectId: string): FileRow[] {
  const folders = new Map<string, { parent: string | null; name: string }>();
  for (const r of ctx.db.all('SELECT id, parent_id, name FROM folders WHERE project_id = ?', projectId)) folders.set(r.id, { parent: r.parent_id ?? null, name: r.name });
  const pathOf = (folderId: string | null, name: string): string => {
    const parts = [name];
    let cur = folderId; let guard = 0;
    while (cur && guard++ < 64) { const f = folders.get(cur); if (!f) break; parts.unshift(f.name); cur = f.parent; }
    return parts.join('/');
  };
  return ctx.db.all('SELECT folder_id, name, content FROM files WHERE project_id = ?', projectId)
    .map((r): FileRow => ({ path: pathOf(r.folder_id ?? null, r.name), content: r.content }));
}

const norm = (base: string, ref: string): string | null => {
  const clean = ref.split('#')[0].split('?')[0];
  if (!clean || /^[a-z][a-z0-9+.-]*:/i.test(clean) || clean.startsWith('//')) return null;
  const parts = (clean.startsWith('/') ? clean.slice(1) : (base ? base + '/' : '') + clean).split('/');
  const out: string[] = [];
  for (const p of parts) { if (p === '' || p === '.') continue; if (p === '..') { if (!out.length) return '\0'; out.pop(); } else out.push(p); }
  return out.join('/');
};
const isExternal = (ref: string) => /^([a-z][a-z0-9+.-]*:|\/\/)/i.test(ref.trim()) && !/^data:/i.test(ref.trim());
const attr = (tag: string, name: string): string | null => {
  const m = new RegExp(`\\s${name}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i').exec(tag);
  return m ? (m[2] ?? m[3] ?? m[4] ?? '') : null;
};

const BRIDGE = `<script>(function(){function s(l,a){try{parent.postMessage({uya:'preview-console',level:l,text:Array.prototype.map.call(a,function(x){try{return typeof x==='string'?x:(x instanceof Error?x.stack||String(x):JSON.stringify(x))}catch(e){return String(x)}}).join(' ')},'*')}catch(e){}}
['log','info','warn','error','debug'].forEach(function(k){var o=console[k];console[k]=function(){s(k,arguments);try{o.apply(console,arguments)}catch(e){}}});
addEventListener('error',function(e){s('error',[e.message+(e.lineno?' ('+e.lineno+':'+e.colno+')':'')])});
addEventListener('unhandledrejection',function(e){s('error',['Unhandled promise rejection: '+(e.reason&&e.reason.message||e.reason)])});})();</script>`;

export function buildPreview(files: FileRow[], entry: string): PreviewResult {
  const byPath = new Map(files.map((f) => [f.path, f.content]));
  const src = byPath.get(entry);
  if (src == null) throw new AppError('run.not_web', 400);
  const dir = entry.includes('/') ? entry.slice(0, entry.lastIndexOf('/')) : '';
  const external: string[] = []; const missing: string[] = [];
  const lookup = (ref: string): string | null | undefined => {
    if (isExternal(ref)) { external.push(ref); return null; }
    const p = norm(dir, ref);
    if (p == null) return null;
    const c = p === '\0' ? undefined : byPath.get(p);
    if (c === undefined) missing.push(ref);
    return c;
  };
  let html = src;
  html = html.replace(/<link\b[^>]*>/gi, (tag) => {
    if (!/\srel\s*=\s*["']?stylesheet/i.test(tag)) return tag;
    const href = attr(tag, 'href'); if (href == null) return tag;
    const c = lookup(href);
    return c == null ? tag : `<style data-src="${href.replace(/"/g, '')}">${c.replace(/<\/style/gi, '<\\/style')}</style>`;
  });
  html = html.replace(/<script\b([^>]*)>\s*<\/script>/gi, (full, attrs: string) => {
    const s = attr(`<script ${attrs}>`, 'src'); if (s == null) return full;
    const c = lookup(s);
    if (c == null) return full;
    const type = attr(`<script ${attrs}>`, 'type');
    return `<script${type ? ` type="${type.replace(/"/g, '')}"` : ''} data-src="${s.replace(/"/g, '')}">${c.replace(/<\/script/gi, '<\\/script')}</script>`;
  });
  html = html.replace(/<(img|source)\b[^>]*>/gi, (tag) => {
    const s = attr(tag, 'src'); if (s == null) return tag;
    if (!/\.svg$/i.test(s.split(/[?#]/)[0])) { if (isExternal(s)) external.push(s); return tag; }
    const c = lookup(s); if (c == null) return tag;
    return tag.replace(s, `data:image/svg+xml;base64,${Buffer.from(c, 'utf8').toString('base64')}`);
  });
  const inject = `<meta http-equiv="Content-Security-Policy" content="${PREVIEW_CSP}">${BRIDGE}`;
  if (/<head\b[^>]*>/i.test(html)) html = html.replace(/<head\b[^>]*>/i, (m) => m + inject);
  else if (/<html\b[^>]*>/i.test(html)) html = html.replace(/<html\b[^>]*>/i, (m) => `${m}<head>${inject}</head>`);
  else html = `<!doctype html><html><head><meta charset="utf-8">${inject}</head><body>${html}</body></html>`;
  if (Buffer.byteLength(html, 'utf8') > MAX_HTML_BYTES) throw new AppError('run.project_too_large', 413);
  return { html, entry, csp: PREVIEW_CSP, external: [...new Set(external)], missing: [...new Set(missing)] };
}

export function preview(ctx: Ctx, userId: string, projectId: string, wantedPath: string | null): PreviewResult {
  requireMember(ctx, userId, projectId);
  ctx.bus.flush?.(projectId);
  const files = projectFiles(ctx, projectId);
  const htmls = files.filter((f) => /\.html?$/i.test(f.path)).map((f) => f.path);
  const settings = ctx.db.get('SELECT entry_point FROM project_settings WHERE project_id = ?', projectId);
  const pick = (wantedPath && htmls.includes(wantedPath) ? wantedPath : null)
    ?? (settings?.entry_point && htmls.includes(settings.entry_point) ? settings.entry_point as string : null)
    ?? htmls.find((p) => /(^|\/)index\.html?$/i.test(p)) ?? htmls[0] ?? null;
  if (!pick) throw new AppError('run.not_web', 400);
  return buildPreview(files, pick);
}
