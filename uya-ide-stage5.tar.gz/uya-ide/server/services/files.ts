import { randomUUID } from 'node:crypto';
import { iso, type Ctx } from '../context.ts';
import { AppError } from '../errors.ts';
import * as v from '../validate.ts';
import { requireEditor, requireMember, touchProject } from './access.ts';

export interface FsNode { id: string; parentId: string | null; name: string; kind: 'file' | 'folder' }

type Found = { kind: 'file' | 'folder'; id: string; parentId: string | null; name: string };

function findNode(ctx: Ctx, projectId: string, nodeId: string): Found {
  const f = ctx.db.get('SELECT id, folder_id, name FROM files WHERE id = ? AND project_id = ?', nodeId, projectId);
  if (f) return { kind: 'file', id: f.id, parentId: f.folder_id ?? null, name: f.name };
  const d = ctx.db.get('SELECT id, parent_id, name FROM folders WHERE id = ? AND project_id = ?', nodeId, projectId);
  if (d) return { kind: 'folder', id: d.id, parentId: d.parent_id ?? null, name: d.name };
  throw new AppError('file.not_found', 404);
}

function nameTaken(ctx: Ctx, projectId: string, parentId: string | null, name: string, exceptId?: string): boolean {
  const p = parentId ?? '';
  const f = ctx.db.get('SELECT 1 FROM files WHERE project_id = ? AND COALESCE(folder_id, \'\') = ? AND name = ? AND id <> ?', projectId, p, name, exceptId ?? '');
  const d = ctx.db.get('SELECT 1 FROM folders WHERE project_id = ? AND COALESCE(parent_id, \'\') = ? AND name = ? AND id <> ?', projectId, p, name, exceptId ?? '');
  return !!(f || d);
}

function depthOf(ctx: Ctx, folderId: string | null): number {
  if (!folderId) return 0;
  const r = ctx.db.get(
    `WITH RECURSIVE up(id, parent_id, d) AS (
       SELECT id, parent_id, 1 FROM folders WHERE id = ?
       UNION ALL SELECT f.id, f.parent_id, up.d + 1 FROM folders f JOIN up ON f.id = up.parent_id)
     SELECT MAX(d) AS d FROM up`, folderId);
  return Number(r?.d ?? 0);
}

export function tree(ctx: Ctx, userId: string, projectId: string): FsNode[] {
  requireMember(ctx, userId, projectId);
  const folders = ctx.db.all('SELECT id, parent_id, name FROM folders WHERE project_id = ?', projectId)
    .map((r): FsNode => ({ id: r.id, parentId: r.parent_id ?? null, name: r.name, kind: 'folder' }));
  const files = ctx.db.all('SELECT id, folder_id, name FROM files WHERE project_id = ?', projectId)
    .map((r): FsNode => ({ id: r.id, parentId: r.folder_id ?? null, name: r.name, kind: 'file' }));
  return [...folders, ...files];
}

export function read(ctx: Ctx, userId: string, projectId: string, nodeId: string): { content: string; version: number } {
  requireMember(ctx, userId, projectId);
  const r = ctx.db.get('SELECT content, version FROM files WHERE id = ? AND project_id = ?', nodeId, projectId);
  if (!r) {
    const isFolder = ctx.db.get('SELECT 1 FROM folders WHERE id = ? AND project_id = ?', nodeId, projectId);
    throw new AppError(isFolder ? 'file.not_a_file' : 'file.not_found', isFolder ? 400 : 404);
  }
  return { content: r.content as string, version: Number(r.version) };
}

export function save(ctx: Ctx, userId: string, projectId: string, nodeId: string, body: v.Json): { version: number } {
  requireEditor(ctx, userId, projectId);
  if (typeof body.content !== 'string') throw new AppError('validation.field_invalid');
  const content = body.content;
  const bytes = Buffer.byteLength(content, 'utf8');
  if (bytes > ctx.cfg.maxFileBytes) throw new AppError('file.too_large', 413);
  if (content.includes('\u0000')) throw new AppError('file.invalid_content');
  const now = iso(ctx.clock.now());
  // Ашық бірлескен құжат болса, мазмұн CRDT арқылы біріктіріледі (басқалардың өзгерісін өшірмейді)
  const handled = ctx.bus.mergeRestSave?.(projectId, nodeId, content, userId);
  if (handled) return handled;
  return ctx.db.tx(() => {
    const r = ctx.db.run(
      'UPDATE files SET content = ?, size_bytes = ?, version = version + 1, updated_at = ?, updated_by = ? WHERE id = ? AND project_id = ?',
      content, bytes, now, userId, nodeId, projectId,
    );
    if (r.changes === 0) {
      const isFolder = ctx.db.get('SELECT 1 FROM folders WHERE id = ? AND project_id = ?', nodeId, projectId);
      throw new AppError(isFolder ? 'file.not_a_file' : 'file.not_found', isFolder ? 400 : 404);
    }
    touchProject(ctx, projectId, now);
    return { version: Number(ctx.db.get('SELECT version FROM files WHERE id = ?', nodeId)!.version) };
  });
}

export function create(ctx: Ctx, userId: string, projectId: string, body: v.Json): FsNode {
  requireEditor(ctx, userId, projectId);
  const kind = body.kind;
  if (kind !== 'file' && kind !== 'folder') throw new AppError('validation.field_invalid');
  const name = v.nodeName(body.name);
  const parentId = body.parentId == null ? null : typeof body.parentId === 'string' ? body.parentId : (() => { throw new AppError('file.parent_invalid'); })();
  const now = iso(ctx.clock.now());
  const id = randomUUID();

  ctx.db.tx(() => {
    if (parentId) {
      const parent = ctx.db.get('SELECT 1 FROM folders WHERE id = ? AND project_id = ?', parentId, projectId);
      if (!parent) throw new AppError('file.parent_invalid', 400);
      if (depthOf(ctx, parentId) + (kind === 'folder' ? 1 : 0) > ctx.cfg.maxFolderDepth) throw new AppError('file.too_deep', 400);
    }
    const count = Number(ctx.db.get(
      'SELECT (SELECT COUNT(*) FROM files WHERE project_id = ?) + (SELECT COUNT(*) FROM folders WHERE project_id = ?) AS c', projectId, projectId)!.c);
    if (count >= ctx.cfg.maxNodesPerProject) throw new AppError('file.limit_reached', 409);
    if (nameTaken(ctx, projectId, parentId, name)) throw new AppError('file.exists', 409);
    if (kind === 'folder') {
      ctx.db.run('INSERT INTO folders (id, project_id, parent_id, name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)', id, projectId, parentId, name, now, now);
    } else {
      ctx.db.run(
        'INSERT INTO files (id, project_id, folder_id, name, content, size_bytes, version, created_at, updated_at, updated_by) VALUES (?, ?, ?, ?, \'\', 0, 1, ?, ?, ?)',
        id, projectId, parentId, name, now, now, userId,
      );
    }
    touchProject(ctx, projectId, now);
  });
  const node: FsNode = { id, parentId, name, kind };
  ctx.bus.publish(projectId, { type: 'fs.created', node, by: userId });
  return node;
}

export function rename(ctx: Ctx, userId: string, projectId: string, nodeId: string, body: v.Json): FsNode {
  requireEditor(ctx, userId, projectId);
  const name = v.nodeName(body.name);
  const now = iso(ctx.clock.now());
  const result = ctx.db.tx(() => {
    const node = findNode(ctx, projectId, nodeId);
    if (node.name !== name && nameTaken(ctx, projectId, node.parentId, name, nodeId)) throw new AppError('file.exists', 409);
    ctx.db.run(`UPDATE ${node.kind === 'file' ? 'files' : 'folders'} SET name = ?, updated_at = ? WHERE id = ? AND project_id = ?`, name, now, nodeId, projectId);
    touchProject(ctx, projectId, now);
    return { id: node.id, parentId: node.parentId, name, kind: node.kind } as FsNode;
  });
  ctx.bus.publish(projectId, { type: 'fs.renamed', node: result, by: userId });
  return result;
}

export function remove(ctx: Ctx, userId: string, projectId: string, nodeId: string) {
  requireEditor(ctx, userId, projectId);
  const gone = ctx.db.tx(() => {
    const node = findNode(ctx, projectId, nodeId);
    let fileIds: string[] = [];
    if (node.kind === 'file') fileIds = [node.id];
    else {
      fileIds = ctx.db.all(
        `WITH RECURSIVE sub(id) AS (SELECT id FROM folders WHERE id = ? AND project_id = ?
           UNION ALL SELECT f.id FROM folders f JOIN sub ON f.parent_id = sub.id)
         SELECT id FROM files WHERE project_id = ? AND folder_id IN (SELECT id FROM sub)`, nodeId, projectId, projectId).map((r) => r.id as string);
    }
    ctx.db.run(`DELETE FROM ${node.kind === 'file' ? 'files' : 'folders'} WHERE id = ? AND project_id = ?`, nodeId, projectId); // қалта: CASCADE
    touchProject(ctx, projectId, iso(ctx.clock.now()));
    return { id: node.id, kind: node.kind, fileIds };
  });
  ctx.bus.publish(projectId, { type: 'fs.deleted', ...gone, by: userId });
}
