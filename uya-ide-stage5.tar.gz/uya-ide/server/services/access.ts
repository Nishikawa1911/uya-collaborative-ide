import type { Ctx } from '../context.ts';
import { AppError } from '../errors.ts';

export type Role = 'owner' | 'editor' | 'viewer';

export function roleOf(ctx: Ctx, userId: string, projectId: string): Role | null {
  const r = ctx.db.get('SELECT role FROM project_members WHERE project_id = ? AND user_id = ?', projectId, userId);
  return (r?.role as Role | undefined) ?? null;
}

/** Қатысушы емес пайдаланушыға жоба «жоқ» болып көрінеді (404): жоба бар-жоғын жасырады. */
export function requireMember(ctx: Ctx, userId: string, projectId: string): Role {
  const role = roleOf(ctx, userId, projectId);
  if (!role) throw new AppError('project.not_found', 404);
  return role;
}

export function requireEditor(ctx: Ctx, userId: string, projectId: string): Role {
  const role = requireMember(ctx, userId, projectId);
  if (role === 'viewer') throw new AppError('permission.denied', 403);
  return role;
}

export function requireOwner(ctx: Ctx, userId: string, projectId: string): void {
  if (requireMember(ctx, userId, projectId) !== 'owner') throw new AppError('permission.denied', 403);
}

export function touchProject(ctx: Ctx, projectId: string, iso: string) {
  ctx.db.run('UPDATE projects SET updated_at = ? WHERE id = ?', iso, projectId);
}
