import { createApp } from './app.ts';

const app = createApp();
const port = await app.listen();
console.log(`Ұя IDE сервері дайын: http://${app.ctx.cfg.host}:${port}  (дерекқор: ${app.ctx.cfg.dbPath})`);

for (const sig of ['SIGINT', 'SIGTERM'] as const) {
  process.on(sig, async () => { console.log('\nСервер тоқтатылуда…'); await app.close(); process.exit(0); });
}
