import { loadConfig } from './config.ts';
import { Db, migrate } from './db.ts';

const cfg = loadConfig();
const db = new Db(cfg.dbPath);
const r = migrate(db);
console.log(`Дерекқор: ${cfg.dbPath}`);
console.log(r.applied.length ? `Қолданылды: ${r.applied.join(', ')}` : 'Жаңа миграция жоқ.');
if (r.skipped.length) console.log(`Бұрын қолданылған: ${r.skipped.join(', ')}`);
db.close();
