import type { Ctx } from './context.ts';
import { iso } from './context.ts';

export interface LockState { locked: boolean; minutes: number }

/** Тұрақты (DB-да сақталатын) сәтсіз әрекеттер санауышы: brute-force қорғанысы. */
export function checkLock(ctx: Ctx, key: string): LockState {
  const row = ctx.db.get('SELECT locked_until FROM auth_attempts WHERE key = ?', key);
  const until = row?.locked_until ? Date.parse(row.locked_until as string) : 0;
  const now = ctx.clock.now();
  if (until > now) return { locked: true, minutes: Math.max(1, Math.ceil((until - now) / 60_000)) };
  return { locked: false, minutes: 0 };
}

/** Сәтсіз әрекетті тіркейді. `max` жеткенде `lockMs` уақытқа бұғаттайды. */
export function registerFailure(ctx: Ctx, key: string, max: number, lockMs: number): { locked: boolean; left: number; minutes: number } {
  return ctx.db.tx(() => {
    const now = ctx.clock.now();
    const row = ctx.db.get('SELECT failures, first_failed FROM auth_attempts WHERE key = ?', key);
    let failures = 0;
    let first = now;
    // Терезе мерзімі өткен болса, санауыш қайта басталады
    if (row?.first_failed && now - Date.parse(row.first_failed as string) < lockMs) {
      failures = Number(row.failures);
      first = Date.parse(row.first_failed as string);
    }
    failures += 1;
    if (failures >= max) {
      ctx.db.run(
        `INSERT INTO auth_attempts (key, failures, first_failed, locked_until) VALUES (?, 0, NULL, ?)
         ON CONFLICT(key) DO UPDATE SET failures = 0, first_failed = NULL, locked_until = excluded.locked_until`,
        key, iso(now + lockMs),
      );
      return { locked: true, left: 0, minutes: Math.ceil(lockMs / 60_000) };
    }
    ctx.db.run(
      `INSERT INTO auth_attempts (key, failures, first_failed, locked_until) VALUES (?, ?, ?, NULL)
       ON CONFLICT(key) DO UPDATE SET failures = excluded.failures, first_failed = excluded.first_failed`,
      key, failures, iso(first),
    );
    return { locked: false, left: max - failures, minutes: 0 };
  });
}

export function resetAttempts(ctx: Ctx, key: string) {
  ctx.db.run('DELETE FROM auth_attempts WHERE key = ?', key);
}
