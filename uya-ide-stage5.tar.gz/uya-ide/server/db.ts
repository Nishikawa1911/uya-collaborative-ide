import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const MIGRATIONS_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'migrations');

export type Row = Record<string, any>;

/** node:sqlite үстіндегі жұқа қабат: типтелген сұраулар және транзакциялар. */
export class Db {
  raw: DatabaseSync;
  private depth = 0;

  constructor(file: string) {
    if (file !== ':memory:') mkdirSync(path.dirname(file), { recursive: true });
    this.raw = new DatabaseSync(file);
    this.raw.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
    if (file !== ':memory:') this.raw.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL;');
  }

  get(sql: string, ...params: any[]): Row | undefined {
    return this.raw.prepare(sql).get(...params) as Row | undefined;
  }
  all(sql: string, ...params: any[]): Row[] {
    return this.raw.prepare(sql).all(...params) as Row[];
  }
  run(sql: string, ...params: any[]): { changes: number } {
    const r = this.raw.prepare(sql).run(...params);
    return { changes: Number(r.changes) };
  }
  exec(sql: string) { this.raw.exec(sql); }

  /** Синхронды транзакция (BEGIN IMMEDIATE). Ішінде `await` болмауы керек. Ішкі шақырулар SAVEPOINT қолданады. */
  tx<T>(fn: () => T): T {
    if (this.depth > 0) {
      const sp = `sp${this.depth}`;
      this.raw.exec(`SAVEPOINT ${sp}`);
      this.depth++;
      try { const r = fn(); this.raw.exec(`RELEASE ${sp}`); return r; }
      catch (e) { this.raw.exec(`ROLLBACK TO ${sp}; RELEASE ${sp}`); throw e; }
      finally { this.depth--; }
    }
    this.raw.exec('BEGIN IMMEDIATE');
    this.depth++;
    try { const r = fn(); this.raw.exec('COMMIT'); return r; }
    catch (e) { this.raw.exec('ROLLBACK'); throw e; }
    finally { this.depth--; }
  }

  close() { this.raw.close(); }
}

export interface MigrationResult { applied: string[]; skipped: string[] }

/** Миграцияларды реті бойынша қолданады; қолданылғандарының чек-сомасын тексереді. */
export function migrate(db: Db, dir = MIGRATIONS_DIR): MigrationResult {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at TEXT NOT NULL
  )`);
  const files = readdirSync(dir).filter((f) => /^\d+_.+\.sql$/.test(f)).sort();
  const done = new Map(db.all('SELECT version, checksum FROM schema_migrations').map((r) => [r.version as string, r.checksum as string]));
  const result: MigrationResult = { applied: [], skipped: [] };
  for (const f of files) {
    const sql = readFileSync(path.join(dir, f), 'utf8');
    const checksum = createHash('sha256').update(sql).digest('hex');
    const prev = done.get(f);
    if (prev) {
      if (prev !== checksum) throw new Error(`Миграция өзгертілген: ${f}. Қолданылған миграцияны өңдеуге болмайды — жаңасын қосыңыз.`);
      result.skipped.push(f);
      continue;
    }
    // PRAGMA foreign_keys транзакция ішінде жұмыс істемейді, сондықтан миграция схеманы ғана өзгертеді
    db.tx(() => {
      db.exec(sql);
      db.run('INSERT INTO schema_migrations (version, checksum, applied_at) VALUES (?, ?, ?)', f, checksum, new Date().toISOString());
    });
    result.applied.push(f);
  }
  return result;
}
