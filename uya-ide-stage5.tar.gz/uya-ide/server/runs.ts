/** Орындау менеджері: тексеру → кезек → runner → нәтиже дерекқорға. Пайдаланушы коды БҰЛ процесте ешқашан орындалмайды. */
import { randomUUID } from 'node:crypto';
import { iso, type Ctx } from './context.ts';
import { AppError } from './errors.ts';
import { projectFiles } from './services/preview.ts';
import { requireEditor, requireMember, roleOf } from './services/access.ts';
import type { RunnerClient, RunnerEvent, RunnerLang } from './runner-client.ts';

export type RunStatus = 'queued' | 'running' | 'ok' | 'error' | 'compile_error' | 'timeout' | 'killed' | 'memory_limit' | 'output_limit' | 'internal_error';
const TERMINAL = new Set<RunStatus>(['ok', 'error', 'compile_error', 'timeout', 'killed', 'memory_limit', 'output_limit', 'internal_error']);

const EXT_LANG: Record<string, string> = {
  py: 'python', java: 'java', cpp: 'cpp', cc: 'cpp', cxx: 'cpp', cs: 'csharp', rs: 'rust', php: 'php', ts: 'typescript',
  js: 'javascript', mjs: 'javascript', go: 'go', sql: 'sql',
};
const WEB_EXT = new Set(['html', 'htm', 'css']);
export const langOf = (p: string) => EXT_LANG[/\.([A-Za-z0-9]+)$/.exec(p)?.[1]?.toLowerCase() ?? ''] ?? null;

export interface RunView {
  id: string; projectId: string; userId: string | null; mode: 'file' | 'project' | 'sql'; entryPath: string; language: string;
  status: RunStatus; phase: string | null; exitCode: number | null; signal: string | null; durationMs: number | null;
  truncated: boolean; message: string | null; createdAt: string; startedAt: string | null; finishedAt: string | null;
  queuePosition?: number;
}
export interface RunEventOut { n: number; stream: 'build' | 'stdout' | 'stderr'; chunk: string }

interface Live {
  id: string; projectId: string; userId: string; status: RunStatus; phase: string | null;
  events: RunEventOut[]; sizes: { build: number; stdout: number; stderr: number }; texts: { build: string; stdout: string; stderr: string };
  truncated: boolean; ac: AbortController; cancelled: boolean; keepUntil: number;
  job: { entry: string; mode: 'file' | 'project'; files: Array<{ path: string; content: string }>; stdin?: string; language: string };
}

export class RunManager {
  private ctx: Ctx;
  private client: RunnerClient | null;
  private live = new Map<string, Live>();
  private queue: string[] = [];
  private active = 0;
  private langs: RunnerLang[] = [];
  private langsAt = 0;
  private closed = false;

  constructor(ctx: Ctx, client: RunnerClient | null) {
    this.ctx = ctx; this.client = client;
    // Алдыңғы процестен қалған орындалмаған тапсырмалар «жетім» болып қалмауы керек
    ctx.db.run(`UPDATE runs SET status = 'internal_error', message = 'server_restart', finished_at = ? WHERE status IN ('queued', 'running')`, iso(ctx.clock.now()));
  }

  private nowIso() { return iso(this.ctx.clock.now()); }

  async refreshLanguages(force = false): Promise<RunnerLang[]> {
    if (!this.client) return [];
    if (!force && this.langs.length && Date.now() - this.langsAt < 30_000) return this.langs;
    try { this.langs = await this.client.languages(); this.langsAt = Date.now(); } catch { this.langs = []; this.langsAt = 0; }
    return this.langs;
  }

  async runtime() {
    const langs = await this.refreshLanguages();
    const available = !!this.client && langs.length > 0;
    return { available, languages: langs.map((l) => ({ id: l.id, label: l.label, enabled: available && l.enabled, reason: l.enabled ? undefined : l.reason })), web: true,
      limits: { concurrency: this.ctx.cfg.runConcurrency, perUserActive: this.ctx.cfg.runPerUserActive } };
  }

  private toView(r: any, pos?: number): RunView {
    return {
      id: r.id, projectId: r.project_id, userId: r.user_id ?? null, mode: r.mode, entryPath: r.entry_path, language: r.language, status: r.status, phase: r.phase ?? null,
      exitCode: r.exit_code ?? null, signal: r.signal ?? null, durationMs: r.duration_ms ?? null, truncated: !!r.truncated, message: r.message ?? null,
      createdAt: r.created_at, startedAt: r.started_at ?? null, finishedAt: r.finished_at ?? null, ...(pos ? { queuePosition: pos } : {}),
    };
  }

  async start(userId: string, projectId: string, body: Record<string, unknown>): Promise<RunView> {
    requireEditor(this.ctx, userId, projectId);
    if (!this.client) throw new AppError('run.unavailable', 503);
    const mode = body.mode;
    if (mode !== 'file' && mode !== 'project' && mode !== 'sql') throw new AppError('validation.field_invalid');

    let entry: string; let files: Array<{ path: string; content: string }>;
    if (mode === 'sql') {
      if (typeof body.sql !== 'string' || !body.sql.trim()) throw new AppError('run.sql_empty');
      if (body.sql.length > 100_000) throw new AppError('run.sql_too_long', 413);
      entry = 'query.sql'; files = [{ path: entry, content: body.sql }];
    } else {
      this.ctx.bus.flush?.(projectId);
      files = projectFiles(this.ctx, projectId);
      if (mode === 'file') {
        const fid = body.fileId;
        if (typeof fid !== 'string') throw new AppError('validation.field_invalid');
        const f = this.ctx.db.get('SELECT folder_id, name FROM files WHERE id = ? AND project_id = ?', fid, projectId);
        if (!f) throw new AppError('file.not_found', 404);
        const all = new Map<string, any>(); for (const r of this.ctx.db.all('SELECT id, parent_id, name FROM folders WHERE project_id = ?', projectId)) all.set(r.id, r);
        const parts = [f.name as string]; let cur = f.folder_id as string | null; let guard = 0;
        while (cur && guard++ < 64) { const d = all.get(cur); if (!d) break; parts.unshift(d.name); cur = d.parent_id; }
        entry = parts.join('/');
      } else {
        const s = this.ctx.db.get('SELECT entry_point FROM project_settings WHERE project_id = ?', projectId);
        entry = String(s?.entry_point ?? '');
        if (!entry || !files.some((x) => x.path === entry)) throw new AppError('run.no_entry', 400);
      }
      let total = 0; for (const x of files) total += Buffer.byteLength(x.content, 'utf8');
      if (files.length > 300 || total > 8 * 1024 * 1024) throw new AppError('run.project_too_large', 413);
    }
    const ext = /\.([A-Za-z0-9]+)$/.exec(entry)?.[1]?.toLowerCase() ?? '';
    const language = langOf(entry);
    if (!language || WEB_EXT.has(ext)) throw new AppError('run.unsupported_file', 400);

    const langs = await this.refreshLanguages();
    const l = langs.find((x) => x.id === language);
    if (!l || !l.enabled) throw new AppError('run.language_unavailable', 409, { language: l?.label ?? language });

    // Шектеулер
    const mine = [...this.live.values()].filter((x) => x.userId === userId && !TERMINAL.has(x.status)).length;
    if (mine >= this.ctx.cfg.runPerUserActive) throw new AppError('run.too_many_active', 429);
    const since = iso(this.ctx.clock.now() - 60_000);
    const recent = Number(this.ctx.db.get('SELECT COUNT(*) AS c FROM runs WHERE user_id = ? AND created_at >= ?', userId, since)?.c ?? 0);
    if (recent >= this.ctx.cfg.runPerUserPerMinute) throw new AppError('run.rate_limited', 429);
    if (this.queue.length >= this.ctx.cfg.runQueueMax) throw new AppError('run.queue_full', 503);

    const id = randomUUID();
    const stdin = typeof body.stdin === 'string' ? body.stdin.slice(0, 64 * 1024) : undefined;
    this.ctx.db.run('INSERT INTO runs (id, project_id, user_id, mode, entry_path, language, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      id, projectId, userId, mode, entry, language, 'queued', this.nowIso());
    this.live.set(id, {
      id, projectId, userId, status: 'queued', phase: null, events: [], sizes: { build: 0, stdout: 0, stderr: 0 }, texts: { build: '', stdout: '', stderr: '' },
      truncated: false, ac: new AbortController(), cancelled: false, keepUntil: 0,
      job: { entry, mode: mode === 'sql' ? 'file' : mode, files, stdin, language },
    });
    this.queue.push(id);
    queueMicrotask(() => this.pump());
    return this.view(id)!;
  }

  private view(id: string): RunView | null {
    const r = this.ctx.db.get('SELECT * FROM runs WHERE id = ?', id);
    if (!r) return null;
    const pos = this.queue.indexOf(id);
    return this.toView(r, pos >= 0 ? pos + 1 : undefined);
  }

  private pump() {
    while (!this.closed && this.active < this.ctx.cfg.runConcurrency && this.queue.length) {
      const id = this.queue.shift()!;
      const l = this.live.get(id);
      if (!l || l.status !== 'queued') continue;
      this.active++;
      this.execute(l).finally(() => { this.active--; this.pump(); });
    }
  }

  private add(l: Live, stream: 'build' | 'stdout' | 'stderr', chunk: string) {
    const cap = this.ctx.cfg.runStoreChars;
    const room = cap - l.sizes[stream];
    if (room <= 0) { l.truncated = true; return; }
    const part = chunk.length > room ? chunk.slice(0, room) : chunk;
    if (part.length < chunk.length) l.truncated = true;
    l.sizes[stream] += part.length; l.texts[stream] += part;
    l.events.push({ n: l.events.length + 1, stream, chunk: part });
  }

  private async execute(l: Live) {
    const db = this.ctx.db;
    l.status = 'running';
    db.run(`UPDATE runs SET status = 'running', started_at = ? WHERE id = ?`, this.nowIso(), l.id);
    let fin: Extract<RunnerEvent, { type: 'finished' }> | null = null;
    let err: string | null = null;
    try {
      await this.client!.run({ id: l.id, entry: l.job.entry, mode: l.job.mode, files: l.job.files, stdin: l.job.stdin }, (e) => {
        if (e.type === 'phase') { l.phase = e.phase; db.run('UPDATE runs SET phase = ? WHERE id = ?', e.phase, l.id); }
        else if (e.type === 'output') this.add(l, e.stream, e.chunk);
        else if (e.type === 'finished') fin = e;
      }, l.ac.signal);
    } catch (e) {
      if (!l.cancelled) err = (e as Error).message || 'runner_error';
    }
    let status: RunStatus; let exitCode: number | null = null; let signal: string | null = null; let duration: number | null = null; let message: string | null = null;
    const f = fin as Extract<RunnerEvent, { type: 'finished' }> | null;
    if (l.cancelled) { status = 'killed'; message = 'cancel'; if (f) { exitCode = f.exitCode; signal = f.signal; duration = f.durationMs; } }
    else if (f) { status = f.status as RunStatus; exitCode = f.exitCode; signal = f.signal; duration = f.durationMs; message = f.message ?? null; }
    else { status = 'internal_error'; message = err ? 'runner_unreachable' : 'runner_error'; }
    if (!TERMINAL.has(status)) status = 'internal_error';
    this.finish(l, status, exitCode, signal, duration, message);
  }

  private finish(l: Live, status: RunStatus, exitCode: number | null, signal: string | null, duration: number | null, message: string | null) {
    l.status = status;
    this.ctx.db.run(
      'UPDATE runs SET status = ?, exit_code = ?, signal = ?, duration_ms = ?, stdout = ?, stderr = ?, build = ?, truncated = ?, message = ?, finished_at = ? WHERE id = ?',
      status, exitCode, signal, duration, l.texts.stdout, l.texts.stderr, l.texts.build, l.truncated ? 1 : 0, message, this.nowIso(), l.id);
    l.keepUntil = Date.now() + 60_000;
    l.job.files = []; // жадты босату
    setTimeout(() => { if (this.live.get(l.id)?.keepUntil === l.keepUntil) this.live.delete(l.id); }, 61_000).unref();
  }

  private authorize(userId: string, projectId: string, runId: string) {
    const role = requireMember(this.ctx, userId, projectId);
    const r = this.ctx.db.get('SELECT * FROM runs WHERE id = ? AND project_id = ?', runId, projectId);
    if (!r || (r.user_id !== userId && role !== 'owner')) throw new AppError('run.not_found', 404);
    return { r, role };
  }

  /** Күйі + `after`-тен кейінгі шығыс оқиғалары (polling). */
  get(userId: string, projectId: string, runId: string, after = 0): { run: RunView; events: RunEventOut[]; next: number } {
    const { r } = this.authorize(userId, projectId, runId);
    const l = this.live.get(runId);
    const pos = this.queue.indexOf(runId);
    let events: RunEventOut[]; let next: number;
    if (l) {
      events = l.events.slice(Math.max(0, after)); next = l.events.length;
      const row = this.ctx.db.get('SELECT * FROM runs WHERE id = ?', runId)!;
      return { run: this.toView({ ...row, truncated: l.truncated ? 1 : row.truncated }, pos >= 0 ? pos + 1 : undefined), events, next };
    }
    // Жадтан шыққан/аяқталған: дерекқордан қалпына келтіру (стримнің толық көшірмесі: build → stdout → stderr)
    const all: RunEventOut[] = []; let n = 0;
    for (const s of ['build', 'stdout', 'stderr'] as const) { const t = r[s] as string; if (t) all.push({ n: ++n, stream: s, chunk: t }); }
    events = after >= n ? [] : all.slice(after); next = n;
    return { run: this.toView(r), events, next };
  }

  list(userId: string, projectId: string, limit = 20): RunView[] {
    const role = requireMember(this.ctx, userId, projectId);
    const rows = role === 'owner'
      ? this.ctx.db.all('SELECT * FROM runs WHERE project_id = ? ORDER BY created_at DESC LIMIT ?', projectId, limit)
      : this.ctx.db.all('SELECT * FROM runs WHERE project_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?', projectId, userId, limit);
    return rows.map((r) => this.toView(r));
  }

  async cancel(userId: string, projectId: string, runId: string): Promise<RunView> {
    this.authorize(userId, projectId, runId);
    if (roleOf(this.ctx, userId, projectId) === 'viewer') throw new AppError('permission.denied', 403);
    const l = this.live.get(runId);
    if (l && !TERMINAL.has(l.status)) {
      l.cancelled = true;
      if (l.status === 'queued') {
        this.queue = this.queue.filter((x) => x !== runId);
        this.finish(l, 'killed', null, null, null, 'cancel');
      } else {
        await this.client?.cancel(runId);
        l.ac.abort();
      }
    }
    return this.get(userId, projectId, runId).run;
  }

  purge(): number {
    const cutoff = iso(this.ctx.clock.now() - this.ctx.cfg.runRetentionDays * 86_400_000);
    return this.ctx.db.run(`DELETE FROM runs WHERE created_at < ? AND status NOT IN ('queued', 'running')`, cutoff).changes;
  }

  shutdown() {
    this.closed = true;
    for (const l of this.live.values()) if (!TERMINAL.has(l.status)) { l.cancelled = true; l.ac.abort(); }
  }
}
