import type { IncomingMessage, ServerResponse } from 'node:http';
import { AppError, formatMessage, type ErrorCode } from './errors.ts';
import type { UserDto } from './services/auth.ts';

export interface RouteCtx {
  req: IncomingMessage;
  params: Record<string, string>;
  query: URLSearchParams;
  body: Record<string, unknown>;
  ip: string;
  ua: string;
  user: UserDto | null;
  sessionId: string | null;
}

export interface Reply {
  status?: number;
  json?: unknown;
  raw?: { body: Buffer; type: string; headers?: Record<string, string> };
  headers?: Record<string, string | string[]>;
}

export type Handler = (c: RouteCtx) => Reply | Promise<Reply>;

export interface Route { method: string; re: RegExp; keys: string[]; handler: Handler; auth: boolean }

export function compile(method: string, pattern: string, handler: Handler, auth = true): Route {
  const keys: string[] = [];
  const src = pattern.replace(/\/:(\w+)/g, (_, k: string) => { keys.push(k); return '/([^/]+)'; });
  return { method, re: new RegExp(`^${src}/?$`), keys, handler, auth };
}

export function match(routes: Route[], method: string, pathname: string): { route?: Route; params: Record<string, string>; pathMatched: boolean } {
  let pathMatched = false;
  for (const r of routes) {
    const m = r.re.exec(pathname);
    if (!m) continue;
    pathMatched = true;
    if (r.method !== method) continue;
    const params: Record<string, string> = {};
    r.keys.forEach((k, i) => { try { params[k] = decodeURIComponent(m[i + 1]); } catch { params[k] = m[i + 1]; } });
    return { route: r, params, pathMatched };
  }
  return { params: {}, pathMatched };
}

export async function readBody(req: IncomingMessage, limit: number): Promise<Buffer> {
  const declared = Number(req.headers['content-length']);
  if (Number.isFinite(declared) && declared > limit) throw new AppError('request.too_large', 413);
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > limit) throw new AppError('request.too_large', 413);
    chunks.push(chunk as Buffer);
  }
  return Buffer.concat(chunks);
}

export function sendJson(res: ServerResponse, status: number, data: unknown, headers: Record<string, string | string[]> = {}) {
  const body = Buffer.from(JSON.stringify(data));
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': body.length,
    'cache-control': 'no-store',
    ...headers,
  });
  res.end(body);
}

export function sendError(res: ServerResponse, err: AppError) {
  sendJson(res, err.status, { error: { code: err.code, message: formatMessage(err.code as ErrorCode, err.params), ...(err.params ? { params: err.params } : {}) } });
}

export function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (header ?? '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}

export function sessionCookie(token: string, maxAgeSec: number, secure: boolean): string {
  return `uya_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSec}${secure ? '; Secure' : ''}`;
}
export const clearCookie = (secure: boolean) => sessionCookie('', 0, secure).replace('uya_session=;', 'uya_session=;') + '; Expires=Thu, 01 Jan 1970 00:00:00 GMT';
