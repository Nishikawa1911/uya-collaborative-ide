import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { existsSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { loadConfig, type Config } from './config.ts';
import { iso, nullBus, type Clock, type Ctx } from './context.ts';
import { Db, migrate } from './db.ts';
import { AppError } from './errors.ts';
import {
  clearCookie, compile, match, parseCookies, readBody, sendError, sendJson, sessionCookie,
  type Reply, type Route,
} from './http.ts';
import * as auth from './services/auth.ts';
import * as files from './services/files.ts';
import * as projects from './services/projects.ts';
import * as chat from './services/chat.ts';
import { attachCollab } from './collab.ts';
import { RunManager } from './runs.ts';
import { httpRunnerClient, type RunnerClient } from './runner-client.ts';
import * as preview from './services/preview.ts';
import { asObject } from './validate.ts';

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.map': 'application/json', '.png': 'image/png',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.txt': 'text/plain; charset=utf-8',
};

const SECURITY_HEADERS = {
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'same-origin',
};

export interface App {
  server: Server;
  ctx: Ctx;
  listen(port?: number, host?: string): Promise<number>;
  close(): Promise<void>;
}

export function createApp(opts: { config?: Partial<Config>; clock?: Clock; runner?: RunnerClient | null } = {}): App {
  const cfg = loadConfig(process.env, opts.config);
  const db = new Db(cfg.dbPath);
  migrate(db);
  const ctx: Ctx = { db, cfg, clock: opts.clock ?? { now: () => Date.now() }, bus: nullBus };
  const runner = opts.runner !== undefined ? opts.runner : (cfg.runnerUrl && cfg.runnerToken ? httpRunnerClient(cfg.runnerUrl, cfg.runnerToken) : null);
  const runs = new RunManager(ctx, runner);
  const ttlSec = cfg.sessionTtlDays * 86_400;
  const J = (status: number, json: unknown, headers?: Reply['headers']): Reply => ({ status, json, headers });

  const routes: Route[] = [
    compile('GET', '/api/health', () => J(200, { status: 'ok' }), false),

    // ── Аутентификация ──
    compile('POST', '/api/auth/register', async (c) => {
      const { token, user } = await auth.register(ctx, c.body, c.ip, c.ua);
      return J(201, { user }, { 'set-cookie': sessionCookie(token, ttlSec, cfg.cookieSecure) });
    }, false),
    compile('POST', '/api/auth/login', async (c) => {
      const { token, user } = await auth.login(ctx, c.body, c.ip, c.ua);
      return J(200, { user }, { 'set-cookie': sessionCookie(token, ttlSec, cfg.cookieSecure) });
    }, false),
    compile('POST', '/api/auth/logout', (c) => {
      if (c.sessionId) auth.logout(ctx, c.sessionId);
      return J(200, { ok: true }, { 'set-cookie': clearCookie(cfg.cookieSecure) });
    }, false),

    // ── Профиль ──
    compile('GET', '/api/me', (c) => J(200, { user: c.user })),
    compile('PATCH', '/api/me', (c) => J(200, { user: auth.updateProfile(ctx, c.user!.id, c.body) })),
    compile('POST', '/api/me/password', async (c) => {
      await auth.changePassword(ctx, c.user!.id, c.sessionId!, c.body);
      return J(200, { ok: true });
    }),
    compile('GET', '/api/users/:id/avatar', (c) => {
      const a = auth.getAvatar(ctx, c.user!.id, c.params.id);
      if (!a) throw new AppError('request.not_found', 404);
      return { raw: { body: a.data, type: a.mime, headers: { 'cache-control': 'private, max-age=3600' } } };
    }),

    // ── Жобалар ──
    compile('GET', '/api/projects', (c) => J(200, { projects: projects.list(ctx, c.user!.id, c.query.get('scope') ?? 'mine') })),
    compile('POST', '/api/projects', (c) => J(201, projects.create(ctx, c.user!.id, c.body))),
    compile('POST', '/api/projects/join', (c) => J(200, projects.join(ctx, c.user!.id, c.ip, c.body))),
    compile('GET', '/api/projects/:id', (c) => J(200, { project: projects.open(ctx, c.user!.id, c.params.id) })),
    compile('DELETE', '/api/projects/:id', (c) => { projects.remove(ctx, c.user!.id, c.params.id, c.body); return J(200, { ok: true }); }),
    compile('GET', '/api/projects/:id/settings', (c) => J(200, { settings: projects.getSettings(ctx, c.user!.id, c.params.id) })),
    compile('PATCH', '/api/projects/:id/settings', (c) => J(200, { settings: projects.updateSettings(ctx, c.user!.id, c.params.id, c.body) })),
    compile('POST', '/api/projects/:id/invite/rotate', (c) => J(200, projects.rotateInvite(ctx, c.user!.id, c.params.id))),
    compile('GET', '/api/projects/:id/members', (c) => J(200, { members: projects.members(ctx, c.user!.id, c.params.id) })),
    compile('PATCH', '/api/projects/:id/members/:userId', (c) => { projects.setMemberRole(ctx, c.user!.id, c.params.id, c.params.userId, c.body); return J(200, { ok: true }); }),
    compile('DELETE', '/api/projects/:id/members/:userId', (c) => { projects.removeMember(ctx, c.user!.id, c.params.id, c.params.userId); return J(200, { ok: true }); }),

    // ── Файл жүйесі ──
    compile('GET', '/api/projects/:id/tree', (c) => J(200, { nodes: files.tree(ctx, c.user!.id, c.params.id) })),
    compile('POST', '/api/projects/:id/nodes', (c) => J(201, { node: files.create(ctx, c.user!.id, c.params.id, c.body) })),
    compile('PATCH', '/api/projects/:id/nodes/:nodeId', (c) => J(200, { node: files.rename(ctx, c.user!.id, c.params.id, c.params.nodeId, c.body) })),
    compile('DELETE', '/api/projects/:id/nodes/:nodeId', (c) => { files.remove(ctx, c.user!.id, c.params.id, c.params.nodeId); return J(200, { ok: true }); }),
    compile('GET', '/api/projects/:id/files/:nodeId/content', (c) => J(200, files.read(ctx, c.user!.id, c.params.id, c.params.nodeId))),
    compile('PUT', '/api/projects/:id/files/:nodeId/content', (c) => J(200, files.save(ctx, c.user!.id, c.params.id, c.params.nodeId, c.body))),

    // ── Чат тарихы (жаңа хабарламалар WebSocket арқылы келеді) ──
    // ── Кодты орындау (оқшауланған runner арқылы) ──
    compile('GET', '/api/runtime', async () => J(200, await runs.runtime())),
    compile('POST', '/api/projects/:id/runs', async (c) => J(202, { run: await runs.start(c.user!.id, c.params.id, c.body) })),
    compile('GET', '/api/projects/:id/runs', (c) => J(200, { runs: runs.list(c.user!.id, c.params.id) })),
    compile('GET', '/api/projects/:id/runs/:runId', (c) => J(200, runs.get(c.user!.id, c.params.id, c.params.runId, Math.max(0, Number(c.query.get('after')) || 0)))),
    compile('POST', '/api/projects/:id/runs/:runId/cancel', async (c) => J(200, { run: await runs.cancel(c.user!.id, c.params.id, c.params.runId) })),
    // ── Веб-алдын ала қарау (код орындамайды: тек файлдарды біріктіреді) ──
    compile('GET', '/api/projects/:id/preview', (c) => J(200, preview.preview(ctx, c.user!.id, c.params.id, c.query.get('path')))),

    compile('GET', '/api/projects/:id/messages', (c) => J(200, chat.history(ctx, c.user!.id, c.params.id, c.query.get('before'), c.query.get('limit')))),
  ];

  function clientIp(req: IncomingMessage): string {
    if (cfg.trustProxy) {
      const xff = String(req.headers['x-forwarded-for'] ?? '').split(',')[0].trim();
      if (xff) return xff;
    }
    return req.socket.remoteAddress ?? 'unknown';
  }

  function originAllowed(req: IncomingMessage): boolean {
    if (req.headers['sec-fetch-site'] === 'cross-site') return false;
    const origin = req.headers.origin;
    if (!origin) return true; // браузерсіз клиенттер (curl, тесттер) Origin жібермейді
    if (cfg.allowedOrigins.includes(origin)) return true;
    try { return new URL(origin).host === req.headers.host; } catch { return false; }
  }

  async function handleApi(req: IncomingMessage, res: ServerResponse, url: URL) {
    const method = req.method ?? 'GET';
    const m = match(routes, method, url.pathname);
    if (!m.route) throw new AppError(m.pathMatched ? 'request.method_not_allowed' : 'request.not_found', m.pathMatched ? 405 : 404);

    if (!['GET', 'HEAD'].includes(method) && !originAllowed(req)) throw new AppError('request.forbidden_origin', 403);

    let body: Record<string, unknown> = {};
    if (!['GET', 'HEAD'].includes(method)) {
      const raw = await readBody(req, cfg.maxBodyBytes);
      if (raw.length > 0) {
        if (!String(req.headers['content-type'] ?? '').toLowerCase().startsWith('application/json')) throw new AppError('request.unsupported_media', 415);
        let parsed: unknown;
        try { parsed = JSON.parse(raw.toString('utf8')); } catch { throw new AppError('request.bad_json', 400); }
        body = asObject(parsed);
      }
    }

    const token = parseCookies(req.headers.cookie).uya_session;
    const session = token ? auth.authenticate(ctx, token) : null;
    if (m.route.auth && !session) throw new AppError('auth.unauthenticated', 401);

    const reply = await m.route.handler({
      req, params: m.params, query: url.searchParams, body, ip: clientIp(req), ua: String(req.headers['user-agent'] ?? ''),
      user: session?.user ?? null, sessionId: session?.sessionId ?? null,
    });
    if (reply.raw) {
      res.writeHead(200, { 'content-type': reply.raw.type, 'content-length': reply.raw.body.length, 'x-content-type-options': 'nosniff', ...reply.raw.headers });
      res.end(reply.raw.body);
    } else {
      sendJson(res, reply.status ?? 200, reply.json ?? {}, reply.headers as Record<string, string | string[]>);
    }
  }

  function serveStatic(req: IncomingMessage, res: ServerResponse, url: URL) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendError(res, new AppError('request.method_not_allowed', 405));
    const root = path.resolve(cfg.staticDir);
    let rel: string;
    try { rel = decodeURIComponent(url.pathname); } catch { return sendError(res, new AppError('request.not_found', 404)); }
    let file = path.resolve(root, '.' + path.posix.normalize('/' + rel));
    if (!file.startsWith(root + path.sep) && file !== root) return sendError(res, new AppError('request.not_found', 404));
    if (!existsSync(file) || statSync(file).isDirectory()) {
      // SPA: белгісіз жолдар index.html береді (бірақ жоқ файл кеңейтуі бар сұраныстар — 404)
      if (path.extname(rel)) return sendError(res, new AppError('request.not_found', 404));
      file = path.join(root, 'index.html');
    }
    if (!existsSync(file)) return sendError(res, new AppError('request.not_found', 404));
    const body = readFileSync(file);
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'content-type': MIME[ext] ?? 'application/octet-stream', 'content-length': body.length,
      'cache-control': ext === '.html' || path.basename(file) === 'config.js' ? 'no-cache' : 'public, max-age=300',
    });
    res.end(req.method === 'HEAD' ? undefined : body);
  }

  const server = createServer(async (req, res) => {
    const started = Date.now();
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    try {
      const url = new URL(req.url ?? '/', 'http://localhost');
      if (url.pathname.startsWith('/api/') || url.pathname === '/api') await handleApi(req, res, url);
      else serveStatic(req, res, url);
    } catch (e) {
      if (e instanceof AppError) sendError(res, e);
      else {
        console.error('[қате]', e);
        sendError(res, new AppError('server.internal', 500));
      }
    } finally {
      if (cfg.logRequests) console.log(`${req.method} ${(req.url ?? '').split('?')[0]} ${res.statusCode} ${Date.now() - started}ms`);
    }
  });

  const hub = attachCollab({ ctx, server, originAllowed });

  const purgeTimer = setInterval(() => { try { auth.purgeExpiredSessions(ctx); runs.purge(); } catch { /* ignore */ } }, 3_600_000);
  purgeTimer.unref();

  return {
    server, ctx,
    listen: (port = cfg.port, host = cfg.host) => new Promise((resolve) => {
      server.listen(port, host, () => { const a = server.address(); resolve(typeof a === 'object' && a ? a.port : port); });
    }),
    close: () => new Promise((resolve) => {
      clearInterval(purgeTimer);
      runs.shutdown();
      hub.shutdown();
      server.close(() => { try { db.close(); } catch { /* already closed */ } resolve(); });
      server.closeAllConnections?.();
    }),
  };
}

export { iso };
