/** Минималды WebSocket сервері (RFC 6455): handshake, ping/pong, close, артқы қысым. */
import type { IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';
import { acceptKey, closePayload, encodeFrame, FrameError, FrameParser, OP } from './wsframe.ts';

export interface WsHandlers {
  onMessage(text: string): void;
  onClose(code: number): void;
}

const MAX_BUFFERED = 8 * 1024 * 1024;

export class WsConn {
  alive = true;
  closed = false;
  handlers: WsHandlers = { onMessage() {}, onClose() {} };
  private parser: FrameParser;
  private lastPong = Date.now();
  private closeTimer: NodeJS.Timeout | null = null;

  private socket: Duplex & { writableLength?: number; setNoDelay?: (b: boolean) => void };

  constructor(socket: Duplex & { writableLength?: number; setNoDelay?: (b: boolean) => void }, head: Buffer, maxPayload: number) {
    this.socket = socket;
    this.parser = new FrameParser({ maxPayload, requireMask: true });
    socket.setNoDelay?.(true);
    socket.on('data', (d: Buffer) => this.feed(d));
    socket.on('error', () => this.finish(1006));
    socket.on('close', () => this.finish(1006));
    // http.Server allowHalfOpen=true: клиент ажырағанда (FIN) қосылымды өзіміз жабамыз
    socket.on('end', () => { this.finish(1006); socket.destroy(); });
    if (head.length) this.feed(head);
  }

  get idleMs() { return Date.now() - this.lastPong; }

  private feed(d: Buffer) {
    if (this.closed) return;
    try {
      for (const f of this.parser.push(d)) {
        this.lastPong = Date.now();
        if (f.opcode === OP.text) this.handlers.onMessage(f.payload.toString('utf8'));
        else if (f.opcode === OP.binary) this.close(1003, 'binary');
        else if (f.opcode === OP.ping) this.raw(encodeFrame(OP.pong, f.payload));
        else if (f.opcode === OP.close) {
          const code = f.payload.length >= 2 ? f.payload.readUInt16BE(0) : 1005;
          this.finish(code, true);
        }
      }
    } catch (e) {
      this.close(e instanceof FrameError ? e.code : 1011, 'protocol');
    }
  }

  private raw(b: Buffer) {
    if (this.closed || this.socket.destroyed) return;
    if ((this.socket.writableLength ?? 0) > MAX_BUFFERED) { this.terminate(1013); return; }
    this.socket.write(b);
  }

  send(text: string) { this.raw(encodeFrame(OP.text, Buffer.from(text, 'utf8'))); }
  ping() { this.raw(encodeFrame(OP.ping, Buffer.alloc(0))); }

  /** Таза жабу: close кадрын жібереді, жауапты ≤2с күтеді. */
  close(code = 1000, reason = '') {
    if (this.closed) return;
    this.closed = true;
    try { this.socket.write(encodeFrame(OP.close, closePayload(code, reason))); } catch { /* ignore */ }
    this.closeTimer = setTimeout(() => this.socket.destroy(), 2000);
    this.closeTimer.unref();
    this.handlers.onClose(code);
  }

  terminate(code = 1006) { this.finish(code); this.socket.destroy(); }

  private finish(code: number, reply = false) {
    if (this.closed) { if (this.closeTimer) clearTimeout(this.closeTimer); this.socket.destroy(); return; }
    this.closed = true;
    if (reply) { try { this.socket.write(encodeFrame(OP.close, closePayload(code === 1005 ? 1000 : code))); } catch { /* ignore */ } this.socket.end(); }
    this.handlers.onClose(code);
  }
}

/** Handshake: сәтті болса WsConn; әйтпесе сокетке HTTP қатесін жазып null қайтарады. */
export function handshake(req: IncomingMessage, socket: Duplex, head: Buffer, maxPayload: number): WsConn | null {
  const key = req.headers['sec-websocket-key'];
  if (String(req.headers.upgrade ?? '').toLowerCase() !== 'websocket' || typeof key !== 'string' || req.headers['sec-websocket-version'] !== '13') {
    reject(socket, 400, 'Bad Request'); return null;
  }
  socket.write(['HTTP/1.1 101 Switching Protocols', 'Upgrade: websocket', 'Connection: Upgrade', `Sec-WebSocket-Accept: ${acceptKey(key)}`, '', ''].join('\r\n'));
  return new WsConn(socket, head, maxPayload);
}

export function reject(socket: Duplex, status: number, text: string) {
  try { socket.write(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`); } catch { /* ignore */ }
  socket.destroy();
}
