import type { Config } from './config.ts';
import type { Db } from './db.ts';

export interface Clock { now(): number }

/** Қызметтерден нақты уақыт хабына оқиғалар жіберу арнасы (хаб болмаса — ешнәрсе істемейді). */
export type BusEvent =
  | { type: 'fs.created'; node: { id: string; parentId: string | null; name: string; kind: 'file' | 'folder' }; by: string }
  | { type: 'fs.renamed'; node: { id: string; parentId: string | null; name: string; kind: 'file' | 'folder' }; by: string }
  | { type: 'fs.deleted'; id: string; kind: 'file' | 'folder'; fileIds: string[]; by: string }
  | { type: 'member.role'; userId: string; role: 'owner' | 'editor' | 'viewer' }
  | { type: 'member.removed'; userId: string }
  | { type: 'members.changed' }
  | { type: 'project.updated' }
  | { type: 'project.deleted' }
  /** REST арқылы сақталған мазмұн: хаб ашық құжат болса, CRDT арқылы біріктіреді */
  | { type: 'file.rest_saved'; fileId: string; content: string; by: string };

export interface Bus {
  publish(projectId: string, event: BusEvent): void;
  /** Ашық CRDT құжат болса REST сақтауын біріктіреді; өңделсе — нәтижені қайтарады, әйтпесе undefined */
  /** Ашық құжаттардың сақталмаған өзгерістерін дерекқорға жазады (орындау алдында) */
  flush?(projectId: string): void;
  mergeRestSave?(projectId: string, fileId: string, content: string, userId: string): { version: number } | undefined;
}
export const nullBus: Bus = { publish() {} };

export interface Ctx { db: Db; cfg: Config; clock: Clock; bus: Bus }

export const iso = (ms: number) => new Date(ms).toISOString();
