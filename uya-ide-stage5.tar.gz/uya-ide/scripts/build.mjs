import { existsSync } from 'node:fs';
// Production build: src/main.tsx -> dist/app.js + dist/app.css, public/* -> dist/*
import { build } from 'esbuild';
import { cp, mkdir, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');

export const options = {
  entryPoints: { app: path.join(root, 'src/main.tsx') },
  outdir: dist,
  bundle: true,
  format: 'esm',
  target: 'es2022',
  jsx: 'automatic',
  charset: 'utf8', // Қазақ әріптері өзгертілмей қалуы үшін (UTF-8)
  loader: { '.woff2': 'file' },
  define: { 'process.env.NODE_ENV': '"production"' },
  logLevel: 'info',
};

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  await rm(dist, { recursive: true, force: true });
  await mkdir(dist, { recursive: true });
  await build({ ...options, minify: true, sourcemap: true });
  await cp(path.join(root, 'public'), dist, { recursive: true });
  // Monaco орнатылған болса, оны жергілікті көшіреміз (CDN-сыз жұмыс істеу үшін).
  const monacoVs = path.join(root, 'node_modules/monaco-editor/min/vs');
  if (existsSync(monacoVs)) await cp(monacoVs, path.join(dist, 'vs'), { recursive: true });
  console.log('✔ dist/ дайын');
}
