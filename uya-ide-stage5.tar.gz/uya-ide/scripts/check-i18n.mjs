// i18n тексеру: кодта қолданылатын әр кілт kk.ts ішінде бар ма, және мәндер бос емес пе.
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'src');
const files = [];
(function walk(d) { for (const f of readdirSync(d)) { const p = path.join(d, f); statSync(p).isDirectory() ? walk(p) : /\.(ts|tsx)$/.test(f) && files.push(p); } })(root);
const kk = readFileSync(path.join(root, 'i18n/kk.ts'), 'utf8');
const keys = new Map([...kk.matchAll(/^\s*'([\w.]+)':\s*(.+?),?\s*$/gm)].map((m) => [m[1], m[2]]));
const used = new Set(); const dynamic = [];
for (const f of files) {
  const s = readFileSync(f, 'utf8');
  for (const m of s.matchAll(/\bt\(\s*'([\w.]+)'/g)) used.add(m[1]);
  for (const m of s.matchAll(/\bt\(\s*`([^`]+)`/g)) dynamic.push(m[1]);
}
const missing = [...used].filter((k) => !keys.has(k));
const empty = [...keys].filter(([, v]) => /^''$/.test(v.trim())).map(([k]) => k);
const prefixes = dynamic.map((d) => d.replace(/\$\{[^}]*\}/g, '*'));
const dynMissing = prefixes.filter((p) => ![...keys.keys()].some((k) => new RegExp('^' + p.replace(/\./g, '\\.').replace(/\*/g, '[\\w]+') + '$').test(k)));
console.log(`кілттер: ${keys.size}, қолданылған: ${used.size}, динамикалық үлгі: ${prefixes.length}`);
if (missing.length) console.log('ЖОҚ кілттер:', missing);
if (empty.length) console.log('БОС мәндер:', empty);
if (dynMissing.length) console.log('Динамикалық үлгіге сәйкес кілт жоқ:', dynMissing);
process.exit(missing.length || empty.length || dynMissing.length ? 1 : 0);
