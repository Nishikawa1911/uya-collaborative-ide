// Әзірлеу режимі: фронтендті бақылап жинайды (dist/) және бэкэнд серверін қайта іске қосып тұрады.
// Бэкэнд dist/ қалтасын да береді, сондықтан бір origin (http://localhost:3000) — кук мәселесі жоқ.
import { context } from 'esbuild';
import { spawn } from 'node:child_process';
import { cp, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { options } from './build.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
await mkdir(dist, { recursive: true });
await cp(path.join(root, 'public'), dist, { recursive: true });

const ctx = await context({
  ...options,
  define: { 'process.env.NODE_ENV': '"development"' },
  sourcemap: true,
  logLevel: 'info',
});
await ctx.watch();

const server = spawn(
  process.execPath,
  ['--disable-warning=ExperimentalWarning', '--env-file-if-exists=.env', '--watch', '--watch-path=server', 'server/main.ts'],
  { cwd: root, stdio: 'inherit' },
);
const stop = () => { server.kill(); ctx.dispose().finally(() => process.exit(0)); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
server.on('exit', (code) => { if (code) { console.error(`Бэкэнд тоқтады (код ${code}).`); stop(); } });
