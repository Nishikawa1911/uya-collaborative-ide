"""E2E (4-кезең): 3 пайдаланушы, 3 бөлек браузер контексті, нақты бэкэнд + дерекқор + WebSocket.
Іске қосу: npm run build && python3 tests/e2e_collab.py"""
import os, re, subprocess, sys, tempfile, time, shutil, urllib.request, sqlite3
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT = os.environ.get('SHOTS', '/tmp/uya-e2e-collab')
os.makedirs(OUT, exist_ok=True)
PORT = 5292
BASE = f'http://127.0.0.1:{PORT}'
tmp = tempfile.mkdtemp(prefix='uya-e2e4-')
DB = os.path.join(tmp, 'e2e.sqlite')
env = {**os.environ, 'PORT': str(PORT), 'DATABASE_PATH': DB, 'REGISTER_PER_HOUR': '1000', 'LOG_REQUESTS': 'false', 'NODE_ENV': 'test'}
srv = subprocess.Popen(['node', '--disable-warning=ExperimentalWarning', 'server/main.ts'], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
for _ in range(50):
    try: urllib.request.urlopen(BASE + '/api/health'); break
    except Exception: time.sleep(0.2)
else:
    print(srv.stdout.read().decode()); sys.exit('сервер іске қосылмады')

fails, errors = [], []
def check(name, cond):
    print(('OK   ' if cond else 'FAIL ') + name)
    if not cond: fails.append(name)

PW = 'Uya-demo-2026'
NET = {}
def new_ctx(b):
    ctx = b.new_context(viewport={'width': 1440, 'height': 860}, device_scale_factor=1)
    st = {'offline': False, 'routes': []}
    NET[id(ctx)] = st
    def handler(route):
        if st['offline']: route.close(); return
        route.connect_to_server(); st['routes'].append(route)
    ctx.route_web_socket(re.compile(r'.*/ws/projects/.*'), handler)
    page = ctx.new_page()
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text and 'monaco' not in m.text.lower() and 'ERR_' not in m.text and 'WebSocket' not in m.text else None)
    page.on('pageerror', lambda e: errors.append(str(e)))
    return ctx, page

def register(page, name, username, email):
    page.goto(BASE + '/#/register'); page.wait_for_selector('#field-password')
    page.locator('input[name=displayName]').fill(name)
    page.locator('input[name=username]').fill(username)
    page.locator('input[name=email]').fill(email)
    page.locator('#field-password').fill(PW); page.locator('#field-confirm').fill(PW)
    page.locator('label[for=field-terms]').click()
    page.get_by_role('button', name='Тіркелу').click()
    page.wait_for_url(re.compile('dashboard'))

def set_offline(ctx, off):
    """WebSocket желісін үзу/қалпына келтіру (Playwright WebSocket proxy арқылы): үзілгенде қосылым жабылады, қайта қосылу бұғатталады."""
    st = NET[id(ctx)]; st['offline'] = off
    if off:
        for r in st['routes']:
            try: r.close()
            except Exception: pass
        st['routes'] = []

def text(page): return page.locator('.fb__area').input_value()
def wait_text(page, pred, timeout=6000):
    try:
        page.wait_for_function("(src) => { const t = document.querySelector('.fb__area')?.value ?? ''; return new Function('t', 'return ' + src)(t); }", arg=pred, timeout=timeout)
        return True
    except Exception: return False
def open_main(page):
    page.get_by_role('treeitem', name=re.compile(r'main\.py')).first.click(); page.wait_for_selector('.fb__area'); 
    page.wait_for_function("document.querySelector('[data-testid=sync-state]')?.textContent.includes('Синхрондалды')", timeout=8000)

try:
  with sync_playwright() as p:
    b = p.chromium.launch()
    ctxA, A = new_ctx(b); ctxB, B = new_ctx(b); ctxC, C = new_ctx(b)
    register(A, 'Айгерім Сейтқазы', 'aigerim_s', 'aigerim.s@example.kz')
    register(B, 'Дана Ермекова', 'dana_e', 'dana.e@example.kz')
    register(C, 'Ержан Нұрланов', 'erzhan_n', 'erzhan.n@example.kz')

    A.goto(BASE + '/#/projects/new'); A.wait_for_selector('input[name=name]')
    A.locator('input[name=name]').fill('Бірлескен жоба'); A.locator('.chip-toggle').first.click()
    A.get_by_role('button', name='Жобаны құру').click(); A.wait_for_selector('[data-testid=invite-code]')
    code = A.locator('[data-testid=invite-code]').inner_text().strip()
    for pg in (B, C):
        pg.goto(BASE + '/#/projects/join'); pg.wait_for_selector('#field-code')
        pg.locator('#field-code').fill(code); pg.get_by_role('button', name=re.compile('Қосылу')).first.click()
        pg.wait_for_selector('.success-card', timeout=8000)
    A.goto(BASE + '/#/dashboard'); A.wait_for_selector('.project-card__link'); A.locator('.project-card__link').first.click()
    A.wait_for_selector('[data-testid=workspace]'); ws_url = A.url; pid = ws_url.split('/projects/')[1]
    for pg in (B, C): pg.goto(ws_url); pg.wait_for_selector('[data-testid=workspace]')
    for pg in (A, B, C): open_main(pg)
    check('3 қолданушы бір жобаны бір мезгілде ашты', all(pg.locator('.fb__area').count() == 1 for pg in (A, B, C)))
    base_text = text(A)
    check('үшеуі бірдей бастапқы мәтінді көреді', text(B) == base_text and text(C) == base_text)

    # ── Онлайн қолданушылар және «қай файлда» ──
    for pg in (A, B, C): pg.locator('[role=tab]', has_text='Қатысушылар').click()
    A.wait_for_function("document.querySelectorAll('.member').length === 3")
    ok = A.wait_for_function("[...document.querySelectorAll('.member__sub')].filter(e => e.textContent.includes('main.py')).length === 3", timeout=6000)
    check('қатысушылар тізімі: үшеуі онлайн және main.py өңдеуде (жаңартусыз)', ok is not None)
    C.get_by_role('button', name='Жаңа файл').first.click(); C.locator('.tree__input').fill('notes.py'); C.keyboard.press('Enter')
    A.wait_for_function("[...document.querySelectorAll('.member__sub')].some(e => e.textContent.includes('notes.py'))", timeout=6000)
    check('C жаңа файлды ашқанда A оны «notes.py өңдеуде» деп көреді', True)
    C.get_by_role('treeitem', name=re.compile(r'main\.py')).first.click(); C.wait_for_selector('.fb__area')
    A.wait_for_function("[...document.querySelectorAll('.member__sub')].filter(e => e.textContent.includes('main.py')).length === 3", timeout=6000)
    check('файл ауысқанда онлайн күйі қайта жаңарады', True)
    A.screenshot(path=f'{OUT}/01-online-users.png')

    # ── Нақты уақыт теру: біреуі жазады, қалғандары бірден көреді ──
    A.locator('.fb__area').click(); A.keyboard.press('Control+End'); A.keyboard.type('\n# A: сәлем')
    check('A жазғаны B-да жаңартусыз пайда болды', wait_text(B, "t.includes('# A: сәлем')"))
    check('A жазғаны C-да жаңартусыз пайда болды', wait_text(C, "t.includes('# A: сәлем')"))

    # ── Курсорлар мен ерекшелеу ──
    B.locator('.fb__area').click(); B.keyboard.press('Control+Home'); B.keyboard.press('Shift+End')
    A.wait_for_function("document.querySelector('.fb__rcaret')", timeout=6000)
    nm = A.locator('.fb__rname').first.inner_text()
    check('A-да B-ның курсоры атымен көрінеді', 'Дана' in nm)
    check('A-да B-ның ерекшелеуі көрінеді', A.locator('.fb__rsel').count() >= 1)
    A.screenshot(path=f'{OUT}/02-remote-cursor.png')

    # ── Параллель өңдеу (офлайн): ешкімнің өзгерісі өшпейді ──
    for ctx in (ctxA, ctxB, ctxC): set_offline(ctx, True)
    for pg in (A, B, C): pg.wait_for_selector('[data-testid=offline-banner]', timeout=8000)
    check('байланыс үзілгенде «қайта қосылуда» баннері шықты', True)
    A.locator('.fb__area').click(); A.keyboard.press('Control+Home'); A.keyboard.type('AAA|')
    B.locator('.fb__area').click(); B.keyboard.press('Control+Home'); B.keyboard.type('BBB|')
    C.locator('.fb__area').click(); C.keyboard.press('Control+End'); C.keyboard.type('|CCC')
    check('офлайн: жергілікті өңдеу жұмыс істейді', 'AAA|' in text(A) and 'BBB|' in text(B) and '|CCC' in text(C))
    check('офлайн: «Желіден тыс» көрсеткіші', 'Желіден тыс' in A.locator('[data-testid=sync-state]').inner_text())
    for ctx in (ctxA, ctxB, ctxC): set_offline(ctx, False)
    for pg in (A, B, C): pg.wait_for_function("!document.querySelector('[data-testid=offline-banner]')", timeout=30000)
    toks = ['AAA|', 'BBB|', '|CCC', '# A: сәлем']
    for pg in (A, B, C): wait_text(pg, ' && '.join(f"t.includes({t!r})" for t in toks), 15000)
    ta, tb, tc = text(A), text(B), text(C)
    check('қайта қосылғаннан кейін барлық 3 көшірме бірдей', ta == tb == tc)
    check('ешкімнің өзгерісі өшпеді (AAA|, BBB|, |CCC, бұрынғы мәтін)', all(t in ta for t in toks))
    A.screenshot(path=f'{OUT}/03-after-reconnect.png')

    # ── Бір мезгілде теру (онлайн) ──
    A.locator('.fb__area').click(); A.keyboard.press('Control+Home'); A.keyboard.type('a1a2a3a4a5')
    B.locator('.fb__area').click(); B.keyboard.press('Control+End'); B.keyboard.type('b1b2b3b4b5')
    for pg in (A, B, C): wait_text(pg, "t.includes('a1a2a3a4a5') && t.includes('b1b2b3b4b5')", 8000)
    check('онлайн теру: үшеуі де бірдей және толық', text(A) == text(B) == text(C) and 'a1a2a3a4a5' in text(C) and 'b1b2b3b4b5' in text(C))

    # ── Дерекқорға түсті ──
    time.sleep(1.2)
    db = sqlite3.connect(DB); db.row_factory = sqlite3.Row
    row = db.execute("SELECT content FROM files WHERE name = 'main.py' AND project_id = ?", (pid,)).fetchone()
    check('files.content дерекқорда соңғы бірлескен мәтінмен тең', row is not None and row['content'] == text(A))
    check('file_docs күйі сақталған', db.execute('SELECT COUNT(*) FROM file_docs').fetchone()[0] >= 1)

    # ── Чат ──
    for pg in (A, B, C): pg.locator('[role=tab]', has_text='Чат').click()
    B.locator('.chat__composer textarea').fill('Сәлем, команда! Дана жазып тұр'); B.keyboard.press('Enter')
    for pg in (A, C): pg.wait_for_function("[...document.querySelectorAll('.msg__body')].some(e => e.textContent.includes('Дана жазып тұр'))", timeout=6000)
    check('чат: хабарлама A мен C-ға жаңартусыз жетті', True)
    A.locator('.chat__composer textarea').fill('Қабылдадым ✔'); A.keyboard.press('Enter')
    B.wait_for_function("[...document.querySelectorAll('.msg__body')].some(e => e.textContent.includes('Қабылдадым'))", timeout=6000)
    check('чат: B жауапты көрді; жіберілуде белгісі жоқ', B.locator('.msg__local').count() == 0)
    C.reload(); C.wait_for_selector('[data-testid=workspace]'); C.wait_for_timeout(600)
    C.locator('[role=tab]', has_text='Чат').click()
    C.wait_for_function("document.querySelectorAll('.msg__body').length >= 2", timeout=6000)
    check('чат тарихы бет жаңартқанда дерекқордан қайта оқылады', 'Дана жазып тұр' in C.locator('.chat__log').inner_text())
    check('чат дерекқорда', db.execute('SELECT COUNT(*) FROM chat_messages WHERE project_id = ?', (pid,)).fetchone()[0] == 2)
    A.screenshot(path=f'{OUT}/04-chat.png')

    # ── Файл жүйесі синхроны ──
    A.get_by_role('button', name='Жаңа файл').first.click(); A.locator('.tree__input').fill('shared.py'); A.keyboard.press('Enter')
    for pg in (B, C): pg.get_by_role('treeitem', name=re.compile('shared.py')).first.wait_for(timeout=6000)
    check('fs: A құрған файл B және C ағашында бірден пайда болды', True)
    B.get_by_role('treeitem', name=re.compile('shared.py')).first.click(); B.wait_for_selector('.fb__area')
    A.get_by_role('treeitem', name=re.compile('shared.py')).first.click(mouse_button='right') if False else None
    # атын өзгерту (контекст мәзірі арқылы емес, REST арқылы A сессиясынан — бұл да A-ның әрекеті)
    nid = A.evaluate("(pid) => fetch('/api/projects/' + pid + '/tree').then(r => r.json()).then(j => j.nodes.find(n => n.name === 'shared.py').id)", pid)
    r = A.evaluate("([pid, nid]) => fetch('/api/projects/' + pid + '/nodes/' + nid, {method:'PATCH', headers:{'content-type':'application/json'}, body: JSON.stringify({name:'renamed.py'})}).then(r => r.status)", [pid, nid])
    for pg in (B, C): pg.get_by_role('treeitem', name=re.compile('renamed.py')).first.wait_for(timeout=6000)
    check('fs: атын өзгерту барлығына жетті', r == 200 and B.get_by_role('treeitem', name=re.compile('shared.py')).count() == 0)
    check('fs: ашық қойындының аты да жаңарды', 'renamed.py' in B.locator('.etab.is-active').inner_text())
    A.evaluate("([pid, nid]) => fetch('/api/projects/' + pid + '/nodes/' + nid, {method:'DELETE'})", [pid, nid])
    B.wait_for_function("!document.querySelector('.etab.is-active')?.textContent.includes('renamed.py')", timeout=6000)
    for pg in (B, C): pg.get_by_role('treeitem', name=re.compile('renamed.py')).first.wait_for(state='detached', timeout=6000)
    check('fs: жойылған файл B-ның қойындысынан және C ағашынан жоғалды', True)
    B.screenshot(path=f'{OUT}/05-fs-deleted.png')

    # ── Рөл: C → viewer (жаңартусыз) ──
    members = A.evaluate("(pid) => fetch('/api/projects/' + pid + '/members').then(r => r.json())", pid)['members']
    erzhan = [m for m in members if m['username'] == 'erzhan_n'][0]
    A.evaluate("([pid, uid]) => fetch('/api/projects/' + pid + '/members/' + uid, {method:'PATCH', headers:{'content-type':'application/json'}, body: JSON.stringify({role:'viewer'})})", [pid, erzhan['userId']])
    C.wait_for_selector('[data-testid=viewer-banner]', timeout=8000)
    open_main(C) if C.locator('.fb__area').count() == 0 else None
    C.wait_for_function("document.querySelector('.fb__area')?.hasAttribute('readonly')", timeout=6000)
    check('рөл өзгергенде C редакторы жаңартусыз тек оқуға ауысты', True)
    before = text(A)
    C.locator('.fb__area').click(force=True); C.keyboard.type('HACK')
    time.sleep(0.6)
    check('viewer жазған мәтін басқаларға жетпейді', 'HACK' not in text(A) and text(A) == before)
    C.screenshot(path=f'{OUT}/06-viewer.png')

    # ── Рұқсатсыз қосылу ──
    ctxD = b.new_context(viewport={'width': 1200, 'height': 800}); D = ctxD.new_page()  # WebSocket proxy-сыз: нақты сервер жауабы
    register(D, 'Бөтен Адам', 'outsider_x', 'outsider.x@example.kz')
    res = D.evaluate("""(pid) => new Promise((resolve) => {
      const ws = new WebSocket((location.protocol === 'https:' ? 'wss' : 'ws') + '://' + location.host + '/ws/projects/' + pid);
      let opened = false; ws.onopen = () => { opened = true; };
      ws.onclose = () => resolve({ opened }); setTimeout(() => resolve({ opened, timeout: true }), 4000);
    })""", pid)
    check('жоба мүшесі емес адам WebSocket қосылымын аша алмайды', res['opened'] is False and not res.get('timeout'))
    ctxN = b.new_context(); N = ctxN.new_page(); N.goto(BASE + '/')
    res2 = N.evaluate("""(pid) => new Promise((resolve) => {
      const ws = new WebSocket('ws://' + location.host + '/ws/projects/' + pid);
      let opened = false; ws.onopen = () => { opened = true; };
      ws.onclose = () => resolve({ opened }); setTimeout(() => resolve({ opened, timeout: true }), 4000);
    })""", pid)
    check('кірмеген адам (cookie жоқ) қосыла алмайды', res2['opened'] is False and not res2.get('timeout'))

    # ── Қатысушыны шығару: қосылым үзіледі ──
    A.evaluate("([pid, uid]) => fetch('/api/projects/' + pid + '/members/' + uid, {method:'DELETE'})", [pid, erzhan['userId']])
    C.wait_for_url(re.compile('dashboard'), timeout=8000)
    check('шығарылған қатысушы жобадан автоматты шығарылды', True)
    b.close()
finally:
    srv.terminate()
    try: srv.wait(5)
    except Exception: srv.kill()
    shutil.rmtree(tmp, ignore_errors=True)

print('\nКонсоль қателері:', errors[:10])
check('консольде қате жоқ', not errors)
print(f"\nНәтиже: {'сәтсіз ' + str(len(fails)) if fails else 'барлығы өтті'}")
sys.exit(1 if fails else 0)
