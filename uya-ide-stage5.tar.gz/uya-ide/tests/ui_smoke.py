"""UI smoke-тест (MOCK режимі, бэкэндсіз — тек визуалды/интерфейс тексеру): беттерді ашады, негізгі әрекеттерді орындайды, скриншот және консоль қателерін жинайды.
Іске қосу: node scripts/build.mjs && python3 tests/ui_smoke.py"""
import http.server, threading, functools, os, sys, re
from playwright.sync_api import sync_playwright

ROOT = os.path.join(os.path.dirname(__file__), '..', 'dist')
OUT = os.environ.get('SHOTS', '/tmp/uya-shots')
os.makedirs(OUT, exist_ok=True)
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
H.log_message = lambda *a, **k: None
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 5199), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = 'http://127.0.0.1:5199/#'
fails, errors = [], []

def check(name, cond):
    print(('OK   ' if cond else 'FAIL ') + name)
    if not cond: fails.append(name)

def login(page):
    page.goto(BASE + '/login'); page.wait_for_selector('input')
    ins = page.locator('input')
    ins.nth(0).fill('aigerim.s@example.kz'); ins.nth(1).fill('Uya-demo-2026')
    page.locator('button[type=submit]').click()
    page.wait_for_url(re.compile('dashboard'))

with sync_playwright() as p:
    b = p.chromium.launch()
    for theme in ('dark', 'light'):
        for label, vp in (('desktop', {'width': 1440, 'height': 860}), ('mobile', {'width': 390, 'height': 800})):
            ctx = b.new_context(viewport=vp, device_scale_factor=1)
            ctx.add_init_script(f"localStorage.setItem('uya.theme','{theme}')")
            ctx.route('**/config.js', lambda r: r.fulfill(content_type='text/javascript', body="window.__UYA_CONFIG__={apiMode:'mock'};"))
            page = ctx.new_page()
            page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'monaco' not in m.text.lower() and 'ERR_' not in m.text and 'Failed to load resource' not in m.text else None)
            page.on('pageerror', lambda e: errors.append(str(e)))
            tag = f'{theme}-{label}'
            page.goto(BASE + '/login'); page.wait_for_timeout(300)
            page.screenshot(path=f'{OUT}/{tag}-login.png')
            page.goto(BASE + '/register'); page.wait_for_timeout(300)
            page.screenshot(path=f'{OUT}/{tag}-register.png')
            login(page); page.wait_for_timeout(500)
            check(f'{tag}: dashboard cards', page.locator('.project-card__link').count() > 0)
            page.screenshot(path=f'{OUT}/{tag}-dashboard.png')
            for route in ('project/new', 'join', 'profile'):
                pass
            page.goto(BASE + '/projects/new'); page.wait_for_timeout(400)
            page.screenshot(path=f'{OUT}/{tag}-create.png')
            page.goto(BASE + '/projects/join'); page.wait_for_timeout(400)
            page.screenshot(path=f'{OUT}/{tag}-join.png')
            page.goto(BASE + '/profile'); page.wait_for_timeout(400)
            page.screenshot(path=f'{OUT}/{tag}-profile.png')
            page.goto(BASE + '/dashboard'); page.wait_for_selector('.project-card__link')
            page.locator('.project-card__link').first.click(); page.wait_for_selector('[data-testid=workspace]', timeout=8000)
            page.wait_for_timeout(1500)
            check(f'{tag}: workspace', page.locator('[data-testid=workspace]').count() == 1)
            page.screenshot(path=f'{OUT}/{tag}-workspace.png')
            if label == 'desktop' and theme == 'dark':
                page.get_by_role('treeitem', name=re.compile('aqi.py')).first.click(); page.wait_for_timeout(1200)
                check('файл ашылды (қойынды)', page.locator('.etab').count() == 1)
                page.screenshot(path=f'{OUT}/{tag}-editor.png')
                page.locator('.fb__area, .monaco-host textarea').first.click(); page.keyboard.type('# сынақ')
                check('өзгеріс белгісі (dirty)', page.locator('.etab.is-dirty').count() == 1)
                page.keyboard.press('Control+s'); page.wait_for_timeout(500)
                check('Ctrl+S сақтады', page.locator('.etab.is-dirty').count() == 0)
                check('mock: runner жоқ → «Файлды іске қосу» өшірулі (өтірік нәтиже жоқ)', page.get_by_role('button', name='Файлды іске қосу').first.is_disabled())
                check('орындау қызметі қосылмағаны көрсетілген', 'қосылмаған' in page.locator('[data-testid=runtime-unavailable]').inner_text())
                page.screenshot(path=f'{OUT}/{tag}-run.png')
                page.get_by_role('tab', name=re.compile('Терминал')).click()
                page.locator('.term__input').fill('ls'); page.keyboard.press('Enter'); page.wait_for_timeout(200)
                check('терминал ls', 'src' in page.locator('.term').inner_text())
                page.locator('.chat__composer textarea').fill('Сәлем, команда!'); page.keyboard.press('Enter'); page.wait_for_timeout(300)
                check('чат хабарламасы', page.locator('.msg', has_text='Сәлем, команда!').count() == 1)
                page.get_by_role('tab', name=re.compile('Қатысушылар')).click(); page.wait_for_timeout(300)
                check('қатысушылар тізімі', page.locator('.member').count() >= 3)
                page.screenshot(path=f'{OUT}/{tag}-members.png')
            ctx.close()
    b.close()

print('\nКонсоль қателері:', errors[:10])
srv.shutdown()
sys.exit(1 if fails else 0)
