"""E2E (5-кезең): браузер → backend → HTTP runner → runc контейнері. Root және runc керек.
Іске қосу: npm run build && python3 tests/e2e_run.py"""
import os, re, subprocess, sys, tempfile, time, shutil, urllib.request, json
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT = os.environ.get('SHOTS', '/tmp/uya-e2e-run'); os.makedirs(OUT, exist_ok=True)
PORT, RPORT = 5293, 5294
BASE = f'http://127.0.0.1:{PORT}'
TOKEN = 'e2e-runner-token-0123456789'
tmp = tempfile.mkdtemp(prefix='uya-e2e5-'); os.chmod(tmp, 0o711)
node = ['node', '--disable-warning=ExperimentalWarning']
renv = {**os.environ, 'RUNNER_TOKEN': TOKEN, 'RUNNER_PORT': str(RPORT), 'RUNNER_STATE_DIR': f'{tmp}/rs', 'RUNNER_JOBS_DIR': f'{tmp}/rj'}
runner = subprocess.Popen(node + ['runner/main.ts'], cwd=ROOT, env=renv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
for _ in range(300):
    try:
        req = urllib.request.Request(f'http://127.0.0.1:{RPORT}/v1/health', headers={'authorization': f'Bearer {TOKEN}'}); urllib.request.urlopen(req); break
    except Exception: time.sleep(0.3)
else: sys.exit('runner іске қосылмады')
senv = {**os.environ, 'PORT': str(PORT), 'DATABASE_PATH': f'{tmp}/e2e.sqlite', 'REGISTER_PER_HOUR': '1000', 'LOG_REQUESTS': 'false', 'NODE_ENV': 'test',
        'RUNNER_URL': f'http://127.0.0.1:{RPORT}', 'RUNNER_TOKEN': TOKEN}
srv = subprocess.Popen(node + ['server/main.ts'], cwd=ROOT, env=senv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
for _ in range(50):
    try: urllib.request.urlopen(BASE + '/api/health'); break
    except Exception: time.sleep(0.2)
else: sys.exit('сервер іске қосылмады')

fails, errors = [], []
def check(name, cond):
    print(('OK   ' if cond else 'FAIL ') + name)
    if not cond: fails.append(name)

PW = 'Uya-demo-2026'
def api(page, method, url, body=None):
    return page.evaluate("""async ([m, u, b]) => { const r = await fetch(u, {method: m, headers: {'content-type': 'application/json'}, body: b ? JSON.stringify(b) : undefined}); let j = null; try { j = await r.json(); } catch {} return {status: r.status, json: j}; }""", [method, url, body])
def put_file(page, pid, name, content, folder=None):
    tree = api(page, 'GET', f'/api/projects/{pid}/tree')['json']['nodes']
    n = next((x for x in tree if x['name'] == name and x['kind'] == 'file'), None)
    if not n:
        n = api(page, 'POST', f'/api/projects/{pid}/nodes', {'kind': 'file', 'name': name, 'parentId': folder})['json']['node']
    r = api(page, 'PUT', f'/api/projects/{pid}/files/{n["id"]}/content', {'content': content})
    assert r['status'] == 200, r
    return n['id']
def open_ws(page, pid):
    page.goto(BASE + f'/#/projects/{pid}'); page.wait_for_selector('[data-testid=workspace]')
    page.wait_for_function("document.querySelector('[data-testid=runtime-unavailable]') === null && !document.body.innerText.includes('тексерілуде')", timeout=8000)
def open_file(page, name):
    page.get_by_role('treeitem', name=re.compile(re.escape(name))).first.click(); page.wait_for_selector('.fb__area'); page.wait_for_timeout(400)
def run_file_and_wait(page, timeout=40000):
    page.get_by_role('button', name='Тазалау').first.click()  # алдыңғы нәтижелер араласпауы үшін
    page.get_by_role('button', name='Файлды іске қосу').first.click()
    page.wait_for_function("document.querySelector('[data-testid=run-output]')?.innerText.match(/Сәтті аяқталды|Қатемен аяқталды|Компиляция қатесі|Уақыт шегі|Пайдаланушы тоқтатты|Жады шегі/)", timeout=timeout)
    return page.locator('[data-testid=run-output]').inner_text()

try:
  with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={'width': 1440, 'height': 860}); page = ctx.new_page()
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text and 'monaco' not in m.text.lower() and 'ERR_' not in m.text and 'WebSocket' not in m.text and 'Content Security Policy' not in m.text and 'Refused to' not in m.text else None)
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(BASE + '/#/register'); page.wait_for_selector('#field-password')
    page.locator('input[name=displayName]').fill('Айгерім Сейтқазы'); page.locator('input[name=username]').fill('aigerim_run'); page.locator('input[name=email]').fill('aigerim.run@example.kz')
    page.locator('#field-password').fill(PW); page.locator('#field-confirm').fill(PW); page.locator('label[for=field-terms]').click()
    page.get_by_role('button', name='Тіркелу').click(); page.wait_for_url(re.compile('dashboard'))

    pr = api(page, 'POST', '/api/projects', {'name': 'Орындау', 'description': '', 'languages': ['python', 'cpp', 'csharp', 'sql'], 'entryPoint': 'main.py', 'joinRole': 'editor', 'template': 'empty'})
    pid = pr['json']['project']['id']
    put_file(page, pid, 'main.py', 'print("Сәлем, оқшауланған әлем!")\n')
    put_file(page, pid, 'bad.cpp', 'int main() { return x; }\n')
    put_file(page, pid, 'Program.cs', 'class P { static void Main() { } }\n')
    put_file(page, pid, 'loop.py', 'import time\nprint("басталды", flush=True)\ntime.sleep(120)\n')
    put_file(page, pid, 'fail.py', 'import sys\nprint("stdout жолы")\nprint("stderr жолы", file=sys.stderr)\nsys.exit(3)\n')
    put_file(page, pid, 'net.py', 'import socket\ntry:\n    socket.create_connection(("1.1.1.1", 53), timeout=3); print("ЖЕЛІ БАР")\nexcept OSError: print("желі жабық")\nimport os\nprint("host:", os.path.exists("/home/claude"), os.listdir("/root"), os.listdir("/home"))\n')
    open_ws(page, pid)
    page.screenshot(path=f'{OUT}/01-workspace.png')

    # ── Run File ──
    open_file(page, 'main.py')
    out = run_file_and_wait(page)
    check('Run File: Python stdout терминалда көрінеді (UTF-8)', 'Сәлем, оқшауланған әлем!' in out)
    check('Run File: сәтті аяқталу және уақыт көрсетіледі', 'Сәтті аяқталды' in out)
    page.screenshot(path=f'{OUT}/02-run-file.png')

    # ── stderr + exit code ──
    open_file(page, 'fail.py'); out = run_file_and_wait(page)
    check('stdout және stderr бөлек көрінеді', 'stdout жолы' in out and 'stderr жолы' in out)
    check('stderr жолы қате түспен (data-kind=error)', page.locator('[data-testid=run-output] [data-kind=error]', has_text='stderr жолы').count() >= 1)
    check('шығу коды 3 көрсетіледі', 'шығу коды 3' in out)

    # ── Желі және хост файлдары ──
    open_file(page, 'net.py'); out = run_file_and_wait(page)
    check('контейнерде желі жабық', 'желі жабық' in out and 'ЖЕЛІ БАР' not in out)
    check('хост файлдары көрінбейді (/home/claude жоқ, /root мен /home бос)', 'host: False [] []' in out)

    # ── Компиляция қатесі ──
    open_file(page, 'bad.cpp'); out = run_file_and_wait(page, 90000)
    check('C++ компиляция қатесі: build ағыны және «іске қосылмады»', 'Компиляция қатесі' in out and page.locator('[data-testid=run-output] [data-kind=build]').count() >= 1)
    page.screenshot(path=f'{OUT}/03-compile-error.png')

    # ── Stop ──
    open_file(page, 'loop.py'); page.get_by_role('button', name='Тазалау').first.click()
    page.get_by_role('button', name='Файлды іске қосу').first.click()
    page.wait_for_function("document.querySelector('[data-testid=run-output]')?.innerText.includes('басталды')", timeout=20000)
    check('орындау кезінде Stop түймесі көрінеді', page.locator('[data-testid=run-stop]').count() == 1)
    page.locator('[data-testid=run-stop]').click()
    page.wait_for_function("document.querySelector('[data-testid=run-output]')?.innerText.includes('Пайдаланушы тоқтатты')", timeout=15000)
    check('Stop: процесс тоқтатылды, түймелер қайта белсенді', page.get_by_role('button', name='Файлды іске қосу').first.is_enabled())
    page.screenshot(path=f'{OUT}/04-stopped.png')

    # ── C# қолжетімсіз ──
    open_file(page, 'Program.cs'); page.wait_for_timeout(300)
    check('C#: «Файлды іске қосу» өшірулі (dotnet жоқ — өтірік қосылмайды)', page.get_by_role('button', name='Файлды іске қосу').first.is_disabled())
    check('C#: себебі интерфейсте жазылған', 'C#' in page.locator('[data-testid=runtime-disabled]').inner_text() and 'dotnet' in page.locator('[data-testid=runtime-disabled]').inner_text())

    # ── SQL Playground ──
    page.get_by_role('tab', name=re.compile('SQL')).click()
    page.locator('[data-testid=sql-input]').fill("CREATE TABLE t(name TEXT, n INT); INSERT INTO t VALUES ('Алма', 3), ('Өрік', 5); SELECT name, n FROM t ORDER BY n DESC;")
    page.locator('[data-testid=sql-run]').click()
    page.wait_for_function("document.querySelector('[data-testid=sql-output]')?.innerText.includes('Сәтті аяқталды')", timeout=20000)
    sq = page.locator('[data-testid=sql-output]').inner_text()
    check('SQL: кесте нәтижесі көрсетілді (Өрік, Алма)', 'Өрік' in sq and 'Алма' in sq and '2 қатар' in sq)
    page.locator('[data-testid=sql-input]').fill("ATTACH DATABASE '/tmp/x.db' AS x;")
    page.locator('[data-testid=sql-run]').click()
    page.wait_for_function("document.querySelector('[data-testid=sql-output]')?.innerText.includes('Қатемен аяқталды')", timeout=20000)
    check('SQL: ATTACH тыйым салынған (қате көрсетілді)', 'Қате' in page.locator('[data-testid=sql-output]').inner_text())
    page.screenshot(path=f'{OUT}/05-sql.png')

    # ── Web Preview ──
    wp = api(page, 'POST', '/api/projects', {'name': 'Веб', 'description': '', 'languages': ['html', 'css', 'javascript'], 'entryPoint': 'index.html', 'joinRole': 'editor', 'template': 'empty'})['json']['project']['id']
    put_file(page, wp, 'index.html', '<!doctype html><html><head><link rel="stylesheet" href="style.css"></head><body><h1 id="t">Бастапқы</h1><script src="app.js"></script></body></html>')
    put_file(page, wp, 'style.css', 'h1{color:rgb(255,0,0)}')
    put_file(page, wp, 'app.js', """document.getElementById('t').textContent = 'JS жұмыс істеді';
console.log('консоль көпірі');
try { document.cookie; window.parent.document.title; console.error('ПАРЕНТКЕ ҚОЛЖЕТІМДІ'); } catch (e) { console.log('parent жабық'); }
fetch('/api/me').then(() => console.error('FETCH ӨТТІ')).catch(() => console.log('fetch бұғатталды'));
""")
    open_ws(page, wp)
    page.get_by_role('button', name='Жобаны іске қосу').first.click()
    page.wait_for_selector('[data-testid=preview-frame]', timeout=10000)
    fr = page.frame_locator('[data-testid=preview-frame]')
    fr.locator('#t').wait_for(timeout=8000)
    page.wait_for_function("document.querySelector('[data-testid=preview-frame]').contentDocument === null", timeout=3000) if False else None
    page.wait_for_timeout(600)
    check('Preview: HTML + CSS + JS бірге жұмыс істейді', fr.locator('#t').inner_text() == 'JS жұмыс істеді' and fr.locator('#t').evaluate("e => getComputedStyle(e).color") == 'rgb(255, 0, 0)')
    attr = page.locator('[data-testid=preview-frame]').get_attribute('sandbox')
    check('Preview: iframe sandbox="allow-scripts" (allow-same-origin жоқ)', attr == 'allow-scripts')
    cons = page.locator('[data-testid=preview-console]').inner_text()
    check('Preview: консоль көпірі жұмыс істейді', 'консоль көпірі' in cons)
    check('Preview: parent DOM/cookie-ге қолжетімділік жоқ', 'parent жабық' in cons and 'ПАРЕНТКЕ' not in cons)
    check('Preview: желіге шығу CSP арқылы бұғатталған', 'fetch бұғатталды' in cons and 'FETCH ӨТТІ' not in cons)
    page.screenshot(path=f'{OUT}/06-preview.png')

    # ── Көрермен іске қоса алмайды ──
    ctx2 = b.new_context(); v = ctx2.new_page()
    v.goto(BASE + '/#/register'); v.wait_for_selector('#field-password')
    v.locator('input[name=displayName]').fill('Дана Көрермен'); v.locator('input[name=username]').fill('dana_view'); v.locator('input[name=email]').fill('dana.view@example.kz')
    v.locator('#field-password').fill(PW); v.locator('#field-confirm').fill(PW); v.locator('label[for=field-terms]').click()
    v.get_by_role('button', name='Тіркелу').click(); v.wait_for_url(re.compile('dashboard'))
    api(page, 'PATCH', f'/api/projects/{pid}/settings', {'joinRole': 'viewer'})
    code = api(page, 'POST', f'/api/projects/{pid}/invite/rotate')['json']['inviteCode']
    check('көрермен жобаға қосылды', api(v, 'POST', '/api/projects/join', {'code': code})['status'] == 200)
    v.goto(BASE + f'/#/projects/{pid}'); v.wait_for_selector('[data-testid=workspace]')
    check('көрермен: «Жобаны іске қосу» өшірулі', v.get_by_role('button', name='Жобаны іске қосу').first.is_disabled())
    r = api(v, 'POST', f'/api/projects/{pid}/runs', {'mode': 'project'})
    check('көрермен: API 403 қайтарады', r['status'] == 403)
    b.close()
finally:
    for pr_ in (srv, runner):
        pr_.terminate()
        try: pr_.wait(8)
        except Exception: pr_.kill()
    time.sleep(0.5)
    subprocess.run(['sh', '-c', f'umount -l {tmp}/rj/*/work 2>/dev/null; true'])
    left = os.listdir(f'{tmp}/rj') if os.path.exists(f'{tmp}/rj') else []
    check('runner тоқтағанда уақытша орталар қалмады', left == [])
    shutil.rmtree(tmp, ignore_errors=True)

print('\nКонсоль қателері:', errors[:10])
check('консольде қате жоқ', not errors)
print(f"\nНәтиже: {'сәтсіз ' + str(len(fails)) if fails else 'барлығы өтті'}")
sys.exit(1 if fails else 0)
