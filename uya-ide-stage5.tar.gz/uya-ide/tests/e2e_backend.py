"""E2E: нақты бэкэнд + нақты дерекқор + нақты браузер. Mock қолданылмайды.
Іске қосу: npm run build && python3 tests/e2e_backend.py"""
import os, re, subprocess, sys, tempfile, time, shutil, urllib.request
from playwright.sync_api import sync_playwright, expect

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT = os.environ.get('SHOTS', '/tmp/uya-e2e')
os.makedirs(OUT, exist_ok=True)
PORT = 5291
BASE = f'http://127.0.0.1:{PORT}'
tmp = tempfile.mkdtemp(prefix='uya-e2e-')
env = {**os.environ, 'PORT': str(PORT), 'DATABASE_PATH': os.path.join(tmp, 'e2e.sqlite'), 'REGISTER_PER_HOUR': '1000', 'LOG_REQUESTS': 'false', 'NODE_ENV': 'test'}
srv = subprocess.Popen(['node', '--disable-warning=ExperimentalWarning', 'server/main.ts'], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
for _ in range(50):
    try: urllib.request.urlopen(BASE + '/api/health'); break
    except Exception: time.sleep(0.2)
else:
    print(srv.stdout.read().decode()); sys.exit('сервер іске қосылмады')

fails, errors = [], []
def check(name, cond):
    print(('OK   ' if cond else 'FAIL ') + name)
    if not cond: fails.append(name)

PW = 'Uya-demo-2026'
def new_page(b, w=1440, h=860):
    ctx = b.new_context(viewport={'width': w, 'height': h}, device_scale_factor=1)
    page = ctx.new_page()
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text and 'monaco' not in m.text.lower() and 'ERR_' not in m.text else None)
    page.on('pageerror', lambda e: errors.append(str(e)))
    return ctx, page

def register(page, name, username, email):
    page.goto(BASE + '/#/register'); page.wait_for_selector('#field-password')
    page.locator('input[name=displayName]').fill(name)
    page.locator('input[name=username]').fill(username)
    page.locator('input[name=email]').fill(email)
    page.locator('#field-password').fill(PW); page.locator('#field-confirm').fill(PW)
    page.locator('label[for=field-terms]').click()
    page.get_by_role('button', name='Тіркелу').click()
    page.wait_for_url(re.compile('dashboard'))

def editor_text(page):
    return page.locator('.fb__area').input_value()

try:
  with sync_playwright() as p:
    b = p.chromium.launch()

    # ── Иесі: тіркелу → бос дашборд ─────────────────────
    ctxA, A = new_page(b)
    register(A, 'Айгерім Сейтқазы', 'aigerim_s', 'aigerim.s@example.kz')
    A.wait_for_selector('.empty-state, .project-card__link', timeout=8000)
    check('жаңа пайдаланушының дашборды бос (mock жоба жоқ)', A.locator('.project-card__link').count() == 0)
    A.screenshot(path=f'{OUT}/01-empty-dashboard.png')
    cookies = {c['name']: c for c in ctxA.cookies()}
    check('сессия кукиі HttpOnly', cookies.get('uya_session', {}).get('httpOnly') is True)
    check('токен localStorage-те жоқ', 'uya_session' not in A.evaluate('JSON.stringify(Object.assign({}, localStorage))'))

    # ── Қате кіру: қазақша хабар ────────────────────────
    ctxX, X = new_page(b)
    X.goto(BASE + '/#/login'); X.wait_for_selector('#field-identifier')
    check('кіру бетінде demo-деректер жоқ (нақты режим)', X.locator('.demo-box').count() == 0)
    X.locator('#field-identifier').fill('aigerim_s'); X.locator('#field-password').fill('wrong-password-1')
    X.get_by_role('button', name='Кіру', exact=True).click()
    X.wait_for_selector('.alert')
    check('қате құпия сөз: қазақша хабар', 'қате' in X.locator('.alert').first.inner_text())
    ctxX.close()

    # ── Жоба құру ───────────────────────────────────────
    A.goto(BASE + '/#/projects/new'); A.wait_for_selector('input[name=name]')
    A.locator('input[name=name]').fill('Алматы ауа сапасы')
    A.locator('textarea[name=description]').fill('Нақты дерекқордағы жоба')
    A.locator('.chip-toggle').first.click()
    A.get_by_role('button', name='Жобаны құру').click()
    A.wait_for_selector('[data-testid=invite-code]')
    code = A.locator('[data-testid=invite-code]').inner_text().strip()
    check('шақыру коды XXXX-XXXX-XXXX форматында', re.fullmatch(r'[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}', code) is not None)
    A.screenshot(path=f'{OUT}/02-created.png')

    A.goto(BASE + '/#/dashboard'); A.wait_for_selector('.project-card__link')
    check('дашбордта жоба көрінеді', A.locator('.project-card__link').count() == 1)
    A.locator('.project-card__link').first.click()
    A.wait_for_selector('[data-testid=workspace]'); A.wait_for_timeout(800)
    ws_url = A.url
    A.get_by_role('treeitem', name=re.compile(r'main\.py')).first.click()
    A.wait_for_selector('.fb__area', timeout=8000)
    check('үлгі файл мазмұны серверден келді', 'Сәлем, әлем' in editor_text(A))

    # ── Редакциялау және сақтау ─────────────────────────
    A.locator('.fb__area').click(); A.keyboard.press('Control+End'); A.keyboard.type('\n# серверге сақталады ӘҒҚ')
    A.keyboard.press('Control+s'); A.wait_for_timeout(900)
    check('Ctrl+S: өзгеріс серверге жетті (синхрондалды)', A.locator('.etab.is-dirty').count() == 0 and 'Синхрондалды' in A.locator('[data-testid=sync-state]').inner_text())

    # ── Жаңа файл (explorer) ────────────────────────────
    A.get_by_role('button', name='Жаңа файл').first.click()
    A.locator('.tree__input').fill('utils.py'); A.keyboard.press('Enter'); A.wait_for_timeout(700)
    check('жаңа файл ағашта пайда болды', A.get_by_role('treeitem', name=re.compile('utils.py')).count() == 1)
    A.get_by_role('button', name='Жаңа файл').first.click()
    A.locator('.tree__input').fill('utils.py'); A.keyboard.press('Enter'); A.wait_for_timeout(700)
    check('қайталанатын атау: қазақша қате көрсетілді', 'бұрыннан бар' in (A.locator('.tree__error').first.inner_text() if A.locator('.tree__error').count() else ''))
    A.keyboard.press('Escape')
    A.get_by_role('button', name='Жаңа қалта').first.click()
    A.locator('.tree__input').fill('docs'); A.keyboard.press('Enter'); A.wait_for_timeout(700)
    check('жаңа қалта жасалды', A.get_by_role('treeitem', name=re.compile('docs')).count() >= 1)

    # ── Бетті жаңарту: деректер дерекқордан қайта оқылады ─
    A.reload(); A.wait_for_selector('[data-testid=workspace]'); A.wait_for_timeout(800)
    check('жаңартудан кейін utils.py сақталған', A.get_by_role('treeitem', name=re.compile('utils.py')).count() == 1)
    check('жаңартудан кейін docs қалтасы сақталған', A.get_by_role('treeitem', name=re.compile('docs')).count() >= 1)
    A.get_by_role('treeitem', name=re.compile(r'main\.py')).first.click(); A.wait_for_selector('.fb__area')
    check('жаңартудан кейін өңделген мазмұн сақталған', '# серверге сақталады ӘҒҚ' in editor_text(A))
    A.screenshot(path=f'{OUT}/03-workspace-persisted.png')

    # ── Екінші пайдаланушы кодпен қосылады ───────────────
    ctxB, B = new_page(b)
    register(B, 'Дана Ермекова', 'dana_e', 'dana.e@example.kz')
    B.goto(BASE + '/#/projects/join'); B.wait_for_selector('#field-code')
    B.locator('#field-code').fill('AAAA-BBBB-CCCC'); B.get_by_role('button', name=re.compile('Қосылу')).first.click()
    B.wait_for_selector('.alert, .field__error')
    check('қате код: қазақша хабар', 'қате' in B.locator('.alert, .field__error').first.inner_text())
    B.locator('#field-code').fill(code); B.get_by_role('button', name=re.compile('Қосылу')).first.click()
    B.wait_for_selector('.success-card', timeout=8000)
    B.screenshot(path=f'{OUT}/04-joined.png')
    B.goto(ws_url); B.wait_for_selector('[data-testid=workspace]'); B.wait_for_timeout(800)
    check('қосылған адам жобаны ашты, файлдар көрінеді', B.get_by_role('treeitem', name=re.compile('utils.py')).count() == 1)
    B.get_by_role('treeitem', name=re.compile(r'main\.py')).first.click(); B.wait_for_selector('.fb__area')
    check('екінші пайдаланушы иесі сақтаған мазмұнды көреді', '# серверге сақталады ӘҒҚ' in editor_text(B))
    B.locator('[role=tab]', has_text='Қатысушылар').click(); B.wait_for_timeout(500)
    check('қатысушылар тізімінде екі нақты адам', B.locator('.member').count() == 2)
    B.screenshot(path=f'{OUT}/05-member-view.png')

    # ── Иесі рөлді viewer-ге түсіреді (нақты API) ────────
    pid = ws_url.split('/projects/')[1]
    members = A.evaluate("(pid) => fetch('/api/projects/' + pid + '/members').then(r => r.json())", pid)['members']
    dana = [m for m in members if m['username'] == 'dana_e'][0]
    r = A.evaluate("([pid, uid]) => fetch('/api/projects/' + pid + '/members/' + uid, {method:'PATCH', headers:{'content-type':'application/json'}, body: JSON.stringify({role:'viewer'})}).then(r => r.status)", [pid, dana['userId']])
    check('иесі рөлді өзгертті (200)', r == 200)
    B.reload(); B.wait_for_selector('[data-testid=workspace]'); B.wait_for_timeout(800)
    check('viewer: файл құру түймесі жоқ немесе өшірулі', B.get_by_role('button', name='Жаңа файл').count() == 0 or B.get_by_role('button', name='Жаңа файл').first.is_disabled())
    check('viewer: Run түймелері өшірулі', B.get_by_role('button', name=re.compile('Жобаны іске қосу')).first.is_disabled())
    B.get_by_role('treeitem', name=re.compile(r'main\.py')).first.click(); B.wait_for_selector('.fb__area')
    check('viewer: редактор тек оқуға', B.locator('.fb__area').get_attribute('readonly') is not None)
    B.screenshot(path=f'{OUT}/06-viewer.png')

    # ── Баптаулар және жою (иесі) ───────────────────────
    A.get_by_role('button', name='Жоба баптаулары').click(); A.wait_for_selector('#set-name', timeout=8000)
    A.locator('#set-name').fill('Алматы ауа сапасы v2'); A.screenshot(path=f'{OUT}/07-settings.png')
    A.get_by_role('button', name='Сақтау', exact=True).click(); A.wait_for_timeout(800)
    check('баптау сақталды: жоба атауы жоғарғы панельде жаңарды', 'v2' in A.locator('.topbar__name').inner_text())
    A.reload(); A.wait_for_selector('[data-testid=workspace]')
    check('жаңартудан кейін жаңа атау сақталған', 'v2' in A.locator('.topbar__name').inner_text())
    A.get_by_role('button', name='Жоба баптаулары').click(); A.wait_for_selector('#set-confirm')
    check('жою түймесі растауға дейін өшірулі', A.get_by_role('button', name='Жобаны біржола жою').is_disabled())
    A.locator('#set-confirm').fill('Алматы ауа сапасы v2')
    A.get_by_role('button', name='Жобаны біржола жою').click()
    A.wait_for_url(re.compile('dashboard'), timeout=8000); A.wait_for_timeout(600)
    check('жойылғаннан кейін дашборд бос', A.locator('.project-card__link').count() == 0)
    B.goto(ws_url); B.reload(); B.wait_for_timeout(1500)
    check('жойылған жоба қатысушыға «табылмады» деп көрінеді', B.locator('[data-testid=workspace]').count() == 0 and 'табылмады' in B.locator('.empty-state').inner_text())
    B.screenshot(path=f'{OUT}/08-deleted.png')

    # ── Шығу ────────────────────────────────────────────
    A.goto(BASE + '/#/profile'); A.wait_for_timeout(500)
    A.locator('.appbar__user').click(); A.get_by_role('menuitem', name='Шығу').click(); A.wait_for_url(re.compile('login'), timeout=8000)
    A.reload(); A.wait_for_timeout(500)
    check('шыққан соң қорғалған бет кіру бетіне бағыттайды', '/login' in A.url)

    # ── Мобильді көрініс ────────────────────────────────
    ctxM, M = new_page(b, 390, 800)
    M.goto(BASE + '/#/login'); M.wait_for_selector('#field-identifier')
    M.locator('#field-identifier').fill('dana_e'); M.locator('#field-password').fill(PW)
    M.get_by_role('button', name='Кіру', exact=True).click(); M.wait_for_url(re.compile('dashboard')); M.wait_for_timeout(500)
    M.screenshot(path=f'{OUT}/09-mobile-dashboard.png')
    b.close()
finally:
    srv.terminate()
    try: srv.wait(5)
    except Exception: srv.kill()
    shutil.rmtree(tmp, ignore_errors=True)

print('\nКонсоль қателері:', errors[:10])
check('консольде қате жоқ', not errors)
print(f"\nНәтиже: {'сәтсіз ' + str(len(fails)) if fails else 'барлығы өтті'}")
sys.exit(1 if fails else 0)
