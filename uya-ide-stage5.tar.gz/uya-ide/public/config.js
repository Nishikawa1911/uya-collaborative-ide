// Орындау уақытындағы баптаулар (қайта құрастырусыз өзгертуге болады).
// monacoBase — Monaco "vs" қалтасының мекенжайы. Өз серверіңізде орналастыру үшін: '/vs'
window.__UYA_CONFIG__ = {
  // 'http' — нақты бэкэнд (әдепкі); 'mock' — тек визуалды сынақ (деректер жадта, сервер қажет емес)
  apiMode: 'http',
  apiBase: '/api',
  monacoBase: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.52.2/min/vs',
};
