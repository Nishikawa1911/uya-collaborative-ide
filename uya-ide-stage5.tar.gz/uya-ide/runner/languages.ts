/**
 * Әр тіл үшін БӨЛЕК орындау конфигурациясы: компиляция/іске қосу пәрмені, құрал-сайман жолдары, шектер, өзін-өзі тексеру (self-test).
 * Тіл тек self-test (компиляция қатесі + дұрыс нәтиже, оқшауланған контейнерде) өтсе ғана қосылады.
 * Тіл құралы орнатылмаған болса (мысалы dotnet), тіл «қолжетімсіз» болады — өтірік қосылмайды.
 */
import { existsSync, readFileSync, realpathSync } from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import type { Limits, Mount } from './sandbox.ts';

export const LANGS = ['python', 'java', 'cpp', 'csharp', 'rust', 'php', 'typescript', 'javascript', 'go', 'sql'] as const;
export type RunLang = (typeof LANGS)[number];
export type WebLang = 'html' | 'css';

export const EXT_TO_LANG: Record<string, RunLang | WebLang> = {
  py: 'python', java: 'java', cpp: 'cpp', cc: 'cpp', cxx: 'cpp', cs: 'csharp', rs: 'rust', php: 'php', ts: 'typescript', js: 'javascript', mjs: 'javascript',
  go: 'go', sql: 'sql', html: 'html', htm: 'html', css: 'css',
};

export function langOfPath(p: string): RunLang | WebLang | null {
  const m = /\.([A-Za-z0-9]+)$/.exec(p);
  return m ? (EXT_TO_LANG[m[1].toLowerCase()] ?? null) : null;
}

export interface SourceFile { path: string; content: string }
export interface PlanInput { files: SourceFile[]; entry: string; mode: 'file' | 'project' }
export interface PlanPhase { name: 'compile' | 'run'; cmd: string[]; env?: Record<string, string>; limits?: Partial<Limits> }
export interface Plan { extraFiles: SourceFile[]; phases: PlanPhase[] }

export interface LangConfig {
  id: RunLang;
  label: string;
  /** Хост құралдары: болмаса — тіл қолжетімсіз */
  requires: string[];
  mounts: Mount[];
  env: Record<string, string>;
  /** Әдепкі шектерді басу */
  limits: { compile?: Partial<Limits>; run?: Partial<Limits> };
  plan(input: PlanInput): Plan;
  selfTest: { files: SourceFile[]; entry: string; expect: string; badFiles?: SourceFile[] };
}

export const DEFAULT_LIMITS: Limits = {
  memoryMB: 256, cpus: 1, pids: 64, timeoutMs: 10_000, fsizeMB: 32, nofile: 256, workMB: 64, outputBytes: 256 * 1024,
};
export const COMPILE_LIMITS: Limits = { ...DEFAULT_LIMITS, memoryMB: 768, cpus: 2, pids: 256, timeoutMs: 45_000, nofile: 1024 };

const SAFE_PATH = '/usr/local/bin:/usr/bin:/bin';
const which = (c: string): string | null => {
  try { return realpathSync(execFileSync('which', [c], { encoding: 'utf8', env: process.env }).trim()); } catch { return null; }
};
const whichRaw = (c: string): string | null => {
  try { return execFileSync('which', [c], { encoding: 'utf8', env: process.env }).trim() || null; } catch { return null; }
};
const underUsr = (p: string) => p === '/usr' || p.startsWith('/usr/');

/** Мәтіннен Java main класының толық атын табу: `package a.b;` + файл аты. */
export function javaMainClass(file: SourceFile): string {
  const pkg = /^\s*package\s+([\w.]+)\s*;/m.exec(file.content)?.[1];
  const cls = path.basename(file.path).replace(/\.java$/i, '');
  return pkg ? `${pkg}.${cls}` : cls;
}

const ofExt = (files: SourceFile[], re: RegExp) => files.filter((f) => re.test(f.path)).map((f) => f.path);
const hasMain = (f: SourceFile) => /\bint\s+main\s*\(/.test(f.content);

export function buildLanguages(): LangConfig[] {
  const list: LangConfig[] = [];

  // ── Python ──
  const py = whichRaw('python3') ? realpathSync(whichRaw('python3')!) : null;
  list.push({
    id: 'python', label: 'Python', requires: py ? [py] : ['python3'], mounts: [], env: { PATH: SAFE_PATH, PYTHONDONTWRITEBYTECODE: '1', PYTHONNOUSERSITE: '1', PYTHONIOENCODING: 'utf-8', PYTHONUNBUFFERED: '1' },
    limits: {},
    plan: ({ entry }) => ({ extraFiles: [], phases: [{ name: 'run', cmd: [py ?? 'python3', '-X', 'utf8', entry] }] }),
    selfTest: { files: [{ path: 'main.py', content: 'import helper\nprint("py:" + helper.f())\n' }, { path: 'helper.py', content: 'def f(): return "ok"\n' }], entry: 'main.py', expect: 'py:ok' },
  });

  // ── JavaScript (Node.js) ──
  const node = whichRaw('node') ? realpathSync(whichRaw('node')!) : null;
  const nodeRoot = node ? path.dirname(path.dirname(node)) : null;
  const nodeMounts: Mount[] = nodeRoot && !underUsr(nodeRoot) ? [{ src: nodeRoot, dst: nodeRoot }] : [];
  list.push({
    id: 'javascript', label: 'JavaScript (Node.js)', requires: node ? [node] : ['node'], mounts: nodeMounts, env: { PATH: SAFE_PATH, NODE_OPTIONS: '--max-old-space-size=160' },
    limits: { run: { memoryMB: 320 } },
    plan: ({ entry }) => ({ extraFiles: [], phases: [{ name: 'run', cmd: [node ?? 'node', '--no-warnings', entry] }] }),
    selfTest: { files: [{ path: 'main.js', content: 'const h = require("./h.js"); console.log("js:" + h());\n' }, { path: 'h.js', content: 'module.exports = () => "ok";\n' }], entry: 'main.js', expect: 'js:ok' },
  });

  // ── TypeScript: tsc → node ──
  const tscBin = whichRaw('tsc') ? realpathSync(whichRaw('tsc')!) : null;
  const tscRoot = tscBin ? tscBin.split('/node_modules/')[0] : null;
  const tsMounts: Mount[] = [...nodeMounts, ...(tscRoot && !underUsr(tscRoot) && tscRoot !== nodeRoot ? [{ src: tscRoot, dst: tscRoot }] : [])];
  const NODE_DTS = 'declare var process: any; declare var require: any; declare var module: any; declare var exports: any; declare var Buffer: any; declare var __dirname: string;\n';
  list.push({
    id: 'typescript', label: 'TypeScript', requires: [node ?? 'node', tscBin ?? 'tsc'], mounts: tsMounts, env: { PATH: SAFE_PATH, NODE_OPTIONS: '--max-old-space-size=160' },
    limits: { compile: { memoryMB: 1024, pids: 256, timeoutMs: 60_000 }, run: { memoryMB: 320 } },
    plan: ({ entry }) => {
      const out = '.uya-out';
      const js = `${out}/${entry.replace(/\.ts$/i, '.js')}`;
      return {
        extraFiles: [{ path: '.uya-node.d.ts', content: NODE_DTS }],
        phases: [
          { name: 'compile', cmd: [node ?? 'node', tscBin ?? 'tsc', '--outDir', out, '--target', 'es2022', '--module', 'commonjs', '--skipLibCheck', '--pretty', 'false', '--noEmitOnError', 'true', '.uya-node.d.ts', entry] },
          { name: 'run', cmd: [node ?? 'node', '--no-warnings', js] },
        ],
      };
    },
    selfTest: {
      files: [{ path: 'main.ts', content: 'import { f } from "./h";\nconst x: number = f();\nconsole.log("ts:" + x);\n' }, { path: 'h.ts', content: 'export const f = (): number => 42;\n' }], entry: 'main.ts', expect: 'ts:42',
      badFiles: [{ path: 'main.ts', content: 'const x: number = "text";\nconsole.log(x);\n' }],
    },
  });

  // ── Java ──
  const javac = whichRaw('javac') ? realpathSync(whichRaw('javac')!) : null;
  const javaBin = whichRaw('java') ? realpathSync(whichRaw('java')!) : null;
  const javaMounts: Mount[] = [];
  if (javaBin) {
    const home = path.dirname(path.dirname(javaBin));
    for (const sub of ['conf', 'lib/security']) {
      const p = path.join(home, sub);
      if (existsSync(p)) { try { const r = realpathSync(p); if (!underUsr(r)) javaMounts.push({ src: r, dst: r }); } catch { /* ignore */ } }
    }
    for (const d of ['/etc/java-21-openjdk', '/etc/ssl/certs/java']) if (existsSync(d) && !javaMounts.some((m) => m.dst === d)) javaMounts.push({ src: d, dst: d });
  }
  const JVM = '-Xmx192m -Xss512k -XX:+UseSerialGC -XX:TieredStopAtLevel=1 -XX:CICompilerCount=1 -XX:-UsePerfData -Xshare:auto -Dfile.encoding=UTF-8';
  list.push({
    id: 'java', label: 'Java', requires: [javac ?? 'javac', javaBin ?? 'java'], mounts: javaMounts, env: { PATH: SAFE_PATH, JAVA_TOOL_OPTIONS: JVM, LC_ALL: 'C.UTF-8' },
    limits: { compile: { memoryMB: 768, pids: 200, timeoutMs: 60_000 }, run: { memoryMB: 448, pids: 96 } },
    plan: ({ files, entry }) => {
      const main = files.find((f) => f.path === entry)!;
      const srcs = ofExt(files, /\.java$/i);
      return {
        extraFiles: [],
        phases: [
          { name: 'compile', cmd: [javac ?? 'javac', '-encoding', 'UTF-8', '-proc:none', '-d', '.uya-out', ...srcs] },
          { name: 'run', cmd: [javaBin ?? 'java', '-cp', '.uya-out', javaMainClass(main)] },
        ],
      };
    },
    selfTest: {
      files: [{ path: 'Main.java', content: 'public class Main { public static void main(String[] a) { System.out.println("java:" + Util.f()); } }\n' }, { path: 'Util.java', content: 'class Util { static String f() { return "ok"; } }\n' }], entry: 'Main.java', expect: 'java:ok',
      badFiles: [{ path: 'Main.java', content: 'public class Main { public static void main(String[] a) { int x = "s"; } }\n' }],
    },
  });

  // ── C++ ──
  const gpp = which('g++');
  list.push({
    id: 'cpp', label: 'C++', requires: [gpp ?? 'g++'], mounts: [], env: { PATH: SAFE_PATH, LC_ALL: 'C.UTF-8' },
    limits: { compile: { memoryMB: 768, pids: 128, timeoutMs: 60_000 }, run: {} },
    plan: ({ files, entry, mode }) => {
      // Басқа .cpp файлдар (main-сыз) тәуелділік ретінде байланыстырылады; бірнеше main болса — тек таңдалған файл
      const others = mode === 'project' || true ? files.filter((f) => /\.(cpp|cc|cxx)$/i.test(f.path) && f.path !== entry && !hasMain(f)).map((f) => f.path) : [];
      return {
        extraFiles: [],
        phases: [
          { name: 'compile', cmd: [gpp ?? 'g++', '-std=c++20', '-O1', '-pipe', '-fdiagnostics-color=never', '-I.', '-o', '.uya-out/prog', entry, ...others] },
          { name: 'run', cmd: ['./.uya-out/prog'] },
        ],
      };
    },
    selfTest: {
      files: [{ path: 'main.cpp', content: '#include <iostream>\n#include "u.h"\nint main(){ std::cout << "cpp:" << f() << std::endl; }\n' }, { path: 'u.h', content: 'inline const char* f(){ return "ok"; }\n' }], entry: 'main.cpp', expect: 'cpp:ok',
      badFiles: [{ path: 'main.cpp', content: 'int main(){ int x = ; }\n' }],
    },
  });

  // ── Rust ──
  const ccPath = which('cc');
  let rustSysroot: string | null = null;
  try { rustSysroot = execFileSync('rustc', ['--print', 'sysroot'], { encoding: 'utf8' }).trim(); } catch { /* жоқ */ }
  const rustc = rustSysroot ? path.join(rustSysroot, 'bin', 'rustc') : null;
  list.push({
    id: 'rust', label: 'Rust', requires: [rustc ?? 'rustc', ccPath ?? 'cc'], mounts: rustSysroot && !underUsr(rustSysroot) ? [{ src: rustSysroot, dst: rustSysroot }] : [], env: { PATH: SAFE_PATH, RUST_BACKTRACE: '0' },
    limits: { compile: { memoryMB: 1024, pids: 200, timeoutMs: 90_000, workMB: 128 }, run: {} },
    plan: ({ entry }) => ({
      extraFiles: [],
      phases: [
        { name: 'compile', cmd: [rustc ?? 'rustc', '--edition', '2021', '-C', 'opt-level=1', '-C', 'codegen-units=4', '--color', 'never', '-C', `linker=${ccPath ?? '/usr/bin/cc'}`, '-o', '.uya-out/prog', entry] },
        { name: 'run', cmd: ['./.uya-out/prog'] },
      ],
    }),
    selfTest: {
      files: [{ path: 'main.rs', content: 'mod u;\nfn main() { println!("rust:{}", u::f()); }\n' }, { path: 'u.rs', content: 'pub fn f() -> &\'static str { "ok" }\n' }], entry: 'main.rs', expect: 'rust:ok',
      badFiles: [{ path: 'main.rs', content: 'fn main() { let x: i32 = "s"; }\n' }],
    },
  });

  // ── Go ──
  const goBin = whichRaw('go') ? realpathSync(whichRaw('go')!) : null;
  const goRoot = goBin ? path.dirname(path.dirname(goBin)) : null;
  list.push({
    id: 'go', label: 'Go', requires: [goBin ?? 'go'], mounts: goRoot && !underUsr(goRoot) ? [{ src: goRoot, dst: goRoot }] : [],
    env: { PATH: `${goRoot ? goRoot + '/bin:' : ''}${SAFE_PATH}`, GOROOT: goRoot ?? '', GOCACHE: '/work/.gocache', GOPATH: '/tmp/gopath', GOFLAGS: '-p=2', GOTOOLCHAIN: 'local', GOPROXY: 'off', GOSUMDB: 'off', CGO_ENABLED: '0', GOMAXPROCS: '2', GOTELEMETRY: 'off' },
    limits: { compile: { memoryMB: 1024, pids: 256, timeoutMs: 120_000, workMB: 320, fsizeMB: 128 }, run: {} },
    plan: ({ files, entry }) => {
      const dir = path.posix.dirname(entry);
      const hasMod = files.some((f) => f.path === 'go.mod');
      const srcs = files.filter((f) => path.posix.dirname(f.path) === dir && /\.go$/.test(f.path) && !/_test\.go$/.test(f.path)).map((f) => f.path);
      return {
        extraFiles: [],
        phases: [
          { name: 'compile', cmd: [goBin ?? 'go', 'build', '-o', '/work/.uya-out/prog', ...(hasMod && dir === '.' ? ['.'] : srcs)] },
          { name: 'run', cmd: ['/work/.uya-out/prog'] },
        ],
      };
    },
    selfTest: {
      files: [{ path: 'main.go', content: 'package main\nimport "fmt"\nfunc main() { fmt.Println("go:" + f()) }\n' }, { path: 'u.go', content: 'package main\nfunc f() string { return "ok" }\n' }], entry: 'main.go', expect: 'go:ok',
      badFiles: [{ path: 'main.go', content: 'package main\nfunc main() { var x int = "s" }\n' }],
    },
  });

  // ── PHP ──
  const php = whichRaw('php') ? realpathSync(whichRaw('php')!) : null;
  const DISABLED = 'exec,shell_exec,system,passthru,popen,proc_open,pcntl_exec,pcntl_fork,mail,dl,putenv,symlink,link,posix_kill,posix_setuid,fsockopen,pfsockopen,stream_socket_client,stream_socket_server,curl_exec,curl_multi_exec';
  list.push({
    id: 'php', label: 'PHP', requires: [php ?? 'php'], mounts: [], env: { PATH: SAFE_PATH },
    limits: { run: { memoryMB: 192 } },
    plan: ({ entry }) => ({
      extraFiles: [],
      phases: [{ name: 'run', cmd: [php ?? 'php', '-n', '-d', 'display_errors=stderr', '-d', 'error_reporting=E_ALL', '-d', 'memory_limit=128M', '-d', 'allow_url_fopen=0', '-d', 'allow_url_include=0', '-d', `disable_functions=${DISABLED}`, '-d', 'open_basedir=/work:/tmp:/usr/share/php', '-d', 'max_execution_time=8', entry] }],
    }),
    selfTest: { files: [{ path: 'main.php', content: '<?php\nrequire_once __DIR__ . "/h.php";\necho "php:" . f() . "\\n";\n' }, { path: 'h.php', content: '<?php function f() { return "ok"; }\n' }], entry: 'main.php', expect: 'php:ok' },
  });

  // ── C# (.NET SDK қажет) ──
  const dotnet = whichRaw('dotnet');
  const dotnetRoot = dotnet ? path.dirname(realpathSync(dotnet)) : null;
  list.push({
    id: 'csharp', label: 'C#', requires: [dotnet ?? 'dotnet'], mounts: dotnetRoot && !underUsr(dotnetRoot) ? [{ src: dotnetRoot, dst: dotnetRoot }] : [],
    env: { PATH: `${dotnetRoot ? dotnetRoot + ':' : ''}${SAFE_PATH}`, DOTNET_CLI_HOME: '/tmp/dotnet', DOTNET_NOLOGO: '1', DOTNET_CLI_TELEMETRY_OPTOUT: '1', DOTNET_SKIP_FIRST_TIME_EXPERIENCE: '1', NUGET_PACKAGES: '/tmp/nuget', DOTNET_gcServer: '0', DOTNET_TieredPGO: '0' },
    limits: { compile: { memoryMB: 1024, pids: 256, timeoutMs: 120_000, workMB: 256 }, run: { memoryMB: 320, pids: 96 } },
    plan: ({ files, entry }) => {
      const csproj = `<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><Nullable>enable</Nullable><ImplicitUsings>enable</ImplicitUsings><EnableDefaultCompileItems>true</EnableDefaultCompileItems></PropertyGroup></Project>\n`;
      void files; void entry;
      return {
        extraFiles: [{ path: 'uya.csproj', content: csproj }],
        phases: [
          { name: 'compile', cmd: [dotnet ?? 'dotnet', 'build', 'uya.csproj', '-c', 'Release', '-o', '.uya-out', '--nologo', '-v', 'q', '--no-restore'] },
          { name: 'run', cmd: [dotnet ?? 'dotnet', '.uya-out/uya.dll'] },
        ],
      };
    },
    selfTest: { files: [{ path: 'Program.cs', content: 'Console.WriteLine("cs:ok");\n' }], entry: 'Program.cs', expect: 'cs:ok', badFiles: [{ path: 'Program.cs', content: 'int x = "s";\n' }] },
  });

  // ── SQL (оқшауланған SQLite, жадтағы дерекқор) ──
  list.push({
    id: 'sql', label: 'SQL (SQLite)', requires: [py ?? 'python3'], mounts: [], env: { PATH: SAFE_PATH, PYTHONDONTWRITEBYTECODE: '1', PYTHONIOENCODING: 'utf-8' },
    limits: { run: { memoryMB: 192, timeoutMs: 12_000 } },
    plan: ({ entry }) => ({
      extraFiles: [{ path: '.uya-sql.py', content: SQL_HARNESS }],
      phases: [{ name: 'run', cmd: [py ?? 'python3', '-X', 'utf8', '-I', '.uya-sql.py', entry] }],
    }),
    selfTest: { files: [{ path: 'q.sql', content: 'CREATE TABLE t(a INT, b TEXT); INSERT INTO t VALUES (1, \'ok\'), (2, \'x\');\nSELECT b FROM t WHERE a = 1;\n' }], entry: 'q.sql', expect: 'ok' },
  });

  return list;
}

/** SQL харнесі: бір рет қолданылатын жадтағы SQLite; ATTACH/ұзартулар/қауіпті PRAGMA тыйым; өлшем, қатар, уақыт шектері. */
export const SQL_HARNESS = String.raw`
import sqlite3, sys, time

MAX_ROWS = 200
MAX_CELL = 200
STMT_SECONDS = 5.0
SAFE_PRAGMAS = {'table_info', 'table_xinfo', 'table_list', 'index_list', 'index_info', 'index_xinfo', 'foreign_key_list', 'foreign_keys', 'database_list', 'collation_list', 'function_list', 'compile_options', 'user_version'}
DENY_ACTIONS = {sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH}

def authorizer(action, a1, a2, db, trigger):
    if action in DENY_ACTIONS:
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_PRAGMA and (a1 or '').lower() not in SAFE_PRAGMAS:
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_FUNCTION and (a2 or '').lower() in ('load_extension', 'readfile', 'writefile', 'edit', 'fts3_tokenizer'):
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK

def cell(v):
    if v is None: return 'NULL'
    if isinstance(v, bytes): return "x'" + v[:16].hex() + ("…'" if len(v) > 16 else "'")
    s = str(v).replace('\n', '↵')
    return s if len(s) <= MAX_CELL else s[:MAX_CELL] + '…'

def render(cols, rows, truncated):
    data = [[cell(v) for v in r] for r in rows]
    widths = [max([len(c)] + [len(r[i]) for r in data]) for i, c in enumerate(cols)]
    line = lambda l, m, r: l + m.join('─' * (w + 2) for w in widths) + r
    out = [line('┌', '┬', '┐'), '│' + '│'.join(' ' + c.ljust(w) + ' ' for c, w in zip(cols, widths)) + '│', line('├', '┼', '┤')]
    for r in data: out.append('│' + '│'.join(' ' + v.ljust(w) + ' ' for v, w in zip(r, widths)) + '│')
    out.append(line('└', '┴', '┘'))
    out.append('(%d қатар%s)' % (len(rows), ', шектелген' if truncated else ''))
    return '\n'.join(out)

def main():
    path = sys.argv[1]
    script = open(path, encoding='utf-8').read()
    db = sqlite3.connect(':memory:', isolation_level=None)
    db.execute('PRAGMA max_page_count = 20000')
    db.execute('PRAGMA trusted_schema = OFF')
    db.set_authorizer(authorizer)
    db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 5_000_000)
    deadline = [0.0]
    db.set_progress_handler(lambda: 1 if time.monotonic() > deadline[0] else 0, 20000)
    buf = ''
    n = 0
    code = 0
    stmts = []
    for ch in script:
        buf += ch
        if ch == ';' and sqlite3.complete_statement(buf):
            stmts.append(buf.strip()); buf = ''
    for stmt in stmts:
        if not stmt: continue
        n += 1
        deadline[0] = time.monotonic() + STMT_SECONDS
        try:
            cur = db.execute(stmt)
            if cur.description:
                cols = [d[0] for d in cur.description]
                rows = cur.fetchmany(MAX_ROWS + 1)
                trunc = len(rows) > MAX_ROWS
                print(render(cols, rows[:MAX_ROWS], trunc), flush=True)
            elif cur.rowcount is not None and cur.rowcount >= 0 and stmt.split(None, 1)[0].upper() in ('INSERT', 'UPDATE', 'DELETE', 'REPLACE'):
                print('OK, өзгерген қатарлар: %d' % cur.rowcount, flush=True)
        except sqlite3.Error as e:
            print('Қате (сұраныс №%d): %s' % (n, e), file=sys.stderr, flush=True)
            print('  ' + stmt.splitlines()[0][:120], file=sys.stderr, flush=True)
            code = 1
            break
    if code == 0 and buf.strip():
        print('Қате: соңғы сұраныс «;» белгісімен аяқталмаған', file=sys.stderr)
        code = 1
    sys.exit(code)

main()
`;
