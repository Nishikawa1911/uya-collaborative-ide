/**
 * Оқшауланған орындау: OCI контейнер (runc) — әр фаза (компиляция / іске қосу) жаңа контейнерде.
 *
 * Изоляция қабаттары (қауіпсіздік жылдамдықтан маңыздырақ):
 *  1. Namespace: user (контейнердегі uid-лер хостта артықшылықсыз 200000+ диапазонға бейнеленеді), pid, mount, net (тек loopback —
 *     сыртқы желі ЖОҚ, ішкі қызметтерге жол жоқ), ipc, uts, cgroup.
 *  2. Файлдық жүйе: бос rootfs, тек оқуға (ro); хосттан тек құрал-саймандар ro bind-пен; жазу тек /work және /tmp (tmpfs, өлшем шегімен).
 *  3. Құқықтар: барлық capability алынған, no_new_privs, seccomp (қауіпті syscall-дар, жаңа namespace жасау тыйым), masked /proc жолдары.
 *  4. Ресурстар (cgroup): жады (+swap жоқ), CPU, pids; rlimit: файл өлшемі, ашық файлдар, core=0, CPU секунд; қабырға уақыты (wall) таймері.
 *  5. Шығыс шегі: stdout/stderr көлемі асқанда процесс өлтіріледі.
 *  6. Тазалау: контейнер өшіріледі, tmpfs unmount, уақытша қалта жойылады (қате болса да).
 *
 * Орындау қызметі (runner) хостта root құқығымен жұмыс істеуі керек (mount, cgroup, userns); ол негізгі бэкэндтен БӨЛЕК процесс/хост.
 */
import { execFile, spawn, type ChildProcess } from 'node:child_process';
import { chmodSync, chownSync, existsSync, mkdirSync, statSync, mkdtempSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';

const exec = promisify(execFile);

/** Контейнер ішіндегі пайдаланушы (хостта UID_BASE + 1000 болады). */
export const SANDBOX_UID = 1000;
export const UID_BASE = 200_000;

/** Жоба файлының қатысты жолы: абсолютті емес, `..`/бос бөлік/NUL/кері қиғаш сызық жоқ. */
export function isSafeRelPath(p: string): boolean {
  if (typeof p !== 'string' || !p || p.length > 400 || p.startsWith('/') || p.includes('\\') || p.includes('\0')) return false;
  return p.split('/').every((s) => s !== '' && s !== '.' && s !== '..' && s.length <= 255);
}

export interface Limits {
  memoryMB: number;
  /** CPU үлесі (1 = бір ядро) */
  cpus: number;
  pids: number;
  /** Қабырға уақыты, мс */
  timeoutMs: number;
  /** Бір файлдың ең үлкен өлшемі, МБ (RLIMIT_FSIZE) */
  fsizeMB: number;
  nofile: number;
  /** /work tmpfs өлшемі, МБ */
  workMB: number;
  /** stdout+stderr қосындысы, байт */
  outputBytes: number;
}

export interface Mount { src: string; dst: string }

export interface Phase {
  /** Қысқа атау (лог үшін): compile | run */
  name: string;
  cmd: string[];
  env: Record<string, string>;
  /** Хосттан ro bind-пен қосылатын жолдар (құрал-саймандар) */
  mounts: Mount[];
  limits: Limits;
  stdin?: string;
}

export type Killed = 'timeout' | 'output' | 'cancel' | 'memory' | null;

export interface PhaseResult {
  exitCode: number | null;
  /** Сигнал арқылы тоқтады (мысалы SIGKILL) */
  signal: string | null;
  killedBy: Killed;
  durationMs: number;
  /** Жады шегі асып, ядро өлтірді */
  oom: boolean;
  maxMemoryBytes: number | null;
  stdoutBytes: number;
  stderrBytes: number;
}

export interface RunnerPaths {
  /** runc күй қалтасы */
  stateDir: string;
  /** Уақытша жұмыс қалталары */
  jobsDir: string;
  runc: string;
}

const NS_FLAGS = [0x20000, 0x2000000, 0x4000000, 0x8000000, 0x10000000, 0x20000000, 0x40000000]; // CLONE_NEW*

/** Контейнерде қажет емес/қауіпті syscall-дар (denylist — capability алынуы мен userns-тің үстіне қосымша қабат). */
const DENY_SYSCALLS = [
  'mount', 'umount', 'umount2', 'pivot_root', 'chroot', 'ptrace', 'process_vm_readv', 'process_vm_writev', 'kcmp', 'pidfd_getfd',
  'kexec_load', 'kexec_file_load', 'reboot', 'swapon', 'swapoff', 'init_module', 'finit_module', 'delete_module', 'create_module', 'query_module',
  'bpf', 'perf_event_open', 'userfaultfd', 'keyctl', 'add_key', 'request_key', 'unshare', 'setns', 'open_by_handle_at', 'name_to_handle_at',
  'iopl', 'ioperm', 'acct', 'settimeofday', 'clock_settime', 'clock_adjtime', 'adjtimex', 'sethostname', 'setdomainname', 'syslog',
  'quotactl', 'mount_setattr', 'move_mount', 'open_tree', 'fsopen', 'fsconfig', 'fsmount', 'fspick', 'lookup_dcookie', 'nfsservctl',
  'vhangup', 'modify_ldt', 'uselib', 'ustat', '_sysctl', 'personality', 'move_pages', 'mbind', 'set_mempolicy', 'migrate_pages',
  'io_uring_setup', 'io_uring_enter', 'io_uring_register', 'landlock_create_ruleset', 'pkey_alloc', 'pkey_free',
];

export function buildSeccomp() {
  return {
    defaultAction: 'SCMP_ACT_ALLOW',
    architectures: ['SCMP_ARCH_X86_64', 'SCMP_ARCH_X86', 'SCMP_ARCH_X32'],
    syscalls: [
      { names: DENY_SYSCALLS, action: 'SCMP_ACT_ERRNO', errnoRet: 1 },
      // clone3 аргументтері құрылымда (сүзуге болмайды) → ENOSYS: glibc clone-ға оралады
      { names: ['clone3'], action: 'SCMP_ACT_ERRNO', errnoRet: 38 },
      // clone жаңа namespace жасай алмайды
      ...NS_FLAGS.map((f) => ({ names: ['clone'], action: 'SCMP_ACT_ERRNO', errnoRet: 1, args: [{ index: 0, value: f, valueTwo: f, op: 'SCMP_CMP_MASKED_EQ' }] })),
    ],
  };
}

export interface BuildOptions { id: string; phase: Phase; rootfs: string; workDir: string; extraDirs: string[] }

export function buildSpec(o: BuildOptions) {
  const { phase: p } = o;
  const L = p.limits;
  const env = Object.entries({ HOME: '/tmp', TMPDIR: '/tmp', LANG: 'C.UTF-8', ...p.env }).map(([k, v]) => `${k}=${v}`);
  return {
    ociVersion: '1.0.2',
    process: {
      terminal: false,
      user: { uid: SANDBOX_UID, gid: SANDBOX_UID },
      args: p.cmd,
      env,
      cwd: '/work',
      noNewPrivileges: true,
      capabilities: { bounding: [], effective: [], inheritable: [], permitted: [], ambient: [] },
      rlimits: [
        { type: 'RLIMIT_NOFILE', hard: L.nofile, soft: L.nofile },
        { type: 'RLIMIT_FSIZE', hard: L.fsizeMB * 1024 * 1024, soft: L.fsizeMB * 1024 * 1024 },
        { type: 'RLIMIT_CORE', hard: 0, soft: 0 },
        { type: 'RLIMIT_CPU', hard: Math.ceil(L.timeoutMs / 1000) + 2, soft: Math.ceil(L.timeoutMs / 1000) + 1 },
      ],
      oomScoreAdj: 500,
    },
    root: { path: o.rootfs, readonly: true },
    hostname: 'sandbox',
    mounts: [
      { destination: '/proc', type: 'proc', source: 'proc', options: ['nosuid', 'noexec', 'nodev'] },
      { destination: '/dev', type: 'tmpfs', source: 'tmpfs', options: ['nosuid', 'noexec', 'strictatime', 'mode=755', 'size=1m'] },
      { destination: '/dev/shm', type: 'tmpfs', source: 'shm', options: ['nosuid', 'noexec', 'nodev', 'mode=1777', 'size=16m'] },
      { destination: '/tmp', type: 'tmpfs', source: 'tmpfs', options: ['nosuid', 'nodev', 'mode=1777', `size=${Math.max(16, Math.floor(L.workMB / 2))}m`] },
      { destination: '/usr', type: 'bind', source: '/usr', options: ['rbind', 'ro', 'nosuid', 'nodev'] },
      ...p.mounts.map((m) => ({ destination: m.dst, type: 'bind', source: m.src, options: ['rbind', 'ro', 'nosuid', 'nodev'] })),
      { destination: '/etc/passwd', type: 'bind', source: path.join(o.rootfs, '..', 'etc-passwd'), options: ['bind', 'ro', 'nosuid', 'nodev', 'noexec'] },
      { destination: '/etc/group', type: 'bind', source: path.join(o.rootfs, '..', 'etc-group'), options: ['bind', 'ro', 'nosuid', 'nodev', 'noexec'] },
      { destination: '/work', type: 'bind', source: o.workDir, options: ['rbind', 'rw', 'nosuid', 'nodev'] },
    ],
    linux: {
      namespaces: ['pid', 'network', 'ipc', 'uts', 'mount', 'user', 'cgroup'].map((type) => ({ type })),
      uidMappings: [{ containerID: 0, hostID: UID_BASE, size: 65536 }],
      gidMappings: [{ containerID: 0, hostID: UID_BASE, size: 65536 }],
      cgroupsPath: `/uya-runner/${o.id}`,
      resources: {
        memory: { limit: L.memoryMB * 1024 * 1024, swap: L.memoryMB * 1024 * 1024, disableOOMKiller: false },
        cpu: { quota: Math.round(L.cpus * 100_000), period: 100_000 },
        pids: { limit: L.pids },
      },
      devices: [],
      seccomp: buildSeccomp(),
      maskedPaths: ['/proc/acpi', '/proc/kcore', '/proc/keys', '/proc/latency_stats', '/proc/timer_list', '/proc/timer_stats', '/proc/sched_debug', '/proc/scsi', '/sys/firmware'],
      readonlyPaths: ['/proc/asound', '/proc/bus', '/proc/fs', '/proc/irq', '/proc/sys', '/proc/sysrq-trigger'],
    },
  };
}

/** Хост rootfs-тің қаңқасы: тек бос қалталар мен /usr-ға сілтемелер; өзі де ro. */
function makeRootfs(dir: string, extra: string[]) {
  const root = path.join(dir, 'rootfs');
  for (const d of ['usr', 'proc', 'dev', 'tmp', 'work', 'etc', 'opt', 'root', 'home', 'var', 'run', ...extra.map((e) => e.replace(/^\//, ''))]) mkdirSync(path.join(root, d), { recursive: true });
  for (const [l, t] of [['bin', 'usr/bin'], ['sbin', 'usr/sbin'], ['lib', 'usr/lib'], ['lib64', 'usr/lib64'], ['lib32', 'usr/lib32']] as const) symlinkSync(t, path.join(root, l));
  return root;
}

export async function ensureRuntime(paths: RunnerPaths): Promise<{ ok: true } | { ok: false; reason: string }> {
  try {
    if (process.getuid?.() !== 0) return { ok: false, reason: 'runner root құқығымен жұмыс істеуі керек (mount, userns, cgroup)' };
    await exec(paths.runc, ['--version']);
    await exec('mount', ['--version']);
    mkdirSync(paths.stateDir, { recursive: true, mode: 0o700 });
    mkdirSync(paths.jobsDir, { recursive: true, mode: 0o711 });
    // userns ішіндегі процесс rootfs жолын орай алуы үшін барлық аталық қалтада «o+x» болуы керек
    for (let d = path.resolve(paths.jobsDir); ; d = path.dirname(d)) {
      if ((statSync(d).mode & 0o001) === 0) return { ok: false, reason: `${d} қалтасында o+x құқығы жоқ (chmod o+x керек)` };
      if (d === path.dirname(d)) break;
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: `OCI runtime (${paths.runc}) табылмады: ${(e as Error).message}` };
  }
}

/** Бір тапсырманың (job) жұмыс ортасы: tmpfs /work + rootfs; dispose() бәрін тазалайды. */
export class JobEnv {
  readonly id: string;
  readonly dir: string;
  readonly workDir: string;
  private paths: RunnerPaths;
  private mounted = false;
  private disposed = false;
  private live = new Set<string>();

  private constructor(paths: RunnerPaths, id: string, dir: string, workDir: string) { this.paths = paths; this.id = id; this.dir = dir; this.workDir = workDir; }

  static async create(paths: RunnerPaths, id: string, workMB: number): Promise<JobEnv> {
    const dir = mkdtempSync(path.join(paths.jobsDir, `${id}-`));
    chmodSync(dir, 0o711); // userns ішіндегі процесс жолды орай алуы үшін (мазмұнын оқи алмайды)
    const work = path.join(dir, 'work');
    mkdirSync(work, { mode: 0o755 });
    const env = new JobEnv(paths, id, dir, work);
    try {
      // Өлшем шегі бар tmpfs: диск толтыру мүмкін емес; иесі — контейнердегі пайдаланушының хост UID-і
      await exec('mount', ['-t', 'tmpfs', '-o', `size=${workMB}m,nr_inodes=20000,nosuid,nodev,mode=0755,uid=${UID_BASE + SANDBOX_UID},gid=${UID_BASE + SANDBOX_UID}`, `uya-${id}`, work]);
      env.mounted = true;
      writeFileSync(path.join(dir, 'etc-passwd'), `root:x:0:0:root:/root:/usr/sbin/nologin\nsandbox:x:${SANDBOX_UID}:${SANDBOX_UID}:sandbox:/tmp:/usr/sbin/nologin\n`);
      writeFileSync(path.join(dir, 'etc-group'), `root:x:0:\nsandbox:x:${SANDBOX_UID}:\n`);
      return env;
    } catch (e) { await env.dispose(); throw e; }
  }

  /** Пайдаланушы файлдарын жазу: жолдар алдын ала тексерілген; symlink/қайта жазу жоқ. */
  writeFiles(files: Array<{ path: string; content: string }>) {
    const uid = UID_BASE + SANDBOX_UID;
    for (const f of files) {
      if (!isSafeRelPath(f.path)) throw new Error('жол жарамсыз');
      const abs = path.join(this.workDir, f.path);
      if (!abs.startsWith(this.workDir + path.sep)) throw new Error('жол жарамсыз');
      const parts = path.relative(this.workDir, path.dirname(abs)).split(path.sep).filter(Boolean);
      let cur = this.workDir;
      for (const part of parts) { cur = path.join(cur, part); if (!existsSync(cur)) { mkdirSync(cur); chownSync(cur, uid, uid); } }
      writeFileSync(abs, f.content, { flag: 'wx', mode: 0o644 });
      chownSync(abs, uid, uid);
    }
  }

  /** Бір фазаны жаңа контейнерде орындайды. `signal` — бас тарту. */
  async runPhase(phase: Phase, hooks: { onStdout(b: Buffer): void; onStderr(b: Buffer): void }, signal?: AbortSignal): Promise<PhaseResult> {
    const cid = `${this.id}-${phase.name}`;
    const bundle = path.join(this.dir, `bundle-${phase.name}`);
    mkdirSync(bundle, { recursive: true });
    chmodSync(bundle, 0o711);
    const extra = [...phase.mounts.map((m) => m.dst), '/etc/passwd', '/etc/group'];
    // Әр фазаға таза rootfs
    const rootfs = makeRootfs(bundle, extra.filter((e) => e !== '/etc/passwd' && e !== '/etc/group'));
    // bind көздері (etc-passwd) rootfs-ке қатысты жол: бундл ішіне көшіреміз
    writeFileSync(path.join(bundle, 'etc-passwd'), `root:x:0:0:root:/root:/usr/sbin/nologin\nsandbox:x:${SANDBOX_UID}:${SANDBOX_UID}:sandbox:/tmp:/usr/sbin/nologin\n`);
    writeFileSync(path.join(bundle, 'etc-group'), `root:x:0:\nsandbox:x:${SANDBOX_UID}:\n`);
    writeFileSync(path.join(rootfs, 'etc', 'passwd'), '');
    writeFileSync(path.join(rootfs, 'etc', 'group'), '');
    const spec = buildSpec({ id: cid, phase, rootfs, workDir: this.workDir, extraDirs: [] });
    writeFileSync(path.join(bundle, 'config.json'), JSON.stringify(spec));

    const L = phase.limits;
    const started = Date.now();
    let killedBy: Killed = null;
    let stdoutBytes = 0, stderrBytes = 0;
    this.live.add(cid);

    const child: ChildProcess = spawn(this.paths.runc, ['--root', this.paths.stateDir, 'run', '--keep', '-b', bundle, cid], { stdio: ['pipe', 'pipe', 'pipe'], env: { PATH: '/usr/sbin:/usr/bin:/sbin:/bin' } });
    const kill = (why: Exclude<Killed, null>) => {
      if (killedBy) return;
      killedBy = why;
      void exec(this.paths.runc, ['--root', this.paths.stateDir, 'kill', '--all', cid, 'KILL']).catch(() => {});
    };
    const total = () => stdoutBytes + stderrBytes;
    child.stdout!.on('data', (b: Buffer) => {
      if (total() >= L.outputBytes) { kill('output'); return; }
      const room = L.outputBytes - total();
      const slice = b.length > room ? b.subarray(0, room) : b;
      stdoutBytes += slice.length; hooks.onStdout(slice);
      if (b.length > room) kill('output');
    });
    child.stderr!.on('data', (b: Buffer) => {
      if (total() >= L.outputBytes) { kill('output'); return; }
      const room = L.outputBytes - total();
      const slice = b.length > room ? b.subarray(0, room) : b;
      stderrBytes += slice.length; hooks.onStderr(slice);
      if (b.length > room) kill('output');
    });
    child.stdin!.on('error', () => {});
    child.stdin!.end(phase.stdin ? Buffer.from(phase.stdin.slice(0, 65_536), 'utf8') : undefined);

    const timer = setTimeout(() => kill('timeout'), L.timeoutMs);
    const onAbort = () => kill('cancel');
    if (signal) { if (signal.aborted) onAbort(); else signal.addEventListener('abort', onAbort, { once: true }); }

    const exit = await new Promise<{ code: number | null; sig: string | null }>((resolve) => {
      child.on('error', () => resolve({ code: null, sig: null }));
      child.on('close', (code, sig) => resolve({ code, sig }));
    });
    clearTimeout(timer);
    signal?.removeEventListener('abort', onAbort);

    // Статистика (жады), сосын контейнерді өшіру
    let maxMem: number | null = null;
    let oom = false;
    try {
      const { stdout } = await exec(this.paths.runc, ['--root', this.paths.stateDir, 'events', '--stats', cid], { timeout: 5000 });
      const st = JSON.parse(stdout);
      maxMem = Number(st?.data?.memory?.usage?.max ?? 0) || null;
      const failcnt = Number(st?.data?.memory?.usage?.failcnt ?? 0);
      oom = failcnt > 0;
    } catch { /* статистика міндетті емес */ }
    await this.deleteContainer(cid);
    this.live.delete(cid);

    const sigKilled = exit.code === 137 || exit.sig === 'SIGKILL';
    // Ядро SIGKILL жіберді, бірақ біз өлтірмедік (timeout/output/cancel емес) — cgroup жады шегі (OOM). Статистика контейнер жойылғаннан кейін қолжетімсіз болуы мүмкін.
    const nearLimit = maxMem != null && maxMem >= L.memoryMB * 1024 * 1024 * 0.9;
    if (!killedBy && sigKilled && (oom || nearLimit || maxMem == null)) killedBy = 'memory';
    return {
      exitCode: exit.code, signal: exit.sig ?? (exit.code != null && exit.code > 128 ? `SIG${exit.code - 128}` : null), killedBy,
      durationMs: Date.now() - started, oom, maxMemoryBytes: maxMem, stdoutBytes, stderrBytes,
    };
  }

  private async deleteContainer(cid: string) {
    for (let i = 0; i < 3; i++) {
      try { await exec(this.paths.runc, ['--root', this.paths.stateDir, 'delete', '--force', cid], { timeout: 10_000 }); return; } catch { await new Promise((r) => setTimeout(r, 100)); }
    }
  }

  /** Барлығын тазалау. Қате болса да тоқтамайды; идемпотентті. */
  async dispose() {
    if (this.disposed) return;
    this.disposed = true;
    for (const cid of this.live) { await exec(this.paths.runc, ['--root', this.paths.stateDir, 'kill', '--all', cid, 'KILL']).catch(() => {}); await this.deleteContainer(cid); }
    if (this.mounted) {
      for (let i = 0; i < 5; i++) { try { await exec('umount', ['-l', this.workDir]); this.mounted = false; break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
    }
    // Бундл ішінде bind-mount қалып қоймағанын тексеріп, содан кейін ғана өшіреміз
    rmSync(this.dir, { recursive: true, force: true, maxRetries: 3 });
  }
}
