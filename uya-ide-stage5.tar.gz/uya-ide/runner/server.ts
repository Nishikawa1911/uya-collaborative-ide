/** Runner HTTP қызметі. Негізгі backend-тен бөлек процесте (және өндірісте бөлек хостта) жұмыс істейді. */
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { ExecError, Executor, type ExecEvent } from './execute.ts';

export interface RunnerServerOpts { executor: Executor; token: string; maxQueue?: number; maxBodyBytes?: number }

const safeEq = (a: string, b: string) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && timingSafeEqual(x, y); };

export function createRunnerServer(opts: RunnerServerOpts): Server {
  const { executor, token } = opts;
  if (!token || token.length < 16) throw new Error('RUNNER_TOKEN кемі 16 таңба болуы керек');
  const maxQueue = opts.maxQueue ?? 32;
  const maxBody = opts.maxBodyBytes ?? 12 * 1024 * 1024;
  let pending = 0;

  const json = (res: ServerResponse, status: number, body: unknown) => {
    const b = Buffer.from(JSON.stringify(body));
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': b.length });
    res.end(b);
  };
  const readJson = (req: IncomingMessage) => new Promise<any>((resolve, reject) => {
    const chunks: Buffer[] = []; let n = 0;
    req.on('data', (c: Buffer) => { n += c.length; if (n > maxBody) { reject(new ExecError('bad_request', 'сұраныс тым үлкен')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new ExecError('bad_request', 'JSON жарамсыз')); } });
    req.on('error', reject);
  });

  return createServer(async (req, res) => {
    try {
      const auth = String(req.headers.authorization ?? '');
      if (!auth.startsWith('Bearer ') || !safeEq(auth.slice(7), token)) return json(res, 401, { error: 'unauthorized' });
      const url = new URL(req.url ?? '/', 'http://x');
      if (req.method === 'GET' && url.pathname === '/v1/health') return json(res, 200, { ok: true, active: executor.activeCount, pending });
      if (req.method === 'GET' && url.pathname === '/v1/languages') return json(res, 200, { languages: executor.languages() });
      const cancel = /^\/v1\/cancel\/([A-Za-z0-9_-]{6,64})$/.exec(url.pathname);
      if (req.method === 'POST' && cancel) return json(res, 200, { cancelled: executor.cancel(cancel[1]) });
      if (req.method === 'POST' && url.pathname === '/v1/run') {
        const body = await readJson(req);
        const exreq = { id: String(body?.id ?? ''), entry: String(body?.entry ?? ''), mode: body?.mode === 'project' ? 'project' as const : 'file' as const, files: body?.files, stdin: typeof body?.stdin === 'string' ? body.stdin.slice(0, 64 * 1024) : undefined };
        const { lang } = executor.validate(exreq);
        if (!executor.isEnabled(lang.id)) throw new ExecError('language_disabled', `${lang.label} қолжетімсіз`);
        if (pending >= maxQueue) return json(res, 429, { error: 'busy' });
        pending++;
        res.writeHead(200, { 'content-type': 'application/x-ndjson; charset=utf-8', 'cache-control': 'no-store', 'x-accel-buffering': 'no' });
        const ac = new AbortController();
        res.on('close', () => { if (!res.writableEnded) ac.abort(); }); // клиент ажырады — орындау тоқтатылады
        const send = (e: ExecEvent) => { if (!res.destroyed) res.write(JSON.stringify(e) + '\n'); };
        try { await executor.execute(exreq, send, ac.signal); }
        catch (e) { send({ type: 'finished', status: 'internal_error', exitCode: null, signal: null, durationMs: 0, phase: 'setup', message: (e as Error).message }); }
        finally { pending--; res.end(); }
        return;
      }
      json(res, 404, { error: 'not_found' });
    } catch (e) {
      if (res.headersSent) { res.end(); return; }
      if (e instanceof ExecError) return json(res, e.code === 'language_disabled' ? 409 : 400, { error: e.code, message: e.message });
      console.error('[runner]', e);
      json(res, 500, { error: 'internal' });
    }
  });
}
