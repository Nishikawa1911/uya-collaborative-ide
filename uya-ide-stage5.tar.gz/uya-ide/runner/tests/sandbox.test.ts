import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { chmodSync, existsSync, mkdtempSync, readdirSync, rmSync } from 'node:fs';
import { createServer, type Server } from 'node:net';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { JobEnv, ensureRuntime, type Limits, type RunnerPaths } from '../sandbox.ts';

const base = mkdtempSync(path.join(tmpdir(), 'uya-sb-'));
chmodSync(base, 0o711);
const paths: RunnerPaths = { stateDir: path.join(base, 'state'), jobsDir: path.join(base, 'jobs'), runc: 'runc' };
const LIM: Limits = { memoryMB: 128, cpus: 1, pids: 64, timeoutMs: 8000, fsizeMB: 8, nofile: 128, workMB: 16, outputBytes: 64 * 1024 };
const PY = '/usr/local/bin/python3.13';
const ENV = { PATH: '/usr/local/bin:/usr/bin:/bin', PYTHONDONTWRITEBYTECODE: '1' };

let rt: Awaited<ReturnType<typeof ensureRuntime>>;
let canary: Server; let canaryPort = 0;
before(async () => {
  rt = await ensureRuntime(paths);
  canary = createServer((s) => { s.end('SECRET-INTERNAL-SERVICE'); });
  await new Promise<void>((r) => canary.listen(0, '0.0.0.0', r));
  canaryPort = (canary.address() as { port: number }).port;
});
after(() => { canary.close(); rmSync(base, { recursive: true, force: true }); });

async function py(code: string, lim: Partial<Limits> = {}, opts: { stdin?: string; signal?: AbortSignal } = {}) {
  const env = await JobEnv.create(paths, `t${Math.random().toString(36).slice(2, 8)}`, 16);
  let out = '', err = '';
  try {
    env.writeFiles([{ path: 'main.py', content: code }]);
    const r = await env.runPhase({ name: 'run', cmd: [PY, 'main.py'], env: ENV, mounts: [], limits: { ...LIM, ...lim }, stdin: opts.stdin }, { onStdout: (b) => { out += b; }, onStderr: (b) => { err += b; } }, opts.signal);
    return { ...r, out, err };
  } finally { await env.dispose(); }
}

describe('runtime', () => {
  it('runc және root құқығы бар', () => { assert.deepEqual(rt, { ok: true }); });
});

describe('изоляция', () => {
  it('stdout, stderr, шығу коды, stdin', async () => {
    const r = await py("import sys\nprint('a'); print('b', file=sys.stderr); print(sys.stdin.read().upper()); sys.exit(3)", {}, { stdin: 'сәлем' });
    assert.equal(r.exitCode, 3); assert.match(r.out, /a\n/); assert.match(r.out, /СӘЛЕМ/); assert.match(r.err, /b/);
  });

  it('желі жоқ: loopback-тегі хост қызметіне де, сыртқы адреске де қосылу мүмкін емес', async () => {
    const r = await py(`
import socket
res = {}
for name, addr in [('host-loopback', ('127.0.0.1', ${canaryPort})), ('host-ip', ('0.0.0.0', ${canaryPort})), ('metadata', ('169.254.169.254', 80)), ('internet', ('1.1.1.1', 53))]:
    s = socket.socket(); s.settimeout(2)
    try:
        s.connect(addr); res[name] = 'CONNECTED:' + s.recv(30).decode()
    except Exception as e:
        res[name] = type(e).__name__
print(res)
try:
    print('dns', socket.gethostbyname('example.com'))
except Exception as e:
    print('dns', type(e).__name__)
import os; print('ifaces', os.listdir('/sys/class/net') if os.path.exists('/sys/class/net') else 'no-sys')
`);
    assert.equal(r.exitCode, 0, r.err);
    assert.ok(!r.out.includes('CONNECTED'), r.out); assert.ok(!r.out.includes('SECRET'), r.out);
    assert.match(r.out, /dns gaierror|dns OSError|dns timeout/);
  });

  it('хост файлдары көрінбейді: /root, /home, /etc/shadow, /var, runner қалталары, сессия деректері', async () => {
    const r = await py(`
import os
for p in ['/root', '/home', '/var', '/opt', '/etc/shadow', '/etc/hostname', '/run', '/sys', '/boot', '/mnt', '/data', '${base}', '/home/claude/uya-ide']:
    try: print(p, 'EXISTS' if os.path.exists(p) else 'absent', sorted(os.listdir(p))[:3] if os.path.isdir(p) else '')
    except Exception as e: print(p, type(e).__name__)
print('ROOT', sorted(os.listdir('/')))
`);
    assert.equal(r.exitCode, 0, r.err);
    assert.ok(!r.out.includes('uya-ide') || /uya-ide absent/.test(r.out) || !/\/home\/claude\/uya-ide EXISTS/.test(r.out));
    assert.doesNotMatch(r.out, /\/etc\/shadow EXISTS/); assert.doesNotMatch(r.out, /\/home\/claude\/uya-ide EXISTS/); assert.doesNotMatch(r.out, new RegExp(`${base} EXISTS`));
    assert.match(r.out, /\/root (EXISTS \[\]|absent)/); // бос қала ғана
  });

  it('rootfs тек оқуға: /usr, /etc, / жазу мүмкін емес; /work пен /tmp жазылады', async () => {
    const r = await py(`
import os
def t(p):
    try:
        open(p, 'w').write('x'); return 'WROTE'
    except Exception as e: return type(e).__name__
print('usr', t('/usr/x')); print('etc', t('/etc/x')); print('root', t('/x')); print('passwd', t('/etc/passwd'))
print('work', t('/work/ok')); print('tmp', t('/tmp/ok'))
try: os.remove('/usr/bin/env'); print('rm usr WROTE')
except Exception as e: print('rm usr', type(e).__name__)
`);
    assert.match(r.out, /usr (OSError|PermissionError|FileNotFoundError)/); assert.doesNotMatch(r.out, /(usr|etc|root|passwd) WROTE/);
    assert.match(r.out, /work WROTE/); assert.match(r.out, /tmp WROTE/); assert.doesNotMatch(r.out, /rm usr WROTE/);
  });

  it('артықшылықтар: capability жоқ, uid≠0, no_new_privs, mount/unshare/ptrace/setns/new userns тыйым', async () => {
    const r = await py(`
import ctypes, os
libc = ctypes.CDLL(None, use_errno=True)
st = open('/proc/self/status').read()
print([l for l in st.splitlines() if l.startswith(('CapEff','CapBnd','NoNewPrivs','Seccomp:','Uid'))])
def call(name, *a):
    r = libc.syscall(*a); return (r, ctypes.get_errno())
SYS = {'mount':165, 'unshare':272, 'ptrace':101, 'setns':308, 'reboot':169, 'bpf':321, 'chroot':161}
print('mount', call('mount', SYS['mount'], b'none', b'/tmp', b'tmpfs', 0, 0))
print('unshare_user', call('unshare', SYS['unshare'], 0x10000000))
print('unshare_net', call('unshare', SYS['unshare'], 0x40000000))
print('ptrace', call('ptrace', SYS['ptrace'], 0, 1, 0, 0))
print('chroot', call('chroot', SYS['chroot'], b'/tmp'))
print('reboot', call('reboot', SYS['reboot'], 0, 0, 0, 0))
print('bpf', call('bpf', SYS['bpf'], 0, 0, 0))
# clone з жаңа user namespace: os.unshare
try: os.unshare(os.CLONE_NEWUSER); print('os.unshare NEWUSER OK')
except Exception as e: print('os.unshare', type(e).__name__)
try: os.setuid(0); print('setuid0 OK')
except Exception as e: print('setuid0', type(e).__name__)
`);
    assert.equal(r.exitCode, 0, r.err);
    assert.match(r.out, /'CapEff:\\t0000000000000000'/); assert.match(r.out, /NoNewPrivs:\\t1/); assert.match(r.out, /Seccomp:\\t2/);
    for (const k of ['mount', 'unshare_user', 'unshare_net', 'ptrace', 'chroot', 'reboot', 'bpf']) assert.match(r.out, new RegExp(`${k} \\(-1, (1|38)\\)`), `${k}: ${r.out}`);
    assert.doesNotMatch(r.out, /OK/);
  });

  it('PID namespace: хост процестері көрінбейді; контейнердегі PID 1 өзі', async () => {
    const r = await py(`
import os
pids = sorted(int(p) for p in os.listdir('/proc') if p.isdigit())
print('pids', pids)
print('ppid', os.getppid())
`);
    assert.match(r.out, /pids \[\d+(, \d+)?\]/); const n = (/pids \[([^\]]*)\]/.exec(r.out)![1].split(',').length); assert.ok(n <= 2, r.out);
  });
});

describe('ресурс шектері', () => {
  it('жады шегі: 128 МБ-тан асса, ядро өлтіреді (memory)', async () => {
    const r = await py("a = []\nwhile True: a.append(bytearray(8*1024*1024))", { memoryMB: 64, timeoutMs: 15000 });
    assert.notEqual(r.exitCode, 0); assert.ok(r.killedBy === 'memory' || r.oom || r.exitCode === 137, JSON.stringify(r));
  });

  it('pids шегі: fork bomb шектеледі, хост зардап шекпейді', async () => {
    const before = readdirSync('/proc').filter((x) => /^\d+$/.test(x)).length;
    const r = await py(`
import os, time
n = 0
try:
    while n < 500:
        pid = os.fork()
        if pid == 0:
            time.sleep(3); os._exit(0)
        n += 1
except OSError as e:
    print('fork blocked after', n, type(e).__name__)
print('children', n)
`, { pids: 32, timeoutMs: 10000 });
    assert.match(r.out, /fork blocked after \d+/); const n = Number(/children (\d+)/.exec(r.out)![1]); assert.ok(n <= 32, r.out);
    await new Promise((res) => setTimeout(res, 300));
    const after2 = readdirSync('/proc').filter((x) => /^\d+$/.test(x)).length;
    assert.ok(after2 <= before + 3, `қалған процестер: ${before} → ${after2}`);
  });

  it('уақыт шегі: ұзақ цикл таймаутпен тоқтатылады', async () => {
    const t = Date.now();
    const r = await py('while True: pass', { timeoutMs: 1500 });
    assert.equal(r.killedBy, 'timeout'); assert.ok(Date.now() - t < 6000);
  });

  it('sleep: wall-time таймері CPU-ға қарамай жұмыс істейді', async () => {
    const r = await py('import time; time.sleep(60)', { timeoutMs: 1000 });
    assert.equal(r.killedBy, 'timeout');
  });

  it('шығыс шегі: шексіз print тоқтатылады, көлемі шектен аспайды', async () => {
    const r = await py("while True: print('x'*1000)", { outputBytes: 20_000, timeoutMs: 15000 });
    assert.equal(r.killedBy, 'output'); assert.ok(r.out.length <= 20_000, String(r.out.length));
  });

  it('диск шегі: /work толғанда жазу тоқтайды (хост диск толмайды)', async () => {
    const r = await py(`
try:
    with open('/work/big', 'wb') as f:
        for i in range(100): f.write(b'0' * 1024 * 1024)
    print('WROTE ALL')
except OSError as e:
    print('limited', e.errno)
`, { fsizeMB: 200 });
    assert.match(r.out, /limited (28|27)/);
  });

  it('файл өлшемі шегі (RLIMIT_FSIZE)', async () => {
    const r = await py(`
try:
    open('/tmp/f','wb').write(b'0' * (20*1024*1024)); print('WROTE')
except Exception as e: print('limited', type(e).__name__)
`, { fsizeMB: 2 });
    assert.doesNotMatch(r.out, /WROTE/);
  });

  it('CPU шегі: 1 ядро, көп ағын да 1 ядродан артық алмайды', async () => {
    const r = await py(`
import time, threading, os
def spin(): 
    t = time.time(); n = 0
    while time.time() - t < 1.5: n += 1
th = [threading.Thread(target=spin) for _ in range(4)]
a = os.times(); w = time.time()
[t.start() for t in th]; [t.join() for t in th]
b = os.times(); print('cpu_ratio', round(((b.user - a.user) + (b.system - a.system)) / (time.time() - w), 2))
`, { cpus: 0.5, timeoutMs: 20000 });
    assert.equal(r.exitCode, 0, r.err);
    const ratio = Number(/cpu_ratio ([\d.]+)/.exec(r.out)![1]); assert.ok(ratio <= 1.1, `CPU қатынасы ${ratio}`); // GIL салдарынан әрі cgroup-пен шектелген
  });
});

describe('бас тарту және тазалау', () => {
  it('бас тарту (AbortSignal) процесті дереу тоқтатады', async () => {
    const ac = new AbortController(); setTimeout(() => ac.abort(), 600);
    const t = Date.now();
    const r = await py('import time; time.sleep(60)', { timeoutMs: 30000 }, { signal: ac.signal });
    assert.equal(r.killedBy, 'cancel'); assert.ok(Date.now() - t < 5000);
  });

  it('алдын ала бас тартылған сигнал: орындалмайды', async () => {
    const ac = new AbortController(); ac.abort();
    const r = await py('print(1)', {}, { signal: ac.signal });
    assert.equal(r.killedBy, 'cancel');
  });

  it('тазалау: қалта, tmpfs mount, контейнер, cgroup қалмайды (қате/таймаутта да)', async () => {
    const jobsBefore = existsSync(paths.jobsDir) ? readdirSync(paths.jobsDir).length : 0;
    await py('print(1)');
    await py('import time; time.sleep(30)', { timeoutMs: 700 });
    await py('raise SystemExit(7)');
    assert.equal(readdirSync(paths.jobsDir).length, jobsBefore);
    const mounts = execFileSync('cat', ['/proc/self/mountinfo'], { encoding: 'utf8' });
    assert.doesNotMatch(mounts, new RegExp(paths.jobsDir));
    assert.equal(execFileSync('runc', ['--root', paths.stateDir, 'list', '-q'], { encoding: 'utf8' }).trim(), '');
    assert.equal(existsSync('/sys/fs/cgroup/memory/uya-runner') ? readdirSync('/sys/fs/cgroup/memory/uya-runner').filter((x) => !x.startsWith('memory.') && !x.startsWith('cgroup.') && !x.startsWith('notify') && !x.startsWith('tasks')).length : 0, 0);
  });

  it('жұмыс қалтасына жол траверсалы: ../ және абсолютті жол қабылданбайды', async () => {
    const env = await JobEnv.create(paths, 'trv', 8);
    try {
      assert.throws(() => env.writeFiles([{ path: '../evil', content: 'x' }]));
      assert.throws(() => env.writeFiles([{ path: '/etc/evil', content: 'x' }]));
      assert.ok(!existsSync(path.join(env.dir, 'evil')));
    } finally { await env.dispose(); }
  });

  it('симлинк арқылы қашу әрекеті: /work ішіндегі symlink хост файлына жеткізбейді', async () => {
    const r = await py(`
import os
os.symlink('/etc/shadow', '/work/link1'); os.symlink('/proc/1/root', '/work/link2'); os.symlink('../../../../etc', '/work/link3')
for p in ['/work/link1', '/work/link2/etc/shadow', '/work/link3/shadow']:
    try: print(p, 'READ', len(open(p).read()))
    except Exception as e: print(p, type(e).__name__)
`);
    assert.doesNotMatch(r.out, /READ/);
  });
});
