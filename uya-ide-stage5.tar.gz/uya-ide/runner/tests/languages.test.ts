/** Әр тіл БӨЛЕК тексеріледі: нақты контейнерде, нақты компилятормен. Қосылмаған тіл (құрал жоқ) — қосылмағаны дұрыс екені тексеріледі. */
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { chmodSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { Executor, type ExecEvent } from '../execute.ts';
import { LANGS } from '../languages.ts';

const base = mkdtempSync(path.join(tmpdir(), 'uya-lang-'));
chmodSync(base, 0o711);
const ex = new Executor({ stateDir: path.join(base, 'state'), jobsDir: path.join(base, 'jobs'), runc: 'runc' }, { maxConcurrent: 3 });
let status: Awaited<ReturnType<Executor['probe']>>;
before(async () => { status = await ex.probe(); });
after(() => rmSync(base, { recursive: true, force: true }));

let n = 0;
const id = () => `tl${Date.now().toString(36)}${n++}`;
async function run(entry: string, files: Array<{ path: string; content: string }>, stdin?: string) {
  const events: ExecEvent[] = [];
  const r = await ex.execute({ id: id(), entry, mode: 'project', files, stdin }, (e) => events.push(e));
  return { ...r, events };
}

describe('тілдердің қолжетімділігі (self-test нәтижесі)', () => {
  for (const l of LANGS) {
    it(`${l}: күйі анық (қосылған немесе себебі көрсетілген)`, () => {
      const s = status.find((x) => x.id === l)!;
      assert.ok(s, l);
      if (!s.enabled) assert.ok(s.reason && s.reason.length > 3, `${l}: себеп жоқ`);
      console.log(`    ${l}: ${s.enabled ? 'ҚОСЫЛҒАН' : 'ӨШІРУЛІ — ' + s.reason}`);
    });
  }
  it('C#: dotnet орнатылмағандықтан қосылмайды (өтірік «қосылған» емес)', () => {
    const s = status.find((x) => x.id === 'csharp')!;
    assert.equal(s.enabled, false);
    assert.match(s.reason!, /орнатылмаған|dotnet/);
  });
});

const T = (lang: string) => (name: string, fn: () => Promise<void>) => it(name, async (t) => { if (!status.find((x) => x.id === lang)?.enabled) return t.skip('тіл қосылмаған'); await fn(); });

describe('Python', () => {
  T('python')('көп файлды жоба, импорт, stdin, шығу коды', async () => {
    const r = await run('main.py', [{ path: 'main.py', content: 'import pkg.util as u, sys\nprint(u.hi(sys.stdin.read().strip()))\nsys.exit(4)\n' }, { path: 'pkg/__init__.py', content: '' }, { path: 'pkg/util.py', content: 'def hi(n): return "сәлем, " + n\n' }], 'Айгерім');
    assert.equal(r.status, 'error'); assert.equal(r.events.at(-1)?.type, 'finished'); assert.equal((r.events.at(-1) as any).exitCode, 4);
    assert.match(r.stdout, /сәлем, Айгерім/);
  });
  T('python')('жасалмаған модуль: stderr traceback, шығу коды 1', async () => {
    const r = await run('main.py', [{ path: 'main.py', content: 'import nothere\n' }]);
    assert.equal(r.status, 'error'); assert.match(r.stderr, /ModuleNotFoundError/);
  });
  T('python')('синтаксис қатесі stderr-де', async () => {
    const r = await run('main.py', [{ path: 'main.py', content: 'def x(:\n' }]);
    assert.equal(r.status, 'error'); assert.match(r.stderr, /SyntaxError/);
  });
  T('python')('желіге шығу мүмкін емес', async () => {
    const r = await run('main.py', [{ path: 'main.py', content: 'import urllib.request\ntry:\n    urllib.request.urlopen("http://example.com", timeout=3); print("NET OK")\nexcept Exception as e: print("blocked", type(e).__name__)\n' }]);
    assert.match(r.stdout, /blocked/); assert.doesNotMatch(r.stdout, /NET OK/);
  });
});

describe('JavaScript (Node)', () => {
  T('javascript')('require, stdout/stderr, process.exit', async () => {
    const r = await run('main.js', [{ path: 'main.js', content: 'const u = require("./lib/u.js"); console.log(u.hi("Дана")); console.error("warn"); process.exit(2);' }, { path: 'lib/u.js', content: 'exports.hi = n => `сәлем, ${n}`;' }]);
    assert.equal(r.status, 'error'); assert.match(r.stdout, /сәлем, Дана/); assert.match(r.stderr, /warn/);
  });
  T('javascript')('child_process арқылы хостқа шығу: желі де, хост файлы да жоқ', async () => {
    const r = await run('main.js', [{ path: 'main.js', content: 'const fs=require("fs"); try{ fs.readFileSync("/etc/shadow"); console.log("LEAK") }catch(e){ console.log("no shadow") }\nrequire("http").get("http://127.0.0.1:1",()=>{}).on("error",e=>console.log("net blocked", e.code));' }]);
    assert.match(r.stdout, /no shadow/); assert.match(r.stdout, /net blocked/); assert.doesNotMatch(r.stdout, /LEAK/);
  });
});

describe('TypeScript', () => {
  T('typescript')('компиляция + іске қосу (бірнеше файл)', async () => {
    const r = await run('main.ts', [{ path: 'main.ts', content: 'import { sq } from "./m/math";\nconst v: number = sq(7);\nconsole.log(`ts:${v}`);\n' }, { path: 'm/math.ts', content: 'export function sq(n: number): number { return n * n; }\n' }]);
    assert.equal(r.status, 'ok', r.build + r.stderr); assert.match(r.stdout, /ts:49/);
  });
  T('typescript')('түр қатесі: compile_error, мәлімдеме build ағынында, іске қосылмайды', async () => {
    const r = await run('main.ts', [{ path: 'main.ts', content: 'const a: string = 5;\nconsole.log(a);\n' }]);
    assert.equal(r.status, 'compile_error'); assert.match(r.build, /main\.ts/); assert.equal(r.stdout, '');
    assert.ok(!r.events.some((e) => e.type === 'phase' && e.phase === 'run'));
  });
});

describe('Java', () => {
  T('java')('пакеттер, бірнеше класс, stdout', async () => {
    const r = await run('app/Main.java', [{ path: 'app/Main.java', content: 'package app;\npublic class Main { public static void main(String[] a) { System.out.println("java:" + new Util().f() + " ұ"); } }\n' }, { path: 'app/Util.java', content: 'package app;\nclass Util { String f() { return "ok"; } }\n' }]);
    assert.equal(r.status, 'ok', r.build + r.stderr); assert.match(r.stdout, /java:ok ұ/);
  });
  T('java')('компиляция қатесі', async () => {
    const r = await run('Main.java', [{ path: 'Main.java', content: 'public class Main { public static void main(String[] a) { String s = 1; } }\n' }]);
    assert.equal(r.status, 'compile_error'); assert.match(r.build, /error/);
  });
  T('java')('runtime exception: stderr + exit 1', async () => {
    const r = await run('Main.java', [{ path: 'Main.java', content: 'public class Main { public static void main(String[] a) { throw new RuntimeException("boom"); } }\n' }]);
    assert.equal(r.status, 'error'); assert.match(r.stderr, /boom/);
  });
});

describe('C++', () => {
  T('cpp')('тақырып + басқа .cpp тәуелділік', async () => {
    const r = await run('main.cpp', [{ path: 'main.cpp', content: '#include <iostream>\n#include "lib.h"\nint main(){ std::cout << "cpp:" << add(2,3) << std::endl; return 0; }\n' }, { path: 'lib.h', content: 'int add(int,int);\n' }, { path: 'lib.cpp', content: '#include "lib.h"\nint add(int a,int b){ return a+b; }\n' }]);
    assert.equal(r.status, 'ok', r.build); assert.match(r.stdout, /cpp:5/);
  });
  T('cpp')('компиляция қатесі', async () => {
    const r = await run('main.cpp', [{ path: 'main.cpp', content: 'int main(){ return x; }\n' }]);
    assert.equal(r.status, 'compile_error'); assert.match(r.build, /error/);
  });
  T('cpp')('segfault: сигнал/exit коды хабарланады', async () => {
    const r = await run('main.cpp', [{ path: 'main.cpp', content: 'int main(){ volatile int* p = nullptr; return *p; }\n' }]);
    assert.equal(r.status, 'error'); assert.ok((r.events.at(-1) as any).exitCode === 139 || (r.events.at(-1) as any).signal === 'SIGSEGV' || (r.events.at(-1) as any).signal === 'SIG11', JSON.stringify(r.events.at(-1)));
  });
});

describe('Rust', () => {
  T('rust')('mod, stdout, exit code', async () => {
    const r = await run('main.rs', [{ path: 'main.rs', content: 'mod util;\nfn main() { println!("rust:{}", util::sq(6)); std::process::exit(0); }\n' }, { path: 'util.rs', content: 'pub fn sq(n: i32) -> i32 { n * n }\n' }]);
    assert.equal(r.status, 'ok', r.build); assert.match(r.stdout, /rust:36/);
  });
  T('rust')('компиляция қатесі (borrow checker)', async () => {
    const r = await run('main.rs', [{ path: 'main.rs', content: 'fn main() { let s = String::from("a"); let t = s; println!("{}", s); }\n' }]);
    assert.equal(r.status, 'compile_error'); assert.match(r.build, /borrow of moved value/);
  });
  T('rust')('panic: stderr және exit 101', async () => {
    const r = await run('main.rs', [{ path: 'main.rs', content: 'fn main() { panic!("kaboom"); }\n' }]);
    assert.equal(r.status, 'error'); assert.equal((r.events.at(-1) as any).exitCode, 101); assert.match(r.stderr, /kaboom/);
  });
});

describe('Go', () => {
  T('go')('бір пакет, бірнеше файл', async () => {
    const r = await run('main.go', [{ path: 'main.go', content: 'package main\nimport "fmt"\nfunc main() { fmt.Println("go:", sq(9)) }\n' }, { path: 'u.go', content: 'package main\nfunc sq(n int) int { return n * n }\n' }]);
    assert.equal(r.status, 'ok', r.build + r.stderr); assert.match(r.stdout, /go: 81/);
  });
  T('go')('компиляция қатесі', async () => {
    const r = await run('main.go', [{ path: 'main.go', content: 'package main\nfunc main() { undefinedFn() }\n' }]);
    assert.equal(r.status, 'compile_error'); assert.match(r.build, /undefined/);
  });
});

describe('PHP', () => {
  T('php')('require, stdout, warning stderr-ге', async () => {
    const r = await run('index.php', [{ path: 'index.php', content: '<?php\nrequire __DIR__."/inc/h.php";\necho hi("Ержан"), "\\n";\necho $undefined;\n' }, { path: 'inc/h.php', content: '<?php function hi($n){ return "сәлем, $n"; }\n' }]);
    assert.match(r.stdout, /сәлем, Ержан/); assert.match(r.stderr, /Undefined variable/);
  });
  T('php')('қауіпті функциялар өшірулі (exec, curl, fsockopen)', async () => {
    const r = await run('index.php', [{ path: 'index.php', content: '<?php\nforeach (["exec","shell_exec","system","proc_open","fsockopen"] as $f) echo $f, ":", function_exists($f) ? "ON" : "off", "\\n";\necho @file_get_contents("/etc/passwd") === false ? "open_basedir blocked\\n" : "LEAK\\n";\n' }]);
    assert.doesNotMatch(r.stdout, /:ON/); assert.match(r.stdout, /open_basedir blocked/);
  });
});

describe('SQL (оқшауланған SQLite)', () => {
  T('sql')('кесте жасау, енгізу, таңдау — кесте түрінде көрсетіледі', async () => {
    const r = await run('q.sql', [{ path: 'q.sql', content: "CREATE TABLE students(id INTEGER PRIMARY KEY, name TEXT, gpa REAL);\nINSERT INTO students(name,gpa) VALUES ('Айгерім', 3.9), ('Дана', 3.7);\nSELECT name, gpa FROM students ORDER BY gpa DESC;\n" }]);
    assert.equal(r.status, 'ok', r.stderr); assert.match(r.stdout, /Айгерім/); assert.match(r.stdout, /OK, өзгерген қатарлар: 2/); assert.match(r.stdout, /\(2 қатар\)/);
  });
  T('sql')('синтаксис қатесі: нөмірі мен мәтіні stderr-де, exit 1', async () => {
    const r = await run('q.sql', [{ path: 'q.sql', content: 'SELECT 1;\nSELEC 2;\n' }]);
    assert.equal(r.status, 'error'); assert.match(r.stderr, /сұраныс №2/);
  });
  T('sql')('ATTACH, load_extension, қауіпті PRAGMA тыйым', async () => {
    for (const q of ["ATTACH DATABASE '/tmp/x.db' AS x;", "SELECT load_extension('/lib/x.so');", 'PRAGMA writable_schema = 1;', "PRAGMA journal_mode = OFF;"]) {
      const r = await run('q.sql', [{ path: 'q.sql', content: q + '\n' }]);
      assert.equal(r.status, 'error', q); assert.match(r.stderr, /Қате/, q);
    }
  });
  T('sql')('шексіз рекурсивті сұраныс уақытпен тоқтатылады; дерекқор өлшемі шектелген', async () => {
    const r1 = await run('q.sql', [{ path: 'q.sql', content: 'WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c) SELECT count(*) FROM c;\n' }]);
    assert.equal(r1.status, 'error'); assert.match(r1.stderr, /interrupted|Қате/);
    const r2 = await run('q.sql', [{ path: 'q.sql', content: "CREATE TABLE b(x BLOB);\nWITH RECURSIVE c(i) AS (SELECT 1 UNION ALL SELECT i+1 FROM c WHERE i < 100000) INSERT INTO b SELECT zeroblob(10000) FROM c;\n" }]);
    assert.equal(r2.status, 'error'); assert.match(r2.stderr, /full|Қате/);
  });
  T('sql')('қатарлар саны шектелген (200)', async () => {
    const r = await run('q.sql', [{ path: 'q.sql', content: 'WITH RECURSIVE c(i) AS (SELECT 1 UNION ALL SELECT i+1 FROM c WHERE i < 1000) SELECT i FROM c;\n' }]);
    assert.match(r.stdout, /\(200 қатар, шектелген\)/);
  });
  T('sql')('әр іске қосу — таза дерекқор (алдыңғы кестелер жоқ)', async () => {
    await run('q.sql', [{ path: 'q.sql', content: 'CREATE TABLE persist(x); INSERT INTO persist VALUES (1);\n' }]);
    const r = await run('q.sql', [{ path: 'q.sql', content: 'SELECT * FROM persist;\n' }]);
    assert.equal(r.status, 'error'); assert.match(r.stderr, /no such table/);
  });
});

describe('жалпы: шектер әр тілде жұмыс істейді', () => {
  T('python')('Python: шексіз цикл → timeout; жады → memory_limit', async () => {
    const orig = ex.config('python')!.limits;
    ex.config('python')!.limits = { run: { timeoutMs: 1200, memoryMB: 64 } };
    try {
      const a = await run('m.py', [{ path: 'm.py', content: 'while True: pass\n' }]);
      assert.equal(a.status, 'timeout');
      const b = await run('m.py', [{ path: 'm.py', content: 'x = []\nwhile True: x.append(bytearray(4_000_000))\n' }]);
      assert.equal(b.status, 'memory_limit');
    } finally { ex.config('python')!.limits = orig; }
  });
  T('javascript')('Node: шығыс тасқыны → output_limit', async () => {
    const orig = ex.config('javascript')!.limits;
    ex.config('javascript')!.limits = { run: { outputBytes: 50_000, memoryMB: 320 } };
    try {
      const r = await run('m.js', [{ path: 'm.js', content: 'for(;;) console.log("x".repeat(1000));' }]);
      assert.equal(r.status, 'output_limit'); assert.ok(r.stdout.length <= 50_000);
    } finally { ex.config('javascript')!.limits = orig; }
  });
});

describe('бас тарту және сұраныс тексеру', () => {
  T('python')('орындау барысында бас тарту → killed, ресурстар тазаланады', async () => {
    const ac = new AbortController(); const events: ExecEvent[] = [];
    const p = ex.execute({ id: id(), entry: 'm.py', mode: 'file', files: [{ path: 'm.py', content: 'import time\nprint("start", flush=True)\ntime.sleep(60)\n' }] }, (e) => events.push(e), ac.signal);
    await new Promise<void>((res) => { const t = setInterval(() => { if (events.some((e) => e.type === 'output')) { clearInterval(t); res(); } }, 20); });
    ac.abort();
    const r = await p;
    assert.equal(r.status, 'killed');
  });
  it('жарамсыз сұраныстар: жол траверсалы, қайталанған жол, резервтелген жол, кіру файлы жоқ, қолдау жоқ тіл', async () => {
    const bad = async (files: any, entry = 'a.py') => { await assert.rejects(ex.execute({ id: id(), entry, mode: 'file', files }, () => {})); };
    await bad([{ path: '../a.py', content: '' }]);
    await bad([{ path: '/etc/a.py', content: '' }]);
    await bad([{ path: 'a.py', content: '' }, { path: 'a.py', content: '' }]);
    await bad([{ path: '.uya-sql.py', content: 'x' }], '.uya-sql.py');
    await bad([{ path: 'b.py', content: '' }]);
    await bad([{ path: 'a.xyz', content: '' }], 'a.xyz');
    await bad([{ path: 'a.py', content: 5 }]);
  });
  it('өшірулі тілде орындау қабылданбайды (C#)', async () => {
    await assert.rejects(ex.execute({ id: id(), entry: 'Program.cs', mode: 'file', files: [{ path: 'Program.cs', content: 'class P{}' }] }, () => {}), /қолжетімсіз/);
  });
});
