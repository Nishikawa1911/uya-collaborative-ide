import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { chmodSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import type { Server } from 'node:http';
import { Executor } from '../execute.ts';
import { createRunnerServer } from '../server.ts';

const TOKEN = 'test-token-0123456789abcdef';
const base = mkdtempSync(path.join(tmpdir(), 'uya-srv-')); chmodSync(base, 0o711);
let server: Server, url: string;
before(async () => {
  const ex = new Executor({ stateDir: path.join(base, 's'), jobsDir: path.join(base, 'j'), runc: 'runc' }, { maxConcurrent: 2 });
  await ex.probe(['python', 'sql']);
  server = createRunnerServer({ executor: ex, token: TOKEN, maxQueue: 3 });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  url = `http://127.0.0.1:${(server.address() as any).port}`;
});
after(() => { server.closeAllConnections(); server.close(); rmSync(base, { recursive: true, force: true }); });
const H = { authorization: `Bearer ${TOKEN}`, 'content-type': 'application/json' };
async function run(id: string, code: string, entry = 'm.py') {
  const r = await fetch(`${url}/v1/run`, { method: 'POST', headers: H, body: JSON.stringify({ id, entry, mode: 'file', files: [{ path: entry, content: code }] }) });
  const text = await r.text();
  return { status: r.status, events: text.trim() ? text.trim().split('\n').map((l) => JSON.parse(l)) : [] };
}

describe('runner HTTP', () => {
  it('токенсіз / қате токен → 401', async () => {
    assert.equal((await fetch(`${url}/v1/languages`)).status, 401);
    assert.equal((await fetch(`${url}/v1/languages`, { headers: { authorization: 'Bearer wrong-wrong-wrong-wrong' } })).status, 401);
  });
  it('тілдер тізімі', async () => {
    const j: any = await (await fetch(`${url}/v1/languages`, { headers: H })).json();
    assert.equal(j.languages.find((l: any) => l.id === 'python').enabled, true);
    assert.equal(j.languages.find((l: any) => l.id === 'csharp').enabled, false);
  });
  it('NDJSON ағыны: started → output → finished', async () => {
    const r = await run('srvrun01', 'print("сәлем")');
    assert.equal(r.status, 200);
    assert.equal(r.events[0].type, 'started');
    assert.ok(r.events.some((e: any) => e.type === 'output' && e.chunk.includes('сәлем')));
    assert.equal(r.events.at(-1).status, 'ok');
  });
  it('жарамсыз сұраныс 400, өшірулі тіл 409', async () => {
    const a = await fetch(`${url}/v1/run`, { method: 'POST', headers: H, body: JSON.stringify({ id: 'x', entry: 'a.py', files: [] }) });
    assert.equal(a.status, 400);
    const b = await run('srvrun02', 'x', 'Program.cs');
    assert.equal(b.status, 409);
  });
  it('cancel эндпоинті орындалып жатқан тапсырманы тоқтатады', async () => {
    const p = run('srvcanc1', 'import time\nprint("go", flush=True)\ntime.sleep(60)');
    await new Promise((r) => setTimeout(r, 1500));
    const c: any = await (await fetch(`${url}/v1/cancel/srvcanc1`, { method: 'POST', headers: H })).json();
    assert.equal(c.cancelled, true);
    assert.equal((await p).events.at(-1).status, 'killed');
  });
  it('клиент ажыраса, орындау тоқтайды (ресурс ағып кетпейді)', async () => {
    const ac = new AbortController();
    fetch(`${url}/v1/run`, { method: 'POST', headers: H, signal: ac.signal, body: JSON.stringify({ id: 'srvdisc1', entry: 'm.py', mode: 'file', files: [{ path: 'm.py', content: 'import time\ntime.sleep(60)' }] }) }).catch(() => {});
    await new Promise((r) => setTimeout(r, 1200));
    assert.equal((await (await fetch(`${url}/v1/health`, { headers: H })).json() as any).active, 1);
    ac.abort();
    for (let i = 0; i < 50; i++) { await new Promise((r) => setTimeout(r, 100)); if ((await (await fetch(`${url}/v1/health`, { headers: H })).json() as any).active === 0) return; }
    assert.fail('орындау тоқтамады');
  });
  it('кезек толса 429 (concurrency 2, queue 3)', async () => {
    const slow = (i: number) => run(`srvq${i}000`, 'import time\ntime.sleep(3)');
    const ps = [slow(1), slow(2), slow(3)];
    await new Promise((r) => setTimeout(r, 800));
    const over = await run('srvq9000', 'print(1)');
    assert.equal(over.status, 429);
    await Promise.all(ps);
  });
});
