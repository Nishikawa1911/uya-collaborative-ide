/** Тапсырманы орындау: тексеру → оқшауланған жұмыс ортасы → компиляция фазасы → іске қосу фазасы → тазалау. */
import { StringDecoder } from 'node:string_decoder';
import { COMPILE_LIMITS, DEFAULT_LIMITS, buildLanguages, langOfPath, type LangConfig, type RunLang, type SourceFile } from './languages.ts';
import { JobEnv, ensureRuntime, isSafeRelPath, type Limits, type PhaseResult, type RunnerPaths } from './sandbox.ts';

export type RunStatus = 'ok' | 'error' | 'compile_error' | 'timeout' | 'killed' | 'memory_limit' | 'output_limit' | 'internal_error';

export interface ExecRequest {
  id: string;
  entry: string;
  mode: 'file' | 'project';
  files: SourceFile[];
  stdin?: string;
}

export type ExecEvent =
  | { type: 'started' }
  | { type: 'phase'; phase: 'compile' | 'run' }
  | { type: 'output'; stream: 'build' | 'stdout' | 'stderr'; chunk: string }
  | { type: 'finished'; status: RunStatus; exitCode: number | null; signal: string | null; durationMs: number; phase: 'compile' | 'run' | 'setup'; message?: string; maxMemoryBytes?: number | null };

export class ExecError extends Error {
  code: string;
  constructor(code: string, msg: string) { super(msg); this.code = code; }
}

export const MAX_FILES = 300;
export const MAX_TOTAL_BYTES = 8 * 1024 * 1024;

export interface LangStatus { id: RunLang; label: string; enabled: boolean; reason?: string }

export class Executor {
  readonly paths: RunnerPaths;
  private langs = new Map<string, LangConfig>();
  private status = new Map<string, LangStatus>();
  private active = new Map<string, AbortController>();
  private maxConcurrent: number;
  private waiting: Array<() => void> = [];
  private running = 0;
  private baseLimits: Limits;

  constructor(paths: RunnerPaths, opts: { maxConcurrent?: number } = {}) {
    this.paths = paths;
    this.maxConcurrent = opts.maxConcurrent ?? 4;
    this.baseLimits = DEFAULT_LIMITS;
    for (const l of buildLanguages()) this.langs.set(l.id, l);
  }

  get activeCount() { return this.active.size; }
  languages(): LangStatus[] { return [...this.langs.values()].map((l) => this.status.get(l.id) ?? { id: l.id, label: l.label, enabled: false, reason: 'тексерілмеген' }); }
  isEnabled(id: string) { return this.status.get(id)?.enabled === true; }
  config(id: string) { return this.langs.get(id); }

  /** Бас тарту: орындалып жатқан контейнерді өлтіреді. */
  cancel(id: string): boolean { const a = this.active.get(id); if (!a) return false; a.abort(); return true; }

  private async slot<T>(fn: () => Promise<T>): Promise<T> {
    if (this.running >= this.maxConcurrent) await new Promise<void>((r) => this.waiting.push(r));
    this.running++;
    try { return await fn(); } finally { this.running--; this.waiting.shift()?.(); }
  }

  /** Әр тілді оқшауланған контейнерде өзін-өзі тексеру: дұрыс нәтиже + (компиляцияланатын тілдер үшін) компиляция қатесі. */
  async probe(only?: string[]): Promise<LangStatus[]> {
    const rt = await ensureRuntime(this.paths);
    for (const l of this.langs.values()) {
      if (only && !only.includes(l.id)) continue;
      const base = { id: l.id, label: l.label };
      if (!rt.ok) { this.status.set(l.id, { ...base, enabled: false, reason: rt.reason }); continue; }
      const missing = l.requires.find((r) => !(r.startsWith('/') ? existsOnHost(r) : false));
      if (missing) { this.status.set(l.id, { ...base, enabled: false, reason: `құрал-сайман орнатылмаған: ${missing}` }); continue; }
      const t = await this.selfTest(l);
      this.status.set(l.id, { ...base, enabled: t.ok, reason: t.ok ? undefined : t.reason });
    }
    return this.languages();
  }

  private async selfTest(l: LangConfig): Promise<{ ok: true } | { ok: false; reason: string }> {
    try {
      const good = await this.execute({ id: `st-${l.id}-${Date.now().toString(36)}`, entry: l.selfTest.entry, mode: 'project', files: l.selfTest.files }, () => {}, undefined, { skipEnabledCheck: true });
      if (good.status !== 'ok' || !good.stdout.includes(l.selfTest.expect)) return { ok: false, reason: `self-test сәтсіз: ${good.status} ${good.stderr.slice(0, 200) || good.build.slice(0, 200)}` };
      if (l.selfTest.badFiles) {
        const bad = await this.execute({ id: `sb-${l.id}-${Date.now().toString(36)}`, entry: l.selfTest.entry, mode: 'project', files: l.selfTest.badFiles }, () => {}, undefined, { skipEnabledCheck: true });
        if (bad.status !== 'compile_error' || !bad.build.trim()) return { ok: false, reason: `компиляция қатесі дұрыс анықталмады: ${bad.status}` };
      }
      return { ok: true };
    } catch (e) { return { ok: false, reason: (e as Error).message }; }
  }

  validate(req: ExecRequest): { lang: LangConfig; files: SourceFile[] } {
    if (!/^[A-Za-z0-9_-]{6,64}$/.test(req.id)) throw new ExecError('bad_request', 'id жарамсыз');
    if (!Array.isArray(req.files) || req.files.length === 0 || req.files.length > MAX_FILES) throw new ExecError('bad_request', 'файлдар саны жарамсыз');
    let total = 0;
    const seen = new Set<string>();
    for (const f of req.files) {
      if (!f || typeof f.path !== 'string' || typeof f.content !== 'string') throw new ExecError('bad_request', 'файл форматы жарамсыз');
      if (!isSafeRelPath(f.path) || f.path.split('/').some((s) => s.startsWith('.uya-') || s === '.gocache')) throw new ExecError('bad_request', `файл жолы жарамсыз: ${f.path}`);
      if (seen.has(f.path)) throw new ExecError('bad_request', 'файл жолы қайталанған');
      seen.add(f.path);
      total += Buffer.byteLength(f.content, 'utf8');
    }
    if (total > MAX_TOTAL_BYTES) throw new ExecError('bad_request', 'жоба тым үлкен');
    if (!seen.has(req.entry)) throw new ExecError('bad_request', 'кіру файлы жобада жоқ');
    const id = langOfPath(req.entry);
    const lang = id ? this.langs.get(id) : undefined;
    if (!lang) throw new ExecError('unsupported_language', 'бұл файл түрін орындау мүмкін емес');
    return { lang, files: req.files };
  }

  async execute(req: ExecRequest, onEvent: (e: ExecEvent) => void, outerSignal?: AbortSignal, opts: { skipEnabledCheck?: boolean } = {}): Promise<{ status: RunStatus; exitCode: number | null; stdout: string; stderr: string; build: string }> {
    const { lang, files } = this.validate(req);
    if (!opts.skipEnabledCheck && !this.isEnabled(lang.id)) throw new ExecError('language_disabled', `${lang.label} қолжетімсіз: ${this.status.get(lang.id)?.reason ?? 'тексерілмеген'}`);
    if (this.active.has(req.id)) throw new ExecError('bad_request', 'бұл id бұрыннан орындалуда');
    const ac = new AbortController();
    this.active.set(req.id, ac);
    const onOuter = () => ac.abort();
    outerSignal?.addEventListener('abort', onOuter, { once: true });
    if (outerSignal?.aborted) ac.abort();

    let stdout = '', stderr = '', build = '';
    const cap = (s: string, add: string) => (s.length < 200_000 ? s + add : s);
    try {
      return await this.slot(async () => {
        const started = Date.now();
        const finish = (status: RunStatus, exitCode: number | null, signal: string | null, phase: 'compile' | 'run' | 'setup', message?: string, mem?: number | null) => {
          onEvent({ type: 'finished', status, exitCode, signal, durationMs: Date.now() - started, phase, message, maxMemoryBytes: mem ?? null });
          return { status, exitCode, stdout, stderr, build };
        };
        if (ac.signal.aborted) return finish('killed', null, null, 'setup', 'cancel');
        onEvent({ type: 'started' });
        const plan = lang.plan({ files, entry: req.entry, mode: req.mode });
        let env: JobEnv | null = null;
        try {
          const workMB = Math.max(...plan.phases.map((p) => (lang.limits[p.name === 'compile' ? 'compile' : 'run']?.workMB ?? (p.name === 'compile' ? COMPILE_LIMITS.workMB : this.baseLimits.workMB))), 64);
          env = await JobEnv.create(this.paths, req.id.replace(/[^A-Za-z0-9]/g, '').slice(0, 24) || 'job', workMB);
          env.writeFiles(files);
          env.writeFiles(plan.extraFiles);
          env.writeFiles([{ path: '.uya-out/.keep', content: '' }]);

          for (const p of plan.phases) {
            if (ac.signal.aborted) return finish('killed', null, null, p.name, 'cancel');
            onEvent({ type: 'phase', phase: p.name });
            const base = p.name === 'compile' ? COMPILE_LIMITS : this.baseLimits;
            const limits: Limits = { ...base, ...(lang.limits[p.name === 'compile' ? 'compile' : 'run'] ?? {}), ...(p.limits ?? {}) };
            const dec1 = new StringDecoder('utf8'), dec2 = new StringDecoder('utf8');
            const emit = (stream: 'stdout' | 'stderr', text: string) => {
              if (!text) return;
              if (p.name === 'compile') { build = cap(build, text); onEvent({ type: 'output', stream: 'build', chunk: text }); }
              else { if (stream === 'stdout') stdout = cap(stdout, text); else stderr = cap(stderr, text); onEvent({ type: 'output', stream, chunk: text }); }
            };
            const r: PhaseResult = await env.runPhase(
              { name: p.name, cmd: p.cmd, env: { ...lang.env, ...(p.env ?? {}) }, mounts: lang.mounts, limits, stdin: p.name === 'run' ? req.stdin : undefined },
              { onStdout: (b) => emit('stdout', dec1.write(b)), onStderr: (b) => emit('stderr', dec2.write(b)) },
              ac.signal,
            );
            emit('stdout', dec1.end()); emit('stderr', dec2.end());
            if (r.killedBy === 'cancel') return finish('killed', r.exitCode, r.signal, p.name, 'cancel', r.maxMemoryBytes);
            if (r.killedBy === 'timeout') return finish('timeout', r.exitCode, r.signal, p.name, `${Math.round(limits.timeoutMs / 1000)}s`, r.maxMemoryBytes);
            if (r.killedBy === 'output') return finish('output_limit', r.exitCode, r.signal, p.name, String(limits.outputBytes), r.maxMemoryBytes);
            if (r.killedBy === 'memory') return finish('memory_limit', r.exitCode, r.signal, p.name, `${limits.memoryMB}MB`, r.maxMemoryBytes);
            if (r.exitCode !== 0) return finish(p.name === 'compile' ? 'compile_error' : 'error', r.exitCode, r.signal, p.name, undefined, r.maxMemoryBytes);
            if (p.name === 'run') return finish('ok', 0, null, 'run', undefined, r.maxMemoryBytes);
          }
          return finish('ok', 0, null, 'run');
        } catch (e) {
          return finish('internal_error', null, null, 'setup', (e as Error).message);
        } finally {
          await env?.dispose();
        }
      });
    } finally {
      outerSignal?.removeEventListener('abort', onOuter);
      this.active.delete(req.id);
    }
  }
}

import { existsSync } from 'node:fs';
const existsOnHost = (p: string) => existsSync(p);
