/** Runner іске қосу: node --disable-warning=ExperimentalWarning runner/main.ts (root құқығы керек, бөлек хостта). */
import { Executor } from './execute.ts';
import { createRunnerServer } from './server.ts';

const env = process.env;
const token = env.RUNNER_TOKEN ?? '';
if (token.length < 16) { console.error('RUNNER_TOKEN орнатылмаған (кемі 16 таңба).'); process.exit(1); }
const executor = new Executor({
  stateDir: env.RUNNER_STATE_DIR ?? '/run/uya-runner', jobsDir: env.RUNNER_JOBS_DIR ?? '/var/lib/uya-runner/jobs', runc: env.RUNNER_RUNC ?? 'runc',
}, { maxConcurrent: Number(env.RUNNER_CONCURRENCY ?? 4) });
console.log('Тілдер тексерілуде (әр тіл контейнерде өзін-өзі тексереді)…');
const langs = await executor.probe();
for (const l of langs) console.log(`  ${l.enabled ? '✔' : '✘'} ${l.label}${l.enabled ? '' : ' — ' + l.reason}`);
const host = env.RUNNER_HOST ?? '127.0.0.1';
const port = Number(env.RUNNER_PORT ?? 7070);
const server = createRunnerServer({ executor, token, maxQueue: Number(env.RUNNER_MAX_QUEUE ?? 32) });
server.listen(port, host, () => console.log(`Runner ${host}:${port} портында тыңдап тұр`));
const stop = () => { server.close(); setTimeout(() => process.exit(0), 500).unref(); };
process.on('SIGTERM', stop); process.on('SIGINT', stop);
