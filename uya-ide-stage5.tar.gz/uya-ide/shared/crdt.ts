/**
 * Мәтіндік CRDT: RGA (Replicated Growable Array), Лампорт уақыт белгілерімен.
 * Yjs бұл ортада орнатылмайтындықтан өз іске асыру жазылды; сервер де, браузер де БІР файлды қолданады.
 *
 * Негізгі қасиеттер (shared/crdt tесттері fuzz-пен тексереді):
 *  • әр таңбаның бірегей id-і бар: [санауыш c, клиент k]; таңба сілтеме жасайтын сол жақ көрші — `ref`;
 *  • insert/delete операциялары коммутативті және идемпотентті → кез келген ретпен/қайталанып келсе де
 *    барлық көшірмелер бірдей мәтінге жинақталады (бір пайдаланушының өзгерісі екіншісін ЕШҚАШАН өшірмейді);
 *  • delete — «қабір тасы» (tombstone): таңба қайта тірілмейді, сондықтан параллель өңдеулер жоғалмайды;
 *  • ref әлі келмеген операциялар `pending` кезегінде күтеді (себепсіз тәртіп бұзылса да қауіпсіз).
 *
 * Операция форматы (JSON-дағы ықшам түрі):
 *   insert-run: { t:'i', c, k, rc, rk, s }  — s мәтінінің j-ші таңбасының id-і [c+j, k], ref — алдыңғы таңба
 *                                              (j=0 үшін [rc, rk]; rc=0 — құжат басы)
 *   delete-run: { t:'d', c, k, n }          — id-лері [c..c+n-1, k] таңбалар өшіріледі
 * Ескерту: мәтін UTF-16 код бірліктері бойынша индекстеледі (Monaco/DOM офсеттерімен бірдей).
 */

export interface InsertOp { t: 'i'; c: number; k: number; rc: number; rk: number; s: string }
export interface DeleteOp { t: 'd'; c: number; k: number; n: number }
export type Op = InsertOp | DeleteOp;

/** Редакторға қолданылатын өзгеріс (ретімен қолданылады: әр келесі офсет алдыңғыдан кейінгі күйге қатысты). */
export interface TextChange { offset: number; deleteCount: number; insert: string }

/** Салыстырмалы позиция: көрінетін [id] таңбасынан кейінгі орын. null — құжаттың басы. */
export type RelPos = readonly [number, number] | null;

export const MAX_CLIENT_ID = 2 ** 22 - 1;
export const MAX_COUNTER = 2 ** 30;
const K = 2 ** 22;
const key = (c: number, k: number) => c * K + k;

class Node {
  c: number; k: number; ch: string; del = false; rc: number; rk: number; next: Node | null = null;
  constructor(c: number, k: number, ch: string, rc: number, rk: number) { this.c = c; this.k = k; this.ch = ch; this.rc = rc; this.rk = rk; }
}

const greater = (a: Node, c: number, k: number) => a.c > c || (a.c === c && a.k > k);

export class CrdtError extends Error {}

const isInt = (v: unknown, min: number, max: number): v is number => typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max;

/** Желіден келген операцияны тексереді (қате/зиянды деректерде CrdtError лақтырады). */
export function validateOp(op: unknown, maxRun = 1_000_000): Op {
  if (op == null || typeof op !== 'object') throw new CrdtError('op');
  const o = op as Record<string, unknown>;
  if (o.t === 'i') {
    if (!isInt(o.c, 1, MAX_COUNTER) || !isInt(o.k, 0, MAX_CLIENT_ID) || !isInt(o.rc, 0, MAX_COUNTER) || !isInt(o.rk, 0, MAX_CLIENT_ID)) throw new CrdtError('op.i');
    if (typeof o.s !== 'string' || o.s.length === 0 || o.s.length > maxRun) throw new CrdtError('op.i.s');
    return { t: 'i', c: o.c, k: o.k, rc: o.rc, rk: o.rk, s: o.s };
  }
  if (o.t === 'd') {
    if (!isInt(o.c, 1, MAX_COUNTER) || !isInt(o.k, 0, MAX_CLIENT_ID) || !isInt(o.n, 1, maxRun)) throw new CrdtError('op.d');
    return { t: 'd', c: o.c, k: o.k, n: o.n };
  }
  throw new CrdtError('op.t');
}

export class TextCRDT {
  clientId: number;
  private head = new Node(0, 0, '', 0, 0);
  private byId = new Map<number, Node>();
  private pending: Op[] = [];
  /** Көрінетін таңбалар саны */
  length = 0;
  /** Бүкіл түйін саны (қабір тастарымен) */
  size = 0;
  /** Көрінген ең үлкен Лампорт санауышы */
  maxC = 0;

  constructor(clientId = 0) {
    if (!isInt(clientId, 0, MAX_CLIENT_ID)) throw new CrdtError('clientId');
    this.clientId = clientId;
  }

  /** Қайта қосылғанда сервер басқа идентификатор бергенде. Санауыш жалғасады (бірегейлік сақталады). */
  setClientId(id: number) {
    if (!isInt(id, 0, MAX_CLIENT_ID)) throw new CrdtError('clientId');
    this.clientId = id;
  }

  get pendingCount() { return this.pending.length; }
  clearPending() { this.pending = []; }

  text(): string {
    let out = '';
    for (let n = this.head.next; n; n = n.next) if (!n.del) out += n.ch;
    return out;
  }

  // ───────── Жергілікті өзгерістер (редактордан) ─────────

  /** `offset` орнына мәтін енгізеді. Қайтарылған операцияны басқаларға жіберу керек. */
  localInsert(offset: number, text: string): InsertOp | null {
    if (!text) return null;
    if (offset < 0 || offset > this.length) throw new CrdtError(`offset ${offset} / ${this.length}`);
    const ref = offset === 0 ? this.head : this.visibleAt(offset - 1)!;
    const op: InsertOp = { t: 'i', c: this.maxC + 1, k: this.clientId, rc: ref.c, rk: ref.k, s: text };
    this.integrateRun(op, ref);
    return op;
  }

  /** [offset, offset+count) аралығын өшіреді. */
  localDelete(offset: number, count: number): DeleteOp[] {
    if (count <= 0) return [];
    if (offset < 0 || offset + count > this.length) throw new CrdtError(`delete ${offset}+${count} / ${this.length}`);
    const ops: DeleteOp[] = [];
    let n = offset === 0 ? this.head.next : this.visibleAt(offset - 1)!.next;
    let left = count;
    let cur: DeleteOp | null = null;
    while (n && left > 0) {
      if (!n.del) {
        n.del = true; this.length--; left--;
        if (cur && cur.k === n.k && cur.c + cur.n === n.c) cur.n++;
        else { cur = { t: 'd', c: n.c, k: n.k, n: 1 }; ops.push(cur); }
      }
      n = n.next;
    }
    return ops;
  }

  /** Бір редактор өзгерісін (офсет, өшірілген саны, енгізілген мәтін) операцияларға айналдырады. */
  localReplace(offset: number, deleteCount: number, insert: string): Op[] {
    const ops: Op[] = [...this.localDelete(offset, deleteCount)];
    const ins = this.localInsert(offset, insert);
    if (ins) ops.push(ins);
    return ops;
  }

  // ───────── Қашықтағы операцияларды қолдану ─────────

  /**
   * Операцияларды қолданады (идемпотентті). Редакторға қолдануға тиісті өзгерістерді қайтарады.
   * Тәуелділігі жоқ операциялар `pending`-те қалады да, кейін автоматты түрде қолданылады.
   */
  applyOps(ops: Op[], maxPending = 20_000): TextChange[] {
    const changes: TextChange[] = [];
    let rest = this.pending.concat(ops);
    this.pending = [];
    let progress = true;
    while (progress && rest.length) {
      progress = false;
      const next: Op[] = [];
      for (const op of rest) {
        const r = op.t === 'i' ? this.tryInsert(op, changes) : this.tryDelete(op, changes, next);
        if (r === 'ok') progress = true;
        else next.push(op);
      }
      rest = next;
    }
    if (rest.length > maxPending) throw new CrdtError('pending overflow');
    this.pending = rest;
    return changes;
  }

  private tryInsert(op: InsertOp, changes: TextChange[]): 'ok' | 'wait' {
    const refNode = op.rc === 0 ? this.head : this.byId.get(key(op.rc, op.rk));
    if (!refNode) return 'wait';
    // Бір run ішінде кейбір таңбалар бұрыннан болуы мүмкін (қайталанған/қиылысқан жіберу)
    let j = 0;
    while (j < op.s.length) {
      if (this.byId.has(key(op.c + j, op.k))) { j++; continue; }
      let e = j;
      while (e < op.s.length && !this.byId.has(key(op.c + e, op.k))) e++;
      const seg: InsertOp = j === 0
        ? { t: 'i', c: op.c, k: op.k, rc: op.rc, rk: op.rk, s: op.s.slice(0, e) }
        : { t: 'i', c: op.c + j, k: op.k, rc: op.c + j - 1, rk: op.k, s: op.s.slice(j, e) };
      const ref = seg.rc === 0 ? this.head : this.byId.get(key(seg.rc, seg.rk));
      if (!ref) return 'wait'; // (j>0 болса, ref — осы run-дың алдыңғы таңбасы, ол бар)
      const offset = this.integrateRun(seg, ref);
      changes.push({ offset, deleteCount: 0, insert: seg.s });
      j = e;
    }
    return 'ok';
  }

  /** Run-ды RGA ережесімен орналастырады; енгізілген орынның көрінетін офсетін қайтарады. */
  private integrateRun(op: InsertOp, ref: Node): number {
    let left = ref;
    let cur = left.next;
    while (cur && greater(cur, op.c, op.k)) { left = cur; cur = cur.next; }
    // көрінетін офсет: left-ке дейінгі көрінетін таңбалар
    let offset = 0;
    for (let n = this.head.next; n; n = n.next) { if (!n.del) offset++; if (n === left) break; }
    if (left === this.head) offset = 0;
    let prev = left;
    for (let j = 0; j < op.s.length; j++) {
      const node = new Node(op.c + j, op.k, op.s[j], j === 0 ? op.rc : op.c + j - 1, j === 0 ? op.rk : op.k);
      node.next = prev === left ? cur : prev.next;
      prev.next = node;
      this.byId.set(key(node.c, node.k), node);
      prev = node;
    }
    this.length += op.s.length;
    this.size += op.s.length;
    if (op.c + op.s.length - 1 > this.maxC) this.maxC = op.c + op.s.length - 1;
    return offset;
  }

  private tryDelete(op: DeleteOp, changes: TextChange[], defer: Op[]): 'ok' | 'wait' {
    const present: Node[] = [];
    const waiting: DeleteOp[] = [];
    let found = 0;
    for (let j = 0; j < op.n; j++) {
      const n = this.byId.get(key(op.c + j, op.k));
      if (n) { found++; if (!n.del) present.push(n); } else {
        const last = waiting[waiting.length - 1];
        if (last && last.c + last.n === op.c + j) last.n++; else waiting.push({ t: 'd', c: op.c + j, k: op.k, n: 1 });
      }
    }
    if (found === 0) return 'wait';
    this.deleteNodes(present, changes);
    // әлі келмеген таңбалардың өшірілуі кейін қолданылады
    defer.push(...waiting);
    return 'ok';
  }

  private deleteNodes(targets: Node[], changes: TextChange[]) {
    if (!targets.length) return;
    const set = new Set(targets);
    const offsets: number[] = [];
    let off = 0;
    for (let n = this.head.next, left = set.size; n && left > 0; n = n.next) {
      if (n.del) continue;
      if (set.has(n)) { offsets.push(off); left--; }
      off++;
    }
    for (const t of targets) t.del = true;
    this.length -= targets.length;
    // Кему ретімен: әр өзгеріс алдыңғы (үлкен офсетті) өзгерістерге әсер етпейді
    let i = offsets.length - 1;
    while (i >= 0) {
      let start = i;
      while (start > 0 && offsets[start - 1] === offsets[start] - 1) start--;
      changes.push({ offset: offsets[start], deleteCount: i - start + 1, insert: '' });
      i = start - 1;
    }
  }

  // ───────── Күй: толық синхрондау үшін ─────────

  /** Бүкіл құжатты операциялар тізімі ретінде береді (құжат реті = себептік реті). */
  toOps(): Op[] {
    const ops: Op[] = [];
    let cur: InsertOp | null = null;
    let last: Node | null = null;
    for (let n = this.head.next; n; n = n.next) {
      if (cur && last && n.k === last.k && n.c === last.c + 1 && n.rc === last.c && n.rk === last.k) {
        cur.s += n.ch;
      } else {
        cur = { t: 'i', c: n.c, k: n.k, rc: n.rc, rk: n.rk, s: n.ch };
        ops.push(cur);
      }
      last = n;
    }
    let del: DeleteOp | null = null;
    for (let n = this.head.next; n; n = n.next) {
      if (!n.del) continue;
      if (del && del.k === n.k && del.c + del.n === n.c) del.n++;
      else { del = { t: 'd', c: n.c, k: n.k, n: 1 }; ops.push(del); }
    }
    return ops;
  }

  /** Бос құжатты мәтіннен құрады (сервер: клиент 0; counter 1…n). */
  static fromText(text: string, clientId = 0): TextCRDT {
    const doc = new TextCRDT(clientId);
    if (text) doc.localInsert(0, text);
    return doc;
  }

  static fromOps(ops: Op[], clientId = 0): TextCRDT {
    const doc = new TextCRDT(clientId);
    doc.applyOps(ops);
    return doc;
  }

  // ───────── Салыстырмалы позициялар (курсорлар) ─────────

  /** Офсеттен салыстырмалы позиция: offset-тен сол жақтағы көрінетін таңбаның id-і. */
  relFromOffset(offset: number): RelPos {
    if (offset <= 0) return null;
    const n = this.visibleAt(Math.min(offset, this.length) - 1);
    return n ? [n.c, n.k] : null;
  }

  /** Салыстырмалы позициядан ағымдағы офсет (өшірілген таңбадан кейін — солдағы көрінетін таңбаның соңы). */
  offsetFromRel(pos: RelPos): number | null {
    if (!pos) return 0;
    const target = this.byId.get(key(pos[0], pos[1]));
    if (!target) return null;
    let off = 0;
    for (let n = this.head.next; n; n = n.next) {
      if (!n.del) off++;
      if (n === target) return off;
    }
    return null;
  }

  has(c: number, k: number) { return this.byId.has(key(c, k)); }

  private visibleAt(index: number): Node | null {
    let i = -1;
    for (let n = this.head.next; n; n = n.next) {
      if (!n.del && ++i === index) return n;
    }
    return null;
  }
}

/** Екі мәтін арасындағы ең қысқа орталық өзгеріс (ортақ префикс/суффикс). Редактор өзгерісін шығару үшін. */
export function diffText(a: string, b: string): { offset: number; deleteCount: number; insert: string } | null {
  if (a === b) return null;
  let s = 0;
  const max = Math.min(a.length, b.length);
  while (s < max && a.charCodeAt(s) === b.charCodeAt(s)) s++;
  let e = 0;
  while (e < max - s && a.charCodeAt(a.length - 1 - e) === b.charCodeAt(b.length - 1 - e)) e++;
  return { offset: s, deleteCount: a.length - s - e, insert: b.slice(s, b.length - e) };
}
