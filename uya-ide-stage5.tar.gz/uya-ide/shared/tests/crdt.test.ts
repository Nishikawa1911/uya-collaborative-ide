import test from 'node:test';
import assert from 'node:assert/strict';
import { TextCRDT, diffText, type Op, type TextChange } from '../crdt.ts';

function rng(seed: number) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 2 ** 32; }; }
function applyChanges(text: string, ch: TextChange[]) { for (const c of ch) text = text.slice(0, c.offset) + c.insert + text.slice(c.offset + c.deleteCount); return text; }
function shuffle<T>(a: T[], r: () => number) { const b = a.slice(); for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; }

test('жергілікті енгізу/өшіру', () => {
  const d = new TextCRDT(1);
  d.localInsert(0, 'abc'); d.localInsert(3, 'def'); d.localDelete(1, 2);
  assert.equal(d.text(), 'adef');
  assert.equal(d.length, 4);
});

test('идемпотенттілік және қайта жіберу', () => {
  const a = new TextCRDT(1); const b = new TextCRDT(2);
  const ops = [a.localInsert(0, 'hello')!, ...a.localDelete(1, 2)];
  b.applyOps(ops); b.applyOps(ops); b.applyOps(ops);
  assert.equal(b.text(), a.text());
});

test('бір орынға параллель енгізу: екеуі де сақталады', () => {
  const base = TextCRDT.fromText('xy', 0);
  const st = base.toOps();
  const a = TextCRDT.fromOps(st, 1); const b = TextCRDT.fromOps(st, 2);
  const oa = a.localInsert(1, 'AAA')!; const ob = b.localInsert(1, 'BBB')!;
  a.applyOps([ob]); b.applyOps([oa]);
  assert.equal(a.text(), b.text());
  assert.ok(a.text().includes('AAA') && a.text().includes('BBB'));
});

test('өшіру мен енгізу параллель', () => {
  const st = TextCRDT.fromText('abcdef', 0).toOps();
  const a = TextCRDT.fromOps(st, 1); const b = TextCRDT.fromOps(st, 2);
  const da = a.localDelete(1, 4); const ib = b.localInsert(3, 'ZZ')!;
  a.applyOps([ib]); b.applyOps(da);
  assert.equal(a.text(), b.text());
  assert.ok(a.text().includes('ZZ')); // басқаның енгізуі өшіру аралығында болса да жоғалмайды
});

test('ref келмей тұрып келген op күтеді (тәртіп бұзылған)', () => {
  const a = new TextCRDT(1);
  const o1 = a.localInsert(0, 'ab')!; const o2 = a.localInsert(2, 'cd')!; const o3 = a.localDelete(1, 2);
  const b = new TextCRDT(2);
  b.applyOps([...o3, o2]); assert.equal(b.text(), ''); assert.ok(b.pendingCount > 0);
  b.applyOps([o1]);
  assert.equal(b.text(), a.text());
  assert.equal(b.pendingCount, 0);
});

test('редактор айнасы: қашықтан келген өзгерістер офсеттері дұрыс', () => {
  const r = rng(11);
  const a = new TextCRDT(1); const b = new TextCRDT(2);
  let mirror = ''; // a-ның редакторы
  for (let i = 0; i < 500; i++) {
    const ops: Op[] = [];
    // b жергілікті өңдейді
    for (let j = 0; j < 1 + Math.floor(r() * 3); j++) {
      if (r() < 0.65 || b.length === 0) ops.push(b.localInsert(Math.floor(r() * (b.length + 1)), 'ab\ncd'.slice(0, 1 + Math.floor(r() * 5)))!);
      else { const o = Math.floor(r() * b.length); ops.push(...b.localDelete(o, Math.min(1 + Math.floor(r() * 4), b.length - o))); }
    }
    // a жергілікті өңдейді (редактор айнасын да жаңартады)
    if (r() < 0.5) {
      const o = Math.floor(r() * (a.length + 1)); const t = 'Z' + i;
      const own = a.localInsert(o, t); mirror = mirror.slice(0, o) + t + mirror.slice(o); void own;
    }
    const ch = a.applyOps(shuffle(ops, r).concat(ops)); // араластырылған + қайталанған
    mirror = applyChanges(mirror, ch);
    assert.equal(mirror, a.text(), `қадам ${i}`);
  }
});

test('fuzz: көп көшірме, кездейсоқ тәртіп, толық конвергенция', () => {
  for (let seed = 1; seed <= 40; seed++) {
    const r = rng(seed);
    const N = 4;
    const docs = Array.from({ length: N }, (_, i) => new TextCRDT(i + 1));
    const log: Op[][] = docs.map(() => []);
    for (let step = 0; step < 150; step++) {
      const i = Math.floor(r() * N); const d = docs[i];
      let ops: Op[] = [];
      if (r() < 0.65 || d.length === 0) ops = [d.localInsert(Math.floor(r() * (d.length + 1)), String.fromCharCode(97 + Math.floor(r() * 26)).repeat(1 + Math.floor(r() * 3)))!];
      else { const o = Math.floor(r() * d.length); ops = d.localDelete(o, Math.min(1 + Math.floor(r() * 5), d.length - o)); }
      log[i].push(...ops);
      if (r() < 0.3) { // ішінара синхрондау
        const j = Math.floor(r() * N);
        if (j !== i) docs[j].applyOps(shuffle(log[i], r));
      }
    }
    const all = log.flat();
    const finals = docs.map((d, i) => { d.applyOps(shuffle(all, rng(seed * 100 + i))); return d.text(); });
    for (const t of finals) assert.equal(t, finals[0], `seed ${seed}`);
    docs.forEach((d) => assert.equal(d.pendingCount, 0));
    // күй сериализациясы: toOps → жаңа құжат бірдей мәтін
    const re = TextCRDT.fromOps(docs[0].toOps(), 9);
    assert.equal(re.text(), finals[0]);
    // толық мерж (reconnect): ескі көшірме + күй
    const stale = TextCRDT.fromOps(docs[1].toOps().slice(0, 3), 8);
    stale.applyOps(docs[2].toOps());
    assert.equal(stale.text(), finals[0]);
  }
});

test('салыстырмалы позициялар параллель өңдеуде тұрақты', () => {
  const d = TextCRDT.fromText('hello world', 1);
  const rel = d.relFromOffset(5); // 'hello' соңы
  d.localInsert(0, '>>> ');
  assert.equal(d.offsetFromRel(rel), 9);
  d.localDelete(0, 12);
  assert.equal(d.offsetFromRel(rel), 0);
  assert.equal(d.offsetFromRel(null), 0);
});

test('diffText', () => {
  assert.equal(diffText('abc', 'abc'), null);
  assert.deepEqual(diffText('abcdef', 'abXef'), { offset: 2, deleteCount: 2, insert: 'X' });
  assert.deepEqual(diffText('', 'hi'), { offset: 0, deleteCount: 0, insert: 'hi' });
});

test('Юникод (суррогат жұптар) офсеттері UTF-16 бойынша', () => {
  const d = TextCRDT.fromText('Қазақ😀', 1);
  assert.equal(d.length, 7);
  assert.equal(d.text(), 'Қазақ😀');
});
