import type { ProjectSummary } from '../../api/types';
import { Link, paths } from '../../app/router';
import { Avatar, Icon, LanguageChip, RoleBadge } from '../../components/ui';
import { useT } from '../../i18n';
import { formatRelativeTime } from '../../i18n/format';
import { colorFor } from '../../lib/utils';

interface ProjectCardProps {
  project: ProjectSummary;
  currentUserId: string;
}

/** Жоба карточкасы: атау, иесі, қатысушылар саны, тілдер, соңғы жаңартылған уақыт. */
export function ProjectCard({ project, currentUserId }: ProjectCardProps) {
  const t = useT();
  const isMine = project.ownerId === currentUserId;
  const shown = project.languages.slice(0, 3);
  const extra = project.languages.length - shown.length;

  return (
    <article className="project-card">
      <div className="project-card__top">
        <h3 className="project-card__name">
          <Link to={paths.workspace(project.id)} className="project-card__link" aria-label={`${t('card.open')}: ${project.name}`}>
            {project.name}
          </Link>
        </h3>
        {!isMine && <RoleBadge role={project.myRole} />}
      </div>
      <p className="project-card__desc">{project.description}</p>

      <div className="project-card__langs">
        {shown.map((l) => <LanguageChip key={l} language={l} />)}
        {extra > 0 && <span className="lang-chip lang-chip--more">+{extra}</span>}
      </div>

      <div className="project-card__meta">
        <span className="project-card__owner" title={t('card.owner')}>
          <Avatar person={{ displayName: project.ownerName, avatarColor: colorFor(project.ownerId) }} size={22} />
          <span className="project-card__owner-name">{project.ownerName}{isMine && <em> · {t('card.you')}</em>}</span>
        </span>
        <span className="project-card__stat" title={t('card.members', { n: project.memberCount })}>
          <Icon name="users" size={14} /> {t('card.members', { n: project.memberCount })}
        </span>
        <span className="project-card__stat project-card__time" title={t('card.updated', { time: formatRelativeTime(project.updatedAt) })}>
          <Icon name="clock" size={14} /> {formatRelativeTime(project.updatedAt)}
        </span>
      </div>
    </article>
  );
}

export function ProjectCardSkeleton() {
  return (
    <div className="project-card project-card--skeleton" aria-hidden="true">
      <span className="skeleton" style={{ height: 20, width: '70%' }} />
      <span className="skeleton" style={{ height: 14, width: '100%', marginTop: 12 }} />
      <span className="skeleton" style={{ height: 14, width: '80%', marginTop: 6 }} />
      <span className="skeleton" style={{ height: 22, width: '50%', marginTop: 18 }} />
      <span className="skeleton" style={{ height: 22, width: '90%', marginTop: 18 }} />
    </div>
  );
}
