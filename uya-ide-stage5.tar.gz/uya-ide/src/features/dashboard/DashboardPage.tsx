import { useMemo, useState } from 'react';
import { api } from '../../api';
import { PROJECT_LANGUAGES, type LanguageId, type ProjectScope, type ProjectSummary } from '../../api/types';
import { Link, navigate, paths, useRoute } from '../../app/router';
import { AppShell } from '../../components/layout/AppShell';
import { Alert, Button, EmptyState, Input, Select, Tabs } from '../../components/ui';
import { useT } from '../../i18n';
import { languageMeta } from '../../lib/languages';
import { useAsync } from '../../lib/useAsync';
import { useCurrentUser } from '../../state/auth';
import { ProjectCard, ProjectCardSkeleton } from './ProjectCard';

type SortKey = 'updated' | 'name' | 'members';
const scopes: ProjectScope[] = ['mine', 'shared', 'recent'];
const isScope = (v: string | null): v is ProjectScope => v === 'mine' || v === 'shared' || v === 'recent';

export function DashboardPage() {
  const t = useT();
  const user = useCurrentUser();
  const route = useRoute();
  const tabParam = route.query.get('tab');
  const scope: ProjectScope = isScope(tabParam) ? tabParam : 'mine';

  const [query, setQuery] = useState('');
  const [language, setLanguage] = useState<LanguageId | 'all'>('all');
  const [sort, setSort] = useState<SortKey>('updated');

  // Үш тізімді қатар жүктейміз: қойынды санауыштары дәл болу үшін.
  const lists = useAsync(async () => {
    const [mine, shared, recent] = await Promise.all(scopes.map((s) => api.projects.list(s)));
    return { mine, shared, recent } as Record<ProjectScope, ProjectSummary[]>;
  }, []);

  const visible = useMemo(() => {
    const all = lists.data?.[scope] ?? [];
    const q = query.trim().toLocaleLowerCase('kk');
    const filtered = all.filter((p) => {
      if (language !== 'all' && !p.languages.includes(language)) return false;
      if (!q) return true;
      return [p.name, p.description, p.ownerName, ...p.languages.map((l) => t(languageMeta[l].labelKey))]
        .some((s) => s.toLocaleLowerCase('kk').includes(q));
    });
    if (scope === 'recent' && sort === 'updated') return filtered; // «Соңғы» тізімі серверден ашылу ретімен келеді
    return [...filtered].sort((a, b) => {
      if (sort === 'name') return a.name.localeCompare(b.name, 'kk');
      if (sort === 'members') return b.memberCount - a.memberCount;
      return +new Date(b.updatedAt) - +new Date(a.updatedAt);
    });
  }, [lists.data, scope, query, language, sort, t]);

  const filtersActive = query.trim() !== '' || language !== 'all';
  const count = (s: ProjectScope) => lists.data?.[s].length;

  return (
    <AppShell>
      <div className="page">
        <header className="page__header page__header--row">
          <div>
            <h1>{t('dashboard.greeting', { name: user.displayName.split(' ')[0] })}</h1>
            <p className="page__subtitle">{t('dashboard.subtitle')}</p>
          </div>
          <div className="page__actions">
            <Button icon="key" onClick={() => navigate(paths.joinProject())}>{t('nav.joinProject')}</Button>
            <Button variant="primary" icon="plus" onClick={() => navigate(paths.newProject())}>{t('nav.newProject')}</Button>
          </div>
        </header>

        <section aria-labelledby="projects-heading">
          <h2 id="projects-heading" className="sr-only">{t('nav.projects')}</h2>
          <Tabs
            label={t('nav.projects')}
            idPrefix="dash"
            value={scope}
            onChange={(id) => navigate(`${paths.dashboard()}?tab=${id}`)}
            items={scopes.map((s) => ({ id: s, label: t(`dashboard.tab.${s}` as const), count: count(s) }))}
          />

          <div className="toolbar" role="search">
            <Input
              icon="search" type="search" className="toolbar__search"
              placeholder={t('dashboard.search')} aria-label={t('dashboard.search')}
              value={query} onChange={(e) => setQuery(e.target.value)}
            />
            <Select aria-label={t('dashboard.filter.language')} value={language} onChange={(e) => setLanguage(e.target.value as LanguageId | 'all')}>
              <option value="all">{t('dashboard.filter.allLanguages')}</option>
              {PROJECT_LANGUAGES.map((l) => <option key={l} value={l}>{t(languageMeta[l].labelKey)}</option>)}
            </Select>
            <Select aria-label={t('dashboard.sort')} value={sort} onChange={(e) => setSort(e.target.value as SortKey)}>
              <option value="updated">{t('dashboard.sort.updated')}</option>
              <option value="name">{t('dashboard.sort.name')}</option>
              <option value="members">{t('dashboard.sort.members')}</option>
            </Select>
          </div>

          <div id={`dash-panel-${scope}`} role="tabpanel" aria-labelledby={`dash-${scope}`}>
            {lists.error ? (
              <Alert kind="error" action={<Button size="sm" onClick={lists.reload}>{t('common.retry')}</Button>}>{t('dashboard.loadError')}</Alert>
            ) : lists.loading && !lists.data ? (
              <div className="grid" aria-busy="true">{Array.from({ length: 6 }, (_, i) => <ProjectCardSkeleton key={i} />)}</div>
            ) : visible.length === 0 ? (
              filtersActive ? (
                <EmptyState icon="search" title={t('dashboard.empty.search.title')} text={t('dashboard.empty.search.text')}
                  action={<Button onClick={() => { setQuery(''); setLanguage('all'); }}>{t('common.retry')}</Button>} />
              ) : (
                <EmptyState
                  icon={scope === 'mine' ? 'rocket' : scope === 'shared' ? 'users' : 'clock'}
                  title={t(`dashboard.empty.${scope}.title` as const)}
                  text={t(`dashboard.empty.${scope}.text` as const)}
                  action={scope === 'shared'
                    ? <Link to={paths.joinProject()} className="btn btn--primary btn--md"><span className="btn__label">{t('nav.joinProject')}</span></Link>
                    : <Link to={paths.newProject()} className="btn btn--primary btn--md"><span className="btn__label">{t('nav.newProject')}</span></Link>}
                />
              )
            ) : (
              <>
                <p className="muted result-count" aria-live="polite">{t('dashboard.count', { n: visible.length })}</p>
                <div className="grid">
                  {visible.map((p) => <ProjectCard key={p.id} project={p} currentUserId={user.id} />)}
                </div>
              </>
            )}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
