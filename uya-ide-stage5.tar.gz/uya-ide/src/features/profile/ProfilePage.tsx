import { useCallback, useRef, useState } from 'react';
import { api } from '../../api';
import { ApiError } from '../../api/types';
import { navigate, paths, useRoute } from '../../app/router';
import { AppShell } from '../../components/layout/AppShell';
import {
  Alert, Avatar, Button, Field, Icon, Input, PasswordInput, Select, SegmentedControl, Tabs,
} from '../../components/ui';
import { PasswordStrength } from '../auth/PasswordStrength';
import { useT } from '../../i18n';
import { formatDate, messageForError } from '../../i18n/format';
import { EMAIL_RE, USERNAME_RE, useForm } from '../../lib/useForm';
import { useAsync } from '../../lib/useAsync';
import { AVATAR_PALETTE, cx } from '../../lib/utils';
import { logout, updateProfile, useCurrentUser } from '../../state/auth';
import { toast } from '../../state/toasts';
import { setTheme, useTheme } from '../../theme/theme';

type TabId = 'account' | 'appearance' | 'security';
const TABS: TabId[] = ['account', 'appearance', 'security'];
const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
const AVATAR_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

const errText = (err: unknown) => messageForError(err instanceof ApiError ? err.code : 'unknown', err instanceof ApiError ? err.params : undefined);

export function ProfilePage() {
  const t = useT();
  const route = useRoute();
  const tabParam = route.query.get('tab');
  const tab: TabId = TABS.includes(tabParam as TabId) ? (tabParam as TabId) : 'account';

  return (
    <AppShell>
      <div className="page page--narrow">
        <header className="page__header">
          <h1>{t('profile.title')}</h1>
          <p className="page__subtitle">{t('profile.subtitle')}</p>
        </header>
        <Tabs
          label={t('profile.title')}
          idPrefix="profile"
          value={tab}
          onChange={(id) => navigate(`${paths.profile()}?tab=${id}`)}
          items={[
            { id: 'account', label: t('profile.section.account'), icon: 'user' },
            { id: 'appearance', label: t('profile.section.appearance'), icon: 'sparkles' },
            { id: 'security', label: t('profile.section.security'), icon: 'shield' },
          ]}
        />
        <div role="tabpanel" id={`profile-panel-${tab}`} aria-labelledby={`profile-${tab}`} className="profile-panel">
          {tab === 'account' && <AccountSection />}
          {tab === 'appearance' && <AppearanceSection />}
          {tab === 'security' && <SecuritySection />}
        </div>
      </div>
    </AppShell>
  );
}

/* ───────── Есептік жазба ───────── */
interface AccountValues extends Record<string, string> { displayName: string; username: string; email: string }

function AccountSection() {
  const t = useT();
  const user = useCurrentUser();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [avatarBusy, setAvatarBusy] = useState(false);
  const [avatarError, setAvatarError] = useState<string | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);

  const stats = useAsync(async () => {
    const [mine, shared] = await Promise.all([api.projects.list('mine'), api.projects.list('shared')]);
    return { mine: mine.length, shared: shared.length };
  }, []);

  const validate = useCallback((v: AccountValues) => {
    const e: Partial<Record<keyof AccountValues, string>> = {};
    if (!v.displayName.trim()) e.displayName = t('validation.required');
    else if (v.displayName.trim().length > 60) e.displayName = t('validation.nameTooLong', { max: 60 });
    if (!v.username.trim()) e.username = t('validation.required');
    else if (!USERNAME_RE.test(v.username.trim())) e.username = t('validation.usernameFormat');
    if (!v.email.trim()) e.email = t('validation.required');
    else if (!EMAIL_RE.test(v.email.trim())) e.email = t('validation.emailInvalid');
    return e;
  }, [t]);

  const form = useForm<AccountValues>({ displayName: user.displayName, username: user.username, email: user.email }, validate);
  const dirty = form.values.displayName !== user.displayName || form.values.username !== user.username || form.values.email !== user.email;

  const submit = form.handleSubmit(async (v) => {
    setBusy(true);
    setServerError(null);
    try {
      await updateProfile({ displayName: v.displayName, username: v.username, email: v.email });
      toast(t('profile.saved'), 'success');
    } catch (err) {
      setServerError(errText(err));
    } finally {
      setBusy(false);
    }
  });

  const onFile = (file: File | undefined) => {
    if (!file) return;
    setAvatarError(null);
    if (!AVATAR_TYPES.includes(file.type)) { setAvatarError(t('profile.avatar.badType')); return; }
    if (file.size > MAX_AVATAR_BYTES) { setAvatarError(t('profile.avatar.tooLarge')); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      setAvatarBusy(true);
      try {
        await updateProfile({ avatarUrl: String(reader.result) });
        toast(t('profile.saved'), 'success');
      } catch (err) {
        setAvatarError(errText(err));
      } finally {
        setAvatarBusy(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const setColor = async (color: string) => {
    setAvatarBusy(true);
    try {
      await updateProfile({ avatarColor: color, avatarUrl: null });
    } catch (err) {
      setAvatarError(errText(err));
    } finally {
      setAvatarBusy(false);
    }
  };

  const removeAvatar = async () => {
    setAvatarBusy(true);
    try {
      await updateProfile({ avatarUrl: null });
      toast(t('profile.saved'), 'success');
    } catch (err) {
      setAvatarError(errText(err));
    } finally {
      setAvatarBusy(false);
    }
  };

  return (
    <div className="profile-grid">
      <section className="panel-card" aria-labelledby="avatar-title">
        <h2 id="avatar-title">{t('profile.avatar')}</h2>
        <div className="avatar-editor">
          <Avatar person={user} size={88} />
          <div className="avatar-editor__actions">
            <input
              ref={fileRef} type="file" accept={AVATAR_TYPES.join(',')} className="sr-only" tabIndex={-1}
              aria-label={t('profile.avatar.upload')} data-testid="avatar-file"
              onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ''; }}
            />
            <Button icon="upload" loading={avatarBusy} onClick={() => fileRef.current?.click()}>{t('profile.avatar.upload')}</Button>
            {user.avatarUrl && <Button variant="ghost" icon="trash" disabled={avatarBusy} onClick={removeAvatar}>{t('profile.avatar.remove')}</Button>}
            <p className="field__hint">{t('profile.avatar.hint')}</p>
          </div>
        </div>
        {avatarError && <Alert kind="error" onDismiss={() => setAvatarError(null)}>{avatarError}</Alert>}
        <div className="field">
          <span className="field__label" id="avatar-color-label">{t('profile.avatar.color')}</span>
          <div className="swatches" role="radiogroup" aria-labelledby="avatar-color-label">
            {AVATAR_PALETTE.map((c) => (
              <button
                key={c} type="button" role="radio" aria-checked={!user.avatarUrl && user.avatarColor === c}
                aria-label={c} title={c} disabled={avatarBusy}
                className={cx('swatch', !user.avatarUrl && user.avatarColor === c && 'is-selected')}
                style={{ background: c }} onClick={() => setColor(c)}
              >
                {!user.avatarUrl && user.avatarColor === c && <Icon name="check" size={14} />}
              </button>
            ))}
          </div>
        </div>
        <dl className="stats">
          <div><dt>{t('profile.stats.projects')}</dt><dd>{stats.data?.mine ?? '—'}</dd></div>
          <div><dt>{t('profile.stats.shared')}</dt><dd>{stats.data?.shared ?? '—'}</dd></div>
        </dl>
        <p className="field__hint">{t('profile.memberSince', { date: formatDate(user.createdAt) })}</p>
      </section>

      <form onSubmit={submit} noValidate className="form panel-card" aria-labelledby="account-title">
        <h2 id="account-title">{t('profile.section.account')}</h2>
        {serverError && <Alert kind="error">{serverError}</Alert>}
        <Field label={t('auth.register.displayName')} htmlFor="field-displayName" error={form.errors.displayName}>
          <Input id="field-displayName" name="displayName" icon="user" autoComplete="name" value={form.values.displayName} invalid={!!form.errors.displayName}
            onChange={(e) => form.setValue('displayName', e.target.value)} onBlur={() => form.touch('displayName')} />
        </Field>
        <Field label={t('auth.register.username')} htmlFor="field-username" error={form.errors.username} hint={t('auth.register.usernameHint')}>
          <Input id="field-username" name="username" icon="braces" autoComplete="username" value={form.values.username} invalid={!!form.errors.username}
            onChange={(e) => form.setValue('username', e.target.value)} onBlur={() => form.touch('username')} />
        </Field>
        <Field label={t('auth.register.email')} htmlFor="field-email" error={form.errors.email}>
          <Input id="field-email" name="email" type="email" icon="globe" autoComplete="email" value={form.values.email} invalid={!!form.errors.email}
            onChange={(e) => form.setValue('email', e.target.value)} onBlur={() => form.touch('email')} />
        </Field>
        <div className="form__actions">
          <Button variant="ghost" disabled={!dirty || busy} onClick={() => { form.reset(); setServerError(null); }}>{t('common.cancel')}</Button>
          <Button type="submit" variant="primary" icon="save" loading={busy} disabled={!dirty}>{t('common.save')}</Button>
        </div>
      </form>
    </div>
  );
}

/* ───────── Сыртқы көрініс ───────── */
function AppearanceSection() {
  const t = useT();
  const theme = useTheme();
  return (
    <section className="panel-card form" aria-labelledby="appearance-title">
      <h2 id="appearance-title">{t('profile.section.appearance')}</h2>
      <div className="field">
        <span className="field__label">{t('profile.theme')}</span>
        <SegmentedControl
          label={t('profile.theme')}
          value={theme}
          onChange={setTheme}
          items={[{ id: 'dark', label: t('theme.dark'), icon: 'moon' }, { id: 'light', label: t('theme.light'), icon: 'sun' }]}
        />
        <div className={cx('theme-preview', `theme-preview--${theme}`)} aria-hidden="true">
          <span /><span /><span />
        </div>
      </div>
      <Field label={t('profile.language')} htmlFor="field-locale" hint={t('profile.language.hint')}>
        <Select id="field-locale" value="kk" onChange={() => {}}>
          <option value="kk">{t('profile.language.kk')}</option>
        </Select>
      </Field>
    </section>
  );
}

/* ───────── Қауіпсіздік ───────── */
interface PwValues extends Record<string, string> { current: string; next: string; confirm: string }
const emptyPw: PwValues = { current: '', next: '', confirm: '' };

function SecuritySection() {
  const t = useT();
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const validate = useCallback((v: PwValues) => {
    const e: Partial<Record<keyof PwValues, string>> = {};
    if (!v.current) e.current = t('validation.required');
    if (!v.next) e.next = t('validation.required');
    else if (v.next.length < 10) e.next = t('validation.passwordShort');
    if (!v.confirm) e.confirm = t('validation.required');
    else if (v.confirm !== v.next) e.confirm = t('validation.passwordMismatch');
    return e;
  }, [t]);
  const form = useForm<PwValues>(emptyPw, validate);

  const submit = form.handleSubmit(async (v) => {
    setBusy(true);
    setServerError(null);
    try {
      await api.auth.changePassword(v.current, v.next);
      toast(t('profile.password.changed'), 'success');
      form.reset();
    } catch (err) {
      setServerError(errText(err));
    } finally {
      setBusy(false);
    }
  });

  const doLogout = async () => {
    await logout();
    navigate(paths.login());
  };

  return (
    <div className="profile-grid profile-grid--single">
      <form onSubmit={submit} noValidate className="form panel-card" aria-labelledby="password-title">
        <h2 id="password-title">{t('profile.password.title')}</h2>
        {serverError && <Alert kind="error">{serverError}</Alert>}
        <Field label={t('profile.password.current')} htmlFor="field-current" error={form.errors.current}>
          <PasswordInput id="field-current" name="current" icon="lock" autoComplete="current-password" value={form.values.current} invalid={!!form.errors.current}
            onChange={(e) => form.setValue('current', e.target.value)} onBlur={() => form.touch('current')} />
        </Field>
        <Field label={t('profile.password.new')} htmlFor="field-next" error={form.errors.next} hint={t('auth.register.passwordHint')}>
          <PasswordInput id="field-next" name="next" icon="key" autoComplete="new-password" value={form.values.next} invalid={!!form.errors.next}
            onChange={(e) => form.setValue('next', e.target.value)} onBlur={() => form.touch('next')} />
        </Field>
        <PasswordStrength value={form.values.next} />
        <Field label={t('profile.password.confirm')} htmlFor="field-confirm" error={form.errors.confirm}>
          <PasswordInput id="field-confirm" name="confirm" icon="key" autoComplete="new-password" value={form.values.confirm} invalid={!!form.errors.confirm}
            onChange={(e) => form.setValue('confirm', e.target.value)} onBlur={() => form.touch('confirm')} />
        </Field>
        <div className="form__actions">
          <Button type="submit" variant="primary" icon="shield" loading={busy}>{t('profile.password.submit')}</Button>
        </div>
      </form>
      <section className="panel-card">
        <Button variant="danger" icon="logout" onClick={doLogout}>{t('profile.logoutAll')}</Button>
      </section>
    </div>
  );
}
