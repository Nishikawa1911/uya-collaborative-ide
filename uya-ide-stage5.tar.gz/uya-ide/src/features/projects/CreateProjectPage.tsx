import { useCallback, useMemo, useState } from 'react';
import { api } from '../../api';
import {
  ApiError, type CreatedProject, type LanguageId, type ProjectSummary, type Role,
} from '../../api/types';
import { Link, navigate, paths } from '../../app/router';
import { AppShell } from '../../components/layout/AppShell';
import {
  Alert, Button, CopyButton, Field, Icon, Input, SegmentedControl, Textarea,
} from '../../components/ui';
import { useT } from '../../i18n';
import { messageForError } from '../../i18n/format';
import { languageMeta, selectableLanguages } from '../../lib/languages';
import { useForm } from '../../lib/useForm';
import { cx, isValidFileName } from '../../lib/utils';
import { useCurrentUser } from '../../state/auth';
import { toast } from '../../state/toasts';
import { ProjectCard } from '../dashboard/ProjectCard';

interface FormValues extends Record<string, string | boolean | string[]> {
  name: string;
  description: string;
  languages: string[];
  entryPoint: string;
  joinRole: 'editor' | 'viewer';
  template: 'empty' | 'hello';
}

const initial: FormValues = { name: '', description: '', languages: [], entryPoint: '', joinRole: 'editor', template: 'hello' };

/** Жол сегменттерінің әрқайсысы жарамды файл атауы болуы керек (src/main.rs → src, main.rs). */
const isValidEntry = (path: string) => path.split('/').every((seg) => isValidFileName(seg));

export function CreateProjectPage() {
  const t = useT();
  const user = useCurrentUser();
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [entryTouched, setEntryTouched] = useState(false);
  const [created, setCreated] = useState<CreatedProject | null>(null);

  const validate = useCallback((v: FormValues) => {
    const e: Partial<Record<keyof FormValues, string>> = {};
    if (!v.name.trim()) e.name = t('validation.required');
    else if (v.name.trim().length > 60) e.name = t('validation.nameTooLong', { max: 60 });
    if (v.languages.length === 0) e.languages = t('validation.languageRequired');
    if (!v.entryPoint.trim()) e.entryPoint = t('validation.required');
    else if (!isValidEntry(v.entryPoint.trim())) e.entryPoint = t('validation.invalidFileName');
    return e;
  }, [t]);

  const form = useForm<FormValues>(initial, validate);
  const selected = form.values.languages as LanguageId[];

  const toggleLanguage = (lang: LanguageId) => {
    const next = selected.includes(lang) ? selected.filter((l) => l !== lang) : [...selected, lang];
    form.setValue('languages', next);
    form.touch('languages');
    // Бастапқы файл атауын бірінші таңдалған тілге қарай ұсынамыз, пайдаланушы өзгертпесе ғана.
    if (!entryTouched) form.setValue('entryPoint', next.length ? languageMeta[next[0]].defaultEntry : '');
  };

  const submit = form.handleSubmit(async (v) => {
    setBusy(true);
    setServerError(null);
    try {
      const result = await api.projects.create({
        name: v.name.trim(),
        description: v.description.trim(),
        languages: v.languages as LanguageId[],
        entryPoint: v.entryPoint.trim(),
        joinRole: v.joinRole,
        template: v.template,
      });
      setCreated(result);
      toast(t('create.successTitle'), 'success');
    } catch (err) {
      setServerError(messageForError(err instanceof ApiError ? err.code : 'unknown', err instanceof ApiError ? err.params : undefined));
    } finally {
      setBusy(false);
    }
  });

  const preview: ProjectSummary = useMemo(() => ({
    id: 'preview',
    name: form.values.name.trim() || t('create.namePlaceholder'),
    description: form.values.description.trim() || t('create.descriptionPlaceholder'),
    ownerId: user.id, ownerName: user.displayName, memberCount: 1,
    languages: selected, updatedAt: new Date().toISOString(), myRole: 'owner' as Role,
    entryPoint: form.values.entryPoint,
  }), [form.values.name, form.values.description, form.values.entryPoint, selected, user, t]);

  if (created) {
    return (
      <AppShell>
        <div className="page page--narrow">
          <section className="success-card" aria-labelledby="created-title">
            <div className="success-card__icon"><Icon name="rocket" size={26} /></div>
            <h1 id="created-title">{t('create.successTitle')}</h1>
            <p className="page__subtitle">«{created.project.name}» — {t('create.successText')}</p>

            <div className="code-box" role="group" aria-label={t('create.inviteCode')}>
              <span className="code-box__label">{t('create.inviteCode')}</span>
              <code className="code-box__code" data-testid="invite-code">{created.inviteCode}</code>
              <CopyButton text={created.inviteCode} />
            </div>
            <Alert kind="warning">{t('create.codeShownOnce')}</Alert>

            <div className="success-card__actions">
              <Button variant="primary" size="lg" icon="forward" onClick={() => navigate(paths.workspace(created.project.id))}>{t('create.openProject')}</Button>
              <Button size="lg" onClick={() => navigate(paths.dashboard())}>{t('create.toDashboard')}</Button>
            </div>
          </section>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="page">
        <header className="page__header">
          <Link to={paths.dashboard()} className="back-link"><Icon name="back" size={15} /> {t('nav.toDashboard')}</Link>
          <h1>{t('create.title')}</h1>
          <p className="page__subtitle">{t('create.subtitle')}</p>
        </header>

        <div className="split-page">
          <form onSubmit={submit} noValidate className="form panel-card">
            {serverError && <Alert kind="error">{serverError}</Alert>}

            <Field label={t('create.name')} htmlFor="field-name" error={form.errors.name}>
              <Input
                id="field-name" name="name" autoFocus maxLength={80} autoComplete="off"
                placeholder={t('create.namePlaceholder')} value={form.values.name} invalid={!!form.errors.name}
                onChange={(e) => form.setValue('name', e.target.value)} onBlur={() => form.touch('name')}
              />
            </Field>

            <Field label={t('create.description')} htmlFor="field-description" optional>
              <Textarea
                id="field-description" name="description" maxLength={300} rows={3}
                placeholder={t('create.descriptionPlaceholder')} value={form.values.description}
                onChange={(e) => form.setValue('description', e.target.value)}
              />
            </Field>

            <fieldset className="fieldset" aria-describedby="languages-hint">
              <legend className="field__label">{t('create.languages')}</legend>
              <div className="chip-grid" role="group" aria-label={t('create.languages')} id="field-languages" tabIndex={-1}>
                {selectableLanguages.map((l) => {
                  const on = selected.includes(l);
                  return (
                    <button
                      key={l} type="button" className={cx('chip-toggle', on && 'is-on')} aria-pressed={on}
                      onClick={() => toggleLanguage(l)}
                    >
                      <span className="lang-chip__dot" style={{ background: languageMeta[l].color }} aria-hidden="true" />
                      {t(languageMeta[l].labelKey)}
                      {on && <Icon name="check" size={13} />}
                    </button>
                  );
                })}
              </div>
              {form.errors.languages
                ? <p className="field__error" role="alert"><Icon name="alert" size={13} /> {form.errors.languages}</p>
                : <p className="field__hint" id="languages-hint">{t('create.languagesHint')}</p>}
            </fieldset>

            <Field label={t('create.entryPoint')} htmlFor="field-entryPoint" hint={t('create.entryPointHint')} error={form.errors.entryPoint}>
              <Input
                id="field-entryPoint" name="entryPoint" icon="fileCode" className="mono" autoComplete="off" spellCheck={false}
                placeholder={t('create.entryPointPlaceholder')} value={form.values.entryPoint} invalid={!!form.errors.entryPoint}
                onChange={(e) => { setEntryTouched(true); form.setValue('entryPoint', e.target.value); }}
                onBlur={() => form.touch('entryPoint')}
              />
            </Field>

            <div className="form__row">
              <div className="field">
                <span className="field__label" id="join-role-label">{t('create.joinRole')}</span>
                <SegmentedControl
                  label={t('create.joinRole')}
                  value={form.values.joinRole}
                  onChange={(v) => form.setValue('joinRole', v)}
                  items={[{ id: 'editor', label: t('role.editor'), icon: 'edit' }, { id: 'viewer', label: t('role.viewer'), icon: 'eye' }]}
                />
                <p className="field__hint">{t(`role.${form.values.joinRole}.desc` as const)} {t('create.joinRoleHint')}</p>
              </div>
              <div className="field">
                <span className="field__label">{t('create.template')}</span>
                <SegmentedControl
                  label={t('create.template')}
                  value={form.values.template}
                  onChange={(v) => form.setValue('template', v)}
                  items={[{ id: 'hello', label: t('create.template.hello'), icon: 'sparkles' }, { id: 'empty', label: t('create.template.empty'), icon: 'file' }]}
                />
              </div>
            </div>

            <div className="form__actions">
              <Button variant="ghost" onClick={() => navigate(paths.dashboard())}>{t('common.cancel')}</Button>
              <Button type="submit" variant="primary" size="lg" icon="plus" loading={busy}>
                {busy ? t('create.submitting') : t('create.submit')}
              </Button>
            </div>
          </form>

          <aside className="split-page__aside" aria-label={t('create.preview')}>
            <h2 className="aside-title">{t('create.preview')}</h2>
            <ProjectCard project={preview} currentUserId={user.id} />
          </aside>
        </div>
      </div>
    </AppShell>
  );
}
