import { useEffect, useState } from 'react';
import { api, isMockApi } from '../../api';
import { DEMO_JOIN_CODE } from '../../api/mock/seed';
import { ApiError, type ProjectSummary, type Role } from '../../api/types';
import { Link, navigate, paths, useRoute } from '../../app/router';
import { AppShell } from '../../components/layout/AppShell';
import { Alert, Button, Field, Icon, Input } from '../../components/ui';
import { useT } from '../../i18n';
import { messageForError } from '../../i18n/format';
import { toast } from '../../state/toasts';

/** Енгізілгенді XXXX-XXXX-XXXX түріне келтіреді (тек әріп/сан, бас әріп). */
export function formatInviteCode(raw: string): string {
  const clean = raw.toLocaleUpperCase('en').replace(/[^A-Z0-9]/g, '').slice(0, 12);
  return clean.replace(/(.{4})(?=.)/g, '$1-');
}
const isCompleteCode = (code: string) => code.replace(/-/g, '').length === 12;

export function JoinProjectPage() {
  const t = useT();
  const route = useRoute();
  const [code, setCode] = useState(() => formatInviteCode(route.query.get('code') ?? ''));
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [attemptsLeft, setAttemptsLeft] = useState<number | null>(null);
  const [lock, setLock] = useState<{ minutes: number; until: number } | null>(null);
  const [joined, setJoined] = useState<{ project: ProjectSummary; role: Role } | null>(null);
  const [, tick] = useState(0);

  // Блок мерзімі аяқталғанда интерфейсті автоматты түрде ашамыз.
  useEffect(() => {
    if (!lock) return;
    const ms = lock.until - Date.now();
    if (ms <= 0) { setLock(null); return; }
    const id = window.setTimeout(() => { setLock(null); tick((n) => n + 1); }, ms);
    return () => window.clearTimeout(id);
  }, [lock]);

  const invalid = touched && !isCompleteCode(code);
  const locked = lock != null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (!isCompleteCode(code)) { document.getElementById('field-code')?.focus(); return; }
    setBusy(true);
    setError(null);
    try {
      const result = await api.projects.join(code);
      setJoined(result);
      toast(t('join.successTitle'), 'success');
    } catch (err) {
      if (err instanceof ApiError) {
        setError(messageForError(err.code, err.params));
        if (err.code === 'project.invalid_invite' && typeof err.params?.left === 'number') setAttemptsLeft(err.params.left);
        if (err.code === 'project.invite_rate_limited') {
          const minutes = Number(err.params?.minutes ?? 15);
          setLock({ minutes, until: Date.now() + minutes * 60_000 });
          setAttemptsLeft(null);
        }
      } else {
        setError(messageForError('unknown'));
      }
    } finally {
      setBusy(false);
    }
  };

  if (joined) {
    return (
      <AppShell>
        <div className="page page--narrow">
          <section className="success-card" aria-labelledby="joined-title">
            <div className="success-card__icon"><Icon name="success" size={26} /></div>
            <h1 id="joined-title">{t('join.successTitle')}</h1>
            <p className="page__subtitle">{t('join.successText', { name: joined.project.name, role: t(`role.${joined.role}` as const) })}</p>
            <div className="success-card__actions">
              <Button variant="primary" size="lg" icon="forward" onClick={() => navigate(paths.workspace(joined.project.id))}>{t('create.openProject')}</Button>
              <Button size="lg" onClick={() => navigate(paths.dashboard())}>{t('create.toDashboard')}</Button>
            </div>
          </section>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="page page--narrow">
        <header className="page__header">
          <Link to={paths.dashboard()} className="back-link"><Icon name="back" size={15} /> {t('nav.toDashboard')}</Link>
          <h1>{t('join.title')}</h1>
          <p className="page__subtitle">{t('join.subtitle')}</p>
        </header>

        <form onSubmit={submit} noValidate className="form panel-card join-form">
          {locked && <Alert kind="warning" title={t('join.locked', { minutes: lock!.minutes })} />}
          {error && !locked && <Alert kind="error">{error}</Alert>}

          <Field label={t('join.code')} htmlFor="field-code" error={invalid ? t('validation.inviteFormat') : undefined}>
            <Input
              id="field-code" name="code" icon="key" className="mono code-input" autoFocus autoComplete="off" spellCheck={false}
              inputMode="text" autoCapitalize="characters" placeholder={t('join.codePlaceholder')}
              value={code} invalid={invalid} disabled={locked}
              onChange={(e) => { setCode(formatInviteCode(e.target.value)); setError(null); }}
              onBlur={() => setTouched(true)}
            />
          </Field>

          {attemptsLeft != null && !locked && (
            <p className="attempts" role="status"><Icon name="shield" size={14} /> {t('join.attemptsLeft', { n: attemptsLeft })}</p>
          )}

          <Button type="submit" variant="primary" size="lg" icon="login" block loading={busy} disabled={locked}>
            {busy ? t('join.submitting') : t('join.submit')}
          </Button>
          <p className="field__hint security-note"><Icon name="lock" size={13} /> {t('join.securityNote')}</p>
        </form>

        {isMockApi && <div className="demo-box">
          <p>{t('join.demoHint')}</p>
          <code className="mono demo-code">{DEMO_JOIN_CODE}</code>
          <Button size="sm" icon="sparkles" onClick={() => { setCode(DEMO_JOIN_CODE); setTouched(false); setError(null); }}>
            {t('auth.login.fillDemo')}
          </Button>
        </div>}
      </div>
    </AppShell>
  );
}
