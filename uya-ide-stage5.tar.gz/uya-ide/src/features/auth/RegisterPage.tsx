import { useCallback, useState } from 'react';
import { ApiError } from '../../api/types';
import { Link, navigate, paths } from '../../app/router';
import { AuthLayout } from '../../components/layout/AuthLayout';
import { Alert, Button, Checkbox, Field, Input, PasswordInput } from '../../components/ui';
import { useT } from '../../i18n';
import { messageForError } from '../../i18n/format';
import { EMAIL_RE, USERNAME_RE, useForm } from '../../lib/useForm';
import { register } from '../../state/auth';
import { toast } from '../../state/toasts';
import { PasswordStrength } from './PasswordStrength';

interface FormValues extends Record<string, string | boolean> {
  displayName: string; username: string; email: string; password: string; confirm: string; terms: boolean;
}
const initial: FormValues = { displayName: '', username: '', email: '', password: '', confirm: '', terms: false };

export function RegisterPage() {
  const t = useT();
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const validate = useCallback((v: FormValues) => {
    const e: Partial<Record<keyof FormValues, string>> = {};
    if (!v.displayName.trim()) e.displayName = t('validation.required');
    else if (v.displayName.trim().length > 60) e.displayName = t('validation.nameTooLong', { max: 60 });
    if (!v.username.trim()) e.username = t('validation.required');
    else if (!USERNAME_RE.test(v.username.trim())) e.username = t('validation.usernameFormat');
    if (!v.email.trim()) e.email = t('validation.required');
    else if (!EMAIL_RE.test(v.email.trim())) e.email = t('validation.emailInvalid');
    if (!v.password) e.password = t('validation.required');
    else if (v.password.length < 10) e.password = t('validation.passwordShort');
    if (!v.confirm) e.confirm = t('validation.required');
    else if (v.confirm !== v.password) e.confirm = t('validation.passwordMismatch');
    if (!v.terms) e.terms = t('validation.termsRequired');
    return e;
  }, [t]);

  const form = useForm<FormValues>(initial, validate);
  const bind = (name: 'displayName' | 'username' | 'email') => ({
    id: `field-${name}`, name, value: form.values[name], invalid: !!form.errors[name],
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => form.setValue(name, e.target.value),
    onBlur: () => form.touch(name),
  });

  const submit = form.handleSubmit(async (v) => {
    setBusy(true);
    setServerError(null);
    try {
      await register({ displayName: v.displayName, username: v.username, email: v.email, password: v.password });
      toast(t('auth.register.title'), 'success', 2200);
      navigate(paths.dashboard(), { replace: true });
    } catch (err) {
      setServerError(messageForError(err instanceof ApiError ? err.code : 'unknown'));
    } finally {
      setBusy(false);
    }
  });

  return (
    <AuthLayout>
      <h2 className="auth__title">{t('auth.register.title')}</h2>
      <p className="auth__subtitle">{t('auth.register.subtitle')}</p>

      <form onSubmit={submit} noValidate className="form">
        {serverError && <Alert kind="error">{serverError}</Alert>}

        <Field label={t('auth.register.displayName')} htmlFor="field-displayName" error={form.errors.displayName}>
          <Input {...bind('displayName')} icon="user" autoComplete="name" autoFocus placeholder={t('auth.register.displayNamePlaceholder')} />
        </Field>
        <div className="form__row">
          <Field label={t('auth.register.username')} htmlFor="field-username" error={form.errors.username} hint={t('auth.register.usernameHint')}>
            <Input {...bind('username')} autoComplete="username" placeholder={t('auth.register.usernamePlaceholder')} />
          </Field>
          <Field label={t('auth.register.email')} htmlFor="field-email" error={form.errors.email}>
            <Input {...bind('email')} type="email" autoComplete="email" placeholder="aigerim@example.kz" />
          </Field>
        </div>
        <Field label={t('auth.register.password')} htmlFor="field-password" error={form.errors.password} hint={t('auth.register.passwordHint')}>
          <PasswordInput
            id="field-password" name="password" icon="lock" autoComplete="new-password"
            value={form.values.password} invalid={!!form.errors.password}
            onChange={(e) => form.setValue('password', e.target.value)} onBlur={() => form.touch('password')}
          />
        </Field>
        <PasswordStrength value={form.values.password} />
        <Field label={t('auth.register.confirm')} htmlFor="field-confirm" error={form.errors.confirm}>
          <PasswordInput
            id="field-confirm" name="confirm" icon="lock" autoComplete="new-password"
            value={form.values.confirm} invalid={!!form.errors.confirm}
            onChange={(e) => form.setValue('confirm', e.target.value)} onBlur={() => form.touch('confirm')}
          />
        </Field>
        <Checkbox
          id="field-terms" name="terms" label={t('auth.register.terms')} error={form.errors.terms}
          checked={form.values.terms}
          onChange={(e) => { form.setValue('terms', e.target.checked); form.touch('terms'); }}
        />

        <Button type="submit" variant="primary" size="lg" block loading={busy}>{t('auth.register.submit')}</Button>
      </form>

      <p className="auth__switch">
        {t('auth.register.haveAccount')} <Link to={paths.login()}>{t('auth.register.toLogin')}</Link>
      </p>
    </AuthLayout>
  );
}
