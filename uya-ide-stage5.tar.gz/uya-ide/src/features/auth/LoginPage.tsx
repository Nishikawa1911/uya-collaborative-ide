import { useCallback, useState } from 'react';
import { isMockApi } from '../../api';
import { DEMO_LOGIN } from '../../api/mock/seed';
import { ApiError } from '../../api/types';
import { Link, navigate, paths, useRoute } from '../../app/router';
import { AuthLayout } from '../../components/layout/AuthLayout';
import { Alert, Button, Field, Input, PasswordInput } from '../../components/ui';
import { messageForError } from '../../i18n/format';
import { useT } from '../../i18n';
import { useForm } from '../../lib/useForm';
import { login } from '../../state/auth';

export function LoginPage() {
  const t = useT();
  const route = useRoute();
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const validate = useCallback((v: { identifier: string; password: string }) => {
    const e: Partial<Record<'identifier' | 'password', string>> = {};
    if (!v.identifier.trim()) e.identifier = t('validation.required');
    if (!v.password) e.password = t('validation.required');
    return e;
  }, [t]);

  const form = useForm({ identifier: '', password: '' }, validate);

  const submit = form.handleSubmit(async (v) => {
    setBusy(true);
    setServerError(null);
    try {
      await login(v.identifier, v.password);
      navigate(route.query.get('next') || paths.dashboard(), { replace: true });
    } catch (err) {
      setServerError(messageForError(err instanceof ApiError ? err.code : 'unknown', err instanceof ApiError ? err.params : undefined));
    } finally {
      setBusy(false);
    }
  });

  return (
    <AuthLayout>
      <h2 className="auth__title">{t('auth.login.title')}</h2>
      <p className="auth__subtitle">{t('auth.login.subtitle')}</p>

      <form onSubmit={submit} noValidate className="form">
        {route.query.get('expired') && <Alert kind="warning">{t('auth.sessionExpired')}</Alert>}
        {serverError && <Alert kind="error">{serverError}</Alert>}

        <Field label={t('auth.login.identifier')} htmlFor="field-identifier" error={form.errors.identifier}>
          <Input
            id="field-identifier" name="identifier" icon="user" autoComplete="username" autoFocus
            placeholder={t('auth.login.identifierPlaceholder')}
            value={form.values.identifier}
            invalid={!!form.errors.identifier}
            onChange={(e) => form.setValue('identifier', e.target.value)}
            onBlur={() => form.touch('identifier')}
          />
        </Field>
        <Field label={t('auth.login.password')} htmlFor="field-password" error={form.errors.password}>
          <PasswordInput
            id="field-password" name="password" icon="lock" autoComplete="current-password"
            value={form.values.password}
            invalid={!!form.errors.password}
            onChange={(e) => form.setValue('password', e.target.value)}
            onBlur={() => form.touch('password')}
          />
        </Field>

        <Button type="submit" variant="primary" size="lg" block loading={busy}>{t('auth.login.submit')}</Button>
      </form>

      {isMockApi && <div className="demo-box">
        <div className="demo-box__head">
          <strong>{t('auth.login.demoTitle')}</strong>
        </div>
        <p>{t('auth.login.demoHint')}</p>
        <dl className="demo-box__creds">
          <div><dt>Email</dt><dd className="mono">{DEMO_LOGIN.identifier}</dd></div>
          <div><dt>{t('auth.login.password')}</dt><dd className="mono">{DEMO_LOGIN.password}</dd></div>
        </dl>
        <Button
          size="sm"
          icon="sparkles"
          onClick={() => {
            form.setValues({ identifier: DEMO_LOGIN.identifier, password: DEMO_LOGIN.password });
            setServerError(null);
          }}
        >
          {t('auth.login.fillDemo')}
        </Button>
      </div>}

      <p className="auth__switch">
        {t('auth.login.noAccount')} <Link to={paths.register()}>{t('auth.login.toRegister')}</Link>
      </p>
    </AuthLayout>
  );
}
