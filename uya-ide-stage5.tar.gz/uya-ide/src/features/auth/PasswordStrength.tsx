import { useT } from '../../i18n';
import { passwordScore } from '../../lib/useForm';
import { cx } from '../../lib/utils';

const labels = ['', 'auth.strength.weak', 'auth.strength.fair', 'auth.strength.good', 'auth.strength.strong'] as const;

/** Құпия сөз беріктігінің индикаторы (тек кеңес; нақты тексеру серверде). */
export function PasswordStrength({ value }: { value: string }) {
  const t = useT();
  const score = passwordScore(value);
  if (!value) return null;
  return (
    <div className="strength" role="status" aria-live="polite">
      <div className="strength__bars" aria-hidden="true">
        {[1, 2, 3, 4].map((i) => <span key={i} className={cx('strength__bar', i <= score && `strength__bar--${score}`)} />)}
      </div>
      <span className="strength__label">{t('auth.strength.label')}: {score ? t(labels[score]) : ''}</span>
    </div>
  );
}
