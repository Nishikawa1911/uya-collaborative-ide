import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../../api';
import { ApiError, type ChatMessage, type ProjectMember, type Role, type User } from '../../api/types';
import { realtime, type RealtimeSession, type RealtimeStatus } from '../../realtime';
import type { CollabClient } from '../../collab/client';
import { useCollabRefresh } from '../../collab/useCollab';
import { uid } from '../../lib/utils';
import { t } from '../../i18n';
import { messageForError } from '../../i18n/format';
import { toast } from '../../state/toasts';

const errMsg = (err: unknown) =>
  messageForError(err instanceof ApiError ? err.code : 'unknown', err instanceof ApiError ? err.params : undefined);

/**
 * Қатысушылар, чат және нақты уақыт күйі.
 *  • Қатысушылар мен рөлдер — дерекқордан (REST); онлайн күйі мен «қай файлда» — WebSocket presence-тен.
 *  • Чат: тарих REST-пен (беттеп), жаңа хабарламалар WebSocket-пен; хабарлама дерекқорға жазылғаннан кейін ғана таралады.
 *  • `collab` жоқ (демо/mock режимі): жергілікті күй, хабарламалар `local` деп белгіленеді.
 */
export function useTeam(
  projectId: string, me: User, myActivePath: string | null,
  collab: CollabClient | null = null, pathOfId: (id: string) => string = () => '',
) {
  const [members, setMembers] = useState<ProjectMember[]>([]);
  const [membersStatus, setMembersStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [chat, setChat] = useState<ChatMessage[]>([]);
  const [chatStatus, setChatStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [chatHasMore, setChatHasMore] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [rtStatus, setRtStatus] = useState<RealtimeStatus>('demo');
  const session = useRef<RealtimeSession | null>(null);
  const chatRef = useRef(chat);
  chatRef.current = chat;
  useCollabRefresh(collab, ['peers', 'status']);

  const loadMembers = useCallback(async () => {
    try {
      setMembers(await api.projects.members(projectId));
      setMembersStatus('ready');
    } catch {
      setMembersStatus('error');
    }
  }, [projectId]);

  /** Соңғы бет. Қайта қосылғанда да шақырылады: ажырау кезінде келген хабарламалар қосылады (id бойынша). */
  const loadChat = useCallback(async () => {
    try {
      const page = await api.chat.history(projectId);
      setChat((cur) => {
        const known = new Set(page.messages.map((m) => m.id));
        const keep = cur.filter((m) => !known.has(m.id) && (m.state || m.local || (m.seq ?? 0) < (page.messages[0]?.seq ?? 0)));
        return [...keep.filter((m) => !m.state && !m.local), ...page.messages, ...keep.filter((m) => m.state || m.local)];
      });
      setChatHasMore((h) => (chatRef.current.length === 0 ? page.hasMore : h || page.hasMore));
      setChatStatus('ready');
    } catch {
      setChatStatus('error');
    }
  }, [projectId]);

  const loadOlderChat = useCallback(async () => {
    const first = chatRef.current.find((m) => m.seq != null);
    if (!first || loadingOlder) return;
    setLoadingOlder(true);
    try {
      const page = await api.chat.history(projectId, first.seq);
      setChat((cur) => [...page.messages.filter((m) => !cur.some((c) => c.id === m.id)), ...cur]);
      setChatHasMore(page.hasMore);
    } catch (err) {
      toast(errMsg(err), 'error');
    } finally { setLoadingOlder(false); }
  }, [projectId, loadingOlder]);

  useEffect(() => { void loadMembers(); void loadChat(); }, [loadMembers, loadChat]);

  // Демо клиент (mock режимі): нақты уақыт жоқ
  useEffect(() => {
    if (collab) return undefined;
    const s = realtime.connect(projectId);
    session.current = s;
    const offStatus = s.onStatus(setRtStatus);
    const off = s.on((ev) => {
      if (ev.type === 'chat.message') setChat((list) => (list.some((m) => m.id === ev.payload.id) ? list : [...list, ev.payload]));
    });
    return () => { off(); offStatus(); s.close(); session.current = null; };
  }, [projectId, collab]);

  // Нақты уақыт клиенті
  useEffect(() => {
    if (!collab) return undefined;
    const map = (s: CollabClient['status']): RealtimeStatus => (s === 'kicked' ? 'disconnected' : s);
    setRtStatus(map(collab.status));
    let wasDown = false;
    return collab.on((e) => {
      if (e.type === 'status') {
        setRtStatus(map(e.status));
        if (e.status === 'reconnecting') wasDown = true;
        if (e.status === 'connected' && wasDown) { wasDown = false; void loadChat(); void loadMembers(); }
      } else if (e.type === 'chat') {
        const m = e.message;
        const msg: ChatMessage = { id: m.id, seq: m.seq, userId: m.userId ?? '', authorName: m.authorName, body: m.body, createdAt: m.createdAt };
        setChat((list) => {
          const rest = e.clientMsgId ? list.filter((x) => x.id !== `pending-${e.clientMsgId}`) : list;
          return rest.some((x) => x.id === msg.id) ? rest : [...rest, msg];
        });
      } else if (e.type === 'members') void loadMembers();
      else if (e.type === 'error' && e.clientMsgId) {
        setChat((list) => list.map((x) => (x.id === `pending-${e.clientMsgId}` ? { ...x, state: 'failed' } : x)));
        toast(messageForError(e.code, undefined), 'error');
      }
    });
  }, [collab, loadChat, loadMembers]);

  // Өз «белсенді файл» күйімізді жіберу
  const activeId = useRef<string | null>(null);
  useEffect(() => {
    if (!collab) session.current?.send({ type: 'presence.active_file', payload: { fileId: myActivePath } });
  }, [myActivePath, collab]);
  void activeId;

  /** Онлайн күйі: нақты режимде — presence (бір пайдаланушының бірнеше беті болуы мүмкін); әйтпесе тек өзіміз. */
  const displayMembers = useMemo<ProjectMember[]>(() => {
    const peers = collab ? [...collab.peers.values()] : [];
    return members.map((m) => {
      if (m.userId === me.id) {
        return { ...m, online: collab ? collab.status === 'connected' : true, activeFile: myActivePath ?? undefined, displayName: me.displayName, avatarColor: me.avatarColor, avatarUrl: me.avatarUrl };
      }
      const mine = peers.filter((p) => p.userId === m.userId);
      if (!mine.length) return m;
      const editing = mine.find((p) => p.activeFileId);
      const path = editing?.activeFileId ? pathOfId(editing.activeFileId) : '';
      return { ...m, online: true, activeFile: path || undefined };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [members, me, myActivePath, collab, collab?.peersVersion, collab?.status, pathOfId]);

  const sendMessage = useCallback((body: string): boolean => {
    const text = body.trim();
    if (!text) return false;
    if (collab) {
      const cid = collab.sendChat(text);
      if (!cid) { toast(t('chat.offline'), 'warning'); return false; }
      setChat((list) => [...list, { id: `pending-${cid}`, userId: me.id, body: text, createdAt: new Date().toISOString(), state: 'sending' }]);
      setTimeout(() => setChat((list) => list.map((x) => (x.id === `pending-${cid}` && x.state === 'sending' ? { ...x, state: 'failed' } : x))), 12_000);
      return true;
    }
    const clientId = uid('c');
    setChat((list) => [...list, { id: clientId, userId: me.id, body: text, createdAt: new Date().toISOString(), local: true }]);
    session.current?.send({ type: 'chat.send', payload: { body: text, clientId } });
    return true;
  }, [me.id, collab]);

  const setMemberRole = useCallback(async (userId: string, role: Exclude<Role, 'owner'>) => {
    try {
      await api.projects.setMemberRole(projectId, userId, role);
      setMembers((list) => list.map((m) => (m.userId === userId ? { ...m, role } : m)));
      const name = members.find((m) => m.userId === userId)?.displayName ?? '';
      toast(t('members.roleChanged', { name, role: t(`role.${role}` as const) }), 'success', 2600);
    } catch (err) {
      toast(errMsg(err), 'error');
    }
  }, [projectId, members]);

  const removeMember = useCallback(async (userId: string) => {
    try {
      await api.projects.removeMember(projectId, userId);
      const name = members.find((m) => m.userId === userId)?.displayName ?? '';
      setMembers((list) => list.filter((m) => m.userId !== userId));
      toast(t('members.removed', { name }), 'success', 2600);
    } catch (err) {
      toast(errMsg(err), 'error');
    }
  }, [projectId, members]);

  return {
    members: displayMembers, membersStatus, reloadMembers: loadMembers, setMemberRole, removeMember,
    chat, chatStatus, reloadChat: loadChat, sendMessage, rtStatus, chatHasMore, loadOlderChat, loadingOlder, live: !!collab,
  };
}

export type TeamApi = ReturnType<typeof useTeam>;
