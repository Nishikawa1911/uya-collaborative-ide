import { useCallback, useState } from 'react';
import type { ProjectSummary } from '../../api/types';
import { api } from '../../api';
import { ApiError } from '../../api/types';
import { navigate, paths } from '../../app/router';
import { Alert, Button, EmptyState, Icon, Skeleton, Splitter } from '../../components/ui';
import { useT } from '../../i18n';
import { useAsync } from '../../lib/useAsync';
import { cx, safeStorage } from '../../lib/utils';
import { useCurrentUser } from '../../state/auth';
import { useCollabRefresh } from '../../collab/useCollab';
import { EditorPane } from './editor/EditorPane';
import { FileExplorer } from './explorer/FileExplorer';
import { BottomPanel } from './panels/BottomPanel';
import { TeamPanel } from './panels/TeamPanel';
import { TopBar } from './TopBar';
import { WorkspaceProvider, useWorkspace } from './WorkspaceContext';
import type { MobileView } from './useLayout';

/** Жоба жұмыс кеңістігі: жобаны жүктеп, WorkspaceProvider ішінде макетті көрсетеді. */
export function WorkspacePage({ projectId }: { projectId: string }) {
  const t = useT();
  const me = useCurrentUser();
  const state = useAsync(() => api.projects.get(projectId), [projectId]);
  // Баптау өзгерісі: толық қайта жүктемей (қойындылар сақталады), жергілікті патч ретінде қолданылады
  const [patch, setPatch] = useState<Partial<ProjectSummary>>({});
  const onProjectChanged = useCallback((p: Partial<ProjectSummary>) => setPatch((prev) => ({ ...prev, ...p })), []);

  if (state.loading) {
    return (
      <div className="ws ws--loading" aria-busy="true">
        <div className="topbar"><Skeleton height={22} width={220} /></div>
        <div className="ws__body">
          <div className="ws__sidebar" style={{ width: 260, padding: 14 }}><Skeleton height={16} width="70%" /></div>
          <div className="ws__center" />
        </div>
      </div>
    );
  }

  if (state.error || !state.data) {
    const notFound = state.error instanceof ApiError && (state.error.status === 404 || state.error.code === 'project.not_found' || state.error.status === 403);
    return (
      <div className="ws ws--center">
        <EmptyState
          icon={notFound ? 'search' : 'alert'}
          title={notFound ? t('ws.notFound') : t('ws.loadError')}
          text={notFound ? t('ws.notFoundText') : undefined}
          action={
            <div className="empty-state__buttons">
              {!notFound && <Button onClick={state.reload}>{t('common.retry')}</Button>}
              <Button variant="primary" onClick={() => navigate(paths.dashboard())}>{t('nav.toDashboard')}</Button>
            </div>
          }
        />
      </div>
    );
  }

  return (
    <WorkspaceProvider project={{ ...state.data, ...patch }} me={me} onProjectChanged={onProjectChanged}>
      <WorkspaceLayout />
    </WorkspaceProvider>
  );
}

const BANNER_KEY = 'uya.demoBanner.dismissed';

function WorkspaceLayout() {
  const t = useT();
  const { layout, isMobile, files, role } = useWorkspace();
  const collab = files.collab;
  useCollabRefresh(collab, ['status', 'role']);
  const [bannerHidden, setBannerHidden] = useState(() => safeStorage.get<boolean>(BANNER_KEY, false));
  const hideBanner = useCallback(() => { setBannerHidden(true); safeStorage.set(BANNER_KEY, true); }, []);

  return (
    <div className="ws" data-testid="workspace">
      <TopBar />
      {!bannerHidden && (
        <Alert kind="info" className="ws__banner" onDismiss={hideBanner} dismissLabel={t('ws.demoBannerDismiss')}>
          {t(collab ? 'ws.runBanner' : 'ws.demoBanner')}
        </Alert>
      )}
      {collab && collab.status !== 'connected' && collab.status !== 'kicked' && (
        <Alert kind="warning" className="ws__banner" data-testid="offline-banner">{t(collab.everConnected ? 'collab.offlineBanner' : 'collab.connectingBanner')}</Alert>
      )}
      {collab && role === 'viewer' && <Alert kind="info" className="ws__banner" data-testid="viewer-banner">{t('collab.viewerBanner')}</Alert>}
      {isMobile ? <MobileLayout /> : <DesktopLayout />}
    </div>
  );
}

function DesktopLayout() {
  const t = useT();
  const { layout } = useWorkspace();
  const bottomVisible = layout.showBottom;

  return (
    <div className="ws__body">
      {layout.showSidebar && (
        <>
          <aside className="ws__sidebar" style={{ width: layout.sidebarW }}><FileExplorer /></aside>
          <Splitter orientation="vertical" label={t('ws.resize')} onDelta={layout.resizeSidebar} />
        </>
      )}
      <div className="ws__center">
        {!(bottomVisible && layout.bottomMax) && <main className="ws__editor" aria-label={t('ws.panel.editor')}><EditorPane /></main>}
        {bottomVisible && (
          <>
            {!layout.bottomMax && <Splitter orientation="horizontal" label={t('ws.resize')} onDelta={layout.resizeBottom} />}
            <div className={cx('ws__bottom', layout.bottomMax && 'is-max')} style={layout.bottomMax ? undefined : { height: layout.bottomH }}><BottomPanel /></div>
          </>
        )}
      </div>
      {layout.showRight && (
        <>
          <Splitter orientation="vertical" label={t('ws.resize')} onDelta={layout.resizeRight} />
          <aside className="ws__right" style={{ width: layout.rightW }}><TeamPanel /></aside>
        </>
      )}
    </div>
  );
}

/** Тар экрандарда бір уақытта бір аймақ көрсетіледі; астыңғы навигация арқылы ауысады. */
function MobileLayout() {
  const t = useT();
  const { layout, files } = useWorkspace();
  const view = layout.mobileView;
  const tabs: Array<{ id: MobileView; label: string; icon: 'folder' | 'fileCode' | 'users' | 'terminal'; badge?: number }> = [
    { id: 'files', label: t('mobile.files'), icon: 'folder' },
    { id: 'editor', label: t('mobile.editor'), icon: 'fileCode', badge: files.dirtyIds.size || undefined },
    { id: 'team', label: t('mobile.team'), icon: 'users' },
    { id: 'console', label: t('mobile.console'), icon: 'terminal' },
  ];
  return (
    <>
      <div className="ws__mobile">
        {view === 'files' && <FileExplorer />}
        {view === 'editor' && <EditorPane />}
        {view === 'team' && <TeamPanel />}
        {view === 'console' && <BottomPanel />}
      </div>
      <nav className="mobile-nav" aria-label={t('ws.panel.editor')}>
        {tabs.map((tab) => (
          <button key={tab.id} type="button" className={cx('mobile-nav__item', view === tab.id && 'is-active')} aria-current={view === tab.id ? 'page' : undefined} onClick={() => layout.setMobileView(tab.id)}>
            <Icon name={tab.icon} size={19} />
            <span>{tab.label}</span>
            {tab.badge ? <i className="mobile-nav__badge" aria-hidden="true" /> : null}
          </button>
        ))}
      </nav>
    </>
  );
}
