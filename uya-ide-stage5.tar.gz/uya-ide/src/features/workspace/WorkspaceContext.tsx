import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api } from '../../api';
import type { ProjectSummary, Role, User } from '../../api/types';
import { navigate, paths } from '../../app/router';
import { useCollab, useCollabRefresh } from '../../collab/useCollab';
import { t } from '../../i18n';
import { toast } from '../../state/toasts';
import { useMediaQuery } from '../../lib/useMediaQuery';
import { useFiles, type FilesApi } from './useFiles';
import { useLayout, type LayoutApi } from './useLayout';
import { useRun, type RunApi } from './useRun';
import { useTeam, type TeamApi } from './useTeam';

export interface RevealRequest { nodeId: string; line: number; col: number; nonce: number }

interface Workspace {
  project: ProjectSummary;
  /** Баптаулар өзгергенде жоба мәліметін (атау, тілдер…) жаңартады; ашық қойындыларды жоғалтпайды. */
  updateProject: (patch: Partial<ProjectSummary>) => void;
  role: Role;
  canEdit: boolean;
  canRun: boolean;
  me: User;
  files: FilesApi;
  team: TeamApi;
  run: RunApi;
  layout: LayoutApi;
  isMobile: boolean;
  activePath: string | null;
  reveal: RevealRequest | null;
  revealAt: (nodeId: string, line: number, col: number) => void;
  /** Файлды ашып, мобильді көріністе редакторға ауысады */
  openFileInEditor: (id: string) => void;
  runFile: () => void;
  runProject: () => void;
}

const Ctx = createContext<Workspace | null>(null);

export function useWorkspace(): Workspace {
  const v = useContext(Ctx);
  if (!v) throw new Error('useWorkspace тек WorkspaceProvider ішінде қолданылады');
  return v;
}

const noop = () => {};

/**
 * Жұмыс кеңістігінің бүкіл клиенттік күйін біріктіреді. Компоненттер тек осы контекстті біледі,
 * ал деректер көзі (mock немесе нақты backend) `api/`, `realtime/`, `runner/` модульдерінде ауыстырылады.
 */
export function WorkspaceProvider({ project, me, onProjectChanged, children }: { project: ProjectSummary; me: User; onProjectChanged?: (patch: Partial<ProjectSummary>) => void; children: ReactNode }) {
  const collab = useCollab(project.id);
  useCollabRefresh(collab, ['role']);
  const role: Role = collab?.role ?? project.myRole; // рөл өзгерсе — бірден (WebSocket role.changed)
  const canEdit = role !== 'viewer';
  const canRun = canEdit; // спецификация 5.3: көрермен әдепкі бойынша іске қоса алмайды
  const isMobile = useMediaQuery('(max-width: 900px)');

  const layout = useLayout();
  const files = useFiles(project.id, canEdit, collab);
  const activePath = files.activeId ? files.pathOf(files.activeId) : null;
  const team = useTeam(project.id, me, activePath, collab, files.pathOf);

  // Қосылым оқиғалары: жоба өзгерді / қатысушы шығарылды / жоба жойылды
  useEffect(() => {
    if (!collab) return undefined;
    return collab.on((e) => {
      if (e.type === 'project') void api.projects.get(project.id).then((p) => onProjectChanged?.(p), () => {});
      if (e.type === 'kicked') {
        toast(t(e.reason === 'deleted' ? 'collab.kickedDeleted' : e.reason === 'session' ? 'collab.kickedSession' : 'collab.kickedRemoved'), 'warning', 5000);
        navigate(paths.dashboard());
      }
    });
  }, [collab, project.id, onProjectChanged]);

  // Presence: белсенді файл
  const { activeId: activeFileId } = files;
  useEffect(() => { collab?.setActiveFile(activeFileId); }, [collab, activeFileId, collab?.status]);

  const { activeId, pathOf, findByPath } = files;
  const getEntry = useCallback(() => {
    // Entry point — нақты бар файл болуы керек, әйтпесе қате ретінде көрсетеміз.
    return findByPath(project.entryPoint) ? project.entryPoint : '';
  }, [project.entryPoint, findByPath]);
  const getActive = useCallback(() => (activeId ? { id: activeId, path: pathOf(activeId) } : null), [activeId, pathOf]);
  const openPreviewTab = useCallback(() => { layout.openBottom('preview'); if (isMobile) layout.setMobileView('console'); }, [layout, isMobile]);
  const run = useRun(project.id, getEntry, getActive, openPreviewTab);

  const [reveal, setReveal] = useState<RevealRequest | null>(null);
  const revealAt = useCallback((nodeId: string, line: number, col: number) => {
    void files.openFile(nodeId);
    setReveal({ nodeId, line, col, nonce: Date.now() });
    layout.setMobileView('editor');
  }, [files, layout]);

  const openFileInEditor = useCallback((id: string) => {
    void files.openFile(id);
    layout.setMobileView('editor');
  }, [files, layout]);

  const runFile = useCallback(() => {
    layout.openBottom('output');
    if (isMobile) layout.setMobileView('console');
    void run.runFile();
  }, [layout, run, isMobile]);
  const runProject = useCallback(() => {
    layout.openBottom('output');
    if (isMobile) layout.setMobileView('console');
    void run.runProject();
  }, [layout, run, isMobile]);

  const value = useMemo<Workspace>(() => ({
    project, updateProject: onProjectChanged ?? noop, role, canEdit, canRun, me, files, team, run, layout, isMobile, activePath,
    reveal, revealAt, openFileInEditor, runFile, runProject,
  }), [project, onProjectChanged, role, canEdit, canRun, me, files, team, run, layout, isMobile, activePath, reveal, revealAt, openFileInEditor, runFile, runProject]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
