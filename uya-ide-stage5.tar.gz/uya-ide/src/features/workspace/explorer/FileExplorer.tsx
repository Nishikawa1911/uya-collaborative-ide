import { useEffect, useMemo, useRef, useState } from 'react';
import { ApiError, type FsNode } from '../../../api/types';
import { ConfirmDialog, EmptyState, Icon, IconButton, Input, Skeleton, Alert, Button, useContextMenu, type MenuItem } from '../../../components/ui';
import { useT } from '../../../i18n';
import { messageForError } from '../../../i18n/format';
import { cx, isValidFileName } from '../../../lib/utils';
import { toast } from '../../../state/toasts';
import { useWorkspace } from '../WorkspaceContext';
import { FileTypeIcon } from './FileTypeIcon';

type Editing =
  | { mode: 'create'; parentId: string | null; kind: FsNode['kind'] }
  | { mode: 'rename'; id: string }
  | null;

interface Row { node: FsNode; depth: number }

const collator = new Intl.Collator('kk', { numeric: true, sensitivity: 'base' });
const sortNodes = (a: FsNode, b: FsNode) => (a.kind === b.kind ? collator.compare(a.name, b.name) : a.kind === 'folder' ? -1 : 1);

export function FileExplorer() {
  const t = useT();
  const { files, team, me, canEdit, openFileInEditor } = useWorkspace();
  const { nodes, status, activeId, dirtyIds, byId } = files;

  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [focusId, setFocusId] = useState<string | null>(null);
  const [editing, setEditing] = useState<Editing>(null);
  const [filter, setFilter] = useState('');
  const [toDelete, setToDelete] = useState<FsNode | null>(null);
  const [deleting, setDeleting] = useState(false);
  const initialized = useRef(false);
  const treeRef = useRef<HTMLDivElement>(null);
  const menu = useContextMenu();

  // Бастапқыда түбірдегі қалталарды ашамыз
  useEffect(() => {
    if (status !== 'ready' || initialized.current) return;
    initialized.current = true;
    setExpanded(new Set(nodes.filter((n) => n.kind === 'folder' && n.parentId === null).map((n) => n.id)));
  }, [status, nodes]);

  const children = useMemo(() => {
    const map = new Map<string | null, FsNode[]>();
    for (const n of nodes) {
      const list = map.get(n.parentId) ?? [];
      list.push(n);
      map.set(n.parentId, list);
    }
    map.forEach((list) => list.sort(sortNodes));
    return map;
  }, [nodes]);

  const query = filter.trim().toLocaleLowerCase('kk');
  const rows = useMemo<Row[]>(() => {
    if (query) {
      return nodes
        .filter((n) => n.kind === 'file' && files.pathOf(n.id).toLocaleLowerCase('kk').includes(query))
        .sort((a, b) => collator.compare(files.pathOf(a.id), files.pathOf(b.id)))
        .map((node) => ({ node, depth: 0 }));
    }
    const out: Row[] = [];
    const walk = (parentId: string | null, depth: number) => {
      for (const node of children.get(parentId) ?? []) {
        out.push({ node, depth });
        if (node.kind === 'folder' && expanded.has(node.id)) walk(node.id, depth + 1);
      }
    };
    walk(null, 0);
    return out;
  }, [query, nodes, children, expanded, files]);

  // Басқа қатысушылардың белсенді файлдары (үлгі деректер): жол → қатысушылар
  const presence = useMemo(() => {
    const map = new Map<string, typeof team.members>();
    for (const m of team.members) {
      if (m.userId === me.id || !m.online || !m.activeFile) continue;
      map.set(m.activeFile, [...(map.get(m.activeFile) ?? []), m]);
    }
    return map;
  }, [team.members, me.id]);

  const focusRow = (id: string) => {
    setFocusId(id);
    requestAnimationFrame(() => treeRef.current?.querySelector<HTMLElement>(`[data-id="${CSS.escape(id)}"]`)?.focus());
  };

  const toggle = (id: string, open?: boolean) =>
    setExpanded((s) => {
      const next = new Set(s);
      if (open ?? !next.has(id)) next.add(id); else next.delete(id);
      return next;
    });

  /** Жаңа элемент қай қалтаға түседі: таңдалған қалта, таңдалған файлдың ата-ана қалтасы немесе түбір */
  const targetParent = (): string | null => {
    const sel = selectedId ? byId.get(selectedId) : undefined;
    if (!sel) return null;
    return sel.kind === 'folder' ? sel.id : sel.parentId;
  };

  const startCreate = (kind: FsNode['kind'], parentId: string | null = targetParent()) => {
    if (!canEdit) { toast(t('explorer.readOnly'), 'warning'); return; }
    setFilter('');
    if (parentId) toggle(parentId, true);
    setEditing({ mode: 'create', parentId, kind });
  };

  const startRename = (id: string) => {
    if (!canEdit) { toast(t('explorer.readOnly'), 'warning'); return; }
    setEditing({ mode: 'rename', id });
  };

  const askDelete = (node: FsNode) => {
    if (!canEdit) { toast(t('explorer.readOnly'), 'warning'); return; }
    setToDelete(node);
  };

  const activate = (node: FsNode) => {
    setSelectedId(node.id);
    setFocusId(node.id);
    if (node.kind === 'folder') toggle(node.id); else openFileInEditor(node.id);
  };

  const menuItems = (node: FsNode): MenuItem[] => {
    const ro = !canEdit;
    return [
      ...(node.kind === 'file'
        ? [{ id: 'open', label: t('common.edit'), icon: 'edit' as const, onSelect: () => openFileInEditor(node.id) }]
        : [
            { id: 'nf', label: t('explorer.newFileIn'), icon: 'filePlus' as const, disabled: ro, onSelect: () => startCreate('file', node.id) },
            { id: 'nd', label: t('explorer.newFolderIn'), icon: 'folderPlus' as const, disabled: ro, onSelect: () => startCreate('folder', node.id) },
          ]),
      { id: 'rename', label: t('explorer.rename'), icon: 'edit' as const, hint: 'F2', disabled: ro, separatorBefore: true, onSelect: () => startRename(node.id) },
      { id: 'delete', label: t('explorer.delete'), icon: 'trash' as const, hint: 'Del', danger: true, disabled: ro, onSelect: () => askDelete(node) },
    ];
  };

  const onTreeKeyDown = (e: React.KeyboardEvent) => {
    if (editing) return;
    const idx = rows.findIndex((r) => r.node.id === focusId);
    const row = rows[idx];
    const go = (i: number) => { const r = rows[Math.min(Math.max(i, 0), rows.length - 1)]; if (r) focusRow(r.node.id); };
    switch (e.key) {
      case 'ArrowDown': e.preventDefault(); go(idx + 1); break;
      case 'ArrowUp': e.preventDefault(); go(idx - 1); break;
      case 'Home': e.preventDefault(); go(0); break;
      case 'End': e.preventDefault(); go(rows.length - 1); break;
      case 'ArrowRight':
        if (row?.node.kind === 'folder') { e.preventDefault(); if (!expanded.has(row.node.id)) toggle(row.node.id, true); else go(idx + 1); }
        break;
      case 'ArrowLeft':
        if (row) {
          e.preventDefault();
          if (row.node.kind === 'folder' && expanded.has(row.node.id)) toggle(row.node.id, false);
          else if (row.node.parentId) focusRow(row.node.parentId);
        }
        break;
      case 'Enter': case ' ': if (row) { e.preventDefault(); activate(row.node); } break;
      case 'F2': if (row) { e.preventDefault(); startRename(row.node.id); } break;
      case 'Delete': if (row) { e.preventDefault(); askDelete(row.node); } break;
      case 'ContextMenu': case 'F10':
        if (row && (e.key === 'ContextMenu' || e.shiftKey)) {
          e.preventDefault();
          const rect = treeRef.current?.querySelector<HTMLElement>(`[data-id="${CSS.escape(row.node.id)}"]`)?.getBoundingClientRect();
          menu.open({ clientX: rect?.left ?? 0, clientY: (rect?.bottom ?? 0), preventDefault() {} }, menuItems(row.node));
        }
        break;
      default:
    }
  };

  /** Атауды тексереді және сақтайды. Қате болса, мәтінін қайтарады (инлайн көрсетіледі). */
  const commitName = async (name: string): Promise<string | null> => {
    const value = name.trim();
    if (!editing) return null;
    if (!isValidFileName(value)) return t('validation.invalidFileName');
    const parentId = editing.mode === 'create' ? editing.parentId : byId.get(editing.id)?.parentId ?? null;
    const clash = nodes.some((n) => n.parentId === parentId && n.id !== (editing.mode === 'rename' ? editing.id : '') && n.name.toLocaleLowerCase('kk') === value.toLocaleLowerCase('kk'));
    if (clash) return messageForError('file.exists');
    try {
      if (editing.mode === 'create') {
        const node = await files.createNode(parentId, value, editing.kind);
        setSelectedId(node.id);
        setFocusId(node.id);
      } else {
        await files.renameNode(editing.id, value);
      }
      setEditing(null);
      return null;
    } catch (err) {
      return messageForError(err instanceof ApiError ? err.code : 'unknown', err instanceof ApiError ? err.params : undefined);
    }
  };

  const confirmDelete = async () => {
    if (!toDelete) return;
    setDeleting(true);
    try {
      await files.deleteNode(toDelete.id);
      if (selectedId === toDelete.id) setSelectedId(null);
      setToDelete(null);
    } catch (err) {
      toast(messageForError(err instanceof ApiError ? err.code : 'unknown'), 'error');
    } finally {
      setDeleting(false);
    }
  };

  const createRowAt = editing?.mode === 'create' ? editing : null;
  const renderCreate = (depth: number) => (
    <NameRow key="__create" depth={depth} kind={createRowAt!.kind} initial="" onCommit={commitName} onCancel={() => setEditing(null)} placeholder={createRowAt!.kind === 'file' ? t('explorer.namePlaceholderFile') : t('explorer.namePlaceholderFolder')} />
  );

  // Жаңа элемент жолын дұрыс орынға қою (ата-ана қалтасының бірінші баласы немесе түбірдің басы)
  const items: Array<Row | 'create'> = [];
  if (!query) {
    if (createRowAt && createRowAt.parentId === null) items.push('create');
    rows.forEach((r) => {
      items.push(r);
      if (createRowAt && createRowAt.parentId === r.node.id && r.node.kind === 'folder') items.push('create');
    });
  } else {
    rows.forEach((r) => items.push(r));
  }
  const createDepth = createRowAt?.parentId ? (rows.find((r) => r.node.id === createRowAt.parentId)?.depth ?? 0) + 1 : 0;

  return (
    <section className="explorer" aria-label={t('explorer.title')}>
      <header className="panel-head">
        <h2 className="panel-head__title">{t('explorer.title')}</h2>
        <div className="panel-head__actions">
          <IconButton icon="filePlus" size="sm" label={t('explorer.newFile')} aria-disabled={!canEdit} onClick={() => startCreate('file')} />
          <IconButton icon="folderPlus" size="sm" label={t('explorer.newFolder')} aria-disabled={!canEdit} onClick={() => startCreate('folder')} />
          <IconButton icon="collapseAll" size="sm" label={t('explorer.collapseAll')} onClick={() => setExpanded(new Set())} />
          <IconButton icon="refresh" size="sm" label={t('explorer.refresh')} onClick={() => void files.reload()} />
        </div>
      </header>

      <div className="explorer__filter">
        <Input icon="search" aria-label={t('explorer.filter')} placeholder={t('explorer.filter')} value={filter} onChange={(e) => setFilter(e.target.value)} className="input--sm" />
      </div>

      {!canEdit && <p className="explorer__ro"><Icon name="lock" size={12} /> {t('explorer.readOnly')}</p>}

      {status === 'loading' && (
        <div className="explorer__skeleton" aria-busy="true">
          {[70, 52, 60, 44, 66, 38].map((w, i) => (
            <div key={i} style={{ marginLeft: i % 3 === 1 ? 18 : 0 }}><Skeleton height={18} width={`${w}%`} /></div>
          ))}
        </div>
      )}
      {status === 'error' && (
        <Alert kind="error" action={<Button size="sm" onClick={() => void files.reload()}>{t('common.retry')}</Button>}>{t('ws.loadError')}</Alert>
      )}

      {status === 'ready' && (
        nodes.length === 0 && !editing ? (
          <EmptyState icon="folder" title={t('explorer.empty')} action={canEdit ? <Button variant="primary" size="sm" icon="filePlus" onClick={() => startCreate('file', null)}>{t('explorer.emptyAction')}</Button> : undefined} />
        ) : (
          <div ref={treeRef} className="tree" role="tree" aria-label={t('explorer.title')} onKeyDown={onTreeKeyDown}
            onContextMenu={(e) => { if (e.target === e.currentTarget) { e.preventDefault(); setSelectedId(null); } }}>
            {items.map((item) => {
              if (item === 'create') return renderCreate(createDepth);
              const { node, depth } = item;
              const isFolder = node.kind === 'folder';
              if (editing?.mode === 'rename' && editing.id === node.id) {
                return <NameRow key={node.id} depth={depth} kind={node.kind} initial={node.name} onCommit={commitName} onCancel={() => { setEditing(null); focusRow(node.id); }} placeholder="" />;
              }
              const here = presence.get(files.pathOf(node.id));
              const isOpen = expanded.has(node.id);
              return (
                <div
                  key={node.id} data-id={node.id} role="treeitem" aria-level={depth + 1} aria-selected={selectedId === node.id}
                  aria-expanded={isFolder ? isOpen : undefined}
                  tabIndex={(focusId ?? rows[0]?.node.id) === node.id ? 0 : -1}
                  className={cx('tree__row', selectedId === node.id && 'is-selected', activeId === node.id && 'is-active')}
                  style={{ paddingLeft: 8 + depth * 14 }}
                  onClick={() => activate(node)}
                  onFocus={() => setFocusId(node.id)}
                  onContextMenu={(e) => { setSelectedId(node.id); menu.open(e, menuItems(node)); }}
                >
                  <span className="tree__chevron" aria-hidden="true">{isFolder && <Icon name={isOpen ? 'chevronDown' : 'chevronRight'} size={13} />}</span>
                  {isFolder ? <Icon name={isOpen ? 'folderOpen' : 'folder'} size={15} className="tree__folder" /> : <FileTypeIcon name={node.name} />}
                  <span className="tree__name">{node.name}</span>
                  {query && <span className="tree__path">{files.pathOf(node.id).split('/').slice(0, -1).join('/')}</span>}
                  {dirtyIds.has(node.id) && <span className="tree__dirty" role="img" aria-label={t('editor.unsaved')} title={t('editor.unsaved')} />}
                  {here && (
                    <span className="tree__presence" title={here.map((m) => `${m.displayName}: ${t('members.editing', { file: files.pathOf(node.id) })}`).join('\n')}>
                      {here.slice(0, 3).map((m) => <i key={m.userId} style={{ background: m.cursorColor }} />)}
                    </span>
                  )}
                  <button
                    type="button" className="tree__more" tabIndex={-1} aria-label={`${t('common.more')}: ${node.name}`}
                    onClick={(e) => { e.stopPropagation(); const r = e.currentTarget.getBoundingClientRect(); setSelectedId(node.id); menu.open({ clientX: r.left, clientY: r.bottom + 2, preventDefault() {} }, menuItems(node)); }}
                  >
                    <Icon name="more" size={14} />
                  </button>
                </div>
              );
            })}
            {query && rows.length === 0 && <p className="explorer__nomatch">{t('explorer.empty')}</p>}
          </div>
        )
      )}

      {menu.element}

      <ConfirmDialog
        open={toDelete != null} danger loading={deleting}
        title={t('explorer.deleteTitle', { name: toDelete?.name ?? '' })}
        text={toDelete?.kind === 'folder' ? t('explorer.deleteFolderText') : t('explorer.deleteFileText')}
        confirmLabel={t('explorer.delete')}
        onCancel={() => setToDelete(null)} onConfirm={() => void confirmDelete()}
      />
    </section>
  );
}

/** Атау енгізу жолы (жаңа файл/қалта немесе атын өзгерту). Enter — сақтау, Esc — болдырмау. */
function NameRow({ depth, kind, initial, placeholder, onCommit, onCancel }: {
  depth: number; kind: FsNode['kind']; initial: string; placeholder: string;
  onCommit: (name: string) => Promise<string | null>; onCancel: () => void;
}) {
  const [value, setValue] = useState(initial);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const done = useRef(false);

  useEffect(() => {
    const el = input.current;
    if (!el) return;
    el.focus();
    const dot = initial.lastIndexOf('.');
    el.setSelectionRange(0, dot > 0 ? dot : initial.length); // кеңейтілімсіз бөлігін таңдау
  }, [initial]);

  const submit = async () => {
    if (busy || done.current) return;
    if (!value.trim() || value.trim() === initial) { done.current = true; onCancel(); return; }
    setBusy(true);
    const err = await onCommit(value);
    setBusy(false);
    if (err) { setError(err); input.current?.focus(); } else done.current = true;
  };

  return (
    <div className="tree__row tree__row--edit" style={{ paddingLeft: 8 + depth * 14 }} role="treeitem" aria-level={depth + 1} aria-selected="false">
      <span className="tree__chevron" />
      {kind === 'folder' ? <Icon name="folder" size={15} className="tree__folder" /> : <FileTypeIcon name={value || initial || 'file.txt'} />}
      <input
        ref={input} className={cx('tree__input', error && 'is-invalid')} value={value} placeholder={placeholder} spellCheck={false}
        aria-label={placeholder || initial} aria-invalid={!!error} aria-describedby={error ? 'name-error' : undefined} disabled={busy}
        onChange={(e) => { setValue(e.target.value); setError(null); }}
        onKeyDown={(e) => {
          e.stopPropagation();
          if (e.key === 'Enter') { e.preventDefault(); void submit(); }
          if (e.key === 'Escape') { e.preventDefault(); done.current = true; onCancel(); }
        }}
        onBlur={() => { if (!done.current && !busy) { if (value.trim() && value.trim() !== initial && !error) void submit(); else { done.current = true; onCancel(); } } }}
      />
      {error && <div id="name-error" role="alert" className="tree__error">{error}</div>}
    </div>
  );
}
