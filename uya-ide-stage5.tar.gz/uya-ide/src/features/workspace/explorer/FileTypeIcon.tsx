import { Icon, type IconName } from '../../../components/ui';
import { languageMeta, languageOfFile } from '../../../lib/languages';

/** Файл атауына қарай белгіше мен түс (тіл түсі). Қалта үшін `folder` пайдаланыңыз. */
export function FileTypeIcon({ name, size = 15 }: { name: string; size?: number }) {
  const lang = languageOfFile(name);
  const icon: IconName =
    lang === 'json' ? 'fileJson'
    : lang === 'markdown' || lang === 'plaintext' ? 'fileText'
    : lang === 'sql' ? 'database'
    : lang === 'html' || lang === 'css' ? 'globe'
    : 'fileCode';
  const color = lang === 'plaintext' || lang === 'markdown' ? undefined : languageMeta[lang].color;
  return <Icon name={icon} size={size} style={color ? { color } : undefined} />;
}
