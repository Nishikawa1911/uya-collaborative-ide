import { useCallback, useEffect, useState } from 'react';
import { clamp, safeStorage } from '../../lib/utils';

export type BottomTab = 'terminal' | 'output' | 'preview' | 'sql' | 'problems';
export type RightTab = 'chat' | 'members';
export type MobileView = 'files' | 'editor' | 'team' | 'console';

interface Persisted {
  sidebarW: number; rightW: number; bottomH: number;
  showSidebar: boolean; showRight: boolean; showBottom: boolean;
  bottomMax: boolean; bottomTab: BottomTab; rightTab: RightTab;
}

const KEY = 'uya.layout.v1';
const LIMITS = { sidebarW: [180, 480], rightW: [260, 560], bottomH: [110, 720] } as const;
const defaults: Persisted = {
  sidebarW: 260, rightW: 340, bottomH: 250,
  showSidebar: true, showRight: true, showBottom: true,
  bottomMax: false, bottomTab: 'output', rightTab: 'chat',
};

/** Панельдердің өлшемі мен көрінуі (localStorage-те сақталады, бұзылған мән болса — әдепкіге оралады). */
export function useLayout() {
  const [state, setState] = useState<Persisted>(() => {
    const saved = safeStorage.get<Partial<Persisted>>(KEY, {});
    return {
      ...defaults, ...saved,
      sidebarW: clamp(Number(saved.sidebarW) || defaults.sidebarW, ...LIMITS.sidebarW),
      rightW: clamp(Number(saved.rightW) || defaults.rightW, ...LIMITS.rightW),
      bottomH: clamp(Number(saved.bottomH) || defaults.bottomH, ...LIMITS.bottomH),
    };
  });
  const [mobileView, setMobileView] = useState<MobileView>('editor');

  useEffect(() => { safeStorage.set(KEY, state); }, [state]);

  const patch = useCallback((p: Partial<Persisted>) => setState((s) => ({ ...s, ...p })), []);

  return {
    ...state,
    mobileView, setMobileView,
    resizeSidebar: (d: number) => setState((s) => ({ ...s, sidebarW: clamp(s.sidebarW + d, ...LIMITS.sidebarW) })),
    resizeRight: (d: number) => setState((s) => ({ ...s, rightW: clamp(s.rightW - d, ...LIMITS.rightW) })),
    resizeBottom: (d: number) => setState((s) => ({ ...s, bottomH: clamp(s.bottomH - d, ...LIMITS.bottomH), bottomMax: false })),
    toggleSidebar: () => setState((s) => ({ ...s, showSidebar: !s.showSidebar })),
    toggleRight: () => setState((s) => ({ ...s, showRight: !s.showRight })),
    toggleBottom: () => setState((s) => ({ ...s, showBottom: !s.showBottom })),
    toggleBottomMax: () => setState((s) => ({ ...s, bottomMax: !s.bottomMax, showBottom: true })),
    openBottom: (tab: BottomTab) => setState((s) => ({ ...s, showBottom: true, bottomTab: tab })),
    setBottomTab: (tab: BottomTab) => patch({ bottomTab: tab }),
    setRightTab: (tab: RightTab) => patch({ rightTab: tab, showRight: true }),
  };
}

export type LayoutApi = ReturnType<typeof useLayout>;
