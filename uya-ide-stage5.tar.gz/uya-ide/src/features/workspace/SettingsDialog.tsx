import { useEffect, useState } from 'react';
import { api } from '../../api';
import { ApiError, type LanguageId, type ProjectSettings, type Role } from '../../api/types';
import { navigate, paths } from '../../app/router';
import { Alert, Button, Checkbox, Field, Icon, Input, Modal, SegmentedControl, Skeleton, Textarea } from '../../components/ui';
import { useT } from '../../i18n';
import { messageForError } from '../../i18n/format';
import { languageMeta, selectableLanguages } from '../../lib/languages';
import { cx } from '../../lib/utils';
import { toast } from '../../state/toasts';
import { useWorkspace } from './WorkspaceContext';

const errText = (err: unknown) => messageForError(err instanceof ApiError ? err.code : 'unknown', err instanceof ApiError ? err.params : undefined);

/** «Жоба баптаулары»: тек иесіне. Баптаулар сервердегі project_settings кестесінде сақталады. */
export function SettingsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useT();
  const { project, updateProject } = useWorkspace();
  const [form, setForm] = useState<ProjectSettings | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirm, setConfirm] = useState('');
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    setForm(null); setLoadError(null); setError(null); setConfirm('');
    api.projects.getSettings(project.id).then((s) => { if (alive) setForm(s); }, (e) => { if (alive) setLoadError(errText(e)); });
    return () => { alive = false; };
  }, [open, project.id]);

  const set = <K extends keyof ProjectSettings>(k: K, v: ProjectSettings[K]) => setForm((f) => (f ? { ...f, [k]: v } : f));
  const toggleLang = (l: LanguageId) => setForm((f) => {
    if (!f) return f;
    return { ...f, languages: f.languages.includes(l) ? f.languages.filter((x) => x !== l) : [...f.languages, l] };
  });

  const save = async () => {
    if (!form) return;
    setSaving(true); setError(null);
    try {
      const s = await api.projects.updateSettings(project.id, {
        name: form.name, description: form.description, languages: form.languages, entryPoint: form.entryPoint,
        joinRole: form.joinRole, inviteEnabled: form.inviteEnabled, maxMembers: form.maxMembers,
      });
      setForm(s);
      updateProject({ name: s.name, description: s.description, languages: s.languages, entryPoint: s.entryPoint });
      toast(t('settings.saved'), 'success');
      onClose();
    } catch (e) {
      setError(errText(e));
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    setDeleting(true); setError(null);
    try {
      await api.projects.remove(project.id, confirm);
      toast(t('settings.deleted'), 'success');
      navigate(paths.dashboard());
    } catch (e) {
      setError(errText(e));
      setDeleting(false);
    }
  };

  return (
    <Modal
      open={open} title={t('settings.title')} onClose={onClose} width={560} locked={saving || deleting}
      footer={<>
        <Button variant="ghost" onClick={onClose} disabled={saving || deleting}>{t('common.cancel')}</Button>
        <Button variant="primary" icon="save" loading={saving} disabled={!form || deleting} onClick={() => void save()}>{t('common.save')}</Button>
      </>}
    >
      {loadError && <Alert kind="error">{loadError}</Alert>}
      {!form && !loadError && <div className="settings__skeleton"><Skeleton height={36} /><Skeleton height={72} /><Skeleton height={36} /></div>}
      {form && (
        <div className="form settings">
          {error && <Alert kind="error">{error}</Alert>}
          <Field label={t('create.name')} htmlFor="set-name">
            <Input id="set-name" maxLength={80} autoComplete="off" value={form.name} onChange={(e) => set('name', e.target.value)} />
          </Field>
          <Field label={t('create.description')} htmlFor="set-desc" optional>
            <Textarea id="set-desc" rows={2} maxLength={300} value={form.description} onChange={(e) => set('description', e.target.value)} />
          </Field>
          <fieldset className="fieldset">
            <legend className="field__label">{t('create.languages')}</legend>
            <div className="chip-grid" role="group" aria-label={t('create.languages')}>
              {selectableLanguages.map((l) => {
                const on = form.languages.includes(l);
                return (
                  <button key={l} type="button" className={cx('chip-toggle', on && 'is-on')} aria-pressed={on} onClick={() => toggleLang(l)}>
                    <span className="lang-chip__dot" style={{ background: languageMeta[l].color }} aria-hidden="true" />
                    {t(languageMeta[l].labelKey)}
                    {on && <Icon name="check" size={13} />}
                  </button>
                );
              })}
            </div>
          </fieldset>
          <Field label={t('create.entryPoint')} htmlFor="set-entry" hint={t('create.entryPointHint')}>
            <Input id="set-entry" icon="fileCode" className="mono" spellCheck={false} autoComplete="off" value={form.entryPoint} onChange={(e) => set('entryPoint', e.target.value)} />
          </Field>
          <div className="field">
            <span className="field__label">{t('create.joinRole')}</span>
            <SegmentedControl
              label={t('create.joinRole')} value={form.joinRole} onChange={(v: Exclude<Role, 'owner'>) => set('joinRole', v)}
              items={[{ id: 'editor', label: t('role.editor'), icon: 'edit' }, { id: 'viewer', label: t('role.viewer'), icon: 'eye' }]}
            />
          </div>
          <Checkbox
            label={t('settings.inviteEnabled')} checked={form.inviteEnabled}
            onChange={(e) => set('inviteEnabled', e.target.checked)}
          />
          <Field label={t('settings.maxMembers')} htmlFor="set-max">
            <Input id="set-max" type="number" min={1} max={500} value={String(form.maxMembers)} onChange={(e) => set('maxMembers', Number(e.target.value))} />
          </Field>

          <section className="danger-zone" aria-labelledby="danger-title">
            <h3 id="danger-title"><Icon name="alert" size={15} /> {t('settings.danger')}</h3>
            <p>{t('settings.deleteText')}</p>
            <Field label={t('settings.confirmLabel', { name: project.name })} htmlFor="set-confirm">
              <Input id="set-confirm" autoComplete="off" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
            </Field>
            <Button variant="danger" icon="trash" loading={deleting} disabled={confirm !== project.name || saving} onClick={() => void remove()}>
              {t('settings.delete')}
            </Button>
          </section>
        </div>
      )}
    </Modal>
  );
}
