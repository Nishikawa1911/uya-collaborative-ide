import { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Button, Icon, IconButton, Tabs } from '../../../components/ui';
import { useT } from '../../../i18n';
import { formatTime } from '../../../i18n/format';
import { languageOfFile } from '../../../lib/languages';
import { cx } from '../../../lib/utils';
import { findProblems, type Problem } from '../problems';
import { useWorkspace } from '../WorkspaceContext';

/** Төменгі панель: Терминал, Нәтиже, Қателер. Үш көрініс те DOM-да қалады (күй жоғалмауы үшін). */
export function BottomPanel() {
  const t = useT();
  const { layout, files, run, activePath } = useWorkspace();
  const tab = layout.bottomTab;

  const code = files.activeId ? files.buffers[files.activeId]?.draft : undefined;
  const lang = files.activeId ? languageOfFile(files.byId.get(files.activeId)?.name ?? '') : 'plaintext';
  const problems = useMemo(() => (code != null ? findProblems(code, lang) : []), [code, lang]);
  const errors = problems.filter((p) => p.severity === 'error').length;

  const [termClear, setTermClear] = useState(0);
  const clear = () => { if (tab === 'output') run.clear(); if (tab === 'terminal') setTermClear((n) => n + 1); };

  return (
    <section className="bottom" aria-label={t('ws.panel.bottom')}>
      <Tabs
        label={t('ws.panel.bottom')} idPrefix="bottom" variant="underline" value={tab} onChange={layout.setBottomTab}
        items={[
          { id: 'terminal', label: t('panel.terminal'), icon: 'terminal' },
          { id: 'output', label: t('panel.output'), icon: 'play', count: run.lines.filter((l) => l.src !== 'sql').length || undefined, badgeTone: 'neutral' },
          { id: 'preview', label: t('panel.preview'), icon: 'globe' },
          { id: 'sql', label: t('panel.sql'), icon: 'database' },
          { id: 'problems', label: t('panel.problems'), icon: 'bug', count: problems.length || undefined, badgeTone: errors ? 'danger' : 'warning' },
        ]}
        trailing={
          <>
            {tab !== 'problems' && <IconButton icon="eraser" size="sm" label={t('panel.clear')} onClick={clear} />}
            <IconButton icon={layout.bottomMax ? 'minimize' : 'maximize'} size="sm" label={layout.bottomMax ? t('panel.restore') : t('panel.maximize')} onClick={layout.toggleBottomMax} />
            <IconButton icon="close" size="sm" label={t('panel.collapse')} onClick={layout.toggleBottom} />
          </>
        }
      />
      <div className="bottom__body">
        <div role="tabpanel" id="bottom-panel-terminal" aria-labelledby="bottom-terminal" hidden={tab !== 'terminal'} className="bottom__view"><TerminalView clearSignal={termClear} /></div>
        <div role="tabpanel" id="bottom-panel-output" aria-labelledby="bottom-output" hidden={tab !== 'output'} className="bottom__view"><OutputView /></div>
        <div role="tabpanel" id="bottom-panel-preview" aria-labelledby="bottom-preview" hidden={tab !== 'preview'} className="bottom__view"><PreviewView active={tab === 'preview'} /></div>
        <div role="tabpanel" id="bottom-panel-sql" aria-labelledby="bottom-sql" hidden={tab !== 'sql'} className="bottom__view"><SqlView /></div>
        <div role="tabpanel" id="bottom-panel-problems" aria-labelledby="bottom-problems" hidden={tab !== 'problems'} className="bottom__view"><ProblemsView problems={problems} hasFile={!!activePath} /></div>
      </div>
    </section>
  );
}

/* ───────── Нәтиже (терминал: stdout / stderr / build, шығу коды, Stop) ───────── */
function RunStatusBar() {
  const t = useT();
  const { run } = useWorkspace();
  const a = run.active;
  if (!a) return null;
  const text = a.status === 'queued' ? t('run.queued', { n: a.queuePosition ?? 1 }) : a.phase === 'compile' ? t('run.compiling') : t('run.running');
  return (
    <div className="runbar" role="status" data-testid="run-status" data-status={a.status}>
      <span className="runbar__spin" aria-hidden="true" />
      <span>{text}</span>
      <Button size="sm" variant="danger" icon="stop" onClick={() => void run.stop()} data-testid="run-stop-panel">{t('run.stop')}</Button>
    </div>
  );
}

function OutputView() {
  const t = useT();
  const { run } = useWorkspace();
  const end = useRef<HTMLDivElement>(null);
  const lines = run.lines.filter((l) => l.src !== 'sql');
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [lines.length]);

  const unavailable = run.runtime && !run.runtime.available ? t('run.runtimeBanner.unavailable') : run.runtimeError ? t('errors.run.unavailable') : null;
  const off = run.runtime?.available ? run.runtime.languages.filter((l) => !l.enabled) : [];
  return (
    <>
      {unavailable && <Alert kind="warning" className="term__banner" data-testid="runtime-unavailable">{unavailable}</Alert>}
      {off.length > 0 && <p className="bottom__note" data-testid="runtime-disabled">{off.map((l) => t('run.language.disabled', { language: l.label, reason: l.reason ?? '' })).join(' · ')}</p>}
      <RunStatusBar />
      {lines.length === 0 ? <p className="bottom__empty">{t('output.empty')}</p> : (
        <div className="output" role="log" aria-live="polite" aria-label={t('panel.output')} tabIndex={0} data-testid="run-output">
          {lines.map((l) => (
            <div key={l.id} className={cx('output__line', `output__line--${l.kind}`)} data-kind={l.kind}>
              <time dateTime={l.at}>{formatTime(l.at)}</time>
              <span>{l.text}</span>
            </div>
          ))}
          <div ref={end} />
        </div>
      )}
      <details className="stdin">
        <summary>{t('run.stdin')}</summary>
        <textarea className="stdin__area" value={run.stdin} onChange={(e) => run.setStdin(e.target.value)} placeholder={t('run.stdinHint')} aria-label={t('run.stdin')} rows={2} maxLength={65536} spellCheck={false} data-testid="run-stdin" />
      </details>
    </>
  );
}

/* ───────── Веб-алдын ала қарау (оқшауланған iframe) ───────── */
interface ConsoleMsg { id: number; level: string; text: string }
function PreviewView({ active }: { active: boolean }) {
  const t = useT();
  const { run } = useWorkspace();
  const frame = useRef<HTMLIFrameElement>(null);
  const [logs, setLogs] = useState<ConsoleMsg[]>([]);
  const seq = useRef(0);
  const p = run.preview;

  useEffect(() => { setLogs([]); }, [p.nonce]);
  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      if (e.source !== frame.current?.contentWindow) return; // тек біздің iframe-ден
      const d = e.data as { uya?: string; level?: string; text?: string } | null;
      if (d?.uya !== 'preview-console' || typeof d.text !== 'string') return;
      setLogs((l) => [...l.slice(-199), { id: seq.current++, level: String(d.level ?? 'log'), text: d.text!.slice(0, 2000) }]);
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, []);

  return (
    <div className="preview" data-active={active}>
      <div className="preview__bar">
        <Icon name="globe" size={14} />
        <span className="preview__title">{p.result ? t('preview.entry', { entry: p.result.entry }) : t('preview.title')}</span>
        <IconButton icon="refresh" size="sm" label={t('preview.refresh')} onClick={() => void run.openPreview(p.result?.entry)} data-testid="preview-refresh" />
      </div>
      {p.error && <Alert kind="error" className="term__banner">{p.error}</Alert>}
      {p.loading && <p className="bottom__empty">{t('preview.loading')}</p>}
      {!p.result && !p.loading && !p.error && <p className="bottom__empty">{t('preview.empty')}</p>}
      {p.result && (
        <>
          {(p.result.external.length > 0 || p.result.missing.length > 0) && (
            <p className="bottom__note">
              {p.result.external.length > 0 && t('preview.external', { list: p.result.external.join(', ') })} {p.result.missing.length > 0 && t('preview.missing', { list: p.result.missing.join(', ') })}
            </p>
          )}
          {/* sandbox="allow-scripts" (allow-same-origin ЖОҚ): бөтен origin, cookie/API/parent DOM-ға қолжетімділік жоқ; CSP желіні жабады */}
          <iframe
            key={p.nonce} ref={frame} className="preview__frame" title={t('preview.title')} data-testid="preview-frame"
            sandbox="allow-scripts" referrerPolicy="no-referrer" srcDoc={p.result.html}
          />
          <details className="preview__console" open={logs.length > 0}>
            <summary>{t('preview.console')} ({logs.length})</summary>
            <div className="output" data-testid="preview-console">
              {logs.map((l) => <div key={l.id} className={cx('output__line', l.level === 'error' ? 'output__line--error' : l.level === 'warn' ? 'output__line--warning' : 'output__line--info')}><span>{l.text}</span></div>)}
            </div>
          </details>
          <p className="bottom__note">{t('preview.sandboxNote')}</p>
        </>
      )}
    </div>
  );
}

/* ───────── SQL ойын алаңы ───────── */
function SqlView() {
  const t = useT();
  const { run, canRun } = useWorkspace();
  const [sql, setSql] = useState('');
  const lines = run.lines.filter((l) => l.src === 'sql');
  const busy = run.running === 'sql';
  const go = () => { if (sql.trim() && !run.active) void run.runSql(sql); };
  return (
    <div className="sqlpane">
      <div className="sqlpane__editor">
        <textarea
          className="sqlpane__area" value={sql} onChange={(e) => setSql(e.target.value)} spellCheck={false} placeholder={t('sql.placeholder')}
          aria-label={t('sql.inputLabel')} data-testid="sql-input" maxLength={100000}
          onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); go(); } }}
        />
        <div className="sqlpane__actions">
          <Button size="sm" variant="primary" icon="play" loading={busy} disabled={!canRun || !sql.trim() || !!run.active || !run.langState('query.sql').ok}
            title={run.langState('query.sql').ok ? undefined : run.langState('query.sql').reason} onClick={go} data-testid="sql-run">{t('sql.run')}</Button>
          {busy && <Button size="sm" variant="danger" icon="stop" onClick={() => void run.stop()}>{t('run.stop')}</Button>}
          <span className="sqlpane__note">{t('sql.note')}</span>
        </div>
      </div>
      <div className="output" role="log" aria-label={t('sql.title')} data-testid="sql-output">
        {lines.length === 0 ? <p className="bottom__empty">{t('sql.empty')}</p> : lines.map((l) => (
          <div key={l.id} className={cx('output__line', `output__line--${l.kind}`)}><span>{l.text}</span></div>
        ))}
      </div>
    </div>
  );
}

/* ───────── Қателер ───────── */
function ProblemsView({ problems, hasFile }: { problems: Problem[]; hasFile: boolean }) {
  const t = useT();
  const { files, revealAt } = useWorkspace();
  const sevIcon = { error: 'error', warning: 'warning', info: 'info' } as const;

  return (
    <div className="problems">
      <p className="problems__hint"><Icon name="info" size={12} /> {t('problems.hint')}</p>
      {!hasFile || problems.length === 0 ? (
        <p className="bottom__empty">{hasFile ? t('problems.empty') : t('editor.noFile')}</p>
      ) : (
        <ul className="problems__list" aria-label={t('problems.count', { n: problems.length })}>
          {problems.map((p) => (
            <li key={p.id}>
              <button type="button" className="problem" onClick={() => files.activeId && revealAt(files.activeId, p.line, p.col)}>
                <Icon name={sevIcon[p.severity]} size={14} className={`problem__icon problem__icon--${p.severity}`} />
                <span className="problem__msg">{p.message}</span>
                <span className="problem__pos">{t('problems.at', { line: p.line, col: p.col })}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ───────── Терминал (жергілікті, тек интерфейсті тексеру үшін) ───────── */
interface TermLine { id: number; kind: 'in' | 'out' | 'err'; text: string }

function TerminalView({ clearSignal }: { clearSignal: number }) {
  const t = useT();
  const { project, files } = useWorkspace();
  const [lines, setLines] = useState<TermLine[]>([]);
  const [value, setValue] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [hIdx, setHIdx] = useState<number | null>(null);
  const seq = useRef(0);
  const box = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);
  const prompt = `${project.name.length > 18 ? project.id : project.name}:~$`;

  const add = (kind: TermLine['kind'], text: string) => setLines((l) => [...l, { id: seq.current++, kind, text }]);

  useEffect(() => { add('out', t('terminal.help')); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (clearSignal) setLines([]); }, [clearSignal]);
  useEffect(() => { const el = box.current; if (el) el.scrollTop = el.scrollHeight; }, [lines.length]);

  const exec = (raw: string) => {
    const cmd = raw.trim();
    add('in', `${prompt} ${raw}`);
    if (!cmd) return;
    setHistory((h) => [...h, cmd]);
    const [name, ...args] = cmd.split(/\s+/);
    switch (name) {
      case 'help': add('out', t('terminal.help')); break;
      case 'clear': setLines([]); break;
      case 'pwd': add('out', `/workspace/${project.id}`); break;
      case 'date': add('out', new Date().toString()); break;
      case 'echo': add('out', args.join(' ')); break;
      case 'ls': {
        const target = args[0] ? files.findByPath(args[0].replace(/\/$/, '')) : null;
        if (args[0] && !target) { add('err', `ls: ${t('terminal.noSuchPath', { path: args[0] })}`); break; }
        if (target?.kind === 'file') { add('out', target.name); break; }
        const parent = target?.id ?? null;
        const list = files.nodes.filter((n) => n.parentId === parent).sort((a, b) => (a.kind === b.kind ? a.name.localeCompare(b.name, 'kk') : a.kind === 'folder' ? -1 : 1));
        add('out', list.length ? list.map((n) => (n.kind === 'folder' ? `${n.name}/` : n.name)).join('   ') : '—');
        break;
      }
      default: add('err', t('terminal.unknown', { cmd: name }));
    }
  };

  const onKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') { exec(value); setValue(''); setHIdx(null); }
    else if (e.key === 'ArrowUp' && history.length) {
      e.preventDefault();
      const i = hIdx == null ? history.length - 1 : Math.max(0, hIdx - 1);
      setHIdx(i); setValue(history[i]);
    } else if (e.key === 'ArrowDown' && hIdx != null) {
      e.preventDefault();
      const i = hIdx + 1;
      if (i >= history.length) { setHIdx(null); setValue(''); } else { setHIdx(i); setValue(history[i]); }
    } else if (e.key === 'l' && e.ctrlKey) { e.preventDefault(); setLines([]); }
  };

  return (
    <div className="term" ref={box} onClick={() => input.current?.focus()}>
      <Alert kind="warning" className="term__banner">{t('terminal.notConnected')}</Alert>
      {lines.map((l) => <div key={l.id} className={cx('term__line', `term__line--${l.kind}`)}>{l.text}</div>)}
      <label className="term__input-row">
        <span className="term__prompt" aria-hidden="true">{prompt}</span>
        <input
          ref={input} className="term__input" value={value} spellCheck={false} autoComplete="off" autoCapitalize="off"
          aria-label={t('terminal.inputLabel')} placeholder={t('terminal.prompt')}
          onChange={(e) => setValue(e.target.value)} onKeyDown={onKey}
        />
      </label>
    </div>
  );
}
