import { useState } from 'react';
import type { ProjectMember } from '../../../api/types';
import { Alert, Avatar, Button, ConfirmDialog, Icon, IconButton, RoleBadge, Skeleton, useContextMenu } from '../../../components/ui';
import { useT } from '../../../i18n';
import { useWorkspace } from '../WorkspaceContext';

/** Қатысушылар мен онлайн күйі. Басқа қатысушылардың онлайн күйі — үлгі деректер (демо клиент). */
export function MembersPanel() {
  const t = useT();
  const { team, me, role } = useWorkspace();
  const [toRemove, setToRemove] = useState<ProjectMember | null>(null);
  const menu = useContextMenu();
  const isOwner = role === 'owner';

  const online = team.members.filter((m) => m.online);
  const offline = team.members.filter((m) => !m.online);

  const actions = (m: ProjectMember) => [
    { id: 'editor', label: t('role.editor'), icon: 'edit' as const, checked: m.role === 'editor', onSelect: () => void team.setMemberRole(m.userId, 'editor') },
    { id: 'viewer', label: t('role.viewer'), icon: 'eye' as const, checked: m.role === 'viewer', onSelect: () => void team.setMemberRole(m.userId, 'viewer') },
    { id: 'remove', label: t('members.remove'), icon: 'userPlus' as const, danger: true, separatorBefore: true, onSelect: () => setToRemove(m) },
  ];

  const row = (m: ProjectMember) => {
    const self = m.userId === me.id;
    const manageable = isOwner && m.role !== 'owner' && !self;
    return (
      <li key={m.userId} className="member">
        <Avatar person={m} size={34} presence={m.online ? 'online' : 'offline'} />
        <div className="member__main">
          <div className="member__name">
            <span className="member__cursor" style={{ background: m.cursorColor }} aria-hidden="true" />
            <strong>{m.displayName}</strong>
            {self && <span className="member__you">({t('members.you')})</span>}
          </div>
          <div className="member__sub">
            {m.online
              ? (m.activeFile
                ? <><Icon name="edit" size={11} /> <span className="member__file" title={m.activeFile}>{t('members.editing', { file: m.activeFile })}</span></>
                : t('members.idle'))
              : <span>@{m.username}</span>}
          </div>
        </div>
        <RoleBadge role={m.role} />
        {manageable && (
          <IconButton
            icon="more" size="sm" label={`${t('members.changeRole')}: ${m.displayName}`}
            onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); menu.open({ clientX: r.right - 200, clientY: r.bottom + 2, preventDefault() {} }, actions(m)); }}
          />
        )}
      </li>
    );
  };

  return (
    <div className="members">
      {team.live ? <p className="members__hint">{t('members.liveHint')}</p> : <Alert kind="info" className="chat__notice">{t('members.demoNotice')}</Alert>}
      {!isOwner && <p className="members__hint"><Icon name="lock" size={12} /> {t('members.ownerOnly')}</p>}

      {team.membersStatus === 'loading' && (
        <div className="members__skeleton" aria-busy="true">
          {[0, 1, 2, 3].map((i) => <div key={i} className="chat__sk-row"><Skeleton height={34} width={34} radius={17} /><div><Skeleton height={12} width={110} /><div style={{ height: 6 }} /><Skeleton height={10} width={150} /></div></div>)}
        </div>
      )}
      {team.membersStatus === 'error' && <Alert kind="error" action={<Button size="sm" onClick={() => void team.reloadMembers()}>{t('common.retry')}</Button>}>{t('ws.loadError')}</Alert>}

      {team.membersStatus === 'ready' && (
        <>
          <h3 className="members__group">{t('members.online')} <span>{online.length}</span></h3>
          <ul className="members__list" aria-label={t('members.online')}>{online.map(row)}</ul>
          {offline.length > 0 && (
            <>
              <h3 className="members__group">{t('members.offline')} <span>{offline.length}</span></h3>
              <ul className="members__list members__list--offline" aria-label={t('members.offline')}>{offline.map(row)}</ul>
            </>
          )}
        </>
      )}

      {menu.element}
      <ConfirmDialog
        open={toRemove != null} danger
        title={t('members.removeTitle', { name: toRemove?.displayName ?? '' })} text={t('members.removeText')}
        confirmLabel={t('members.remove')}
        onCancel={() => setToRemove(null)}
        onConfirm={() => { const m = toRemove!; setToRemove(null); void team.removeMember(m.userId); }}
      />
    </div>
  );
}
