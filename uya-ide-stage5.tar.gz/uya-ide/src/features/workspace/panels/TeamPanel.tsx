import { Tabs } from '../../../components/ui';
import { useT } from '../../../i18n';
import { useWorkspace } from '../WorkspaceContext';
import { ChatPanel } from './ChatPanel';
import { MembersPanel } from './MembersPanel';

/** Оң панель: «Командалық чат» және «Қатысушылар» қойындылары. */
export function TeamPanel() {
  const t = useT();
  const { layout, team } = useWorkspace();
  const onlineCount = team.members.filter((m) => m.online).length;
  const tab = layout.rightTab;

  return (
    <section className="team" aria-label={t('ws.panel.collab')}>
      <Tabs
        label={t('ws.panel.collab')} idPrefix="team" variant="underline" value={tab} onChange={layout.setRightTab}
        items={[
          { id: 'chat', label: t('chat.title'), icon: 'chat' },
          { id: 'members', label: t('members.title'), icon: 'users', count: onlineCount, badgeTone: 'neutral' },
        ]}
      />
      <div className="team__body" role="tabpanel" id={`team-panel-${tab}`} aria-labelledby={`team-${tab}`}>
        {tab === 'chat' ? <ChatPanel /> : <MembersPanel />}
      </div>
    </section>
  );
}
