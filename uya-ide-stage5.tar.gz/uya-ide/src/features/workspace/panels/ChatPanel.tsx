import { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Avatar, Button, Icon, Skeleton } from '../../../components/ui';
import { useT } from '../../../i18n';
import { formatDate, formatTime } from '../../../i18n/format';
import { cx } from '../../../lib/utils';
import { useWorkspace } from '../WorkspaceContext';

const GROUP_MS = 5 * 60_000;
const sameDay = (a: string, b: string) => new Date(a).toDateString() === new Date(b).toDateString();

/** Командалық чат. Прототипте хабарламалар серверге жіберілмейді (`local` белгісі) — нақты уақыт клиенті қосылғанда ауыстырылады. */
export function ChatPanel() {
  const t = useT();
  const { team, me } = useWorkspace();
  const [text, setText] = useState('');
  const log = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const offline = team.rtStatus !== 'connected';

  const people = useMemo(() => new Map(team.members.map((m) => [m.userId, m])), [team.members]);

  useEffect(() => {
    const el = log.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [team.chat.length, team.chatStatus]);

  const send = () => {
    if (!text.trim()) return;
    if (!team.sendMessage(text)) return; // жіберілмесе, мәтін жоғалмайды
    setText('');
    if (input.current) input.current.style.height = '';
  };

  const grow = (el: HTMLTextAreaElement) => { el.style.height = 'auto'; el.style.height = `${Math.min(el.scrollHeight, 120)}px`; };

  return (
    <div className="chat">
      {!team.live && <Alert kind="info" className="chat__notice">{t('chat.demoNotice')}</Alert>}
      {team.live && offline && <Alert kind="warning" className="chat__notice" data-testid="chat-offline">{t('chat.reconnecting')}</Alert>}

      <div className="chat__log" ref={log} role="log" aria-live="polite" aria-label={t('chat.title')} tabIndex={0}>
        {team.chatStatus === 'loading' && (
          <div className="chat__skeleton" aria-busy="true">
            {[0, 1, 2].map((i) => <div key={i} className="chat__sk-row"><Skeleton height={28} width={28} radius={14} /><div><Skeleton height={12} width={90} /><div style={{ height: 6 }} /><Skeleton height={14} width={`${150 + i * 30}px`} /></div></div>)}
          </div>
        )}
        {team.chatStatus === 'error' && <Alert kind="error" action={<Button size="sm" onClick={() => void team.reloadChat()}>{t('common.retry')}</Button>}>{t('ws.loadError')}</Alert>}
        {team.chatStatus === 'ready' && team.chat.length === 0 && (
          <p className="chat__empty"><Icon name="chat" size={20} /><br />{t('chat.empty')}</p>
        )}

        {team.chatHasMore && (
          <div className="chat__more"><Button size="sm" onClick={() => void team.loadOlderChat()} disabled={team.loadingOlder}>{t('chat.older')}</Button></div>
        )}
        {team.chat.map((m, i) => {
          const prev = team.chat[i - 1];
          const newDay = !prev || !sameDay(prev.createdAt, m.createdAt);
          const grouped = !newDay && prev.userId === m.userId && new Date(m.createdAt).getTime() - new Date(prev.createdAt).getTime() < GROUP_MS;
          const author = m.userId === me.id ? { ...me } : people.get(m.userId) ?? (m.authorName ? { displayName: m.authorName, avatarColor: '#7a6ff0' } : undefined);
          const mine = m.userId === me.id;
          return (
            <div key={m.id}>
              {newDay && <div className="chat__day"><span>{sameDay(m.createdAt, new Date().toISOString()) ? t('chat.today') : formatDate(m.createdAt)}</span></div>}
              <div className={cx('msg', mine && 'msg--mine', grouped && 'msg--grouped')}>
                <div className="msg__avatar">{!grouped && author && <Avatar person={author} size={28} />}</div>
                <div className="msg__main">
                  {!grouped && (
                    <div className="msg__head">
                      <strong>{author?.displayName ?? '—'}</strong>
                      <time dateTime={m.createdAt}>{formatTime(m.createdAt)}</time>
                    </div>
                  )}
                  <p className="msg__body" data-msg-id={m.id}>{m.body}</p>
                  {m.state === 'sending' && <span className="msg__local"><Icon name="clock" size={11} /> {t('chat.sending')}</span>}
                  {m.state === 'failed' && <span className="msg__local" role="alert">{t('chat.failed')}</span>}
                  {m.local && <span className="msg__local" title={t('chat.local')}><Icon name="clock" size={11} /> {t('chat.local')}</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <form className="chat__composer" onSubmit={(e) => { e.preventDefault(); send(); }}>
        <textarea
          ref={input} rows={1} value={text} placeholder={t('chat.placeholder')} aria-label={t('chat.placeholder')} maxLength={2000}
          onChange={(e) => { setText(e.target.value); grow(e.target); }}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(); } }}
        />
        <Button type="submit" variant="primary" size="sm" icon="send" disabled={!text.trim() || (team.live && offline)} aria-label={t('chat.send')} title={`${t('chat.send')} (Enter)`} />
      </form>
    </div>
  );
}
