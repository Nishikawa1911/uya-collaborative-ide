import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../../api';
import { ApiError, type RunStatus, type RunView, type Runtime, type PreviewResult } from '../../api/types';
import { t } from '../../i18n';
import { toast } from '../../state/toasts';
import { uid } from '../../lib/utils';

export type OutputKind = 'info' | 'warning' | 'error' | 'muted' | 'build' | 'success';
export interface OutputLine { id: string; kind: OutputKind; text: string; at: string; src?: 'sql' }
export type RunKind = 'file' | 'project' | 'sql';

/** Кеңейтім → runner тілі. Веб файлдар (html/css) орындалмайды — алдын ала қарау арқылы ашылады. */
const EXT_LANG: Record<string, string> = {
  py: 'python', java: 'java', cpp: 'cpp', cc: 'cpp', cxx: 'cpp', cs: 'csharp', rs: 'rust', php: 'php', ts: 'typescript',
  js: 'javascript', mjs: 'javascript', go: 'go', sql: 'sql',
};
export const runnerLangOf = (path: string): string | null => EXT_LANG[/\.([A-Za-z0-9]+)$/.exec(path)?.[1]?.toLowerCase() ?? ''] ?? null;
export const isWebFile = (path: string) => /\.(html?|css)$/i.test(path);

const errText = (code: string, params?: Record<string, string | number>): string => {
  const key = `errors.${code}`;
  const txt = t(key as never, params as never);
  return txt === key ? t('errors.unknown') : txt;
};

const POLL_MS = 300;
const FINAL: RunStatus[] = ['ok', 'error', 'compile_error', 'timeout', 'killed', 'memory_limit', 'output_limit', 'internal_error'];

export interface ActiveRun { id: string; kind: RunKind; status: RunStatus; queuePosition?: number; phase: string | null }

/**
 * Кодты орындау. Код ешқашан браузерде де, негізгі серверде де орындалмайды: backend оны оқшауланған
 * runner контейнеріне жібереді, ал бұл хук нәтижені (stdout/stderr/build) 300 мс сайын сұрап, терминалға жазады.
 */
export function useRun(projectId: string, getEntry: () => string, getActiveFile: () => { id: string; path: string } | null, onOpenPreview?: () => void) {
  const [lines, setLines] = useState<OutputLine[]>([]);
  const [active, setActive] = useState<ActiveRun | null>(null);
  const [runtime, setRuntime] = useState<Runtime | null>(null);
  const [runtimeError, setRuntimeError] = useState(false);
  const [stdin, setStdin] = useState('');
  const [preview, setPreview] = useState<{ result: PreviewResult | null; loading: boolean; error: string | null; nonce: number }>({ result: null, loading: false, error: null, nonce: 0 });
  const alive = useRef(true);
  const activeRef = useRef<ActiveRun | null>(null);
  activeRef.current = active;
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const push = useCallback((kind: OutputKind, text: string, src?: 'sql') => {
    setLines((l) => [...l, { id: uid('o'), kind, text, at: new Date().toISOString(), src }]);
  }, []);

  const loadRuntime = useCallback(async () => {
    try { setRuntime(await api.runs.runtime()); setRuntimeError(false); } catch { setRuntimeError(true); }
  }, []);
  useEffect(() => { void loadRuntime(); }, [loadRuntime]);

  const langState = useCallback((path: string): { ok: boolean; reason?: string } => {
    const id = runnerLangOf(path);
    if (!id) return { ok: false, reason: t('run.unsupportedFile') };
    if (!runtime) return { ok: false, reason: runtimeError ? t('errors.run.unavailable') : t('run.checking') };
    if (!runtime.available) return { ok: false, reason: t('errors.run.unavailable') };
    const l = runtime.languages.find((x) => x.id === id);
    if (!l || !l.enabled) return { ok: false, reason: t('errors.run.language_unavailable', { language: l?.label ?? id }) };
    return { ok: true };
  }, [runtime, runtimeError]);

  const finishText = (r: RunView): { kind: OutputKind; text: string } => {
    const sec = r.durationMs != null ? (r.durationMs / 1000).toFixed(2) : '—';
    const code = r.exitCode != null ? String(r.exitCode) : '—';
    switch (r.status) {
      case 'ok': return { kind: 'success', text: t('run.done.ok', { sec }) };
      case 'error': return { kind: 'error', text: t('run.done.error', { code, sec }) + (r.signal ? ` (${r.signal})` : '') };
      case 'compile_error': return { kind: 'error', text: t('run.done.compileError', { code }) };
      case 'timeout': return { kind: 'error', text: t('run.done.timeout', { sec: r.message ?? '' }) };
      case 'memory_limit': return { kind: 'error', text: t('run.done.memory', { mb: r.message ?? '' }) };
      case 'output_limit': return { kind: 'error', text: t('run.done.output') };
      case 'killed': return { kind: 'warning', text: t('run.done.killed') };
      default: return { kind: 'error', text: r.message === 'runner_unreachable' ? t('run.done.runnerDown') : r.message === 'server_restart' ? t('run.done.restart') : t('run.done.internal') };
    }
  };

  const track = useCallback(async (kind: RunKind, first: RunView) => {
    const src = kind === 'sql' ? 'sql' as const : undefined;
    let after = 0;
    let run = first;
    setActive({ id: run.id, kind, status: run.status, queuePosition: run.queuePosition, phase: run.phase });
    let lastPhase: string | null = null;
    for (let guard = 0; guard < 20_000 && alive.current; guard++) {
      let res;
      try { res = await api.runs.poll(projectId, run.id, after); }
      catch (e) {
        if (e instanceof ApiError && e.status === 0) { await new Promise((r) => setTimeout(r, 1000)); continue; } // желі үзілді — қайталау
        push('error', t('errors.unknown'), src); break;
      }
      run = res.run; after = res.next;
      for (const ev of res.events) push(ev.stream === 'stderr' ? 'error' : ev.stream === 'build' ? 'build' : 'info', ev.chunk.replace(/\n$/, ''), src);
      if (run.phase && run.phase !== lastPhase) { lastPhase = run.phase; if (run.phase === 'compile') push('muted', t('run.phase.compile'), src); }
      setActive({ id: run.id, kind, status: run.status, queuePosition: run.queuePosition, phase: run.phase });
      if (FINAL.includes(run.status)) {
        const f = finishText(run);
        if (run.truncated) push('warning', t('run.truncated'), src);
        push(f.kind, f.text, src);
        break;
      }
      await new Promise((r) => setTimeout(r, POLL_MS));
    }
    if (alive.current) setActive(null);
  }, [projectId, push]); // eslint-disable-line react-hooks/exhaustive-deps

  const startRun = useCallback(async (kind: RunKind, body: Parameters<typeof api.runs.start>[1], label: string) => {
    if (activeRef.current) return false;
    const src = kind === 'sql' ? 'sql' as const : undefined;
    push('muted', label, src);
    try {
      const run = await api.runs.start(projectId, { ...body, ...(stdin ? { stdin } : {}) });
      await track(kind, run);
    } catch (err) {
      if (err instanceof ApiError) {
        push('warning', errText(err.code, err.params), src);
        if (err.code === 'run.unavailable') toast(t('errors.run.unavailable'), 'warning');
        void loadRuntime();
      } else push('error', t('errors.unknown'), src);
      return false;
    }
    return true;
  }, [projectId, push, track, stdin, loadRuntime]);

  const openPreview = useCallback(async (path?: string) => {
    onOpenPreview?.();
    setPreview((p) => ({ ...p, loading: true, error: null }));
    try {
      const result = await api.runs.preview(projectId, path);
      setPreview((p) => ({ result, loading: false, error: null, nonce: p.nonce + 1 }));
    } catch (err) {
      const code = err instanceof ApiError ? err.code : 'unknown';
      setPreview((p) => ({ ...p, loading: false, error: errText(code) }));
    }
  }, [projectId, onOpenPreview]);

  const runFile = useCallback(async () => {
    const file = getActiveFile();
    if (!file) { toast(t('ws.runNoFile'), 'warning'); return false; }
    if (isWebFile(file.path)) { void openPreview(); return true; }
    const st = langState(file.path);
    if (!st.ok) { push('warning', st.reason ?? t('errors.unknown')); return false; }
    return startRun('file', { mode: 'file', fileId: file.id }, t('output.requestFile', { file: file.path }));
  }, [getActiveFile, langState, push, startRun, openPreview]);

  const runProject = useCallback(async () => {
    const entry = getEntry();
    if (!entry) { push('error', t('output.noEntry')); return false; }
    if (isWebFile(entry)) { void openPreview(entry); return true; }
    const st = langState(entry);
    if (!st.ok) { push('warning', st.reason ?? t('errors.unknown')); return false; }
    return startRun('project', { mode: 'project' }, t('output.requestProject', { entry }));
  }, [getEntry, langState, push, startRun, openPreview]);

  const runSql = useCallback(async (sql: string) => {
    const st = langState('query.sql');
    if (!st.ok) { push('warning', st.reason ?? t('errors.unknown'), 'sql'); return false; }
    return startRun('sql', { mode: 'sql', sql }, t('sql.running'));
  }, [langState, push, startRun]);

  const stop = useCallback(async () => {
    const a = activeRef.current;
    if (!a) return;
    try { await api.runs.cancel(projectId, a.id); } catch { /* polling соңғы күйді көрсетеді */ }
  }, [projectId]);

  const clear = useCallback(() => setLines([]), []);

  return {
    lines, active, running: active ? active.kind : null, runtime, runtimeError, langState, stdin, setStdin, preview,
    runFile, runProject, runSql, stop, openPreview, clear, refreshRuntime: loadRuntime,
  };
}

export type RunApi = ReturnType<typeof useRun>;
