import { useState } from 'react';
import { api } from '../../api';
import { ApiError } from '../../api/types';
import { navigate, paths } from '../../app/router';
import { ThemeToggle } from '../../components/layout/ThemeToggle';
import { Alert, AvatarStack, Avatar, Button, CopyButton, IconButton, LanguageChip, Menu, Modal, RoleBadge } from '../../components/ui';
import { useT } from '../../i18n';
import { messageForError } from '../../i18n/format';
import { logout } from '../../state/auth';
import { toast } from '../../state/toasts';
import { SettingsDialog } from './SettingsDialog';
import { isWebFile } from './useRun';
import { useWorkspace } from './WorkspaceContext';

/** Жоғарғы панель: жоба атауы, белсенді қатысушылар, панельдерді басқару, Run File / Run Project. */
export function TopBar() {
  const t = useT();
  const { project, role, me, team, layout, canRun, isMobile, run, runFile, runProject, files } = useWorkspace();
  const activePathForRun = files.activeId ? files.pathOf(files.activeId) : null;
  const fileLang = activePathForRun && !isWebFile(activePathForRun) ? run.langState(activePathForRun) : { ok: true as const };
  const entryLang = project.entryPoint && !isWebFile(project.entryPoint) ? run.langState(project.entryPoint) : { ok: true as const };
  const [shareOpen, setShareOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const online = team.members.filter((m) => m.online);
  const runBusy = run.running != null;

  const noFile = files.activeId == null;
  const fileTitle = !canRun ? t('ws.runDisabledViewer') : noFile ? t('ws.runNoFile') : !fileLang.ok ? (fileLang.reason ?? t('ws.runFile')) : t('ws.runFile');
  const projectTitle = !canRun ? t('ws.runDisabledViewer') : !entryLang.ok ? (entryLang.reason ?? t('ws.runProject')) : t('ws.runProject');

  return (
    <header className="topbar">
      <IconButton icon="back" label={t('ws.back')} onClick={() => navigate(paths.dashboard())} />
      <div className="topbar__project">
        <h1 className="topbar__name" title={project.name}>{project.name}</h1>
        <RoleBadge role={role} />
        <div className="topbar__langs">
          {project.languages.slice(0, 3).map((l) => <LanguageChip key={l} language={l} compact />)}
        </div>
      </div>

      <div className="topbar__spacer" />

      {!isMobile && (
        <div className="topbar__panels" role="group" aria-label={t('ws.panel.editor')}>
          <IconButton icon="panelLeft" size="sm" active={layout.showSidebar} aria-pressed={layout.showSidebar} label={t('ws.toggleSidebar')} onClick={layout.toggleSidebar} />
          <IconButton icon="panelBottom" size="sm" active={layout.showBottom} aria-pressed={layout.showBottom} label={t('ws.toggleBottom')} onClick={layout.toggleBottom} />
          <IconButton icon="panelRight" size="sm" active={layout.showRight} aria-pressed={layout.showRight} label={t('ws.toggleRight')} onClick={layout.toggleRight} />
        </div>
      )}

      <button
        type="button" className="topbar__online" aria-label={`${t('ws.activeMembers')}: ${t('ws.activeMembersCount', { n: online.length })}`}
        onClick={() => layout.setRightTab('members')}
        title={online.map((m) => m.displayName).join(', ')}
      >
        <AvatarStack people={online} max={4} size={26} />
        <span className="topbar__online-count">{t('ws.activeMembersCount', { n: online.length })}</span>
      </button>

      <Button size="sm" icon="share" onClick={() => setShareOpen(true)}>
        <span className="hide-sm">{t('ws.share')}</span>
      </Button>

      {role === 'owner' && <IconButton icon="settings" size="sm" label={t('settings.title')} onClick={() => setSettingsOpen(true)} />}

      <div className="topbar__run" role="group" aria-label={t('ws.runFile')}>
        <Button
          size="sm" variant="accent-outline" icon="play" loading={run.running === 'file'} disabled={!canRun || noFile || runBusy || !fileLang.ok}
          title={fileTitle} onClick={runFile}
        >
          <span className="hide-sm">{t('ws.runFile.short')}</span>
          <span className="sr-only">{t('ws.runFile')}</span>
        </Button>
        <Button
          size="sm" variant="primary" icon="rocket" loading={run.running === 'project'} disabled={!canRun || runBusy || !entryLang.ok}
          title={projectTitle} onClick={runProject}
        >
          <span className="hide-sm">{t('ws.runProject.short')}</span>
          <span className="sr-only">{t('ws.runProject')}</span>
        </Button>
        {runBusy && (
          <Button size="sm" variant="danger" icon="stop" onClick={() => void run.stop()} data-testid="run-stop" title={t('run.stop')}>
            <span className="hide-sm">{t('run.stop')}</span>
          </Button>
        )}
      </div>

      <ThemeToggle size="sm" />
      <Menu
        label={t('nav.profile')}
        trigger={(p) => (
          <button type="button" className="topbar__user" aria-label={`${t('nav.profile')}: ${me.displayName}`} {...p}>
            <Avatar person={me} size={28} />
          </button>
        )}
        items={[
          { id: 'dash', label: t('nav.projects'), icon: 'grid', onSelect: () => navigate(paths.dashboard()) },
          { id: 'profile', label: t('nav.profile'), icon: 'user', onSelect: () => navigate(paths.profile()) },
          { id: 'logout', label: t('nav.logout'), icon: 'logout', danger: true, separatorBefore: true, onSelect: async () => { await logout(); navigate(paths.login()); } },
        ]}
      />

      {role === 'owner' && <SettingsDialog open={settingsOpen} onClose={() => setSettingsOpen(false)} />}
      <ShareDialog open={shareOpen} onClose={() => setShareOpen(false)} />
    </header>
  );
}

/** «Бөлісу»: код хэші ғана сақталады, сондықтан иесі жаңа код жасайды және оны бір рет көреді. */
function ShareDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useT();
  const { project, role } = useWorkspace();
  const [code, setCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const rotate = async () => {
    setBusy(true);
    try {
      const res = await api.projects.rotateInvite(project.id);
      setCode(res.inviteCode);
      toast(t('ws.inviteRotated'), 'success');
    } catch (err) {
      toast(messageForError(err instanceof ApiError ? err.code : 'unknown'), 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} title={t('ws.inviteTitle')} onClose={() => { setCode(null); onClose(); }} footer={<Button onClick={() => { setCode(null); onClose(); }}>{t('common.close')}</Button>}>
      <p className="modal__text">{t('ws.inviteText')}</p>
      {role === 'owner' ? (
        <div className="share">
          {code ? (
            <div className="code-box">
              <span className="code-box__label">{t('create.inviteCode')}</span>
              <code className="code-box__code" data-testid="share-code">{code}</code>
              <CopyButton text={code} />
            </div>
          ) : null}
          <Button icon="key" loading={busy} onClick={() => void rotate()}>{t('ws.inviteRotate')}</Button>
          {code && <Alert kind="warning">{t('create.codeShownOnce')}</Alert>}
        </div>
      ) : (
        <Alert kind="info">{t('ws.inviteOwnerOnly')}</Alert>
      )}
    </Modal>
  );
}
