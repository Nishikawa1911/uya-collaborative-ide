import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { diffText } from '../../../../shared/crdt';
import type { RemoteSel, DocSession } from '../../../collab/client';
import { tokenize } from './highlight';
import type { EditorProps } from './types';

const INDENT = '    ';
const LINE_H = 21;

/**
 * Резервтік редактор: Monaco жүктелмегенде ғана қолданылады (желі жоқ / CDN бұғатталған).
 * textarea + астыңғы қабатта бояулы <pre>. Монакодағы сияқты кеңейтілген мүмкіндіктер
 * (автотолтыру, көп курсор, minimap) жоқ — бұл ашық түрде интерфейсте көрсетіледі.
 */
/** Мәтіндегі офсетті (жол, баған) түріне айналдыру. */
function lineCol(starts: number[], off: number): { line: number; col: number } {
  let lo = 0, hi = starts.length - 1;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (starts[mid] <= off) lo = mid; else hi = mid - 1; }
  return { line: lo, col: off - starts[lo] };
}

/** Қашықтағы өзгерістер бойынша жергілікті офсетті жылжыту (курсор өз орнында қалуы үшін). */
function mapOffset(pos: number, changes: Array<{ offset: number; deleteCount: number; insert: string }>): number {
  for (const c of changes) {
    if (pos > c.offset + c.deleteCount) pos += c.insert.length - c.deleteCount;
    else if (pos > c.offset) pos = c.offset + (c.deleteCount === 0 ? 0 : c.insert.length);
  }
  return pos;
}

export function FallbackEditor({ value, language, readOnly, ariaLabel, onChange, onCursor, onSave, reveal, collab }: EditorProps) {
  const area = useRef<HTMLTextAreaElement>(null);
  const pre = useRef<HTMLPreElement>(null);
  const gutter = useRef<HTMLDivElement>(null);
  const [scroll, setScroll] = useState({ top: 0, left: 0 });
  const [caretLine, setCaretLine] = useState(1);

  // Бірлескен режимде мәтіннің көзі — сессия; жергілікті күй тек көрсету үшін
  const [collabText, setCollabText] = useState(() => (collab ? collab.text() : ''));
  const shown = collab ? collabText : value;
  const shownRef = useRef(shown);
  shownRef.current = shown;
  const pendingSel = useRef<{ s: number; e: number; dir: 'forward' | 'backward' | 'none' } | null>(null);
  const [remote, setRemote] = useState<RemoteSel[]>([]);

  const tokens = useMemo(() => tokenize(shown, language), [shown, language]);
  const lineCount = useMemo(() => shown.split('\n').length, [shown]);
  const starts = useMemo(() => { const s = [0]; for (let i = 0; i < shown.length; i++) if (shown.charCodeAt(i) === 10) s.push(i + 1); return s; }, [shown]);

  const syncScroll = () => {
    const a = area.current;
    if (!a) return;
    if (pre.current) { pre.current.scrollTop = a.scrollTop; pre.current.scrollLeft = a.scrollLeft; }
    if (gutter.current) gutter.current.scrollTop = a.scrollTop;
    setScroll({ top: a.scrollTop, left: a.scrollLeft });
  };
  useLayoutEffect(() => {
    const a = area.current;
    const ps = pendingSel.current;
    if (a && ps) { pendingSel.current = null; a.setSelectionRange(ps.s, ps.e, ps.dir); }
    syncScroll();
  }, [shown]);

  /** Бірлескен құжатқа жазылу: қашықтағы өзгерістер мен курсорлар. */
  useEffect(() => {
    if (!collab) return undefined;
    setCollabText(collab.text());
    let raf = 0;
    const refreshCursors = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; setRemote(collab.remoteSelections()); }); };
    refreshCursors();
    const off = collab.subscribe((e) => {
      const a = area.current;
      if (e.kind === 'remote' && a) {
        const dir = (a.selectionDirection ?? 'none') as 'forward' | 'backward' | 'none';
        pendingSel.current = { s: mapOffset(a.selectionStart, e.changes), e: mapOffset(a.selectionEnd, e.changes), dir };
        const top = a.scrollTop;
        setCollabText(collab.text());
        requestAnimationFrame(() => { if (area.current) area.current.scrollTop = top; });
      } else if (e.kind === 'state') setCollabText(collab.text());
      refreshCursors();
    });
    return () => { off(); if (raf) cancelAnimationFrame(raf); };
  }, [collab]);

  /** Жергілікті ерекшелеуді басқаларға жіберу (салыстырмалы позициялар). */
  const publishSelection = () => {
    const a = area.current;
    if (!a || !collab) return;
    const backward = a.selectionDirection === 'backward';
    collab.setSelections([{ anchor: backward ? a.selectionEnd : a.selectionStart, head: backward ? a.selectionStart : a.selectionEnd }]);
  };

  /** textarea өзгерісі → CRDT операциясы (ортақ префикс/суффикс айырмасы). */
  const onTextChange = (next: string) => {
    if (!collab) { onChange(next); return; }
    const d = diffText(shownRef.current, next);
    if (!d) return;
    if (!collab.edit(d.offset, d.deleteCount, d.insert)) { setCollabText(collab.text()); return; } // қабылданбады: мәтінді қайтару
    shownRef.current = next;
    setCollabText(next);
    onChange(next);
    publishSelection();
  };

  const reportCursor = () => {
    const a = area.current;
    if (!a) return;
    const before = a.value.slice(0, a.selectionStart);
    const line = before.split('\n').length;
    const col = before.length - before.lastIndexOf('\n');
    setCaretLine(line);
    onCursor(line, col);
    publishSelection();
  };

  /** Мәтінді undo тарихын бұзбай енгізеді (execCommand), болмаса setRangeText-ке оралады. */
  const insert = (text: string) => {
    const a = area.current!;
    a.focus();
    if (!document.execCommand?.('insertText', false, text)) {
      a.setRangeText(text, a.selectionStart, a.selectionEnd, 'end');
      onTextChange(a.value);
    }
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const a = e.currentTarget;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); onSave(); return; }
    if (readOnly) return;
    if (e.key === 'Escape') { a.blur(); return; } // Tab фокус ауыстыруы үшін (қолжетімділік)
    if (e.key === 'Tab' && !e.shiftKey) { e.preventDefault(); insert(INDENT); return; }
    if (e.key === 'Tab' && e.shiftKey) {
      e.preventDefault();
      const start = a.value.lastIndexOf('\n', a.selectionStart - 1) + 1;
      if (a.value.startsWith(INDENT, start)) {
        const keepStart = a.selectionStart; const keepEnd = a.selectionEnd;
        a.setSelectionRange(start, start + INDENT.length);
        insert('');
        a.setSelectionRange(Math.max(start, keepStart - INDENT.length), Math.max(start, keepEnd - INDENT.length));
      }
      return;
    }
    if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.metaKey) {
      // Автоматты шегініс: алдыңғы жолдың шегінісін сақтау (+4, егер жол { ( [ : арқылы аяқталса)
      const before = a.value.slice(0, a.selectionStart);
      const lineStart = before.lastIndexOf('\n') + 1;
      const currentLine = before.slice(lineStart);
      const indent = /^[ \t]*/.exec(currentLine)![0];
      const extra = /[{(\[:]\s*$/.test(currentLine) ? INDENT : '';
      e.preventDefault();
      insert(`\n${indent}${extra}`);
    }
  };

  useEffect(() => {
    const a = area.current;
    if (!reveal || !a) return;
    const lines = a.value.split('\n');
    const line = Math.min(Math.max(reveal.line, 1), lines.length);
    const offset = lines.slice(0, line - 1).reduce((n, l) => n + l.length + 1, 0) + Math.min(reveal.col - 1, lines[line - 1].length);
    a.focus();
    a.setSelectionRange(offset, offset);
    a.scrollTop = Math.max(0, (line - 1) * LINE_H - a.clientHeight / 2);
    syncScroll();
    reportCursor();
  }, [reveal?.nonce]); // eslint-disable-line react-hooks/exhaustive-deps

  const numbers = useMemo(() => Array.from({ length: lineCount }, (_, i) => i + 1), [lineCount]);

  return (
    <div className="fb" data-engine="fallback">
      <div className="fb__gutter" ref={gutter} aria-hidden="true">
        <div className="fb__gutter-inner">
          {numbers.map((n) => <div key={n} className={n === caretLine ? 'is-current' : undefined}>{n}</div>)}
        </div>
      </div>
      <div className="fb__body">
        <div className="fb__current" style={{ transform: `translateY(${(caretLine - 1) * LINE_H - scroll.top}px)` }} aria-hidden="true" />
        <pre className="fb__pre" ref={pre} aria-hidden="true">
          {tokens.map((tok, i) => (tok.type === 'plain' ? tok.text : <span key={i} className={`tok tok--${tok.type}`}>{tok.text}</span>))}
          {'\n'}
        </pre>
        {remote.length > 0 && (
          <div className="fb__remote" aria-hidden="true" style={{ transform: `translate(${-scroll.left}px, ${-scroll.top}px)` }}>
            {remote.map((r, i) => {
              const a = lineCol(starts, Math.min(r.from, shown.length));
              const b = lineCol(starts, Math.min(r.to, shown.length));
              const h = lineCol(starts, Math.min(r.head, shown.length));
              const segs: Array<{ line: number; from: number; to: number }> = [];
              if (r.from !== r.to) {
                for (let l = a.line; l <= b.line; l++) {
                  const lineLen = (starts[l + 1] ?? shown.length + 1) - starts[l] - 1;
                  segs.push({ line: l, from: l === a.line ? a.col : 0, to: l === b.line ? b.col : lineLen + 1 });
                }
              }
              return (
                <div key={`${r.clientId}-${i}`} style={{ ['--rc' as string]: r.color }}>
                  {segs.map((s) => (
                    <span key={s.line} className="fb__rsel" style={{ top: 12 + s.line * LINE_H, left: `calc(14px + ${s.from}ch)`, width: `${Math.max(s.to - s.from, 0.5)}ch` }} />
                  ))}
                  <span className="fb__rcaret" data-remote-user={r.userId} style={{ top: 12 + h.line * LINE_H, left: `calc(14px + ${h.col}ch)` }}>
                    <span className="fb__rname">{r.name}</span>
                  </span>
                </div>
              );
            })}
          </div>
        )}
        <textarea
          ref={area} className="fb__area" value={shown} readOnly={readOnly} aria-label={ariaLabel} aria-multiline="true"
          spellCheck={false} autoCapitalize="off" autoComplete="off" autoCorrect="off" wrap="off"
          onChange={(e) => { onTextChange(e.target.value); }}
          onScroll={syncScroll} onKeyDown={onKeyDown} onKeyUp={reportCursor} onClick={reportCursor} onSelect={reportCursor}
        />
      </div>
    </div>
  );
}
