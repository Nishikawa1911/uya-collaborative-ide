import { useEffect, useRef } from 'react';
import { languageMeta } from '../../../lib/languages';
import type { RemoteSel } from '../../../collab/client';
import type { MonacoApi } from './monacoLoader';
import type { EditorProps } from './types';

/**
 * Monaco Editor қозғалтқышы. Бір editor данасы, ал әр файл үшін бөлек модель (undo тарихы файл бойынша сақталады).
 * Мазмұнның көзі — `value` (жұмыс кеңістігінің draft-ы); Monaco-дағы өзгеріс `onChange` арқылы қайтады.
 * Бірлескен режимде (`collab` бар) мазмұнның көзі — CRDT сессиясы: модель өзгерістері (`e.changes`) операцияға айналады,
 * қашықтағы өзгерістер `model.applyEdits` арқылы (кері байланыссыз) қолданылады, ал басқалардың курсорлары —
 * decoration ретінде көрсетіледі.
 */

const esc = (n: string) => n.replace(/[\\"\n\r]/g, ' ').slice(0, 40);
export function MonacoEditor({ monaco, modelKey, language, value, readOnly, theme, ariaLabel, onChange, onCursor, onSave, reveal, collab }: EditorProps & { monaco: MonacoApi }) {
  const host = useRef<HTMLDivElement>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const editorRef = useRef<any>(null);
  const applying = useRef(false);
  const cb = useRef({ onChange, onCursor, onSave });
  cb.current = { onChange, onCursor, onSave };
  const latest = useRef({ modelKey, language, value });
  latest.current = { modelKey, language, value };
  const collabRef = useRef(collab ?? null);
  collabRef.current = collab ?? null;
  const decoIds = useRef<string[]>([]);
  const styleEl = useRef<HTMLStyleElement | null>(null);

  const modelFor = (key: string, lang: string, content: string) => {
    const uri = monaco.Uri.parse(`inmemory://uya/${encodeURIComponent(key)}`);
    let model = monaco.editor.getModel(uri);
    if (!model) model = monaco.editor.createModel(content, lang, uri);
    return model;
  };

  // Редакторды бір рет жасау
  useEffect(() => {
    if (!host.current) return;
    const { modelKey: k, language: l, value: v0 } = latest.current;
    const v = collabRef.current ? collabRef.current.text() : v0;
    const editor = monaco.editor.create(host.current, {
      model: modelFor(k, languageMeta[l].monaco, v),
      theme: theme === 'dark' ? 'uya-dark' : 'uya-light',
      automaticLayout: true, readOnly,
      fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'DejaVu Sans Mono', monospace",
      fontSize: 13.5, lineHeight: 21, tabSize: 4, insertSpaces: true,
      minimap: { enabled: false }, scrollBeyondLastLine: false, renderWhitespace: 'selection',
      bracketPairColorization: { enabled: true }, padding: { top: 12, bottom: 12 },
      smoothScrolling: true, cursorBlinking: 'smooth', accessibilitySupport: 'auto',
      ariaLabel,
    });
    editorRef.current = editor;
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => cb.current.onSave());
    const sub1 = editor.onDidChangeModelContent(() => {
      if (!applying.current && !collabRef.current) cb.current.onChange(editor.getValue());
    });
    const sub2 = editor.onDidChangeCursorPosition((e: { position: { lineNumber: number; column: number } }) =>
      cb.current.onCursor(e.position.lineNumber, e.position.column));
    return () => {
      sub1.dispose(); sub2.dispose();
      const model = editor.getModel();
      editor.dispose();
      model?.dispose();
      editorRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [monaco]);

  // Файл ауысқанда: модельді ауыстыру
  useEffect(() => {
    const editor = editorRef.current;
    if (!editor) return;
    if (collabRef.current) return; // бірлескен режимде модельді collab эффекті басқарады
    const model = modelFor(modelKey, languageMeta[language].monaco, value);
    if (model.getValue() !== value) {
      // Қойынды жабылып қайта ашылса, ескі модельде ескірген мәтін қалуы мүмкін.
      applying.current = true;
      model.setValue(value);
      applying.current = false;
    }
    if (editor.getModel() !== model) editor.setModel(model);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modelKey]);

  // Сырттан келген мәннің өзгеруі (мысалы, «Сақтамай жабу» → қайта оқу)
  useEffect(() => {
    const editor = editorRef.current;
    const model = editor?.getModel();
    if (!collabRef.current && model && model.getValue() !== value) {
      applying.current = true;
      model.setValue(value);
      applying.current = false;
    }
  }, [value]);

  // ───────── Бірлескен режим ─────────
  useEffect(() => {
    const editor = editorRef.current;
    if (!editor || !collab) return undefined;
    const model = modelFor(modelKey, languageMeta[language].monaco, collab.text());
    const setText = () => {
      if (model.getValue() === collab.text()) return;
      applying.current = true;
      try { model.setValue(collab.text()); } finally { applying.current = false; }
    };
    model.setEOL(monaco.editor.EndOfLineSequence.LF);
    setText();
    if (editor.getModel() !== model) editor.setModel(model);

    const publish = () => {
      const sels = (editor.getSelections?.() ?? []) as Array<{ getSelectionStart(): { lineNumber: number; column: number }; getPosition(): { lineNumber: number; column: number } }>;
      collab.setSelections(sels.map((s) => ({ anchor: model.getOffsetAt(s.getSelectionStart()), head: model.getOffsetAt(s.getPosition()) })));
    };

    const renderRemote = () => {
      const sels: RemoteSel[] = collab.remoteSelections();
      // Қатысушы түстері мен аттары үшін динамикалық CSS
      if (!styleEl.current) { styleEl.current = document.createElement('style'); styleEl.current.dataset.uyaRemote = '1'; document.head.appendChild(styleEl.current); }
      const seen = new Set<number>();
      let css = '';
      for (const r of sels) {
        if (seen.has(r.clientId)) continue;
        seen.add(r.clientId);
        css += `.uya-u${r.clientId}{--rc:${/^#[0-9a-fA-F]{6}$/.test(r.color) ? r.color : '#3cc6d6'}}.uya-rcb-${r.clientId}::after{content:"${esc(r.name)}"}`;
      }
      styleEl.current.textContent = css;
      const decos = sels.flatMap((r) => {
        const from = model.getPositionAt(r.from), to = model.getPositionAt(r.to), head = model.getPositionAt(r.head);
        const list: unknown[] = [];
        if (r.from !== r.to) list.push({ range: new monaco.Range(from.lineNumber, from.column, to.lineNumber, to.column), options: { className: `uya-rs uya-u${r.clientId}`, stickiness: 1 } });
        list.push({ range: new monaco.Range(head.lineNumber, head.column, head.lineNumber, head.column), options: { beforeContentClassName: `uya-rcb uya-u${r.clientId} uya-rcb-${r.clientId}`, stickiness: 1 } });
        return list;
      });
      decoIds.current = editor.deltaDecorations(decoIds.current, decos);
    };

    const subLocal = model.onDidChangeContent((e: { changes: Array<{ rangeOffset: number; rangeLength: number; text: string }> }) => {
      if (applying.current) return;
      // Өзгерістер түпнұсқа модельге қатысты: үлкен офсеттен кішісіне қарай қолданамыз
      const list = [...e.changes].sort((a, b) => b.rangeOffset - a.rangeOffset);
      for (const c of list) {
        if (!collab.edit(c.rangeOffset, c.rangeLength, c.text)) { setText(); applying.current = true; try { model.setValue(collab.text()); } finally { applying.current = false; } return; }
      }
      cb.current.onChange(model.getValue());
    });
    const subSel = editor.onDidChangeCursorSelection(() => publish());
    const subRemote = collab.subscribe((ev) => {
      if (ev.kind === 'remote') {
        applying.current = true;
        try {
          for (const c of ev.changes) {
            const a = model.getPositionAt(c.offset), b = model.getPositionAt(c.offset + c.deleteCount);
            model.applyEdits([{ range: new monaco.Range(a.lineNumber, a.column, b.lineNumber, b.column), text: c.insert }]);
          }
        } finally { applying.current = false; }
        renderRemote();
      } else if (ev.kind === 'state') { setText(); renderRemote(); }
      else if (ev.kind === 'cursors') renderRemote();
    });
    renderRemote(); publish();
    return () => {
      subLocal.dispose(); subSel.dispose(); subRemote();
      decoIds.current = editor.deltaDecorations(decoIds.current, []);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collab, modelKey]);

  useEffect(() => () => { styleEl.current?.remove(); styleEl.current = null; }, []);

  useEffect(() => {
    const model = editorRef.current?.getModel();
    if (model) monaco.editor.setModelLanguage(model, languageMeta[language].monaco);
  }, [language, monaco]);

  useEffect(() => { editorRef.current?.updateOptions({ readOnly, ariaLabel }); }, [readOnly, ariaLabel]);
  useEffect(() => { monaco.editor.setTheme(theme === 'dark' ? 'uya-dark' : 'uya-light'); }, [theme, monaco]);

  useEffect(() => {
    const editor = editorRef.current;
    if (!reveal || !editor) return;
    editor.revealLineInCenter(reveal.line);
    editor.setPosition({ lineNumber: reveal.line, column: reveal.col });
    editor.focus();
  }, [reveal?.nonce]); // eslint-disable-line react-hooks/exhaustive-deps

  return <div ref={host} className="monaco-host" data-engine="monaco" />;
}
