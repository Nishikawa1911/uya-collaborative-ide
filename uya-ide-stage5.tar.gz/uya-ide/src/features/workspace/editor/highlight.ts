import type { FileLanguageId } from '../../../api/types';

/**
 * Жеңіл синтаксис бөлектегіш — Monaco жүктелмегенде (желі жоқ) ғана қолданылатын резервтік редактор үшін.
 * Бұл толық парсер емес: регулярлы өрнектер негізінде жұмыс істейді.
 */
export type TokenType = 'keyword' | 'string' | 'comment' | 'number' | 'type' | 'func' | 'tag' | 'attr' | 'punct' | 'plain';
export interface Token { type: TokenType; text: string }

const words = (s: string) => new Set(s.split(/\s+/).filter(Boolean));

const KEYWORDS: Partial<Record<FileLanguageId, Set<string>>> = {
  python: words('False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case self'),
  javascript: words('break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new of return super switch this throw try typeof var void while with yield async await true false null undefined'),
  typescript: words('break case catch class const continue debugger default delete do else enum export extends finally for function if implements import in instanceof interface let namespace new of private protected public readonly return static super switch this throw try type typeof var void while yield async await as keyof true false null undefined abstract declare'),
  java: words('abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for if implements import instanceof int interface long native new package private protected public return short static super switch synchronized this throw throws try void volatile while var record true false null'),
  go: words('break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var true false nil'),
  cpp: words('alignas auto bool break case catch char class const constexpr continue default delete do double else enum explicit extern false float for friend goto if inline int long namespace new noexcept nullptr operator private protected public return short signed sizeof static struct switch template this throw true try typedef typename union unsigned using virtual void volatile while include define'),
  csharp: words('abstract as base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach goto if implicit in int interface internal is lock long namespace new null object operator out override params private protected public readonly ref return sbyte sealed short sizeof static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using var virtual void volatile while async await record'),
  rust: words('as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while'),
  php: words('abstract and array as break case catch class clone const continue declare default do echo else elseif empty extends final finally fn for foreach function global if implements include instanceof interface isset list namespace new null or print private protected public require return static switch throw trait true false try use var while yield'),
  sql: words('select from where group by order having join left right inner outer full on as and or not null is in like between exists union all distinct insert into values update set delete create table alter drop index view primary key foreign references default constraint limit offset case when then else end with asc desc count sum avg min max over partition coalesce cast'),
  json: words('true false null'),
};

interface Rule { type: TokenType; source: string }

const slashComments: Rule[] = [{ type: 'comment', source: '\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?(?:\\*\\/|$)' }];
const num: Rule = { type: 'number', source: '\\b(?:0[xX][0-9a-fA-F_]+|\\d[\\d_]*(?:\\.\\d+)?(?:[eE][+-]?\\d+)?)\\b' };
const word: Rule = { type: 'plain', source: '[A-Za-z_$\\u0400-\\u04FF\\u04D8\\u04D9\\u0492\\u0493\\u049A\\u049B\\u04A2\\u04A3\\u04E8\\u04E9\\u04B0\\u04B1\\u04AE\\u04AF\\u04BA\\u04BB\\u0406\\u0456][\\w$\\u0400-\\u04FF]*' };
const punct: Rule = { type: 'punct', source: '[{}()\\[\\];,.:<>=+\\-*/%&|!?^~]+' };

const dq = '"(?:\\\\.|[^"\\\\\\n])*"?';
const sq = "'(?:\\\\.|[^'\\\\\\n])*'?";
const bt = '`(?:\\\\.|[^`\\\\])*`?';

function cLike(strings: string[], extra: Rule[] = []): Rule[] {
  return [...slashComments, { type: 'string', source: strings.join('|') }, ...extra, num, word, punct];
}

const RULES: Record<FileLanguageId, Rule[]> = {
  javascript: cLike([dq, sq, bt]),
  typescript: cLike([dq, sq, bt]),
  java: cLike([dq, sq]),
  go: cLike([dq, sq, bt]),
  cpp: cLike([dq, sq], [{ type: 'keyword', source: '^[ \\t]*#[ \\t]*\\w+' }]),
  csharp: cLike([dq, sq]),
  rust: cLike([dq, sq]),
  php: [
    { type: 'comment', source: '\\/\\/[^\\n]*|#[^\\n]*|\\/\\*[\\s\\S]*?(?:\\*\\/|$)' },
    { type: 'string', source: [dq, sq].join('|') },
    { type: 'attr', source: '\\$[A-Za-z_]\\w*' },
    num, word, punct,
  ],
  python: [
    { type: 'comment', source: '#[^\\n]*' },
    { type: 'string', source: '(?:[rRbBfF]{0,2})(?:"""[\\s\\S]*?(?:"""|$)|\'\'\'[\\s\\S]*?(?:\'\'\'|$)|' + dq + '|' + sq + ')' },
    { type: 'func', source: '@[A-Za-z_][\\w.]*' },
    num, word, punct,
  ],
  sql: [
    { type: 'comment', source: '--[^\\n]*|\\/\\*[\\s\\S]*?(?:\\*\\/|$)' },
    { type: 'string', source: sq },
    num, word, punct,
  ],
  html: [
    { type: 'comment', source: '<!--[\\s\\S]*?(?:-->|$)' },
    { type: 'tag', source: '<\\/?[A-Za-z!][\\w:-]*' },
    { type: 'string', source: [dq, sq].join('|') },
    { type: 'attr', source: '[A-Za-z_:@][\\w:.-]*(?=\\s*=)' },
    { type: 'punct', source: '\\/?>|=' },
  ],
  css: [
    { type: 'comment', source: '\\/\\*[\\s\\S]*?(?:\\*\\/|$)' },
    { type: 'string', source: [dq, sq].join('|') },
    { type: 'keyword', source: '@[A-Za-z-]+' },
    { type: 'number', source: '#[0-9a-fA-F]{3,8}\\b|-?\\d*\\.?\\d+(?:px|em|rem|%|vh|vw|s|ms|deg|fr)?\\b' },
    { type: 'attr', source: '--?[A-Za-z][\\w-]*(?=\\s*:)' },
    { type: 'type', source: '[.#][A-Za-z_][\\w-]*' },
    word, punct,
  ],
  json: [
    { type: 'attr', source: '"(?:\\\\.|[^"\\\\\\n])*"(?=\\s*:)' },
    { type: 'string', source: dq },
    num, word, punct,
  ],
  markdown: [
    { type: 'keyword', source: '^#{1,6}[ \\t].*$' },
    { type: 'string', source: '`[^`\\n]+`|```[\\s\\S]*?(?:```|$)' },
    { type: 'func', source: '\\[[^\\]\\n]+\\]\\([^)\\n]*\\)' },
    { type: 'punct', source: '^[ \\t]*(?:[-*+]|\\d+\\.)[ \\t]' },
  ],
  plaintext: [],
};

const compiled = new Map<FileLanguageId, RegExp>();
function regexFor(lang: FileLanguageId): RegExp | null {
  const rules = RULES[lang];
  if (!rules.length) return null;
  let re = compiled.get(lang);
  if (!re) {
    re = new RegExp(rules.map((r) => `(${r.source})`).join('|'), 'gm');
    compiled.set(lang, re);
  }
  re.lastIndex = 0;
  return re;
}

/** Мәтінді токендерге бөледі. Токендерді қайта біріктірсе, түпнұсқа мәтін шығады. */
export function tokenize(code: string, lang: FileLanguageId): Token[] {
  const re = regexFor(lang);
  if (!re) return [{ type: 'plain', text: code }];
  const rules = RULES[lang];
  const keywords = KEYWORDS[lang];
  const caseless = lang === 'sql';
  const out: Token[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(code))) {
    if (m[0] === '') { re.lastIndex++; continue; }
    if (m.index > last) out.push({ type: 'plain', text: code.slice(last, m.index) });
    let idx = 1;
    while (idx <= rules.length && m[idx] === undefined) idx++;
    let type = rules[idx - 1].type;
    const text = m[0];
    if (type === 'plain') {
      // сөз: кілт сөз / функция / тип па?
      const probe = caseless ? text.toLowerCase() : text;
      if (keywords?.has(probe)) type = 'keyword';
      else if (code[re.lastIndex] === '(') type = 'func';
      else if (/^[A-ZА-ЯӘҒҚҢӨҰҮҺІ]/.test(text) && lang !== 'sql' && lang !== 'json') type = 'type';
    }
    out.push({ type, text });
    last = re.lastIndex;
  }
  if (last < code.length) out.push({ type: 'plain', text: code.slice(last) });
  return out;
}
