import { useCallback, useEffect, useState } from 'react';
import { useCollabRefresh } from '../../../collab/useCollab';
import { Alert, Button, ConfirmDialog, EmptyState, Icon, IconButton, Spinner } from '../../../components/ui';
import { useT } from '../../../i18n';
import { languageMeta, languageOfFile } from '../../../lib/languages';
import { cx } from '../../../lib/utils';
import { useTheme } from '../../../theme/theme';
import { FileTypeIcon } from '../explorer/FileTypeIcon';
import { useWorkspace } from '../WorkspaceContext';
import { CodeEditor } from './CodeEditor';
import type { EditorEngine } from './types';

/** Редактор аймағы: қойындылар, жол жолағы (breadcrumb), редактор және күй жолағы. */
export function EditorPane() {
  const t = useT();
  const theme = useTheme();
  const { files, canEdit, reveal } = useWorkspace();
  const { openIds, activeId, buffers, byId, dirtyIds, loadingIds, savingIds } = files;

  const [engine, setEngine] = useState<EditorEngine | null>(null);
  const [cursor, setCursor] = useState({ line: 1, col: 1 });
  const [closing, setClosing] = useState<string | null>(null);
  const [hideNotice, setHideNotice] = useState(false);

  const active = activeId ? byId.get(activeId) : undefined;
  const buffer = activeId ? buffers[activeId] : undefined;
  const dirty = !!activeId && dirtyIds.has(activeId);
  const language = active ? languageOfFile(active.name) : 'plaintext';
  useCollabRefresh(files.collab, ['status', 'role']);
  const session = active ? files.sessionOf(active.id) : null;
  const collabMode = !!files.collab;
  const online = files.collab?.status === 'connected';
  const pending = activeId ? (session?.pending ?? 0) : 0;

  useEffect(() => { setCursor({ line: 1, col: 1 }); }, [activeId]);

  const requestClose = useCallback((id: string) => {
    if (dirtyIds.has(id)) setClosing(id); else files.closeTab(id);
  }, [dirtyIds, files]);

  // Alt+W — қойындыны жабу (Ctrl+W браузерде сақталған).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.altKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyW' && activeId) { e.preventDefault(); requestClose(activeId); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeId, requestClose]);

  const onTabKeyDown = (e: React.KeyboardEvent, i: number) => {
    const move = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
    if (move) {
      e.preventDefault();
      const next = openIds[(i + move + openIds.length) % openIds.length];
      files.setActiveId(next);
      requestAnimationFrame(() => document.getElementById(`etab-${next}`)?.focus());
    }
    if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); requestClose(openIds[i]); }
  };

  const closingName = closing ? byId.get(closing)?.name ?? '' : '';
  const crumbs = activeId ? files.pathOf(activeId).split('/') : [];

  return (
    <div className="editor">
      {openIds.length > 0 && (
        <div className="editor__tabs" role="tablist" aria-label={t('ws.panel.editor')}>
          {openIds.map((id, i) => {
            const node = byId.get(id);
            if (!node) return null;
            const isActive = id === activeId;
            return (
              <div key={id} className={cx('etab', isActive && 'is-active', dirtyIds.has(id) && 'is-dirty')}>
                <button
                  id={`etab-${id}`} type="button" role="tab" aria-selected={isActive} tabIndex={isActive ? 0 : -1}
                  className="etab__main" title={files.pathOf(id)}
                  onClick={() => files.setActiveId(id)} onKeyDown={(e) => onTabKeyDown(e, i)}
                  onAuxClick={(e) => { if (e.button === 1) { e.preventDefault(); requestClose(id); } }}
                >
                  <FileTypeIcon name={node.name} size={14} />
                  <span className="etab__name">{node.name}</span>
                  {dirtyIds.has(id) && <span className="etab__dot" role="img" aria-label={t('editor.unsaved')} title={t('editor.unsaved')} />}
                </button>
                <button type="button" className="etab__close" tabIndex={-1} aria-label={t('editor.closeTab', { name: node.name })} onClick={() => requestClose(id)}>
                  <Icon name="close" size={13} />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {active ? (
        <>
          <div className="editor__crumbs">
            <nav aria-label={t('ws.panel.editor')} className="crumbs">
              {crumbs.map((c, i) => (
                <span key={i} className={cx('crumbs__part', i === crumbs.length - 1 && 'is-last')}>
                  {i > 0 && <Icon name="chevronRight" size={12} />}{c}
                </span>
              ))}
            </nav>
            <div className="editor__crumb-actions">
              {!canEdit && <span className="badge badge--gold"><Icon name="lock" size={11} /> {t('editor.readOnly')}</span>}
              <IconButton
                icon="save" size="sm" label={`${t('common.save')} (Ctrl+S)`} disabled={!canEdit || !dirty || savingIds.includes(active.id)}
                onClick={() => void files.save(active.id)}
              />
            </div>
          </div>

          {engine === 'fallback' && !hideNotice && (
            <Alert kind="info" onDismiss={() => setHideNotice(true)}>{t('editor.monacoFallback')}</Alert>
          )}

          <div className="editor__body">
            {buffer && !loadingIds.includes(active.id) ? (
              <CodeEditor
                key={session ? 'collab' : 'plain'} collab={session}
                modelKey={active.id} language={language} value={buffer.draft} readOnly={!canEdit || (collabMode && !session)} theme={theme}
                ariaLabel={`${t('ws.panel.editor')}: ${active.name}`}
                onChange={(v) => files.setDraft(active.id, v)} onCursor={(line, col) => setCursor({ line, col })}
                onSave={() => void files.save(active.id)} reveal={reveal && reveal.nodeId === active.id ? reveal : null}
                onEngine={setEngine}
              />
            ) : (
              <div className="editor-loading" role="status"><Spinner size={22} /> <span>{t('common.loading')}</span></div>
            )}
          </div>

          <div className="statusbar" role="status">
            <span>{t('editor.line', { n: cursor.line })}, {t('editor.col', { n: cursor.col })}</span>
            <span className={cx('statusbar__dirty', dirty && 'is-dirty')}>
              {savingIds.includes(active.id) ? t('common.loading') : !collabMode && dirty ? t('editor.unsaved') : ''}
            </span>
            {collabMode && (
              <span
                className={cx('sync-badge', !online && 'is-offline', online && pending > 0 && 'is-pending')} data-testid="sync-state"
                title={t(!online ? 'collab.syncOffline' : pending > 0 ? 'collab.syncPending' : 'collab.syncDone')}
              >
                {t(!online ? 'collab.syncOffline' : !session ? 'collab.syncConnecting' : pending > 0 ? 'collab.syncPending' : 'collab.syncDone')}
              </span>
            )}
            <span className="statusbar__spacer" />
            <span>{t('editor.spaces', { n: 4 })}</span>
            <span>{t('editor.encoding')}</span>
            <span>{t(languageMeta[language].labelKey)}</span>
            {engine && <span className={cx('statusbar__engine', engine === 'fallback' && 'is-fallback')}>{t(`editor.engine.${engine}` as const)}</span>}
          </div>
        </>
      ) : (
        <EmptyState
          icon="fileCode" title={t('editor.noFile')} text={t('editor.noFileText')}
          action={
            <dl className="shortcuts" aria-label={t('editor.shortcuts')}>
              <div><dt><kbd>Ctrl</kbd> + <kbd>S</kbd></dt><dd>{t('editor.shortcut.save')}</dd></div>
              <div><dt><kbd>Alt</kbd> + <kbd>W</kbd></dt><dd>{t('editor.shortcut.close')}</dd></div>
            </dl>
          }
        />
      )}

      <ConfirmDialog
        open={closing != null}
        title={t('editor.closeUnsavedTitle')}
        text={t('editor.closeUnsavedText', { name: closingName })}
        confirmLabel={t('editor.saveAndClose')}
        onCancel={() => setClosing(null)}
        onConfirm={async () => {
          const id = closing!;
          if (await files.save(id)) { files.closeTab(id); setClosing(null); }
        }}
        extra={<Button variant="danger" onClick={() => { files.closeTab(closing!); setClosing(null); }}>{t('editor.discard')}</Button>}
      />
    </div>
  );
}
