import { useEffect, useState } from 'react';
import { Spinner } from '../../../components/ui';
import { useT } from '../../../i18n';
import { FallbackEditor } from './FallbackEditor';
import { MonacoEditor } from './MonacoEditor';
import { loadMonaco, type MonacoApi } from './monacoLoader';
import type { EditorEngine, EditorProps } from './types';

type Load = { state: 'loading' } | { state: 'ready'; monaco: MonacoApi } | { state: 'failed' };

/** Монакоды жүктеп көреді; сәтсіз болса, резервтік редакторға ауысады және қай қозғалтқыш жұмыс істеп тұрғанын хабарлайды. */
export function CodeEditor(props: EditorProps & { onEngine: (e: EditorEngine) => void }) {
  const t = useT();
  const { onEngine, ...editorProps } = props;
  const [load, setLoad] = useState<Load>({ state: 'loading' });

  useEffect(() => {
    let alive = true;
    loadMonaco().then(
      (monaco) => { if (alive) setLoad({ state: 'ready', monaco }); },
      () => { if (alive) setLoad({ state: 'failed' }); },
    );
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (load.state === 'ready') onEngine('monaco');
    if (load.state === 'failed') onEngine('fallback');
  }, [load.state, onEngine]);

  if (load.state === 'loading') {
    return <div className="editor-loading" role="status"><Spinner size={22} /> <span>{t('editor.loading')}</span></div>;
  }
  if (load.state === 'failed') return <FallbackEditor {...editorProps} />;
  return <MonacoEditor monaco={load.monaco} {...editorProps} />;
}
