import type { FileLanguageId } from '../../../api/types';
import type { Theme } from '../../../theme/theme';
import type { DocSession } from '../../../collab/client';

/** Екі редактор қозғалтқышы (Monaco және резервтік) да осы келісімді орындайды. */
export interface EditorProps {
  /** Тұрақты кілт (файл түйінінің id-і): Monaco-да модель кілті */
  modelKey: string;
  language: FileLanguageId;
  value: string;
  readOnly: boolean;
  theme: Theme;
  ariaLabel: string;
  onChange: (value: string) => void;
  onCursor: (line: number, col: number) => void;
  onSave: () => void;
  /** Бірлескен құжат сессиясы: бар болса, мазмұнның көзі — CRDT (value тек бастапқы/резерв). Режим өмір бойы тұрақты (key). */
  collab?: DocSession | null;
  /** Жолға өту сұрауы (мысалы, «Қателер» тізімінен) */
  reveal?: { line: number; col: number; nonce: number } | null;
}

export type EditorEngine = 'monaco' | 'fallback';
