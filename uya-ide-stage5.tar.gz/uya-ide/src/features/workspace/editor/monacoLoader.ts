/**
 * Monaco Editor жүктеуші (AMD loader).
 *
 * Production-да Monaco-ны өз серверіңізден беру ұсынылады: `npm i monaco-editor`, `npm run build`
 * (build скрипті `node_modules/monaco-editor/min/vs` қалтасын `dist/vs` ішіне көшіреді)
 * және `public/config.js` ішінде `monacoBase: '/vs'` деп қойыңыз. Әдепкі — CDN (jsDelivr).
 *
 * Monaco жүктелмесе (желі жоқ, CSP бұғаттады, тайм-аут) — `loadMonaco` қабылданбайды, ал интерфейс
 * резервтік редакторға ауысады және бұл туралы пайдаланушыға ашық айтады.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type MonacoApi = any;

declare global {
  interface Window {
    monaco?: MonacoApi;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    require?: any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    MonacoEnvironment?: any;
  }
}

const DEFAULT_BASE = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.52.2/min/vs';
let pending: Promise<MonacoApi> | null = null;

export const monacoBase = () => (window.__UYA_CONFIG__?.monacoBase || DEFAULT_BASE).replace(/\/$/, '');

function injectScript(src: string, timeoutMs: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const el = document.createElement('script');
    const timer = window.setTimeout(() => { el.remove(); reject(new Error('monaco: timeout')); }, timeoutMs);
    el.src = src;
    el.async = true;
    el.onload = () => { window.clearTimeout(timer); resolve(); };
    el.onerror = () => { window.clearTimeout(timer); el.remove(); reject(new Error('monaco: loader failed')); };
    document.head.appendChild(el);
  });
}

export function loadMonaco(timeoutMs = 10_000): Promise<MonacoApi> {
  if (window.monaco?.editor) return Promise.resolve(window.monaco);
  if (pending) return pending;
  const base = monacoBase();
  pending = (async () => {
    await injectScript(`${base}/loader.js`, timeoutMs);
    const amdRequire = window.require;
    if (!amdRequire?.config) throw new Error('monaco: AMD loader missing');
    amdRequire.config({ paths: { vs: base } });
    // Worker-лар басқа origin-нен (CDN) жүктелгенде қажет стандартты айналма жол.
    window.MonacoEnvironment = {
      getWorkerUrl: () => `data:text/javascript;charset=utf-8,${encodeURIComponent(
        `self.MonacoEnvironment={baseUrl:'${base}/../'};importScripts('${base}/base/worker/workerMain.js');`,
      )}`,
    };
    await new Promise<void>((resolve, reject) => {
      const timer = window.setTimeout(() => reject(new Error('monaco: editor.main timeout')), timeoutMs);
      amdRequire(['vs/editor/editor.main'], () => { window.clearTimeout(timer); resolve(); }, (e: unknown) => { window.clearTimeout(timer); reject(e); });
    });
    defineThemes(window.monaco);
    return window.monaco as MonacoApi;
  })();
  // Сәтсіздікте кэшті тазалаймыз: кейінірек қайта әрекет жасауға болады.
  pending.catch(() => { pending = null; });
  return pending;
}

function defineThemes(monaco: MonacoApi) {
  monaco.editor.defineTheme('uya-dark', {
    base: 'vs-dark', inherit: true,
    rules: [
      { token: 'comment', foreground: '62768d', fontStyle: 'italic' },
      { token: 'keyword', foreground: 'c792ea' },
      { token: 'string', foreground: '9fd98b' },
      { token: 'number', foreground: 'f5a97f' },
      { token: 'type', foreground: '5ad6e4' },
      { token: 'delimiter', foreground: '8aa0b8' },
    ],
    colors: {
      'editor.background': '#0c141d', 'editor.foreground': '#e8eef6',
      'editorLineNumber.foreground': '#5a6c82', 'editorLineNumber.activeForeground': '#a2b3c7',
      'editor.lineHighlightBackground': '#a0bee60d', 'editor.selectionBackground': '#3cc6d638',
      'editorCursor.foreground': '#5ad6e4', 'editorIndentGuide.background1': '#1e2b3b',
      'editorWidget.background': '#142030', 'editorWidget.border': '#2c3d53',
    },
  });
  monaco.editor.defineTheme('uya-light', {
    base: 'vs', inherit: true,
    rules: [
      { token: 'comment', foreground: '8393a7', fontStyle: 'italic' },
      { token: 'keyword', foreground: '8a3fc0' },
      { token: 'string', foreground: '2f7d32' },
      { token: 'number', foreground: 'b4561b' },
      { token: 'type', foreground: '0b7488' },
    ],
    colors: {
      'editor.background': '#fbfcfe', 'editor.foreground': '#142030',
      'editorLineNumber.foreground': '#93a3b7', 'editor.lineHighlightBackground': '#14284612',
      'editor.selectionBackground': '#0b8da133', 'editorCursor.foreground': '#0b8da1',
    },
  });
}
