import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../../api';
import { ApiError, type FsNode } from '../../api/types';
import { t } from '../../i18n';
import { messageForError } from '../../i18n/format';
import { toast } from '../../state/toasts';
import type { CollabClient, DocSession } from '../../collab/client';

interface Buffer { saved: string; draft: string }

const errMsg = (err: unknown) =>
  messageForError(err instanceof ApiError ? err.code : 'unknown', err instanceof ApiError ? err.params : undefined);

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * Файл ағашы, ашық қойындылар және сақталмаған өзгерістер (draft).
 * - `collab` жоқ (демо режимі): мазмұн REST арқылы оқылып/сақталады (draft → «Сақтау»).
 * - `collab` бар: әр ашық файл — CRDT құжат сессиясы. `buffers[id]` сессия мәтінінің айнасы
 *   (Мәселелер/Іске қосу панельдері үшін), «сақталмаған» = серверге әлі жетпеген өзгерістер.
 *   Файл жүйесі өзгерістері (құру/атын өзгерту/жою) басқалардан WebSocket оқиғасымен келіп, ағашқа қолданылады.
 */
export function useFiles(projectId: string, canEdit: boolean, collab: CollabClient | null = null) {
  const [nodes, setNodes] = useState<FsNode[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [openIds, setOpenIds] = useState<string[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [buffers, setBuffers] = useState<Record<string, Buffer>>({});
  const [loadingIds, setLoadingIds] = useState<string[]>([]);
  const [savingIds, setSavingIds] = useState<string[]>([]);
  const [pendingIds, setPendingIds] = useState<Record<string, number>>({});
  const [readyIds, setReadyIds] = useState<Record<string, boolean>>({});
  const sessions = useRef(new Map<string, { session: DocSession; off: () => void }>());
  const nodesRef = useRef(nodes);
  nodesRef.current = nodes;
  const buffersRef = useRef(buffers);
  buffersRef.current = buffers;
  const openIdsRef = useRef(openIds);
  openIdsRef.current = openIds;

  const load = useCallback(async () => {
    try {
      const tree = await api.files.tree(projectId);
      setNodes(tree);
      setStatus('ready');
      return tree;
    } catch {
      setStatus('error');
      return [] as FsNode[];
    }
  }, [projectId]);

  useEffect(() => { void load(); }, [load]);

  const byId = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);

  const pathOf = useCallback((id: string): string => {
    const parts: string[] = [];
    let cur = byId.get(id);
    let guard = 0;
    while (cur && guard++ < 64) {
      parts.unshift(cur.name);
      cur = cur.parentId ? byId.get(cur.parentId) : undefined;
    }
    return parts.join('/');
  }, [byId]);

  const findByPath = useCallback((path: string): FsNode | undefined => {
    const parts = path.split('/');
    let parent: string | null = null;
    let found: FsNode | undefined;
    for (const part of parts) {
      found = nodesRef.current.find((n) => n.parentId === parent && n.name === part);
      if (!found) return undefined;
      parent = found.id;
    }
    return found;
  }, []);

  const descendantsOf = useCallback((id: string): string[] => {
    const out: string[] = [];
    const walk = (pid: string) => nodesRef.current.filter((n) => n.parentId === pid).forEach((c) => { out.push(c.id); walk(c.id); });
    walk(id);
    return out;
  }, []);

  const attach = useCallback((id: string) => {
    if (!collab || sessions.current.has(id)) return;
    const session = collab.openDoc(id);
    const sync = () => {
      if (session.ready) {
        const text = session.text();
        setBuffers((b) => (b[id] && b[id].draft === text && b[id].saved === text ? b : { ...b, [id]: { saved: text, draft: text } }));
      }
      setPendingIds((p) => ((p[id] ?? 0) === session.pending ? p : { ...p, [id]: session.pending }));
      setReadyIds((r) => (r[id] === session.ready ? r : { ...r, [id]: session.ready }));
    };
    const off = session.subscribe((e) => { if (e.kind !== 'cursors') sync(); });
    sessions.current.set(id, { session, off });
    sync();
  }, [collab]);

  const detach = useCallback((id: string) => {
    const s = sessions.current.get(id);
    if (!s) return;
    s.off(); sessions.current.delete(id);
    collab?.closeDoc(id);
    setPendingIds((p) => { if (!(id in p)) return p; const { [id]: _d, ...rest } = p; return rest; });
    setReadyIds((r) => { if (!(id in r)) return r; const { [id]: _d, ...rest } = r; return rest; });
  }, [collab]);

  // Қосылым/клиент ауысқанда немесе хук жойылғанда барлық сессияны жабу
  useEffect(() => () => {
    for (const id of [...sessions.current.keys()]) { const s = sessions.current.get(id)!; s.off(); }
    sessions.current.clear();
  }, [collab]);

  // Клиент кейін дайын болса (алғашқы рендерде null), ашық файлдарды қосамыз
  useEffect(() => {
    if (!collab) return;
    for (const id of openIds) if (buffersRef.current[id]) attach(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collab]);

  const openFile = useCallback(async (id: string) => {
    const node = nodesRef.current.find((n) => n.id === id);
    if (!node || node.kind !== 'file') return;
    setOpenIds((ids) => (ids.includes(id) ? ids : [...ids, id]));
    setActiveId(id);
    if (buffersRef.current[id]) { attach(id); return; }
    setLoadingIds((l) => [...l, id]);
    try {
      const content = await api.files.read(projectId, id);
      setBuffers((b) => (b[id] ? b : { ...b, [id]: { saved: content, draft: content } }));
      attach(id);
    } catch (err) {
      toast(errMsg(err), 'error');
      setOpenIds((ids) => ids.filter((x) => x !== id));
      setActiveId((cur) => (cur === id ? null : cur));
    } finally {
      setLoadingIds((l) => l.filter((x) => x !== id));
    }
  }, [projectId, attach]);

  const closeTab = useCallback((id: string) => {
    detach(id);
    setOpenIds((ids) => {
      const i = ids.indexOf(id);
      if (i < 0) return ids;
      const next = ids.filter((x) => x !== id);
      setActiveId((cur) => (cur === id ? (next[i] ?? next[i - 1] ?? null) : cur));
      return next;
    });
    setBuffers((b) => {
      if (!(id in b)) return b;
      const { [id]: _drop, ...rest } = b;
      return rest;
    });
  }, [detach]);

  const setDraft = useCallback((id: string, draft: string) => {
    if (sessions.current.get(id)?.session.ready) return; // бірлескен құжаттың айнасын сессияның өзі жаңартады
    setBuffers((b) => (b[id] && b[id].draft !== draft ? { ...b, [id]: { ...b[id], draft } } : b));
  }, []);

  const save = useCallback(async (id: string): Promise<boolean> => {
    const live = sessions.current.get(id)?.session;
    if (live?.ready) {
      // Бірлескен режим: өзгерістер автоматты түрде серверге жіберіледі; «Сақтау» — жетуін күту.
      if (!canEdit) { toast(t('editor.readOnlyHint'), 'warning'); return false; }
      if (collab?.status !== 'connected') { toast(t('collab.saveOffline'), 'warning'); return false; }
      setSavingIds((s) => [...s, id]);
      try {
        const end = Date.now() + 6000;
        while (live.pending > 0 && Date.now() < end) await sleep(40);
        if (live.pending > 0) { toast(t('collab.saveOffline'), 'warning'); return false; }
        const name = nodesRef.current.find((n) => n.id === id)?.name ?? '';
        toast(t('editor.saved', { name }), 'success', 2200);
        return true;
      } finally { setSavingIds((s) => s.filter((x) => x !== id)); }
    }
    const buf = buffersRef.current[id];
    if (!buf || buf.draft === buf.saved) return true;
    if (!canEdit) { toast(t('editor.readOnlyHint'), 'warning'); return false; }
    const content = buf.draft;
    setSavingIds((s) => [...s, id]);
    try {
      await api.files.save(projectId, id, content);
      setBuffers((b) => (b[id] ? { ...b, [id]: { ...b[id], saved: content } } : b));
      const name = nodesRef.current.find((n) => n.id === id)?.name ?? '';
      toast(t('editor.saved', { name }), 'success', 2200);
      return true;
    } catch (err) {
      toast(errMsg(err), 'error');
      return false;
    } finally {
      setSavingIds((s) => s.filter((x) => x !== id));
    }
  }, [projectId, canEdit, collab]);

  const discard = useCallback((id: string) => {
    if (sessions.current.get(id)?.session.ready) return;
    setBuffers((b) => (b[id] ? { ...b, [id]: { ...b[id], draft: b[id].saved } } : b));
  }, []);

  const createNode = useCallback(async (parentId: string | null, name: string, kind: FsNode['kind']) => {
    const node = await api.files.create(projectId, parentId, name.trim(), kind);
    setNodes((list) => (list.some((n) => n.id === node.id) ? list : [...list, node]));
    toast(t('explorer.created', { name: node.name }), 'success', 2200);
    if (kind === 'file') {
      setBuffers((b) => ({ ...b, [node.id]: { saved: '', draft: '' } }));
      setOpenIds((ids) => (ids.includes(node.id) ? ids : [...ids, node.id]));
      setActiveId(node.id);
      attach(node.id);
    }
    return node;
  }, [projectId, attach]);

  const renameNode = useCallback(async (id: string, name: string) => {
    const node = await api.files.rename(projectId, id, name.trim());
    setNodes((list) => list.map((n) => (n.id === id ? node : n)));
    toast(t('explorer.renamed'), 'success', 2000);
    return node;
  }, [projectId]);

  const deleteNode = useCallback(async (id: string) => {
    const node = nodesRef.current.find((n) => n.id === id);
    const gone = new Set([id, ...descendantsOf(id)]);
    await api.files.remove(projectId, id);
    for (const g of gone) detach(g);
    setNodes((list) => list.filter((n) => !gone.has(n.id)));
    setOpenIds((ids) => {
      const next = ids.filter((x) => !gone.has(x));
      setActiveId((cur) => (cur && gone.has(cur) ? (next[next.length - 1] ?? null) : cur));
      return next;
    });
    setBuffers((b) => Object.fromEntries(Object.entries(b).filter(([k]) => !gone.has(k))));
    toast(t('explorer.deleted', { name: node?.name ?? '' }), 'success', 2200);
  }, [projectId, descendantsOf, detach]);

  /** Басқа қатысушының файл жүйесі өзгерісі (WebSocket): ағашқа бірден қолданылады, қайта жүктеусіз. */
  const applyRemoteFs = useCallback((fs: import('../../collab/client').FsEvent, myId: string | undefined) => {
    if (fs.event === 'created') { setNodes((l) => (l.some((n) => n.id === fs.node.id) ? l : [...l, fs.node])); return; }
    if (fs.event === 'renamed') { setNodes((l) => l.map((n) => (n.id === fs.node.id ? { ...n, ...fs.node } : n))); return; }
    const gone = new Set([fs.id, ...fs.fileIds, ...descendantsOf(fs.id)]);
    const hit = nodesRef.current.find((n) => n.id === fs.id);
    const affectsOpen = [...gone].some((g) => openIdsRef.current.includes(g));
    for (const g of gone) detach(g);
    setNodes((l) => l.filter((n) => !gone.has(n.id)));
    setOpenIds((ids) => {
      const next = ids.filter((x) => !gone.has(x));
      setActiveId((cur) => (cur && gone.has(cur) ? (next[next.length - 1] ?? null) : cur));
      return next;
    });
    setBuffers((b) => Object.fromEntries(Object.entries(b).filter(([k]) => !gone.has(k))));
    if (affectsOpen && fs.by !== myId) toast(t('collab.fileDeleted', { name: hit?.name ?? '' }), 'warning', 4000);
  }, [descendantsOf, detach]);

  const wasDown = useRef(false);
  useEffect(() => {
    if (!collab) return undefined;
    return collab.on((e) => {
      if (e.type === 'fs') applyRemoteFs(e.fs, collab.me?.userId);
      if (e.type === 'status') {
        if (e.status === 'reconnecting') wasDown.current = true;
        // Ажырап тұрғанда басқалар файл жүйесін өзгерткен болуы мүмкін: қосылғанда ағашты жаңартамыз
        if (e.status === 'connected' && wasDown.current) { wasDown.current = false; void load(); }
      }
    });
  }, [collab, applyRemoteFs, load]);

  const dirtyIds = useMemo(() => {
    const ids = new Set((Object.entries(buffers) as Array<[string, Buffer]>).filter(([, b]) => b.draft !== b.saved).map(([k]) => k));
    for (const [k, n] of Object.entries(pendingIds) as Array<[string, number]>) if (n > 0) ids.add(k);
    return ids;
  }, [buffers, pendingIds]);

  /** Файл бірлескен құжат ретінде дайын болса — сессия (редактор осыған байланады). */
  const sessionOf = useCallback((id: string): DocSession | null => {
    const s = sessions.current.get(id)?.session;
    return s && readyIds[id] ? s : null;
  }, [readyIds]);

  return {
    nodes, status, reload: load, byId, pathOf, findByPath, descendantsOf,
    openIds, activeId, setActiveId, openFile, closeTab,
    buffers, loadingIds, savingIds, dirtyIds, setDraft, save, discard, sessionOf, collab,
    createNode, renameNode, deleteNode,
  };
}

export type FilesApi = ReturnType<typeof useFiles>;
