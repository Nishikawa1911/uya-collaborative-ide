import type { FileLanguageId } from '../../api/types';
import { t } from '../../i18n';
import { tokenize } from './editor/highlight';

export type Severity = 'error' | 'warning' | 'info';
export interface Problem {
  id: string;
  severity: Severity;
  message: string;
  line: number;
  col: number;
}

/** Жақшаларды тексеретін тілдер (HTML/Markdown/мәтін үшін мағынасыз). */
const BRACKET_LANGS = new Set<FileLanguageId>(['python', 'java', 'go', 'cpp', 'csharp', 'rust', 'php', 'typescript', 'javascript', 'sql', 'css', 'json']);
const PAIRS: Record<string, string> = { ')': '(', ']': '[', '}': '{' };
const OPENERS = new Set(['(', '[', '{']);
const MAX = 100;

/**
 * Жергілікті жылдам тексеру: теңгерімсіз жақшалар, TODO/FIXME белгілері, жол соңындағы бос орын.
 * ЕСКЕРТУ: бұл компилятор емес. Нақты компиляция/интерпретатор қателері орындау қызметі қосылғанда келеді.
 */
export function findProblems(code: string, lang: FileLanguageId): Problem[] {
  const problems: Problem[] = [];
  const push = (severity: Severity, message: string, line: number, col: number) => {
    if (problems.length < MAX) problems.push({ id: `${severity}:${line}:${col}:${problems.length}`, severity, message, line, col });
  };

  const tokens = tokenize(code, lang);
  const checkBrackets = BRACKET_LANGS.has(lang);
  const stack: Array<{ ch: string; line: number; col: number }> = [];
  let line = 1;
  let col = 1;

  for (const tok of tokens) {
    const skip = tok.type === 'string' || tok.type === 'comment';
    if (tok.type === 'comment') {
      const todo = /\b(TODO|FIXME|XXX)\b[:\s]*(.*)/.exec(tok.text);
      if (todo) {
        const before = tok.text.slice(0, todo.index);
        const nl = before.split('\n');
        const tLine = line + nl.length - 1;
        const tCol = (nl.length === 1 ? col : 1) + nl[nl.length - 1].length;
        push('info', t('problems.todo', { text: (todo[2] || todo[1]).trim().slice(0, 80) }), tLine, tCol);
      }
    }
    for (const ch of tok.text) {
      if (checkBrackets && !skip) {
        if (OPENERS.has(ch)) stack.push({ ch, line, col });
        else if (ch in PAIRS) {
          if (stack.length && stack[stack.length - 1].ch === PAIRS[ch]) stack.pop();
          else push('error', t('problems.unexpected', { ch }), line, col);
        }
      }
      if (ch === '\n') { line++; col = 1; } else col++;
    }
  }
  for (const open of stack) push('error', t('problems.unclosed', { ch: open.ch }), open.line, open.col);

  if (lang !== 'markdown') {
    code.split('\n').forEach((text, i) => {
      if (/\S[ \t]+$/.test(text)) push('warning', t('problems.trailing'), i + 1, text.replace(/[ \t]+$/, '').length + 1);
    });
  }

  return problems.sort((a, b) => a.line - b.line || a.col - b.col);
}
