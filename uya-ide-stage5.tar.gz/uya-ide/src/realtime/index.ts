import type { RealtimeClient } from './contracts';
import { demoRealtime } from './demoClient';

/** Бэкэнд дайын болғанда: `export const realtime: RealtimeClient = createWsRealtime(config.wsUrl)`. */
export const realtime: RealtimeClient = demoRealtime;
export type { RealtimeClient, RealtimeSession, RealtimeStatus, ServerEvent, ClientEvent } from './contracts';
