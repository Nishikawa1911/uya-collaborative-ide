import type { ChatMessage, FsNode, ProjectMember, Role } from '../api/types';

/**
 * Нақты уақыт интеграция нүктесі (спецификацияның 7-бөлімі).
 * - Yjs арнасы: wss://rt…/yjs/:projectId/:nodeId  (екілік протокол, құжат бойынша бөлек)
 * - Жоба арнасы: wss://rt…/project/:projectId     (JSON оқиғалар: presence, chat, fs, members, run, term)
 *
 * Прототипте `status` әрқашан 'demo' — интерфейс мұны пайдаланушыға ашық көрсетеді.
 */
export type RealtimeStatus = 'demo' | 'connecting' | 'connected' | 'reconnecting' | 'disconnected';

/** S→C оқиғалар (қысқартылған: spec 7.2 кестесіне сәйкес). */
export type ServerEvent =
  | { type: 'presence.snapshot'; payload: { users: ProjectMember[] } }
  | { type: 'presence.joined'; payload: { user: ProjectMember } }
  | { type: 'presence.left'; payload: { userId: string } }
  | { type: 'presence.editing'; payload: { fileId: string; userIds: string[] } }
  | { type: 'chat.message'; payload: ChatMessage }
  | { type: 'fs.changed'; payload: { op: 'create' | 'rename' | 'delete' | 'move'; node: FsNode; by: string } }
  | { type: 'members.changed'; payload: { userId: string; role?: Role; removed?: boolean } }
  | { type: 'session.revoked'; payload: { reason: string } };

/** C→S оқиғалар. */
export type ClientEvent =
  | { type: 'presence.hello'; payload: { activeFileId: string | null } }
  | { type: 'presence.active_file'; payload: { fileId: string | null } }
  | { type: 'chat.send'; payload: { body: string; clientId: string } };

export interface RealtimeSession {
  readonly status: RealtimeStatus;
  send(event: ClientEvent): void;
  on(listener: (event: ServerEvent) => void): () => void;
  onStatus(listener: (status: RealtimeStatus) => void): () => void;
  close(): void;
}

export interface RealtimeClient {
  connect(projectId: string): RealtimeSession;
}

/** Yjs құжатына байланыстыру нүктесі: редактор осы интерфейс арқылы бірлескен күйді алады. */
export interface CollabBinding {
  /** Mонaco моделін Yjs-пен байланыстыру (y-monaco). Прототипте жоқ. */
  bind(editor: unknown, model: unknown, nodeId: string): { destroy(): void };
}
