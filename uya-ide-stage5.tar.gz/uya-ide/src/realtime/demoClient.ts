import type { ClientEvent, RealtimeClient, RealtimeSession, RealtimeStatus, ServerEvent } from './contracts';

/**
 * Прототип үшін «қосылымсыз» клиент: ешқандай желі сұрауын жасамайды және
 * ешқандай оқиға жасамайды. Күйі 'demo' — интерфейс осыған қарап «үлгі деректер» ескертуін көрсетеді.
 * Нақты WebSocket клиентін (Hocuspocus/y-websocket) осы интерфейс бойынша жазып, `realtime/index.ts`-те ауыстырыңыз.
 */
class DemoSession implements RealtimeSession {
  readonly status: RealtimeStatus = 'demo';
  send(_event: ClientEvent) {
    /* сервер жоқ — жіберілмейді */
  }
  on(_listener: (e: ServerEvent) => void) {
    return () => {};
  }
  onStatus(listener: (s: RealtimeStatus) => void) {
    listener('demo');
    return () => {};
  }
  close() {}
}

export const demoRealtime: RealtimeClient = {
  connect: () => new DemoSession(),
};
