import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactElement, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { cx } from '../../lib/utils';
import { Icon, type IconName } from './Icon';

export interface MenuItem {
  id: string;
  label: string;
  icon?: IconName;
  hint?: string;
  danger?: boolean;
  disabled?: boolean;
  checked?: boolean;
  separatorBefore?: boolean;
  onSelect: () => void;
}

interface PopoverProps {
  items: MenuItem[];
  x: number;
  y: number;
  /** Триггердің оң жақ шеті бойынша туралау */
  alignRight?: boolean;
  onClose: () => void;
  label?: string;
}

/** Портал арқылы fixed орналасатын мәзір: overflow:hidden панельдерден қиылмайды. */
function MenuPopover({ items, x, y, alignRight, onClose, label }: PopoverProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ left: x, top: y });
  const [active, setActive] = useState(() => Math.max(0, items.findIndex((i) => !i.disabled)));

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const { width, height } = el.getBoundingClientRect();
    let left = alignRight ? x - width : x;
    let top = y;
    left = Math.min(Math.max(8, left), window.innerWidth - width - 8);
    if (top + height > window.innerHeight - 8) top = Math.max(8, window.innerHeight - height - 8);
    setPos({ left, top });
  }, [x, y, alignRight, items.length]);

  useEffect(() => {
    ref.current?.focus();
    const onDown = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) onClose(); };
    const onScroll = () => onClose();
    document.addEventListener('mousedown', onDown, true);
    window.addEventListener('resize', onScroll);
    window.addEventListener('blur', onScroll);
    return () => {
      document.removeEventListener('mousedown', onDown, true);
      window.removeEventListener('resize', onScroll);
      window.removeEventListener('blur', onScroll);
    };
  }, [onClose]);

  const move = (dir: 1 | -1) => {
    let i = active;
    for (let n = 0; n < items.length; n++) {
      i = (i + dir + items.length) % items.length;
      if (!items[i].disabled) break;
    }
    setActive(i);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); onClose(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      const item = items[active];
      if (item && !item.disabled) { onClose(); item.onSelect(); }
    } else if (e.key === 'Tab') onClose();
  };

  return createPortal(
    <div ref={ref} className="menu" role="menu" aria-label={label} tabIndex={-1} style={{ left: pos.left, top: pos.top }} onKeyDown={onKeyDown}>
      {items.map((item, i) => (
        <div key={item.id}>
          {item.separatorBefore && <div className="menu__sep" role="separator" />}
          <button
            type="button"
            role="menuitem"
            className={cx('menu__item', item.danger && 'menu__item--danger', i === active && 'is-active')}
            disabled={item.disabled}
            onMouseEnter={() => !item.disabled && setActive(i)}
            onClick={() => { onClose(); item.onSelect(); }}
          >
            <span className="menu__icon">{item.checked ? <Icon name="check" size={14} /> : item.icon ? <Icon name={item.icon} size={14} /> : null}</span>
            <span className="menu__label">{item.label}</span>
            {item.hint && <span className="menu__hint">{item.hint}</span>}
          </button>
        </div>
      ))}
    </div>,
    document.body,
  );
}

interface MenuProps {
  items: MenuItem[];
  /** Триггер элементі: onClick пен aria атрибуттарын осы компонент береді */
  trigger: (props: { onClick: (e: React.MouseEvent<HTMLElement>) => void; 'aria-haspopup': 'menu'; 'aria-expanded': boolean }) => ReactElement;
  label?: string;
  alignRight?: boolean;
}

/** Түймеден ашылатын мәзір. */
export function Menu({ items, trigger, label, alignRight = true }: MenuProps) {
  const [anchor, setAnchor] = useState<{ x: number; y: number } | null>(null);
  const close = useCallback(() => setAnchor(null), []);
  return (
    <>
      {trigger({
        onClick: (e) => {
          const r = e.currentTarget.getBoundingClientRect();
          setAnchor(anchor ? null : { x: alignRight ? r.right : r.left, y: r.bottom + 6 });
        },
        'aria-haspopup': 'menu',
        'aria-expanded': anchor != null,
      })}
      {anchor && <MenuPopover items={items} x={anchor.x} y={anchor.y} alignRight={alignRight} onClose={close} label={label} />}
    </>
  );
}

/** Тінтуір оң жақ батырмасымен ашылатын мәзір (файл ағашы үшін). */
export function useContextMenu(): {
  open: (e: { clientX: number; clientY: number; preventDefault(): void }, items: MenuItem[]) => void;
  element: ReactNode;
} {
  const [state, setState] = useState<{ x: number; y: number; items: MenuItem[] } | null>(null);
  const close = useCallback(() => setState(null), []);
  return {
    open: (e, items) => {
      e.preventDefault();
      setState({ x: e.clientX, y: e.clientY, items });
    },
    element: state ? <MenuPopover items={state.items} x={state.x} y={state.y} onClose={close} /> : null,
  };
}
