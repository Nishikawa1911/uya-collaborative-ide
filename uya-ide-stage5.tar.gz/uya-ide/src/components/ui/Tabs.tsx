import { useRef, type KeyboardEvent, type ReactNode } from 'react';
import { cx } from '../../lib/utils';
import { Icon, type IconName } from './Icon';

export interface TabItem<Id extends string = string> {
  id: Id;
  label: string;
  icon?: IconName;
  count?: number | string;
  badgeTone?: 'danger' | 'warning' | 'neutral';
}

interface TabsProps<Id extends string> {
  items: Array<TabItem<Id>>;
  value: Id;
  onChange: (id: Id) => void;
  label: string;
  variant?: 'underline' | 'pill';
  className?: string;
  /** Оң жақтағы қосымша басқару элементтері */
  trailing?: ReactNode;
  idPrefix?: string;
}

/** ARIA tablist: ←/→/Home/End пернелерімен навигация. */
export function Tabs<Id extends string>({ items, value, onChange, label, variant = 'underline', className, trailing, idPrefix = 'tab' }: TabsProps<Id>) {
  const refs = useRef<Record<string, HTMLButtonElement | null>>({});
  const onKey = (e: KeyboardEvent) => {
    const idx = items.findIndex((i) => i.id === value);
    let next = idx;
    if (e.key === 'ArrowRight') next = (idx + 1) % items.length;
    else if (e.key === 'ArrowLeft') next = (idx - 1 + items.length) % items.length;
    else if (e.key === 'Home') next = 0;
    else if (e.key === 'End') next = items.length - 1;
    else return;
    e.preventDefault();
    onChange(items[next].id);
    refs.current[items[next].id]?.focus();
  };
  return (
    <div className={cx('tabs', `tabs--${variant}`, className)}>
      <div className="tabs__list" role="tablist" aria-label={label} onKeyDown={onKey}>
        {items.map((item) => {
          const selected = item.id === value;
          return (
            <button
              key={item.id}
              ref={(el) => { refs.current[item.id] = el; }}
              type="button"
              role="tab"
              id={`${idPrefix}-${item.id}`}
              aria-selected={selected}
              aria-controls={`${idPrefix}-panel-${item.id}`}
              tabIndex={selected ? 0 : -1}
              className={cx('tabs__tab', selected && 'is-selected')}
              onClick={() => onChange(item.id)}
            >
              {item.icon && <Icon name={item.icon} size={15} />}
              <span>{item.label}</span>
              {item.count != null && <span className={cx('tabs__count', item.badgeTone && `tabs__count--${item.badgeTone}`)}>{item.count}</span>}
            </button>
          );
        })}
      </div>
      {trailing && <div className="tabs__trailing">{trailing}</div>}
    </div>
  );
}

interface SegmentedProps<Id extends string> {
  items: Array<{ id: Id; label: string; icon?: IconName }>;
  value: Id;
  onChange: (id: Id) => void;
  label: string;
}

export function SegmentedControl<Id extends string>({ items, value, onChange, label }: SegmentedProps<Id>) {
  return (
    <div className="segmented" role="radiogroup" aria-label={label}>
      {items.map((i) => (
        <button
          key={i.id}
          type="button"
          role="radio"
          aria-checked={i.id === value}
          className={cx('segmented__item', i.id === value && 'is-selected')}
          onClick={() => onChange(i.id)}
        >
          {i.icon && <Icon name={i.icon} size={15} />}
          {i.label}
        </button>
      ))}
    </div>
  );
}
