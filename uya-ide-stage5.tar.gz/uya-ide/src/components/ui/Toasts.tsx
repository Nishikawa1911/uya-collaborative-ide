import { dismissToast, toastStore, type ToastKind } from '../../state/toasts';
import { useStore } from '../../state/createStore';
import { useT } from '../../i18n';
import { Icon, type IconName } from './Icon';

const iconFor: Record<ToastKind, IconName> = { success: 'success', error: 'error', info: 'info', warning: 'warning' };

export function ToastRegion() {
  const t = useT();
  const toasts = useStore(toastStore, (s) => s);
  return (
    <div className="toast-region" aria-live="polite" aria-atomic="false">
      {toasts.map((toast) => (
        <div key={toast.id} className={`toast toast--${toast.kind}`} role={toast.kind === 'error' ? 'alert' : 'status'}>
          <Icon name={iconFor[toast.kind]} size={17} />
          <span className="toast__text">{toast.message}</span>
          <button type="button" className="toast__close" onClick={() => dismissToast(toast.id)} aria-label={t('common.close')} title={t('common.close')}>
            <Icon name="close" size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
