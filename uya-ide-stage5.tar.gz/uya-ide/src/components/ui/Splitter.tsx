import { useRef, type KeyboardEvent, type PointerEvent } from 'react';
import { cx } from '../../lib/utils';
import { useT } from '../../i18n';

interface SplitterProps {
  /** 'vertical' — тік сызық (ені өзгереді), 'horizontal' — көлденең сызық (биіктігі өзгереді) */
  orientation: 'vertical' | 'horizontal';
  /** Пикселдегі жылжу (оң = оңға/төмен). Ата-ана өлшемді өзі шектейді. */
  onDelta: (deltaPx: number) => void;
  onCommit?: () => void;
  label?: string;
  className?: string;
}

/** Өлшемін өзгертетін бөлгіш: тінтуір/сенсор (pointer capture) және пернетақта (←→↑↓). */
export function Splitter({ orientation, onDelta, onCommit, label, className }: SplitterProps) {
  const t = useT();
  const last = useRef(0);
  const dragging = useRef(false);
  const axis = orientation === 'vertical' ? 'clientX' : 'clientY';

  const onDown = (e: PointerEvent<HTMLDivElement>) => {
    dragging.current = true;
    last.current = e[axis];
    e.currentTarget.setPointerCapture(e.pointerId);
    document.body.style.userSelect = 'none';
    document.body.style.cursor = orientation === 'vertical' ? 'col-resize' : 'row-resize';
  };
  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!dragging.current) return;
    const d = e[axis] - last.current;
    last.current = e[axis];
    if (d) onDelta(d);
  };
  const end = (e: PointerEvent<HTMLDivElement>) => {
    if (!dragging.current) return;
    dragging.current = false;
    e.currentTarget.releasePointerCapture(e.pointerId);
    document.body.style.userSelect = '';
    document.body.style.cursor = '';
    onCommit?.();
  };
  const onKey = (e: KeyboardEvent) => {
    const step = e.shiftKey ? 40 : 12;
    const keys: Record<string, number> = orientation === 'vertical' ? { ArrowLeft: -step, ArrowRight: step } : { ArrowUp: -step, ArrowDown: step };
    const d = keys[e.key];
    if (d == null) return;
    e.preventDefault();
    onDelta(d);
    onCommit?.();
  };

  return (
    <div
      role="separator"
      aria-orientation={orientation === 'vertical' ? 'vertical' : 'horizontal'}
      aria-label={label ?? t('ws.resize')}
      tabIndex={0}
      className={cx('splitter', `splitter--${orientation}`, className)}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={end}
      onPointerCancel={end}
      onKeyDown={onKey}
    />
  );
}
