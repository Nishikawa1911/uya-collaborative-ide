import type { ReactNode } from 'react';
import { cx } from '../../lib/utils';
import { useT } from '../../i18n';
import { Icon, type IconName } from './Icon';

export function Spinner({ size = 18 }: { size?: number }) {
  const t = useT();
  return <span className="spinner" style={{ width: size, height: size }} role="status" aria-label={t('common.loading')} />;
}

export function Skeleton({ height = 16, width = '100%', radius = 6 }: { height?: number; width?: number | string; radius?: number }) {
  return <span className="skeleton" style={{ height, width, borderRadius: radius }} aria-hidden="true" />;
}

interface EmptyStateProps {
  icon?: IconName;
  title: string;
  text?: string;
  action?: ReactNode;
}
export function EmptyState({ icon = 'folder', title, text, action }: EmptyStateProps) {
  return (
    <div className="empty-state">
      <div className="empty-state__icon"><Icon name={icon} size={26} /></div>
      <h3>{title}</h3>
      {text && <p>{text}</p>}
      {action && <div className="empty-state__action">{action}</div>}
    </div>
  );
}

type AlertKind = 'info' | 'warning' | 'error' | 'success';
const alertIcon: Record<AlertKind, IconName> = { info: 'info', warning: 'warning', error: 'alert', success: 'success' };

interface AlertProps {
  kind?: AlertKind;
  title?: string;
  children?: ReactNode;
  action?: ReactNode;
  onDismiss?: () => void;
  dismissLabel?: string;
  className?: string;
  'data-testid'?: string;
}
export function Alert({ kind = 'info', title, children, action, onDismiss, dismissLabel, className, 'data-testid': testId }: AlertProps) {
  const t = useT();
  const closeLabel = dismissLabel ?? t('common.close');
  return (
    <div className={cx('alert', `alert--${kind}`, className)} role={kind === 'error' ? 'alert' : 'status'} data-testid={testId}>
      <Icon name={alertIcon[kind]} size={17} className="alert__icon" />
      <div className="alert__body">
        {title && <strong>{title}</strong>}
        {children && <div>{children}</div>}
      </div>
      {action}
      {onDismiss && (
        <button type="button" className="alert__close" onClick={onDismiss} aria-label={closeLabel} title={closeLabel}>
          <Icon name="close" size={14} />
        </button>
      )}
    </div>
  );
}
