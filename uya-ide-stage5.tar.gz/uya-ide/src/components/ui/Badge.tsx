import type { ReactNode } from 'react';
import type { FileLanguageId, Role } from '../../api/types';
import { languageMeta } from '../../lib/languages';
import { cx } from '../../lib/utils';
import { useT } from '../../i18n';
import { Icon } from './Icon';

type Tone = 'neutral' | 'accent' | 'gold' | 'success' | 'danger' | 'info';

export function Badge({ tone = 'neutral', children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return <span className={cx('badge', `badge--${tone}`, className)}>{children}</span>;
}

/** Тіл белгісі: түсті нүкте + атау. */
export function LanguageChip({ language, compact }: { language: FileLanguageId; compact?: boolean }) {
  const t = useT();
  const meta = languageMeta[language];
  return (
    <span className={cx('lang-chip', compact && 'lang-chip--compact')}>
      <span className="lang-chip__dot" style={{ background: meta.color }} aria-hidden="true" />
      {t(meta.labelKey)}
    </span>
  );
}

const roleTone: Record<Role, Tone> = { owner: 'gold', editor: 'accent', viewer: 'neutral' };

export function RoleBadge({ role }: { role: Role }) {
  const t = useT();
  return (
    <Badge tone={roleTone[role]}>
      {role === 'owner' && <Icon name="crown" size={11} />}
      {t(`role.${role}` as const)}
    </Badge>
  );
}
