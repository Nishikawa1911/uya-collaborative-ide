import { useEffect, useRef, useState } from 'react';
import { useT } from '../../i18n';
import { toast } from '../../state/toasts';
import { Button } from './Button';

async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Резерв: ескі браузерлер / рұқсатсыз контекст
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    ta.remove();
    return ok;
  }
}

export function CopyButton({ text, label }: { text: string; label?: string }) {
  const t = useT();
  const [copied, setCopied] = useState(false);
  const timer = useRef<number>();
  useEffect(() => () => window.clearTimeout(timer.current), []);
  return (
    <Button
      variant="secondary"
      size="sm"
      icon={copied ? 'check' : 'copy'}
      onClick={async () => {
        const ok = await copyText(text);
        if (!ok) { toast(t('errors.unknown'), 'error'); return; }
        setCopied(true);
        window.clearTimeout(timer.current);
        timer.current = window.setTimeout(() => setCopied(false), 1800);
      }}
    >
      {copied ? t('common.copied') : label ?? t('common.copy')}
    </Button>
  );
}
