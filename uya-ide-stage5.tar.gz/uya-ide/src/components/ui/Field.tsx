import {
  forwardRef, useId, useState, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes,
} from 'react';
import { cx } from '../../lib/utils';
import { useT } from '../../i18n';
import { Icon, type IconName } from './Icon';

interface FieldProps {
  label: string;
  htmlFor: string;
  hint?: string;
  error?: string;
  optional?: boolean;
  children: ReactNode;
  className?: string;
}

/** Белгі + көмекші мәтін + қате хабарламасы. Қате aria-describedby арқылы байланысады. */
export function Field({ label, htmlFor, hint, error, optional, children, className }: FieldProps) {
  const t = useT();
  return (
    <div className={cx('field', error && 'field--error', className)}>
      <label className="field__label" htmlFor={htmlFor}>
        {label}
        {optional && <span className="field__optional"> · {t('common.optional')}</span>}
      </label>
      {children}
      {error ? (
        <p className="field__error" id={`${htmlFor}-error`} role="alert">
          <Icon name="alert" size={13} /> {error}
        </p>
      ) : hint ? (
        <p className="field__hint" id={`${htmlFor}-hint`}>{hint}</p>
      ) : null}
    </div>
  );
}

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  icon?: IconName;
  invalid?: boolean;
  trailing?: ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { icon, invalid, trailing, className, id, ...rest }, ref,
) {
  return (
    <div className={cx('input-wrap', invalid && 'input-wrap--error', className)}>
      {icon && <Icon name={icon} size={16} className="input-wrap__icon" />}
      <input
        ref={ref}
        id={id}
        className={cx('input', icon && 'input--with-icon', trailing && 'input--with-trailing')}
        aria-invalid={invalid || undefined}
        aria-describedby={id ? (invalid ? `${id}-error` : `${id}-hint`) : undefined}
        {...rest}
      />
      {trailing && <div className="input-wrap__trailing">{trailing}</div>}
    </div>
  );
});

export const PasswordInput = forwardRef<HTMLInputElement, Omit<InputProps, 'type' | 'trailing'>>(
  function PasswordInput(props, ref) {
    const t = useT();
    const [shown, setShown] = useState(false);
    return (
      <Input
        ref={ref}
        {...props}
        type={shown ? 'text' : 'password'}
        trailing={
          <button
            type="button"
            className="input-wrap__toggle"
            onClick={() => setShown((s) => !s)}
            aria-label={shown ? t('common.hidePassword') : t('common.showPassword')}
            title={shown ? t('common.hidePassword') : t('common.showPassword')}
            aria-pressed={shown}
          >
            <Icon name={shown ? 'eyeOff' : 'eye'} size={16} />
          </button>
        }
      />
    );
  },
);

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }>(
  function Textarea({ invalid, className, ...rest }, ref) {
    return <textarea ref={ref} className={cx('textarea', invalid && 'textarea--error', className)} aria-invalid={invalid || undefined} {...rest} />;
  },
);

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(
  function Select({ className, children, ...rest }, ref) {
    return (
      <div className={cx('select-wrap', className)}>
        <select ref={ref} className="select" {...rest}>{children}</select>
        <Icon name="chevronDown" size={15} className="select-wrap__chevron" />
      </div>
    );
  },
);

interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: ReactNode;
  error?: string;
}
export function Checkbox({ label, error, id, className, ...rest }: CheckboxProps) {
  const auto = useId();
  const cid = id ?? auto;
  return (
    <div className={cx('checkbox', error && 'checkbox--error', className)}>
      <input type="checkbox" id={cid} {...rest} />
      <label htmlFor={cid}>{label}</label>
      {error && <p className="field__error" role="alert"><Icon name="alert" size={13} /> {error}</p>}
    </div>
  );
}
