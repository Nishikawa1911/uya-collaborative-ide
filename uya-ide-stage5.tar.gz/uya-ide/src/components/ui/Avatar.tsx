import { cx, initials } from '../../lib/utils';
import { useT } from '../../i18n';

interface Person {
  displayName: string;
  avatarColor: string;
  avatarUrl?: string;
}

interface AvatarProps {
  person: Person;
  size?: number;
  /** Онлайн нүктесі (үлгі деректер) */
  presence?: 'online' | 'offline';
  className?: string;
  ring?: string;
}

export function Avatar({ person, size = 32, presence, className, ring }: AvatarProps) {
  return (
    <span
      className={cx('avatar', className)}
      style={{ width: size, height: size, fontSize: Math.max(10, Math.round(size * 0.38)), background: person.avatarUrl ? undefined : person.avatarColor, boxShadow: ring ? `0 0 0 2px ${ring}` : undefined }}
      title={person.displayName}
    >
      {person.avatarUrl ? <img src={person.avatarUrl} alt={person.displayName} /> : <span aria-hidden="true">{initials(person.displayName)}</span>}
      {!person.avatarUrl && <span className="sr-only">{person.displayName}</span>}
      {presence && <span className={cx('avatar__presence', `avatar__presence--${presence}`)} />}
    </span>
  );
}

interface StackProps {
  people: Array<Person & { userId: string }>;
  max?: number;
  size?: number;
  label?: string;
}

/** Қабаттасқан аватарлар (жоғарғы панельдегі «белсенді қатысушылар»). */
export function AvatarStack({ people, max = 4, size = 28, label }: StackProps) {
  const t = useT();
  const shown = people.slice(0, max);
  const extra = people.length - shown.length;
  return (
    <div className="avatar-stack" role="group" aria-label={label ?? t('ws.activeMembers')}>
      {shown.map((p) => (
        <Avatar key={p.userId} person={p} size={size} className="avatar-stack__item" />
      ))}
      {extra > 0 && (
        <span className="avatar avatar-stack__item avatar-stack__more" style={{ width: size, height: size, fontSize: 11 }} title={`+${extra}`}>
          +{extra}
        </span>
      )}
    </div>
  );
}
