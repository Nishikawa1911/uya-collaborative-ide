import type { CSSProperties } from 'react';
import {
  LuArrowLeft, LuArrowRight, LuBraces, LuBug, LuCheck, LuChevronDown, LuChevronRight, LuChevronUp,
  LuCircle, LuCircleAlert, LuCircleCheck, LuCircleX, LuClock, LuCopy, LuCornerDownLeft, LuCrown,
  LuDatabase, LuEllipsis, LuEraser, LuEye, LuEyeOff, LuFile, LuFileCode, LuFileJson, LuFilePlus,
  LuFileText, LuFolder, LuFolderOpen, LuFolderPlus, LuFoldVertical, LuGlobe, LuHouse, LuInfo,
  LuKeyRound, LuLayoutGrid, LuListFilter, LuLock, LuLogIn, LuLogOut, LuMaximize2, LuMenu,
  LuMessageSquare, LuMinimize2, LuMoon, LuPackage, LuPanelBottom, LuPanelLeft, LuPanelRight,
  LuPencil, LuPlay, LuPlus, LuRefreshCw, LuRocket, LuSave, LuSearch, LuSend, LuSettings, LuShare2,
  LuShieldCheck, LuSparkles, LuSquare, LuSquareTerminal, LuSun, LuTerminal, LuTrash2, LuTriangleAlert,
  LuUpload, LuUser, LuUserPlus, LuUsers, LuX,
} from 'react-icons/lu';

const icons = {
  back: LuArrowLeft, forward: LuArrowRight, braces: LuBraces, bug: LuBug, check: LuCheck,
  chevronDown: LuChevronDown, chevronRight: LuChevronRight, chevronUp: LuChevronUp, circle: LuCircle,
  alert: LuCircleAlert, success: LuCircleCheck, error: LuCircleX, clock: LuClock, copy: LuCopy,
  enter: LuCornerDownLeft, crown: LuCrown, database: LuDatabase, more: LuEllipsis, eraser: LuEraser,
  eye: LuEye, eyeOff: LuEyeOff, file: LuFile, fileCode: LuFileCode, fileJson: LuFileJson,
  filePlus: LuFilePlus, fileText: LuFileText, folder: LuFolder, folderOpen: LuFolderOpen,
  folderPlus: LuFolderPlus, collapseAll: LuFoldVertical, globe: LuGlobe, home: LuHouse, info: LuInfo,
  key: LuKeyRound, grid: LuLayoutGrid, filter: LuListFilter, lock: LuLock, login: LuLogIn,
  logout: LuLogOut, maximize: LuMaximize2, menu: LuMenu, chat: LuMessageSquare, minimize: LuMinimize2,
  moon: LuMoon, package: LuPackage, panelBottom: LuPanelBottom, panelLeft: LuPanelLeft,
  panelRight: LuPanelRight, edit: LuPencil, play: LuPlay, plus: LuPlus, refresh: LuRefreshCw,
  rocket: LuRocket, save: LuSave, search: LuSearch, send: LuSend, settings: LuSettings, share: LuShare2,
  shield: LuShieldCheck, sparkles: LuSparkles, terminal: LuTerminal, terminalSquare: LuSquareTerminal,
  stop: LuSquare, sun: LuSun, trash: LuTrash2, warning: LuTriangleAlert, upload: LuUpload, user: LuUser,
  userPlus: LuUserPlus, users: LuUsers, close: LuX,
} as const;

export type IconName = keyof typeof icons;

interface IconProps {
  name: IconName;
  size?: number;
  className?: string;
  style?: CSSProperties;
}

/** Бір орталықтандырылған белгіше жиыны (Lucide). Декоративті: aria-hidden. */
export function Icon({ name, size = 16, className, style }: IconProps) {
  const Cmp = icons[name];
  return <Cmp size={size} className={className} style={style} aria-hidden="true" focusable="false" />;
}
