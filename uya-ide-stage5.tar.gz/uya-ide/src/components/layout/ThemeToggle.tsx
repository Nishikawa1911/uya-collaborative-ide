import { toggleTheme, useTheme } from '../../theme/theme';
import { useT } from '../../i18n';
import { IconButton } from '../ui';

export function ThemeToggle({ size = 'md' }: { size?: 'sm' | 'md' }) {
  const t = useT();
  const theme = useTheme();
  return (
    <IconButton
      icon={theme === 'dark' ? 'sun' : 'moon'}
      label={theme === 'dark' ? t('theme.switchToLight') : t('theme.switchToDark')}
      size={size}
      onClick={toggleTheme}
    />
  );
}
