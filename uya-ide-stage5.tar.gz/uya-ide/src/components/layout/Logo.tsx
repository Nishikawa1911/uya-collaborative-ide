import { useT } from '../../i18n';
import { cx } from '../../lib/utils';

/** Ұя белгісі: алтыбұрышты ұяшық + алтын нүкте (командалық «ұя»). */
export function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <path d="M16 3.8l10.5 6.1v12.2L16 28.2 5.5 22.1V9.9z" fill="var(--accent-soft)" stroke="var(--accent)" strokeWidth="2" strokeLinejoin="round" />
      <path d="M16 9.6l5.6 3.2v6.4L16 22.4l-5.6-3.2v-6.4z" fill="none" stroke="var(--accent)" strokeOpacity=".55" strokeWidth="1.4" strokeLinejoin="round" />
      <circle cx="16" cy="16" r="2.9" fill="var(--gold)" />
    </svg>
  );
}

export function Logo({ className, showText = true }: { className?: string; showText?: boolean }) {
  const t = useT();
  return (
    <span className={cx('logo', className)}>
      <LogoMark />
      {showText && <span className="logo__text">{t('app.name')}</span>}
    </span>
  );
}
