import type { ReactNode } from 'react';
import { useT } from '../../i18n';
import { Icon, type IconName } from '../ui';
import { Logo } from './Logo';
import { ThemeToggle } from './ThemeToggle';

const highlights: Array<{ icon: IconName; titleKey: 'auth.hl.collab.title' | 'auth.hl.secure.title' | 'auth.hl.langs.title'; textKey: 'auth.hl.collab.text' | 'auth.hl.secure.text' | 'auth.hl.langs.text' }> = [
  { icon: 'users', titleKey: 'auth.hl.collab.title', textKey: 'auth.hl.collab.text' },
  { icon: 'shield', titleKey: 'auth.hl.secure.title', textKey: 'auth.hl.secure.text' },
  { icon: 'braces', titleKey: 'auth.hl.langs.title', textKey: 'auth.hl.langs.text' },
];

/** Кіру/тіркелу беттеріне арналған екі бағанды макет. */
export function AuthLayout({ children }: { children: ReactNode }) {
  const t = useT();
  return (
    <div className="auth">
      <aside className="auth__aside">
        <Logo />
        <div className="auth__pitch">
          <h1>{t('app.tagline')}</h1>
          <p>{t('app.taglineLong')}</p>
          <ul className="auth__list">
            {highlights.map((h) => (
              <li key={h.titleKey}>
                <span className="auth__list-icon"><Icon name={h.icon} size={18} /></span>
                <div><strong>{t(h.titleKey)}</strong><span>{t(h.textKey)}</span></div>
              </li>
            ))}
          </ul>
        </div>
        <div className="auth__code" aria-hidden="true">
          <span className="c-c">{t('auth.codeComment')}</span>{'\n'}
          <span className="c-k">def</span> <span className="c-f">salem</span>(team):{'\n'}
          {'    '}<span className="c-k">return</span> <span className="c-s">"{t('auth.codeString')}"</span>
        </div>
      </aside>
      <main className="auth__main" id="main">
        <div className="auth__toolbar"><ThemeToggle /></div>
        <div className="auth__card">{children}</div>
      </main>
    </div>
  );
}
