import type { ReactNode } from 'react';
import { useT } from '../../i18n';
import { Link, navigate, paths, useRoute, type RouteName } from '../../app/router';
import { logout, useCurrentUser } from '../../state/auth';
import { toast } from '../../state/toasts';
import { cx } from '../../lib/utils';
import { Avatar, IconButton, Menu, type MenuItem } from '../ui';
import { Icon, type IconName } from '../ui/Icon';
import { Logo } from './Logo';
import { ThemeToggle } from './ThemeToggle';

interface NavItem { route: RouteName; to: string; icon: IconName; labelKey: 'nav.home' | 'nav.newProject' | 'nav.joinProject' }

const navItems: NavItem[] = [
  { route: 'dashboard', to: paths.dashboard(), icon: 'home', labelKey: 'nav.home' },
  { route: 'project.new', to: paths.newProject(), icon: 'plus', labelKey: 'nav.newProject' },
  { route: 'project.join', to: paths.joinProject(), icon: 'key', labelKey: 'nav.joinProject' },
];

/** Жұмыс кеңістігінен тыс беттердің ортақ шеңбері: жоғарғы панель + мазмұн. */
export function AppShell({ children, wide }: { children: ReactNode; wide?: boolean }) {
  const t = useT();
  const route = useRoute();
  const user = useCurrentUser();

  const doLogout = async () => {
    await logout();
    toast(t('nav.logout'), 'info', 1800);
    navigate(paths.login());
  };

  const userItems: MenuItem[] = [
    { id: 'profile', label: t('nav.profile'), icon: 'user', onSelect: () => navigate(paths.profile()) },
    { id: 'settings', label: t('nav.settings'), icon: 'settings', onSelect: () => navigate('/profile?tab=appearance') },
    { id: 'logout', label: t('nav.logout'), icon: 'logout', danger: true, separatorBefore: true, onSelect: doLogout },
  ];
  const navMenuItems: MenuItem[] = navItems.map((n) => ({ id: n.route, label: t(n.labelKey), icon: n.icon, checked: route.name === n.route, onSelect: () => navigate(n.to) }));

  return (
    <div className="shell">
      <a href="#main" className="skip-link" onClick={(e) => { e.preventDefault(); document.getElementById('main')?.focus(); }}>{t('nav.skipToContent')}</a>
      <header className="appbar">
        <div className="appbar__inner">
          <Link to={paths.dashboard()} className="appbar__brand" aria-label={t('nav.toDashboard')}><Logo /></Link>
          <nav className="appbar__nav" aria-label={t('nav.home')}>
            {navItems.map((n) => (
              <Link key={n.route} to={n.to} className={cx('appbar__link', route.name === n.route && 'is-active')} aria-current={route.name === n.route ? 'page' : undefined}>
                <Icon name={n.icon} size={16} />{t(n.labelKey)}
              </Link>
            ))}
          </nav>
          <div className="appbar__spacer" />
          <div className="appbar__burger">
            <Menu label={t('common.menu')} alignRight items={navMenuItems} trigger={(p) => <IconButton icon="menu" label={t('common.menu')} {...p} />} />
          </div>
          <ThemeToggle />
          <Menu
            label={t('nav.profile')}
            items={userItems}
            trigger={(p) => (
              <button type="button" className="appbar__user" aria-label={`${t('nav.profile')}: ${user.displayName}`} {...p}>
                <Avatar person={user} size={30} />
                <span className="appbar__user-name">{user.displayName}</span>
                <Icon name="chevronDown" size={14} />
              </button>
            )}
          />
        </div>
      </header>
      <main id="main" tabIndex={-1} className={cx('shell__main', wide && 'shell__main--wide')}>{children}</main>
    </div>
  );
}
