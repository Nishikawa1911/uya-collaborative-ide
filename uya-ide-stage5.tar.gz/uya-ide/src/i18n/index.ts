import { kk, type Dictionary, type TranslationKey } from './kk';
import { createStore, useStore } from '../state/createStore';

/**
 * i18n архитектурасы: тілдер тізімі `dictionaries` ішінде тіркеледі.
 * Жаңа тіл қосу = жаңа сөздік файлы + осы тізімге қосу. Әдепкі және резервтік тіл — қазақша.
 */
export type Locale = 'kk';
const dictionaries: Record<Locale, Dictionary> = { kk };
export const DEFAULT_LOCALE: Locale = 'kk';

const localeStore = createStore<Locale>(DEFAULT_LOCALE);

export function getLocale(): Locale {
  return localeStore.get();
}
export function setLocale(locale: Locale) {
  localeStore.set(locale);
  document.documentElement.lang = locale;
}

export type Params = Record<string, string | number>;

/** Аударманы алу. {name} түріндегі параметрлерді ауыстырады. */
export function t(key: TranslationKey, params?: Params): string {
  const dict = dictionaries[localeStore.get()] ?? dictionaries[DEFAULT_LOCALE];
  const template = dict[key] ?? dictionaries[DEFAULT_LOCALE][key] ?? key;
  if (!params) return template;
  return template.replace(/\{(\w+)\}/g, (_, name: string) =>
    name in params ? String(params[name]) : `{${name}}`,
  );
}

/** React-те тіл өзгергенде қайта сурет салу үшін. */
export function useT() {
  useStore(localeStore, (l) => l);
  return t;
}

export type { TranslationKey };
