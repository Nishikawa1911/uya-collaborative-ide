import { t } from './index';

const MONTHS_KK = [
  'қаңтар', 'ақпан', 'наурыз', 'сәуір', 'мамыр', 'маусым',
  'шілде', 'тамыз', 'қыркүйек', 'қазан', 'қараша', 'желтоқсан',
];

/** «5 минут бұрын», «кеше», «12 қазан» сияқты қазақша қатысты уақыт. */
export function formatRelativeTime(iso: string, now: Date = new Date()): string {
  const date = new Date(iso);
  const diffSec = Math.max(0, Math.round((now.getTime() - date.getTime()) / 1000));
  if (diffSec < 45) return 'жаңа ғана';
  const min = Math.round(diffSec / 60);
  if (min < 60) return `${min} минут бұрын`;
  const hours = Math.round(min / 60);
  if (hours < 24) return `${hours} сағат бұрын`;
  const days = Math.round(hours / 24);
  if (days === 1) return 'кеше';
  if (days < 7) return `${days} күн бұрын`;
  return formatDate(iso);
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  return `${d.getDate()} ${MONTHS_KK[d.getMonth()]} ${d.getFullYear()}`;
}

export function formatTime(iso: string): string {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/** Қате кодын (API) қазақша хабарламаға айналдырады. */
export function messageForError(code: string, params?: Record<string, string | number>): string {
  const key = `errors.${code}` as Parameters<typeof t>[0];
  const msg = t(key, params);
  return msg === key ? t('errors.unknown') : msg;
}
