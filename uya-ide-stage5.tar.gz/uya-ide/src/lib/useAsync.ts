import { useCallback, useEffect, useRef, useState } from 'react';

export interface AsyncState<T> {
  data: T | undefined;
  error: unknown;
  loading: boolean;
  reload: () => void;
  setData: (updater: T | ((prev: T | undefined) => T | undefined)) => void;
}

/**
 * Асинхронды деректерді жүктеу: loading / error / data + қайта жүктеу.
 * Ескі сұраулардың жауаптары елеусіз қалдырылады (race condition-нан қорғаныс).
 */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]): AsyncState<T> {
  const [state, setState] = useState<{ data: T | undefined; error: unknown; loading: boolean }>({ data: undefined, error: undefined, loading: true });
  const [tick, setTick] = useState(0);
  const run = useRef(0);

  useEffect(() => {
    const id = ++run.current;
    setState((s) => ({ ...s, loading: true, error: undefined }));
    fn().then(
      (data) => { if (id === run.current) setState({ data, error: undefined, loading: false }); },
      (error) => { if (id === run.current) setState({ data: undefined, error, loading: false }); },
    );
    return () => { run.current++; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  const reload = useCallback(() => setTick((n) => n + 1), []);
  const setData = useCallback((updater: T | ((prev: T | undefined) => T | undefined)) => {
    setState((s) => ({ ...s, data: typeof updater === 'function' ? (updater as (p: T | undefined) => T | undefined)(s.data) : updater }));
  }, []);

  return { ...state, reload, setData };
}
