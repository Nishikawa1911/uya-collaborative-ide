import type { FileLanguageId, LanguageId } from '../api/types';
import type { TranslationKey } from '../i18n';
import { extOf } from './utils';

interface LanguageMeta {
  labelKey: TranslationKey;
  color: string;
  /** Monaco тіл идентификаторы */
  monaco: string;
  /** Мүмкін бастапқы файл */
  defaultEntry: string;
}

export const languageMeta: Record<FileLanguageId, LanguageMeta> = {
  python: { labelKey: 'lang.python', color: '#4b8bbe', monaco: 'python', defaultEntry: 'main.py' },
  java: { labelKey: 'lang.java', color: '#e76f51', monaco: 'java', defaultEntry: 'Main.java' },
  go: { labelKey: 'lang.go', color: '#00add8', monaco: 'go', defaultEntry: 'main.go' },
  cpp: { labelKey: 'lang.cpp', color: '#6c8cd5', monaco: 'cpp', defaultEntry: 'main.cpp' },
  csharp: { labelKey: 'lang.csharp', color: '#9b5de5', monaco: 'csharp', defaultEntry: 'Program.cs' },
  rust: { labelKey: 'lang.rust', color: '#dea584', monaco: 'rust', defaultEntry: 'src/main.rs' },
  php: { labelKey: 'lang.php', color: '#8892bf', monaco: 'php', defaultEntry: 'index.php' },
  typescript: { labelKey: 'lang.typescript', color: '#3178c6', monaco: 'typescript', defaultEntry: 'src/index.ts' },
  html: { labelKey: 'lang.html', color: '#e34c26', monaco: 'html', defaultEntry: 'index.html' },
  css: { labelKey: 'lang.css', color: '#a259ff', monaco: 'css', defaultEntry: 'styles.css' },
  javascript: { labelKey: 'lang.javascript', color: '#f1c40f', monaco: 'javascript', defaultEntry: 'index.js' },
  sql: { labelKey: 'lang.sql', color: '#f29111', monaco: 'sql', defaultEntry: 'queries.sql' },
  json: { labelKey: 'lang.json', color: '#9aa8b8', monaco: 'json', defaultEntry: 'data.json' },
  markdown: { labelKey: 'lang.markdown', color: '#7f9bb5', monaco: 'markdown', defaultEntry: 'README.md' },
  plaintext: { labelKey: 'lang.plaintext', color: '#8091a5', monaco: 'plaintext', defaultEntry: 'notes.txt' },
};

const byExtension: Record<string, FileLanguageId> = {
  py: 'python', java: 'java', go: 'go', cpp: 'cpp', cc: 'cpp', cxx: 'cpp', hpp: 'cpp', h: 'cpp', c: 'cpp',
  cs: 'csharp', rs: 'rust', php: 'php', ts: 'typescript', tsx: 'typescript', html: 'html', htm: 'html',
  css: 'css', js: 'javascript', mjs: 'javascript', jsx: 'javascript', sql: 'sql', json: 'json',
  md: 'markdown', txt: 'plaintext', toml: 'plaintext', mod: 'plaintext',
};

export function languageOfFile(name: string): FileLanguageId {
  return byExtension[extOf(name)] ?? 'plaintext';
}

/** Жоба тілдері үшін таңдау тізімі (спецификациядағы 12 тіл). */
export const selectableLanguages: LanguageId[] = [
  'python', 'java', 'go', 'cpp', 'csharp', 'rust', 'php', 'typescript', 'html', 'css', 'javascript', 'sql',
];
