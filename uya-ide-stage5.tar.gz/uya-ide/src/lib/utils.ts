export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '?';
  const first = [...parts[0]][0] ?? '';
  const second = parts.length > 1 ? [...parts[parts.length - 1]][0] : '';
  return (first + second).toLocaleUpperCase('kk');
}

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export function uid(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-3)}`;
}

/** localStorage-ке қауіпсіз қол жеткізу (жеке режимде қате бермейді). */
export const safeStorage = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem(key);
      return raw == null ? fallback : (JSON.parse(raw) as T);
    } catch {
      return fallback;
    }
  },
  set(key: string, value: unknown) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* елемейміз */
    }
  },
  remove(key: string) {
    try {
      localStorage.removeItem(key);
    } catch {
      /* елемейміз */
    }
  },
};

/** Файл атауының валидациясы (спецификация 9.4): жол бөлгіштер, басқару таңбалары, ұзындық. */
export function isValidFileName(name: string): boolean {
  const trimmed = name.trim();
  if (!trimmed || trimmed === '.' || trimmed === '..') return false;
  if (new Uint8Array(new TextEncoder().encode(trimmed)).length > 255) return false;
  // eslint-disable-next-line no-control-regex
  return !/[\\/:*?"<>|\u0000-\u001f]/.test(trimmed);
}

export function extOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i <= 0 ? '' : name.slice(i + 1).toLowerCase();
}

export const AVATAR_PALETTE = ['#1fa7b8', '#7a6ff0', '#e0709a', '#d98c2b', '#4cae7c', '#cf5c4f', '#4a86d8', '#9b6fc4'];
/** Идентификатор бойынша тұрақты аватар түсі. */
export function colorFor(id: string): string {
  let h = 0;
  for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return AVATAR_PALETTE[h % AVATAR_PALETTE.length];
}
