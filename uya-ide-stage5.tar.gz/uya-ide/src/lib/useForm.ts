import { useCallback, useMemo, useState, type FormEvent } from 'react';

type Values = Record<string, string | boolean | string[]>;
type Errors<T> = Partial<Record<keyof T, string>>;

/**
 * Жеңіл форма хукі: қателер өріс «touched» болғанда немесе жіберу әрекетінен кейін көрінеді.
 * Жарамсыз жіберуде бірінші қате өріске фокус түседі (қолжетімділік).
 * Өріс id-і `field-<name>` болуы керек.
 */
export function useForm<T extends Values>(initial: T, validate: (values: T) => Errors<T>) {
  const [values, setValues] = useState<T>(initial);
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({});
  const [submitted, setSubmitted] = useState(false);

  const allErrors = useMemo(() => validate(values), [values, validate]);

  const errors = useMemo(() => {
    const visible: Errors<T> = {};
    for (const k of Object.keys(allErrors) as Array<keyof T>) {
      if (submitted || touched[k]) visible[k] = allErrors[k];
    }
    return visible;
  }, [allErrors, touched, submitted]);

  const setValue = useCallback(<K extends keyof T>(key: K, value: T[K]) => {
    setValues((v) => ({ ...v, [key]: value }));
  }, []);

  const touch = useCallback((key: keyof T) => setTouched((t) => ({ ...t, [key]: true })), []);

  const handleSubmit = (onValid: (values: T) => void | Promise<void>) => (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    const keys = Object.keys(allErrors) as Array<keyof T>;
    if (keys.length) {
      const el = document.getElementById(`field-${String(keys[0])}`);
      el?.focus();
      return;
    }
    return onValid(values);
  };

  const reset = useCallback(() => {
    setValues(initial);
    setTouched({});
    setSubmitted(false);
  }, [initial]);

  return { values, errors, setValue, touch, handleSubmit, reset, setValues, hasErrors: Object.keys(allErrors).length > 0 };
}

/** Құпия сөз беріктігі 0–4 (тек интерфейс көмекшісі; нақты тексеру серверде). */
export function passwordScore(pw: string): 0 | 1 | 2 | 3 | 4 {
  if (!pw) return 0;
  let score = 0;
  if (pw.length >= 10) score++;
  if (pw.length >= 14) score++;
  if (/[a-zа-яәғқңөұүһі]/.test(pw) && /[A-ZА-ЯӘҒҚҢӨҰҮҺІ]/.test(pw)) score++;
  if (/\d/.test(pw) && /[^\p{L}\d]/u.test(pw)) score++;
  return Math.min(4, Math.max(pw.length >= 4 ? 1 : 0, score)) as 0 | 1 | 2 | 3 | 4;
}

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
export const USERNAME_RE = /^[A-Za-z0-9_]{3,24}$/;
