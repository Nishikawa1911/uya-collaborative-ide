import { useEffect, useReducer, useState } from 'react';
import { api, isMockApi } from '../api';
import { ApiError } from '../api/types';
import { CollabClient, type CollabEvent } from './client';

/**
 * Жобаға бірлескен жұмыс қосылымын ашады. Демо (mock) режимінде сервер жоқ → null (жергілікті жұмыс).
 * Компонент демонтаждалғанда қосылым жабылады.
 */
export function useCollab(projectId: string): CollabClient | null {
  const [client, setClient] = useState<CollabClient | null>(null);
  useEffect(() => {
    if (isMockApi) return undefined;
    const c = new CollabClient(projectId, {
      probe: async () => {
        try { await api.projects.get(projectId); return 'ok'; } catch (e) {
          if (e instanceof ApiError && (e.code === 'project.not_found' || e.code === 'auth.unauthenticated')) return 'denied';
          return 'ok';
        }
      },
    });
    c.start();
    setClient(c);
    return () => { c.stop(); setClient(null); };
  }, [projectId]);
  return client;
}

/** Клиент оқиғаларына жазылып, берілген түрдегі оқиғада компонентті қайта сызады. */
export function useCollabRefresh(client: CollabClient | null, types: CollabEvent['type'][]): void {
  const [, tick] = useReducer((n: number) => n + 1, 0);
  const key = types.join(',');
  useEffect(() => {
    if (!client) return undefined;
    return client.on((e) => { if (types.includes(e.type)) tick(); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, key]);
}
