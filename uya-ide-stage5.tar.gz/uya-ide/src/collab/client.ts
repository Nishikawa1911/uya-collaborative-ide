/**
 * Нақты уақыт клиенті (React-тан тәуелсіз): WebSocket қосылымы, қайта қосылу, құжат сессиялары (CRDT),
 * presence (курсорлар, кім қай файлды өңдеуде), чат және файл жүйесі оқиғалары.
 * Протокол сипаттамасы: docs/kk/realtime.md.
 */
import { TextCRDT, CrdtError, type Op, type RelPos, type TextChange } from '../../shared/crdt';

export type CollabStatus = 'connecting' | 'connected' | 'reconnecting' | 'disconnected' | 'kicked';
export type CollabRole = 'owner' | 'editor' | 'viewer';

export interface PeerSel { a: RelPos; h: RelPos }
export interface Peer {
  clientId: number; userId: string; name: string; color: string; role: CollabRole;
  activeFileId: string | null; cursor: { fileId: string; sels: PeerSel[] } | null;
}
export interface ChatWire { id: string; seq: number; userId: string | null; authorName: string; body: string; createdAt: string }

export type FsEvent =
  | { event: 'created'; node: { id: string; parentId: string | null; name: string; kind: 'file' | 'folder' }; by: string }
  | { event: 'renamed'; node: { id: string; parentId: string | null; name: string; kind: 'file' | 'folder' }; by: string }
  | { event: 'deleted'; id: string; kind: 'file' | 'folder'; fileIds: string[]; by: string };

export type CollabEvent =
  | { type: 'status'; status: CollabStatus }
  | { type: 'peers' }
  | { type: 'chat'; message: ChatWire; clientMsgId?: string }
  | { type: 'fs'; fs: FsEvent }
  | { type: 'role'; role: CollabRole }
  | { type: 'members' }
  | { type: 'project' }
  | { type: 'kicked'; reason: string }
  | { type: 'error'; code: string; message?: string; clientMsgId?: string; fileId?: string };

export type DocEvent =
  | { kind: 'remote'; changes: TextChange[] }
  | { kind: 'state' }
  | { kind: 'pending' }
  | { kind: 'cursors' };

export interface RemoteSel { clientId: number; userId: string; name: string; color: string; from: number; to: number; head: number }

const sleepJitter = (ms: number) => ms * (0.6 + Math.random() * 0.4);
const safe = {
  get(k: string) { try { return sessionStorage.getItem(k); } catch { return null; } },
  set(k: string, v: string) { try { sessionStorage.setItem(k, v); } catch { /* ignore */ } },
};

export class DocSession {
  readonly fileId: string;
  state: 'opening' | 'ready' | 'too_large' | 'gone' = 'opening';
  private client: CollabClient;
  private crdt: TextCRDT | null = null;
  private inflight = new Map<number, number>();
  private offlineEdits = 0;
  private seq = 0;
  private everSynced = false;
  private listeners = new Set<(e: DocEvent) => void>();
  private opened = false;

  constructor(client: CollabClient, fileId: string) { this.client = client; this.fileId = fileId; }

  subscribe(fn: (e: DocEvent) => void): () => void { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }
  private emit(e: DocEvent) { for (const l of [...this.listeners]) l(e); }

  text(): string { return this.crdt ? this.crdt.text() : ''; }
  get length(): number { return this.crdt?.length ?? 0; }
  get ready(): boolean { return this.state === 'ready'; }
  get readOnly(): boolean { return this.client.role === 'viewer' || this.state !== 'ready'; }
  /** Серверге әлі жетпеген өзгерістер саны (ack күтіліп тұрған + офлайн). */
  get pending(): number { return this.inflight.size + this.offlineEdits; }

  /** Серверден құжатты сұрату. Қайта қосылғанда — жергілікті күйді де жүктейді (офлайн өзгерістер сақталады). */
  open() {
    this.opened = true;
    const writable = this.client.role !== 'viewer';
    this.client.sendRaw({ type: 'doc.open', fileId: this.fileId, ...(this.crdt && this.everSynced && writable ? { ops: this.crdt.toOps() } : {}) });
  }

  close() { if (this.opened) this.client.sendRaw({ type: 'doc.close', fileId: this.fileId }); this.opened = false; this.listeners.clear(); }

  /** Редакторда болған жергілікті өзгеріс. Қабылданбаса (шектен асты/оқу режимі) — false: редактор мәтінді қайтаруы керек. */
  edit(offset: number, deleteCount: number, insert: string): boolean {
    if (!this.crdt || this.readOnly) return false;
    const ins = insert.replace(/\r\n?/g, '\n').replace(/\u0000/g, '');
    if (this.crdt.length - deleteCount + ins.length > this.client.maxChars) {
      this.client.emit({ type: 'error', code: 'collab.doc_too_large', fileId: this.fileId });
      return false;
    }
    let ops: Op[];
    try { ops = this.crdt.localReplace(offset, deleteCount, ins); } catch (e) {
      if (e instanceof CrdtError) { this.emit({ kind: 'state' }); return false; }
      throw e;
    }
    if (!ops.length) return true;
    if (this.client.status === 'connected' && this.opened && this.everSynced) {
      const seq = ++this.seq;
      if (this.client.sendRaw({ type: 'doc.ops', fileId: this.fileId, seq, ops })) this.inflight.set(seq, ops.length);
      else this.offlineEdits++;
    } else this.offlineEdits++;
    this.emit({ kind: 'pending' });
    return true;
  }

  // ───────── сервер хабарламалары ─────────
  onState(ops: Op[]) {
    if (!this.crdt) this.crdt = new TextCRDT(this.client.clientId);
    else this.crdt.setClientId(this.client.clientId);
    let changes: TextChange[] = [];
    try { changes = this.crdt.applyOps(ops); } catch { /* бұзылған күй: төменде тазаланады */ }
    this.crdt.clearPending();
    this.inflight.clear(); this.offlineEdits = 0;
    const first = !this.everSynced;
    this.everSynced = true; this.state = 'ready';
    if (first) this.emit({ kind: 'state' });
    else if (changes.length) this.emit({ kind: 'remote', changes });
    this.emit({ kind: 'pending' });
    this.emit({ kind: 'cursors' });
  }
  onOps(ops: Op[]) {
    if (!this.crdt) return;
    let changes: TextChange[] = [];
    try { changes = this.crdt.applyOps(ops); } catch { return; }
    if (changes.length) this.emit({ kind: 'remote', changes });
    this.emit({ kind: 'cursors' });
  }
  onAck(seq: number) { if (this.inflight.delete(seq)) this.emit({ kind: 'pending' }); }
  onTooLarge() { this.state = 'too_large'; this.emit({ kind: 'state' }); }
  onGone() { this.state = 'gone'; this.emit({ kind: 'state' }); }
  onDisconnected() {
    this.offlineEdits += this.inflight.size; this.inflight.clear();
    this.emit({ kind: 'pending' });
  }
  rolesChanged() { this.emit({ kind: 'state' }); }

  // ───────── курсорлар ─────────
  remoteSelections(): RemoteSel[] {
    const crdt = this.crdt;
    if (!crdt) return [];
    const out: RemoteSel[] = [];
    for (const p of this.client.peers.values()) {
      if (p.clientId === this.client.clientId || p.cursor?.fileId !== this.fileId) continue;
      for (const s of p.cursor.sels) {
        const a = crdt.offsetFromRel(s.a), h = crdt.offsetFromRel(s.h);
        if (a === null || h === null) continue;
        out.push({ clientId: p.clientId, userId: p.userId, name: p.name, color: p.color, from: Math.min(a, h), to: Math.max(a, h), head: h });
      }
    }
    return out;
  }
  /** Жергілікті курсор/ерекшелеу (офсеттер) — басқаларға салыстырмалы позиция ретінде жіберіледі. */
  setSelections(sels: Array<{ anchor: number; head: number }>) {
    if (!this.crdt) return;
    this.client.setCursor(this.fileId, sels.slice(0, 20).map((s) => ({ a: this.crdt!.relFromOffset(s.anchor), h: this.crdt!.relFromOffset(s.head) })));
  }
  emitCursors() { this.emit({ kind: 'cursors' }); }
}

export interface CollabOptions {
  /** ws(s):// мекенжайының бастауы; әдепкі — ағымдағы бет көзі */
  wsOrigin?: string;
  /** Қосылымсыз тексеру (кіру/рұқсат бар ма): сәтсіз қосылымдарда шақырылады */
  probe?: () => Promise<'ok' | 'denied'>;
}

export class CollabClient {
  readonly projectId: string;
  status: CollabStatus = 'connecting';
  role: CollabRole | null = null;
  clientId = 0;
  me: { userId: string; name: string; color: string } | null = null;
  maxChars = 200_000;
  peers = new Map<number, Peer>();
  /** peers өзгергенде өседі (React тәуелділіктері үшін) */
  peersVersion = 0;
  docs = new Map<string, DocSession>();
  everConnected = false;

  private opts: CollabOptions;
  private ws: WebSocket | null = null;
  private listeners = new Set<(e: CollabEvent) => void>();
  private retry = 0;
  private fails = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private watchdog: ReturnType<typeof setInterval> | null = null;
  private lastMsgAt = 0;
  private hbMs = 20_000;
  private stopped = false;
  private presence: { activeFileId: string | null; cursor: { fileId: string; sels: PeerSel[] } | null } = { activeFileId: null, cursor: null };
  private presenceTimer: ReturnType<typeof setTimeout> | null = null;
  private lastPresenceSent = 0;
  private onlineHandler = () => { if (this.status === 'reconnecting' || this.status === 'disconnected') this.connectNow(); };

  constructor(projectId: string, opts: CollabOptions = {}) { this.projectId = projectId; this.opts = opts; }

  on(fn: (e: CollabEvent) => void): () => void { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }
  emit(e: CollabEvent) { for (const l of [...this.listeners]) l(e); }

  start() {
    this.stopped = false;
    if (typeof window !== 'undefined') window.addEventListener('online', this.onlineHandler);
    this.connect();
  }

  stop() {
    this.stopped = true;
    if (typeof window !== 'undefined') window.removeEventListener('online', this.onlineHandler);
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.presenceTimer) clearTimeout(this.presenceTimer);
    this.stopWatchdog();
    const ws = this.ws; this.ws = null;
    if (ws) { ws.onclose = null; ws.onmessage = null; ws.onerror = null; try { ws.close(1000); } catch { /* ignore */ } }
    for (const d of this.docs.values()) d.close();
    this.docs.clear(); this.listeners.clear();
  }

  private setStatus(s: CollabStatus) { if (this.status !== s) { this.status = s; this.emit({ type: 'status', status: s }); } }

  private url(): string {
    const origin = this.opts.wsOrigin ?? `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}`;
    const cid = safe.get(`uya.collab.cid.${this.projectId}`);
    return `${origin}/ws/projects/${encodeURIComponent(this.projectId)}${cid ? `?cid=${encodeURIComponent(cid)}` : ''}`;
  }

  private connectNow() {
    if (this.reconnectTimer) { clearTimeout(this.reconnectTimer); this.reconnectTimer = null; }
    this.connect();
  }

  private connect() {
    if (this.stopped) return;
    this.setStatus(this.everConnected ? 'reconnecting' : 'connecting');
    let ws: WebSocket;
    try { ws = new WebSocket(this.url()); } catch { this.scheduleReconnect(); return; }
    this.ws = ws;
    let gotHello = false;
    this.lastMsgAt = Date.now();
    ws.onmessage = (ev) => {
      this.lastMsgAt = Date.now();
      let m: Record<string, any>;
      try { m = JSON.parse(String(ev.data)); } catch { return; }
      if (m.type === 'hello') gotHello = true;
      this.handle(m);
    };
    ws.onclose = (ev) => {
      if (this.ws !== ws) return;
      this.ws = null;
      this.stopWatchdog();
      this.onLost(ev.code, gotHello);
    };
    ws.onerror = () => { /* onclose жалғасады */ };
  }

  private onLost(code: number, hadHello: boolean) {
    for (const d of this.docs.values()) d.onDisconnected();
    this.peers.clear(); this.peersVersion++; this.emit({ type: 'peers' });
    if (code === 4403 || code === 4404 || code === 4401) {
      this.setStatus('kicked');
      this.emit({ type: 'kicked', reason: code === 4404 ? 'deleted' : code === 4401 ? 'session' : 'removed' });
      return;
    }
    if (!hadHello) this.fails++; else this.fails = 0;
    this.scheduleReconnect();
  }

  private scheduleReconnect() {
    if (this.stopped) return;
    this.setStatus(this.everConnected ? 'reconnecting' : 'disconnected');
    const delay = sleepJitter(Math.min(15_000, 500 * 2 ** Math.min(this.retry, 5)));
    this.retry++;
    this.reconnectTimer = setTimeout(async () => {
      this.reconnectTimer = null;
      if (this.fails >= 2 && this.opts.probe) {
        try {
          if ((await this.opts.probe()) === 'denied') { this.setStatus('kicked'); this.emit({ type: 'kicked', reason: 'removed' }); return; }
        } catch { /* желі жоқ: қайталай береміз */ }
      }
      this.connect();
    }, delay);
  }

  private startWatchdog() {
    this.stopWatchdog();
    this.watchdog = setInterval(() => {
      const ws = this.ws;
      if (!ws) return;
      if (Date.now() - this.lastMsgAt > this.hbMs * 2.5) { // сервер үнсіз: қосылым өлі
        ws.onclose = null; ws.onmessage = null;
        try { ws.close(); } catch { /* ignore */ }
        this.ws = null; this.stopWatchdog();
        this.onLost(1006, true);
      } else if (ws.readyState === WebSocket.OPEN) {
        try { ws.send('{"type":"hb"}'); } catch { /* ignore */ }
      }
    }, 5_000);
  }
  private stopWatchdog() { if (this.watchdog) { clearInterval(this.watchdog); this.watchdog = null; } }

  sendRaw(msg: Record<string, unknown>): boolean {
    const ws = this.ws;
    if (!ws || ws.readyState !== WebSocket.OPEN || this.status !== 'connected') return false;
    try { ws.send(JSON.stringify(msg)); return true; } catch { return false; }
  }

  private handle(m: Record<string, any>) {
    switch (m.type) {
      case 'hello': {
        this.clientId = m.clientId; this.role = m.role; this.maxChars = m.maxChars ?? this.maxChars;
        this.hbMs = m.heartbeatMs ?? this.hbMs;
        this.me = { userId: m.userId, name: m.name, color: m.color };
        safe.set(`uya.collab.cid.${this.projectId}`, String(m.clientId));
        this.retry = 0; this.fails = 0; this.everConnected = true;
        this.setStatus('connected');
        this.startWatchdog();
        this.emit({ type: 'role', role: m.role });
        for (const d of this.docs.values()) d.open();
        this.flushPresence(true);
        break;
      }
      case 'presence.snapshot':
        this.peers = new Map((m.peers as Peer[]).map((p) => [p.clientId, p]));
        this.peersChanged(); break;
      case 'presence.join': case 'presence.update':
        this.peers.set(m.peer.clientId, m.peer); this.peersChanged(); break;
      case 'presence.leave':
        this.peers.delete(m.clientId); this.peersChanged(); break;
      case 'doc.state': this.docs.get(m.fileId)?.onState(m.ops); break;
      case 'doc.resync': this.docs.get(m.fileId)?.onState(m.ops); break;
      case 'doc.ops': this.docs.get(m.fileId)?.onOps(m.ops); break;
      case 'doc.ack': this.docs.get(m.fileId)?.onAck(m.seq); break;
      case 'doc.too_large': this.docs.get(m.fileId)?.onTooLarge(); break;
      case 'chat.message': this.emit({ type: 'chat', message: m.message, clientMsgId: m.clientMsgId }); break;
      case 'fs.event': {
        const { type: _t, ...rest } = m;
        if (m.event === 'deleted') for (const id of m.fileIds as string[]) { this.docs.get(id)?.onGone(); }
        this.emit({ type: 'fs', fs: rest as FsEvent }); break;
      }
      case 'role.changed':
        this.role = m.role; this.emit({ type: 'role', role: m.role });
        for (const d of this.docs.values()) d.rolesChanged();
        break;
      case 'members.changed': this.emit({ type: 'members' }); break;
      case 'project.updated': this.emit({ type: 'project' }); break;
      case 'kicked': this.emit({ type: 'kicked', reason: String(m.reason) }); break;
      case 'error':
        if (m.code === 'collab.file_not_found' && m.fileId) this.docs.get(m.fileId)?.onGone();
        this.emit({ type: 'error', code: m.code, message: m.message, clientMsgId: m.clientMsgId, fileId: m.fileId }); break;
      default: break;
    }
  }

  private peersChanged() {
    this.peersVersion++;
    this.emit({ type: 'peers' });
    for (const d of this.docs.values()) d.emitCursors();
  }

  // ───────── құжаттар ─────────
  openDoc(fileId: string): DocSession {
    let d = this.docs.get(fileId);
    if (!d) { d = new DocSession(this, fileId); this.docs.set(fileId, d); }
    if (this.status === 'connected') d.open();
    return d;
  }
  closeDoc(fileId: string) {
    const d = this.docs.get(fileId);
    if (!d) return;
    d.close(); this.docs.delete(fileId);
  }

  // ───────── presence ─────────
  setActiveFile(fileId: string | null) {
    if (this.presence.activeFileId === fileId) return;
    this.presence = { activeFileId: fileId, cursor: this.presence.cursor?.fileId === fileId ? this.presence.cursor : null };
    this.flushPresence(false);
  }
  setCursor(fileId: string, sels: PeerSel[]) {
    this.presence = { activeFileId: this.presence.activeFileId ?? fileId, cursor: { fileId, sels } };
    this.flushPresence(false);
  }
  private flushPresence(now: boolean) {
    if (this.status !== 'connected') return;
    const send = () => {
      this.presenceTimer = null; this.lastPresenceSent = Date.now();
      this.sendRaw({ type: 'presence', activeFileId: this.presence.activeFileId, cursor: this.presence.cursor });
    };
    if (now) { if (this.presenceTimer) clearTimeout(this.presenceTimer); send(); return; }
    if (this.presenceTimer) return;
    const wait = Math.max(0, 80 - (Date.now() - this.lastPresenceSent));
    this.presenceTimer = setTimeout(send, wait);
  }

  // ───────── чат ─────────
  sendChat(text: string): string | null {
    if (this.status !== 'connected') return null;
    const id = (globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`).replace(/[^A-Za-z0-9_-]/g, '');
    return this.sendRaw({ type: 'chat.send', text, clientMsgId: id }) ? id : null;
  }
}
