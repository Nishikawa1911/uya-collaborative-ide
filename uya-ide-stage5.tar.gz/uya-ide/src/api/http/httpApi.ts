import type { IdeApi } from '../contracts';
import {
  ApiError, type ChatMessage, type PreviewResult, type RunEventOut, type RunView, type Runtime, type CreatedProject, type FsNode, type ProjectMember, type ProjectScope,
  type ProjectSettings, type ProjectSummary, type Role, type User,
} from '../types';

/** Сессия мерзімі өткенде (401) интерфейсті «кірмеген» күйге ауыстыру үшін (state/auth қосады). */
let onUnauthenticated: (() => void) | null = null;
export const setUnauthenticatedHandler = (fn: (() => void) | null) => { onUnauthenticated = fn; };

interface ErrorBody { error?: { code?: string; params?: Record<string, string | number> } }

/**
 * Нақты бэкэндке арналған `IdeApi` іске асыруы. Сессия — HttpOnly кукиде (JS оқи алмайды),
 * сондықтан токен жад пен localStorage-ге ешқашан түспейді.
 */
export function createHttpApi(base = '/api'): IdeApi {
  async function request<T>(method: string, path: string, body?: unknown, opts: { quiet401?: boolean } = {}): Promise<T> {
    let res: Response;
    try {
      res = await fetch(base + path, {
        method,
        credentials: 'same-origin',
        headers: body !== undefined ? { 'content-type': 'application/json' } : undefined,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch {
      throw new ApiError('network', undefined, 0);
    }
    const text = await res.text();
    let json: unknown = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* JSON емес жауап (мысалы, прокси қатесі) */ }
    if (!res.ok) {
      const e = (json as ErrorBody | null)?.error;
      const code = e?.code ?? (res.status >= 500 ? 'server.internal' : 'unknown');
      if (res.status === 401 && code === 'auth.unauthenticated' && !opts.quiet401) onUnauthenticated?.();
      throw new ApiError(code, e?.params, res.status);
    }
    return json as T;
  }

  const enc = encodeURIComponent;

  return {
    auth: {
      async login(identifier, password) {
        return (await request<{ user: User }>('POST', '/auth/login', { identifier, password })).user;
      },
      async register(input) {
        return (await request<{ user: User }>('POST', '/auth/register', input)).user;
      },
      async logout() {
        await request('POST', '/auth/logout', {});
      },
      async me() {
        try {
          return (await request<{ user: User }>('GET', '/me', undefined, { quiet401: true })).user;
        } catch (err) {
          if (err instanceof ApiError && err.status === 401) return null;
          throw err;
        }
      },
      async updateProfile(input) {
        return (await request<{ user: User }>('PATCH', '/me', input)).user;
      },
      async changePassword(current, next) {
        await request('POST', '/me/password', { current, next });
      },
    },
    projects: {
      async list(scope: ProjectScope) {
        return (await request<{ projects: ProjectSummary[] }>('GET', `/projects?scope=${enc(scope)}`)).projects;
      },
      async get(id) {
        return (await request<{ project: ProjectSummary }>('GET', `/projects/${enc(id)}`)).project;
      },
      create(input) {
        return request<CreatedProject>('POST', '/projects', input);
      },
      join(code) {
        return request<{ project: ProjectSummary; role: Role }>('POST', '/projects/join', { code });
      },
      rotateInvite(id) {
        return request<{ inviteCode: string }>('POST', `/projects/${enc(id)}/invite/rotate`, {});
      },
      async members(id) {
        return (await request<{ members: ProjectMember[] }>('GET', `/projects/${enc(id)}/members`)).members;
      },
      async setMemberRole(id, userId, role) {
        await request('PATCH', `/projects/${enc(id)}/members/${enc(userId)}`, { role });
      },
      async removeMember(id, userId) {
        await request('DELETE', `/projects/${enc(id)}/members/${enc(userId)}`);
      },
      async getSettings(id) {
        return (await request<{ settings: ProjectSettings }>('GET', `/projects/${enc(id)}/settings`)).settings;
      },
      async updateSettings(id, patch) {
        return (await request<{ settings: ProjectSettings }>('PATCH', `/projects/${enc(id)}/settings`, patch)).settings;
      },
      async remove(id, confirmName) {
        await request('DELETE', `/projects/${enc(id)}`, { confirmName });
      },
    },
    files: {
      async tree(projectId) {
        return (await request<{ nodes: FsNode[] }>('GET', `/projects/${enc(projectId)}/tree`)).nodes;
      },
      async read(projectId, nodeId) {
        return (await request<{ content: string }>('GET', `/projects/${enc(projectId)}/files/${enc(nodeId)}/content`)).content;
      },
      async save(projectId, nodeId, content) {
        await request('PUT', `/projects/${enc(projectId)}/files/${enc(nodeId)}/content`, { content });
      },
      async create(projectId, parentId, name, kind) {
        return (await request<{ node: FsNode }>('POST', `/projects/${enc(projectId)}/nodes`, { parentId, name, kind })).node;
      },
      async rename(projectId, nodeId, name) {
        return (await request<{ node: FsNode }>('PATCH', `/projects/${enc(projectId)}/nodes/${enc(nodeId)}`, { name })).node;
      },
      async remove(projectId, nodeId) {
        await request('DELETE', `/projects/${enc(projectId)}/nodes/${enc(nodeId)}`);
      },
    },
    runs: {
      runtime: () => request<Runtime>('GET', '/runtime'),
      async start(projectId, input) {
        return (await request<{ run: RunView }>('POST', `/projects/${enc(projectId)}/runs`, input)).run;
      },
      poll: (projectId, runId, after) =>
        request<{ run: RunView; events: RunEventOut[]; next: number }>('GET', `/projects/${enc(projectId)}/runs/${enc(runId)}?after=${after}`),
      async cancel(projectId, runId) {
        return (await request<{ run: RunView }>('POST', `/projects/${enc(projectId)}/runs/${enc(runId)}/cancel`, {})).run;
      },
      preview: (projectId, path) => request<PreviewResult>('GET', `/projects/${enc(projectId)}/preview${path ? `?path=${enc(path)}` : ''}`),
    },
    chat: {
      async history(projectId, before) {
        const q = before ? `?before=${before}&limit=50` : '?limit=50';
        const r = await request<{ messages: Array<ChatMessage & { authorName?: string; userId: string | null; body: string }>; hasMore: boolean }>('GET', `/projects/${enc(projectId)}/messages${q}`);
        return { messages: r.messages.map((m) => ({ ...m, userId: m.userId ?? '' })), hasMore: r.hasMore };
      },
    },
  };
}
