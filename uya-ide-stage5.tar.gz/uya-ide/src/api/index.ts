import type { IdeApi } from './contracts';
import { createHttpApi } from './http/httpApi';
import { mockApi } from './mock/mockApi';

declare global {
  interface Window {
    __UYA_CONFIG__?: { monacoBase?: string; apiMode?: 'http' | 'mock'; apiBase?: string };
  }
}

const cfg = typeof window !== 'undefined' ? window.__UYA_CONFIG__ : undefined;

/** `mock` — тек визуалды сынақ үшін (деректер жадта). Әдепкі — нақты бэкэнд. */
export const isMockApi = cfg?.apiMode === 'mock';

/** Бэкэнд интеграциясының БІРДЕН-БІР ауыстыру нүктесі (`public/config.js` арқылы бапталады). */
export const api: IdeApi = isMockApi ? mockApi : createHttpApi(cfg?.apiBase ?? '/api');

export { setUnauthenticatedHandler } from './http/httpApi';
export * from './types';
export type { IdeApi } from './contracts';
