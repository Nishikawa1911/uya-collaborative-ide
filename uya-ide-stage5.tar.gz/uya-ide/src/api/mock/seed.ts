import type { ChatMessage, LanguageId, ProjectMember, Role, User } from '../types';

const minutesAgo = (m: number) => new Date(Date.now() - m * 60_000).toISOString();
const hoursAgo = (h: number) => minutesAgo(h * 60);
const daysAgo = (d: number) => hoursAgo(d * 24);

/** Қосылуға болатын үлгі шақыру коды («Онлайн дүкен — PHP» жобасы). Тек прототип үшін. */
export const DEMO_JOIN_CODE = 'R7K2-9XMD-4TBH';
export const DEMO_LOGIN = { identifier: 'aigerim.s@example.kz', password: 'Uya-demo-2026' };

export interface SeedUser extends User {
  password: string;
  cursorColor: string;
}

const user = (
  id: string, displayName: string, username: string, avatarColor: string, cursorColor: string, createdDaysAgo: number,
): SeedUser => ({
  id, displayName, username, email: `${username.replace(/_/g, '.')}@example.kz`,
  avatarColor, cursorColor, locale: 'kk', createdAt: daysAgo(createdDaysAgo), password: 'Uya-demo-2026',
});

export const seedUsers: SeedUser[] = [
  user('u1', 'Айгерім Сейтқазы', 'aigerim_s', '#1fa7b8', '#3cc6d6', 214),
  user('u2', 'Нұрлан Әбдіқадыр', 'nurlan_a', '#7a6ff0', '#9a8cff', 301),
  user('u3', 'Дана Жұмабекова', 'dana_zh', '#e0709a', '#ff8fb5', 188),
  user('u4', 'Ержан Қасымов', 'erzhan_k', '#d98c2b', '#f2b84b', 150),
  user('u5', 'Ләззат Оспанова', 'lazzat_o', '#4cae7c', '#6fdca0', 97),
  user('u6', 'Тимур Хасенов', 'timur_h', '#cf5c4f', '#ff8174', 260),
  user('u7', 'Ғалымжан Тоқтаров', 'galymzhan_t', '#4a86d8', '#7fb4ff', 75),
  user('u8', 'Асылбек Нұрғалиев', 'asylbek_n', '#9b6fc4', '#c79bf0', 60),
  user('u9', 'Мадина Бекова', 'madina_b', '#c4547f', '#f07aa4', 44),
  user('u10', 'Руслан Сатыбалдиев', 'ruslan_s', '#3f9aa0', '#66d0d6', 31),
  user('u11', 'Әсел Тоқтарова', 'asel_t', '#b8863b', '#e8b25c', 22),
  user('u12', 'Бауыржан Дүйсен', 'bauyrzhan_d', '#6b8f3e', '#9ccc62', 12),
];

export interface SeedProject {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  languages: LanguageId[];
  entryPoint: string;
  updatedAt: string;
  /** Ағымдағы демо пайдаланушының (u1) рөлі; null — мүше емес */
  myRole: Role | null;
  lastOpenedAt?: string;
  members: Array<{ userId: string; role: Role; online?: boolean; activeFile?: string }>;
  joinRole: Exclude<Role, 'owner'>;
  inviteCode: string;
}

export const seedProjects: SeedProject[] = [
  {
    id: 'almaty-aqi',
    name: 'Алматы ауа сапасы мониторы',
    description: 'Қала бекеттерінің PM2.5 деректерінен AQI индексін есептеп, санат бойынша көрсетеді.',
    ownerId: 'u1', languages: ['python', 'sql'], entryPoint: 'main.py',
    updatedAt: minutesAgo(12), lastOpenedAt: minutesAgo(12), myRole: 'owner', joinRole: 'editor',
    inviteCode: 'A1QX-7M2K-9TBH',
    members: [
      { userId: 'u1', role: 'owner', online: true, activeFile: 'main.py' },
      { userId: 'u2', role: 'editor', online: true, activeFile: 'src/aqi.py' },
      { userId: 'u3', role: 'editor', online: true, activeFile: 'tests/test_aqi.py' },
      { userId: 'u5', role: 'viewer', online: false },
      { userId: 'u7', role: 'editor', online: false },
    ],
  },
  {
    id: 'cafe-site',
    name: 'Бейсенбі кафесі — сайт',
    description: 'Шағын кафеге арналған бір беттік сайт: мәзір, брондау түймесі, адаптивті дизайн.',
    ownerId: 'u1', languages: ['html', 'css', 'javascript'], entryPoint: 'index.html',
    updatedAt: hoursAgo(3), lastOpenedAt: hoursAgo(3), myRole: 'owner', joinRole: 'viewer',
    inviteCode: 'B2RK-8N3M-5VCD',
    members: [
      { userId: 'u1', role: 'owner', online: true, activeFile: 'index.html' },
      { userId: 'u9', role: 'editor', online: true, activeFile: 'styles/main.css' },
      { userId: 'u4', role: 'viewer', online: false },
    ],
  },
  {
    id: 'sql-practice',
    name: 'Деректер қоры: SQL тапсырмалары',
    description: 'Университет курсының практикалық тапсырмалары: SELECT, JOIN, топтау және индекстер.',
    ownerId: 'u3', languages: ['sql'], entryPoint: 'queries.sql',
    updatedAt: hoursAgo(26), lastOpenedAt: hoursAgo(27), myRole: 'editor', joinRole: 'editor',
    inviteCode: 'C3SM-9P4N-6WDF',
    members: [
      { userId: 'u3', role: 'owner', online: false },
      { userId: 'u1', role: 'editor', online: true, activeFile: 'queries.sql' },
      { userId: 'u8', role: 'editor', online: false },
      { userId: 'u11', role: 'editor', online: true, activeFile: 'seed.sql' },
      { userId: 'u12', role: 'viewer', online: false },
      { userId: 'u9', role: 'viewer', online: false },
      { userId: 'u10', role: 'viewer', online: false },
    ],
  },
  {
    id: 'pay-gateway',
    name: 'Төлем шлюзі — Go микросервис',
    description: 'Төлем сұрауларын валидациялайтын және бағыттайтын жеңіл HTTP қызметі.',
    ownerId: 'u2', languages: ['go'], entryPoint: 'main.go',
    updatedAt: daysAgo(2), lastOpenedAt: daysAgo(2), myRole: 'editor', joinRole: 'viewer',
    inviteCode: 'D4TN-2Q5P-7XFG',
    members: [
      { userId: 'u2', role: 'owner', online: true, activeFile: 'main.go' },
      { userId: 'u1', role: 'editor', online: true, activeFile: 'internal/validate.go' },
      { userId: 'u6', role: 'editor', online: false },
      { userId: 'u10', role: 'viewer', online: false },
    ],
  },
  {
    id: 'rust-logger',
    name: 'Жазба — командалық жолға арналған күнделік',
    description: 'Rust-та жазылған шағын CLI: терминалдан жазбаларды файлға қосады.',
    ownerId: 'u5', languages: ['rust'], entryPoint: 'src/main.rs',
    updatedAt: daysAgo(4), myRole: 'viewer', joinRole: 'viewer',
    inviteCode: 'E5VP-3R6Q-8ZGH',
    members: [
      { userId: 'u5', role: 'owner', online: false },
      { userId: 'u1', role: 'viewer', online: false },
    ],
  },
  {
    id: 'inventory-ts',
    name: 'Қойма есебі — TypeScript API',
    description: 'Тауар қалдықтарын беретін REST API прототипі.',
    ownerId: 'u1', languages: ['typescript', 'javascript'], entryPoint: 'src/index.ts',
    updatedAt: daysAgo(5), myRole: 'owner', joinRole: 'editor',
    inviteCode: 'F6WQ-4S7R-9AHJ',
    members: [
      { userId: 'u1', role: 'owner', online: true, activeFile: 'src/index.ts' },
      { userId: 'u4', role: 'editor', online: false },
      { userId: 'u6', role: 'editor', online: false },
      { userId: 'u7', role: 'viewer', online: false },
    ],
  },
  {
    id: 'java-uni',
    name: 'Университет курсы: Java ООП',
    description: 'Объектіге бағытталған бағдарламалау бойынша зертханалық жұмыстар.',
    ownerId: 'u6', languages: ['java'], entryPoint: 'Main.java',
    updatedAt: daysAgo(9), lastOpenedAt: daysAgo(9), myRole: 'editor', joinRole: 'viewer',
    inviteCode: 'G7XR-5T8S-2BJK',
    members: [
      { userId: 'u6', role: 'owner', online: false },
      { userId: 'u1', role: 'editor', online: false },
      { userId: 'u8', role: 'viewer', online: false },
      { userId: 'u9', role: 'viewer', online: false },
      { userId: 'u10', role: 'viewer', online: false },
      { userId: 'u11', role: 'viewer', online: false },
      { userId: 'u12', role: 'viewer', online: false },
      { userId: 'u3', role: 'editor', online: false },
      { userId: 'u4', role: 'viewer', online: false },
      { userId: 'u7', role: 'viewer', online: false },
    ],
  },
  {
    id: 'tokenizer-cpp',
    name: 'Қазақ мәтін токенизаторы',
    description: 'C++ жылдам токенизатор: Ә, Ғ, Қ, Ң, Ө, Ұ, Ү, Һ, І әріптерін дұрыс өңдеу эксперименттері.',
    ownerId: 'u1', languages: ['cpp', 'python'], entryPoint: 'main.cpp',
    updatedAt: daysAgo(21), myRole: 'owner', joinRole: 'editor',
    inviteCode: 'H8YS-6V9T-3CKM',
    members: [
      { userId: 'u1', role: 'owner', online: false },
      { userId: 'u2', role: 'editor', online: false },
    ],
  },
  // Қосылуға болатын жобалар (демо пайдаланушы мүше емес):
  {
    id: 'php-shop',
    name: 'Онлайн дүкен — PHP',
    description: 'Ұлттық өнімдерге арналған шағын дүкен.',
    ownerId: 'u4', languages: ['php'], entryPoint: 'index.php',
    updatedAt: daysAgo(6), myRole: null, joinRole: 'editor',
    inviteCode: 'R7K2-9XMD-4TBH',
    members: [
      { userId: 'u4', role: 'owner', online: false },
      { userId: 'u10', role: 'editor', online: false },
      { userId: 'u12', role: 'viewer', online: false },
    ],
  },
  {
    id: 'music-py',
    name: 'Күй мен термелер плейлисті',
    description: 'Python-мен жазылған шағын музыка каталогы.',
    ownerId: 'u9', languages: ['python'], entryPoint: 'playlist.py',
    updatedAt: daysAgo(14), myRole: null, joinRole: 'viewer',
    inviteCode: 'W3FN-8HZQ-5GCV',
    members: [
      { userId: 'u9', role: 'owner', online: false },
      { userId: 'u11', role: 'editor', online: false },
    ],
  },
];

export function membersOf(project: SeedProject): ProjectMember[] {
  return project.members.map((m) => {
    const u = seedUsers.find((x) => x.id === m.userId)!;
    return {
      userId: u.id, displayName: u.displayName, username: u.username, avatarColor: u.avatarColor,
      cursorColor: u.cursorColor, role: m.role, online: !!m.online, activeFile: m.activeFile,
    };
  });
}

export const seedChat: Record<string, ChatMessage[]> = {
  'almaty-aqi': [
    { id: 'm1', userId: 'u2', body: 'Қайырлы таң! aqi.py ішіндегі шекаралар кестесін EPA-ның жаңа нұсқасымен салыстырдым.', createdAt: minutesAgo(94) },
    { id: 'm2', userId: 'u3', body: 'Тамаша 👍 Мен test_aqi.py-ға шеткі мәндерге тест қосамын.', createdAt: minutesAgo(81) },
    { id: 'm3', userId: 'u1', body: 'Келістік. 500-ден жоғары мәндер үшін TODO қалдырдым, соны кейін қараймыз.', createdAt: minutesAgo(63) },
    { id: 'm4', userId: 'u2', body: 'Әуезов ауданының деректері күдікті көрінеді — 61.3 мкг/м³ шынымен бе?', createdAt: minutesAgo(35) },
    { id: 'm5', userId: 'u3', body: 'Бекеттің журналын тексердім: сенсор калибрленген, мән дұрыс.', createdAt: minutesAgo(22) },
    { id: 'm6', userId: 'u1', body: 'Рақмет! Келесі қадам — аудандар бойынша диаграмма қосу.', createdAt: minutesAgo(14) },
  ],
  'cafe-site': [
    { id: 'm1', userId: 'u9', body: 'Түстер схемасын жаңарттым: --brand қоңыр-қызыл болды.', createdAt: hoursAgo(5) },
    { id: 'm2', userId: 'u1', body: 'Өте жақсы! Мобильді нұсқада батырма үлкенірек болса екен.', createdAt: hoursAgo(3) },
  ],
};
