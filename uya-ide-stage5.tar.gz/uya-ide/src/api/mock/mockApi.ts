import type { IdeApi } from '../contracts';
import {
  ApiError, type ChatMessage, type CreateProjectInput, type FsNode, type LanguageId, type ProjectMember,
  type ProjectScope, type ProjectSummary, type RegisterInput, type Role, type UpdateProfileInput, type User,
} from '../types';
import { delay, isValidFileName, safeStorage, uid } from '../../lib/utils';
import { membersOf, seedChat, seedProjects, seedUsers, type SeedProject, type SeedUser } from './seed';
import { seedProjectFiles, type FileSpec } from './seedFiles';

/**
 * Mock API: IdeApi келісімін жад ішінде іске асырады. Тек визуалды тестілеу үшін.
 * Деректер бет жаңартылғанда бастапқы күйіне оралады (тек сессия мен тіркелген пайдаланушылар сақталады).
 */

const SESSION_KEY = 'uya.mock.session';
const USERS_KEY = 'uya.mock.users';
const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

// ── Күй ───────────────────────────────────────────────────
const users: SeedUser[] = [...seedUsers, ...safeStorage.get<SeedUser[]>(USERS_KEY, [])];
const projects: SeedProject[] = structuredClone(seedProjects);
const chat: Record<string, ChatMessage[]> = structuredClone(seedChat);
let currentUserId: string | null = safeStorage.get<string | null>(SESSION_KEY, null);
let failedJoinAttempts = 0;
let lockedUntil = 0;

interface FileStore { nodes: FsNode[]; contents: Record<string, string> }
const fileStores: Record<string, FileStore> = {};

const latency = () => delay(140 + Math.random() * 180);

const publicUser = ({ password: _p, cursorColor: _c, ...u }: SeedUser): User => u;

function requireUser(): SeedUser {
  const u = users.find((x) => x.id === currentUserId);
  if (!u) throw new ApiError('auth.invalid_credentials', undefined, 401);
  return u;
}

function summary(p: SeedProject): ProjectSummary {
  const owner = users.find((u) => u.id === p.ownerId)!;
  return {
    id: p.id, name: p.name, description: p.description, ownerId: p.ownerId, ownerName: owner.displayName,
    memberCount: p.members.length, languages: p.languages, updatedAt: p.updatedAt, lastOpenedAt: p.lastOpenedAt,
    myRole: p.myRole ?? 'viewer', entryPoint: p.entryPoint,
  };
}

function findProject(id: string): SeedProject {
  const p = projects.find((x) => x.id === id);
  if (!p || p.myRole == null) throw new ApiError('project.not_found', undefined, 404);
  return p;
}

// ── Файл қоймасы ──────────────────────────────────────────
function buildStore(projectId: string, spec: FileSpec): FileStore {
  const nodes: FsNode[] = [];
  const contents: Record<string, string> = {};
  const walk = (obj: FileSpec, parentId: string | null, prefix: string) => {
    const entries = Object.entries(obj).sort(([an, av], [bn, bv]) => {
      const af = typeof av === 'object', bf = typeof bv === 'object';
      return af === bf ? an.localeCompare(bn, 'kk') : af ? -1 : 1;
    });
    for (const [name, value] of entries) {
      const id = `${projectId}:${prefix}${name}`;
      if (typeof value === 'string') {
        nodes.push({ id, parentId, name, kind: 'file' });
        contents[id] = value;
      } else {
        nodes.push({ id, parentId, name, kind: 'folder' });
        walk(value, id, `${prefix}${name}/`);
      }
    }
  };
  walk(spec, null, '');
  return { nodes, contents };
}

function storeOf(projectId: string): FileStore {
  findProject(projectId);
  return (fileStores[projectId] ??= buildStore(projectId, seedProjectFiles[projectId] ?? {}));
}

function descendants(store: FileStore, id: string): string[] {
  const kids = store.nodes.filter((n) => n.parentId === id).map((n) => n.id);
  return kids.flatMap((k) => [k, ...descendants(store, k)]);
}

function assertNameFree(store: FileStore, parentId: string | null, name: string, exceptId?: string) {
  if (!isValidFileName(name)) throw new ApiError('file.invalid_name');
  const clash = store.nodes.some((n) => n.parentId === parentId && n.name === name.trim() && n.id !== exceptId);
  if (clash) throw new ApiError('file.exists', undefined, 409);
}

const HELLO: Record<string, string> = {
  py: 'print("Сәлем, әлем!")\n',
  js: 'console.log("Сәлем, әлем!");\n',
  ts: 'const message: string = "Сәлем, әлем!";\nconsole.log(message);\n',
  java: 'public class Main {\n    public static void main(String[] args) {\n        System.out.println("Сәлем, әлем!");\n    }\n}\n',
  go: 'package main\n\nimport "fmt"\n\nfunc main() {\n\tfmt.Println("Сәлем, әлем!")\n}\n',
  cpp: '#include <iostream>\n\nint main() {\n    std::cout << "Сәлем, әлем!" << std::endl;\n    return 0;\n}\n',
  cs: 'Console.WriteLine("Сәлем, әлем!");\n',
  rs: 'fn main() {\n    println!("Сәлем, әлем!");\n}\n',
  php: '<?php\necho "Сәлем, әлем!" . PHP_EOL;\n',
  html: '<!doctype html>\n<html lang="kk">\n  <head><meta charset="utf-8" /><title>Сәлем</title></head>\n  <body><h1>Сәлем, әлем!</h1></body>\n</html>\n',
  css: 'body {\n  font-family: system-ui, sans-serif;\n}\n',
  sql: "SELECT 'Сәлем, әлем!' AS сәлемдесу;\n",
};

// ── Көмекші ───────────────────────────────────────────────
const CROCKFORD = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
function generateInviteCode(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  const raw = [...bytes].map((b) => CROCKFORD[b % 32]).join('');
  return `${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8)}`;
}
const normalizeCode = (s: string) =>
  s.toUpperCase().replace(/[\s-]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');

function persistUsers() {
  safeStorage.set(USERS_KEY, users.slice(seedUsers.length));
}

// ── API ───────────────────────────────────────────────────
export const mockApi: IdeApi = {
  auth: {
    async login(identifier, password) {
      await latency();
      const id = identifier.trim().toLowerCase();
      const u = users.find((x) => x.email.toLowerCase() === id || x.username.toLowerCase() === id);
      if (!u || u.password !== password) throw new ApiError('auth.invalid_credentials', undefined, 401);
      currentUserId = u.id;
      safeStorage.set(SESSION_KEY, u.id);
      return publicUser(u);
    },
    async register(input: RegisterInput) {
      await latency();
      if (users.some((u) => u.email.toLowerCase() === input.email.trim().toLowerCase())) throw new ApiError('auth.email_taken', undefined, 409);
      if (users.some((u) => u.username.toLowerCase() === input.username.trim().toLowerCase())) throw new ApiError('auth.username_taken', undefined, 409);
      const palette = ['#1fa7b8', '#7a6ff0', '#e0709a', '#d98c2b', '#4cae7c', '#4a86d8'];
      const u: SeedUser = {
        id: uid('u'), displayName: input.displayName.trim(), username: input.username.trim(), email: input.email.trim(),
        avatarColor: palette[users.length % palette.length], cursorColor: '#3cc6d6', locale: 'kk',
        createdAt: new Date().toISOString(), password: input.password,
      };
      users.push(u);
      persistUsers();
      currentUserId = u.id;
      safeStorage.set(SESSION_KEY, u.id);
      return publicUser(u);
    },
    async logout() {
      await delay(80);
      currentUserId = null;
      safeStorage.remove(SESSION_KEY);
    },
    async me() {
      await delay(60);
      const u = users.find((x) => x.id === currentUserId);
      return u ? publicUser(u) : null;
    },
    async updateProfile(input: UpdateProfileInput) {
      await latency();
      const u = requireUser();
      if (input.username && users.some((x) => x.id !== u.id && x.username.toLowerCase() === input.username!.toLowerCase())) throw new ApiError('auth.username_taken', undefined, 409);
      if (input.email && users.some((x) => x.id !== u.id && x.email.toLowerCase() === input.email!.toLowerCase())) throw new ApiError('auth.email_taken', undefined, 409);
      if (input.displayName !== undefined) u.displayName = input.displayName.trim();
      if (input.username !== undefined) u.username = input.username.trim();
      if (input.email !== undefined) u.email = input.email.trim();
      if (input.avatarColor !== undefined) u.avatarColor = input.avatarColor;
      if (input.avatarUrl !== undefined) u.avatarUrl = input.avatarUrl ?? undefined;
      persistUsers();
      return publicUser(u);
    },
    async changePassword(current, next) {
      await latency();
      const u = requireUser();
      if (u.password !== current) throw new ApiError('auth.wrong_password', undefined, 400);
      u.password = next;
      persistUsers();
    },
  },

  projects: {
    async list(scope: ProjectScope) {
      await latency();
      const me = requireUser();
      const mine = projects.filter((p) => p.myRole != null);
      let result: SeedProject[];
      if (scope === 'mine') result = mine.filter((p) => p.ownerId === me.id);
      else if (scope === 'shared') result = mine.filter((p) => p.ownerId !== me.id);
      else result = mine.filter((p) => p.lastOpenedAt).sort((a, b) => +new Date(b.lastOpenedAt!) - +new Date(a.lastOpenedAt!));
      if (scope !== 'recent') result = [...result].sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt));
      return result.map(summary);
    },
    async get(id) {
      await latency();
      const p = findProject(id);
      p.lastOpenedAt = new Date().toISOString();
      return summary(p);
    },
    async create(input: CreateProjectInput) {
      await latency();
      const me = requireUser();
      const base = input.name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'joba';
      const id = `${base}-${Math.random().toString(36).slice(2, 6)}`;
      const code = generateInviteCode();
      const p: SeedProject = {
        id, name: input.name.trim(), description: input.description.trim(), ownerId: me.id,
        languages: input.languages as LanguageId[], entryPoint: input.entryPoint.trim() || 'main.txt',
        updatedAt: new Date().toISOString(), lastOpenedAt: new Date().toISOString(), myRole: 'owner',
        joinRole: input.joinRole, inviteCode: code, members: [{ userId: me.id, role: 'owner', online: true }],
      };
      projects.unshift(p);
      const ext = p.entryPoint.split('.').pop() ?? '';
      const files: FileSpec = {};
      const entryName = p.entryPoint.split('/').pop()!;
      const dir = p.entryPoint.includes('/') ? p.entryPoint.split('/').slice(0, -1) : [];
      let cursor: FileSpec = files;
      for (const d of dir) cursor = (cursor[d] = (cursor[d] as FileSpec) ?? {}) as FileSpec;
      cursor[entryName] = input.template === 'hello' ? HELLO[ext] ?? '' : '';
      fileStores[id] = buildStore(id, files);
      chat[id] = [];
      return { project: summary(p), inviteCode: code };
    },
    async join(rawCode) {
      await latency();
      const me = requireUser();
      if (Date.now() < lockedUntil) {
        throw new ApiError('project.invite_rate_limited', { minutes: Math.max(1, Math.ceil((lockedUntil - Date.now()) / 60_000)) }, 429);
      }
      const code = normalizeCode(rawCode);
      const p = projects.find((x) => normalizeCode(x.inviteCode) === code);
      if (!p) {
        failedJoinAttempts += 1;
        if (failedJoinAttempts >= MAX_FAILED_ATTEMPTS) {
          lockedUntil = Date.now() + LOCK_MINUTES * 60_000;
          failedJoinAttempts = 0;
          throw new ApiError('project.invite_rate_limited', { minutes: LOCK_MINUTES }, 429);
        }
        throw new ApiError('project.invalid_invite', { left: MAX_FAILED_ATTEMPTS - failedJoinAttempts }, 404);
      }
      failedJoinAttempts = 0;
      if (p.members.some((m) => m.userId === me.id)) throw new ApiError('project.already_member', undefined, 409);
      p.members.push({ userId: me.id, role: p.joinRole, online: false });
      p.myRole = p.joinRole;
      p.lastOpenedAt = new Date().toISOString();
      return { project: summary(p), role: p.joinRole };
    },
    async rotateInvite(id) {
      await latency();
      const p = findProject(id);
      if (p.myRole !== 'owner') throw new ApiError('permission.denied', undefined, 403);
      p.inviteCode = generateInviteCode();
      return { inviteCode: p.inviteCode };
    },
    async members(id): Promise<ProjectMember[]> {
      await latency();
      const p = findProject(id);
      const me = requireUser();
      const list = membersOf(p);
      // Ағымдағы пайдаланушының аватар/аты өзгерсе, соңғы күйін көрсету
      return list.map((m) => (m.userId === me.id ? { ...m, displayName: me.displayName, avatarColor: me.avatarColor, avatarUrl: me.avatarUrl, username: me.username } : m));
    },
    async setMemberRole(id, userId, role: Role) {
      await delay(120);
      const p = findProject(id);
      if (p.myRole !== 'owner') throw new ApiError('permission.denied', undefined, 403);
      const m = p.members.find((x) => x.userId === userId);
      if (m && m.role !== 'owner') m.role = role;
    },
    async removeMember(id, userId) {
      await delay(120);
      const p = findProject(id);
      if (p.myRole !== 'owner') throw new ApiError('permission.denied', undefined, 403);
      p.members = p.members.filter((m) => m.userId !== userId || m.role === 'owner');
    },
    async getSettings(id) {
      await latency();
      const p = findProject(id);
      if (p.myRole !== 'owner') throw new ApiError('permission.denied', undefined, 403);
      return { name: p.name, description: p.description, languages: p.languages, entryPoint: p.entryPoint, joinRole: p.joinRole, inviteEnabled: true, maxMembers: 50 };
    },
    async updateSettings(id, patch) {
      await latency();
      const p = findProject(id);
      if (p.myRole !== 'owner') throw new ApiError('permission.denied', undefined, 403);
      Object.assign(p, Object.fromEntries(Object.entries(patch).filter(([k]) => ['name', 'description', 'languages', 'entryPoint', 'joinRole'].includes(k))));
      return { name: p.name, description: p.description, languages: p.languages, entryPoint: p.entryPoint, joinRole: p.joinRole, inviteEnabled: true, maxMembers: 50 };
    },
    async remove(id, confirmName) {
      await latency();
      const p = findProject(id);
      if (p.myRole !== 'owner') throw new ApiError('permission.denied', undefined, 403);
      if (confirmName !== p.name) throw new ApiError('project.confirm_mismatch');
      projects.splice(projects.indexOf(p), 1);
    },
  },

  files: {
    async tree(projectId) {
      await latency();
      return structuredClone(storeOf(projectId).nodes);
    },
    async read(projectId, nodeId) {
      await delay(90);
      return storeOf(projectId).contents[nodeId] ?? '';
    },
    async save(projectId, nodeId, content) {
      await delay(120);
      const p = findProject(projectId);
      if (p.myRole === 'viewer') throw new ApiError('permission.denied', undefined, 403);
      storeOf(projectId).contents[nodeId] = content;
      p.updatedAt = new Date().toISOString();
    },
    async create(projectId, parentId, name, kind) {
      await delay(120);
      const p = findProject(projectId);
      if (p.myRole === 'viewer') throw new ApiError('permission.denied', undefined, 403);
      const store = storeOf(projectId);
      assertNameFree(store, parentId, name);
      const node: FsNode = { id: uid('n'), parentId, name: name.trim(), kind };
      store.nodes.push(node);
      if (kind === 'file') store.contents[node.id] = '';
      p.updatedAt = new Date().toISOString();
      return { ...node };
    },
    async rename(projectId, nodeId, name) {
      await delay(120);
      const p = findProject(projectId);
      if (p.myRole === 'viewer') throw new ApiError('permission.denied', undefined, 403);
      const store = storeOf(projectId);
      const node = store.nodes.find((n) => n.id === nodeId);
      if (!node) throw new ApiError('project.not_found', undefined, 404);
      assertNameFree(store, node.parentId, name, nodeId);
      node.name = name.trim();
      return { ...node };
    },
    async remove(projectId, nodeId) {
      await delay(120);
      const p = findProject(projectId);
      if (p.myRole === 'viewer') throw new ApiError('permission.denied', undefined, 403);
      const store = storeOf(projectId);
      const ids = new Set([nodeId, ...descendants(store, nodeId)]);
      store.nodes = store.nodes.filter((n) => !ids.has(n.id));
      ids.forEach((id) => delete store.contents[id]);
    },
  },

  /** Mock режимінде орындау қызметі ЖОҚ: өтірік нәтиже жасалмайды, барлық тіл «қолжетімсіз» көрінеді. */
  runs: {
    async runtime() {
      await latency();
      return { available: false, languages: [], web: false, limits: { concurrency: 0, perUserActive: 0 } };
    },
    async start() { await latency(); throw new ApiError('run.unavailable', undefined, 503); },
    async poll() { throw new ApiError('run.not_found', undefined, 404); },
    async cancel() { throw new ApiError('run.not_found', undefined, 404); },
    async preview() { await latency(); throw new ApiError('run.unavailable', undefined, 503); },
  },

  chat: {
    async history(projectId) {
      await latency();
      findProject(projectId);
      return { messages: structuredClone(chat[projectId] ?? []), hasMore: false };
    },
  },
};
