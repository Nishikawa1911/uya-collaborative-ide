/**
 * Үлгі жоба файлдары (визуалды тестілеуге арналған нақты көрінетін код).
 * Ескерту: мұнда template literal ішінде backtick және `${` қолданылмайды.
 */
export type FileSpec = { [name: string]: string | FileSpec };

const almatyAqi: FileSpec = {
  'README.md': `# Алматы ауа сапасы мониторы

Қала бекеттерінен алынған PM2.5 көрсеткіштерін AQI индексіне айналдырып,
санат бойынша көрсететін шағын жоба.

## Іске қосу

    python main.py

## Құрылым

- main.py — кіру нүктесі
- src/aqi.py — индексті есептеу
- src/fetch.py — бекеттер деректерін жүктеу
- sql/schema.sql — архивтік деректерге арналған кесте
`,
  'main.py': `"""Алматы ауа сапасы мониторы — негізгі іске қосу файлы."""
from src.fetch import load_stations
from src.aqi import aqi_pm25, category


def main() -> None:
    stations = load_stations("data/stations.json")
    print("Алматы — ауа сапасы индексі (PM2.5)")
    print("-" * 52)
    for st in stations:
        index = aqi_pm25(st["pm25"])
        print(f"{st['name']:<22} {st['pm25']:>6.1f} мкг/м³  AQI={index:>3}  {category(index)}")


if __name__ == "__main__":
    main()
`,
  'requirements.txt': `requests==2.32.3
pytest==8.3.3
`,
  'scratch.py': `# Уақытша жазбалар — әзірге аяқталмаған
def draft(values):
    total = sum(values
    return total / len(values)
`,
  src: {
    '__init__.py': '',
    'aqi.py': `"""PM2.5 концентрациясынан AQI индексін есептеу (US EPA шектері)."""

# (C_low, C_high, I_low, I_high)
BREAKPOINTS = [
    (0.0, 12.0, 0, 50),
    (12.1, 35.4, 51, 100),
    (35.5, 55.4, 101, 150),
    (55.5, 150.4, 151, 200),
    (150.5, 250.4, 201, 300),
    (250.5, 500.4, 301, 500),
]

CATEGORIES = [
    (50, "Жақсы"),
    (100, "Қанағаттанарлық"),
    (150, "Сезімтал топтарға зиянды"),
    (200, "Зиянды"),
    (300, "Өте зиянды"),
    (500, "Қауіпті"),
]


def aqi_pm25(concentration: float) -> int:
    """Концентрацияны (мкг/м³) AQI мәніне айналдырады."""
    c = round(concentration, 1)
    for c_lo, c_hi, i_lo, i_hi in BREAKPOINTS:
        if c_lo <= c <= c_hi:
            return round((i_hi - i_lo) / (c_hi - c_lo) * (c - c_lo) + i_lo)
    # TODO: 500.4 мкг/м³-тан жоғары мәндерді өңдеу
    return 500


def category(index: int) -> str:
    for limit, name in CATEGORIES:
        if index <= limit:
            return name
    return CATEGORIES[-1][1]
`,
    'fetch.py': `import json
from pathlib import Path


def load_stations(path: str) -> list[dict]:
    """Бекеттер тізімін JSON файлынан оқиды."""
    with Path(path).open(encoding="utf-8") as fh:
        return json.load(fh)
`,
  },
  data: {
    'stations.json': `[
  { "name": "Медеу ауданы", "pm25": 18.4 },
  { "name": "Алмалы ауданы", "pm25": 42.7 },
  { "name": "Әуезов ауданы", "pm25": 61.3 },
  { "name": "Бостандық ауданы", "pm25": 27.9 },
  { "name": "Түрксіб ауданы", "pm25": 88.1 }
]
`,
  },
  tests: {
    'test_aqi.py': `from src.aqi import aqi_pm25, category


def test_good_air():
    assert aqi_pm25(8.0) <= 50
    assert category(aqi_pm25(8.0)) == "Жақсы"


def test_unhealthy_air():
    assert 151 <= aqi_pm25(88.1) <= 200
`,
  },
  sql: {
    'schema.sql': `-- Архивтік өлшемдерге арналған кесте
CREATE TABLE measurements (
    id          INTEGER PRIMARY KEY,
    station     TEXT    NOT NULL,
    pm25        REAL    NOT NULL CHECK (pm25 >= 0),
    measured_at TEXT    NOT NULL
);

CREATE INDEX idx_measurements_station ON measurements (station, measured_at);

SELECT station, ROUND(AVG(pm25), 1) AS орташа_pm25
FROM measurements
WHERE measured_at >= date('now', '-7 days')
GROUP BY station
ORDER BY орташа_pm25 DESC;
`,
  },
};

const cafeSite: FileSpec = {
  'index.html': `<!doctype html>
<html lang="kk">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Бейсенбі кафесі</title>
    <link rel="stylesheet" href="styles/main.css" />
  </head>
  <body>
    <header class="hero">
      <h1>Бейсенбі кафесі</h1>
      <p>Таңғы ас, қазақы шай және үйдегі тәттілер — Алматы орталығында.</p>
      <button id="order" class="btn">Үстел брондау</button>
    </header>
    <main>
      <section id="menu"></section>
    </main>
    <script src="scripts/app.js"></script>
  </body>
</html>
`,
  styles: {
    'main.css': `:root {
  --brand: #b5532a;
  --cream: #fbf3e6;
  --ink: #2b1d14;
}

body {
  margin: 0;
  font-family: "Inter", system-ui, sans-serif;
  background: var(--cream);
  color: var(--ink);
}

.hero {
  padding: 64px 24px;
  text-align: center;
  background: linear-gradient(160deg, #f6dcbf, var(--cream));
}

.btn {
  padding: 12px 22px;
  border: 0;
  border-radius: 999px;
  background: var(--brand);
  color: #fff;
  font-size: 16px;
  cursor: pointer;
}

.btn:hover { filter: brightness(1.08); }
`,
  },
  scripts: {
    'app.js': `// Мәзірді жүктеп, бетке шығару
const menu = [
  { name: "Қазақы шай", price: 900 },
  { name: "Бауырсақ + қаймақ", price: 1400 },
  { name: "Сырники", price: 2100 },
  { name: "Іздеу: ә, ғ, қ, ң, ө, ұ, ү, һ, і", price: 0 },
];

function renderMenu(items) {
  const root = document.getElementById("menu");
  root.innerHTML = items
    .filter((item) => item.price > 0)
    .map((item) => "<article><h3>" + item.name + "</h3><span>" + item.price + " ₸</span></article>")
    .join("");
}

document.getElementById("order").addEventListener("click", () => {
  alert("Брондау формасы жақында қосылады!");
});

renderMenu(menu);
`,
  },
};

const sqlPractice: FileSpec = {
  'schema.sql': `CREATE TABLE students (
    id        INTEGER PRIMARY KEY,
    full_name TEXT NOT NULL,
    faculty   TEXT NOT NULL,
    gpa       REAL
);

CREATE TABLE enrollments (
    student_id INTEGER REFERENCES students(id),
    course     TEXT NOT NULL,
    grade      INTEGER
);
`,
  'seed.sql': `INSERT INTO students (full_name, faculty, gpa) VALUES
  ('Әсел Тоқтарова', 'Информатика', 3.8),
  ('Бауыржан Дүйсен', 'Математика', 3.4),
  ('Мадина Бекова', 'Информатика', 3.9);
`,
  'queries.sql': `-- 1-тапсырма: GPA бойынша үздік студенттер
SELECT full_name, faculty, gpa
FROM students
WHERE gpa >= 3.5
ORDER BY gpa DESC;

-- 2-тапсырма: факультет бойынша орташа GPA
SELECT faculty, COUNT(*) AS студент_саны, ROUND(AVG(gpa), 2) AS орташа_gpa
FROM students
GROUP BY faculty;
`,
};

const payGateway: FileSpec = {
  'go.mod': `module example.kz/paygateway

go 1.23
`,
  'main.go': `package main

import (
	"encoding/json"
	"log"
	"net/http"
	"time"
)

type Payment struct {
	ID       string  \`json:"id"\`
	Amount   float64 \`json:"amount"\`
	Currency string  \`json:"currency"\`
}

func health(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	_ = json.NewEncoder(w).Encode(map[string]string{"status": "жұмыс істеп тұр"})
}

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", health)

	srv := &http.Server{Addr: ":8080", Handler: mux, ReadTimeout: 5 * time.Second}
	log.Println("Төлем шлюзі :8080 портында")
	log.Fatal(srv.ListenAndServe())
}
`,
  internal: {
    'validate.go': `package internal

import "errors"

var ErrInvalidAmount = errors.New("сома нөлден үлкен болуы керек")

func ValidateAmount(amount float64) error {
	if amount <= 0 {
		return ErrInvalidAmount
	}
	return nil
}
`,
  },
};

const rustLogger: FileSpec = {
  'Cargo.toml': `[package]
name = "zhazba"
version = "0.2.0"
edition = "2021"

[dependencies]
chrono = "0.4"
`,
  src: {
    'main.rs': `use std::fs::OpenOptions;
use std::io::Write;

fn append_entry(path: &str, text: &str) -> std::io::Result<()> {
    let mut file = OpenOptions::new().create(true).append(true).open(path)?;
    writeln!(file, "{}", text)
}

fn main() {
    let note = std::env::args().skip(1).collect::<Vec<_>>().join(" ");
    if note.is_empty() {
        eprintln!("Қолданылуы: zhazba <жазба мәтіні>");
        std::process::exit(2);
    }
    append_entry("logbook.txt", &note).expect("жазба сақталмады");
    println!("Жазба сақталды ✔");
}
`,
  },
};

const inventoryTs: FileSpec = {
  'package.json': `{
  "name": "qoima-api",
  "version": "1.0.0",
  "scripts": { "start": "tsx src/index.ts" }
}
`,
  src: {
    'index.ts': `import { createServer } from "node:http";
import { listItems } from "./items";

const server = createServer((req, res) => {
  if (req.url === "/items") {
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.end(JSON.stringify(listItems()));
    return;
  }
  res.statusCode = 404;
  res.end("Табылмады");
});

server.listen(3000, () => console.log("Қойма API: http://localhost:3000"));
`,
    'items.ts': `export interface Item {
  sku: string;
  title: string;
  quantity: number;
}

const items: Item[] = [
  { sku: "TEA-001", title: "Қара шай, 100 г", quantity: 240 },
  { sku: "HNY-014", title: "Бал, 500 г", quantity: 58 },
  { sku: "NUT-203", title: "Жаңғақ қоспасы", quantity: 12 },
];

export function listItems(): Item[] {
  return items;
}
`,
  },
};

const javaUni: FileSpec = {
  'Main.java': `public class Main {
    public static void main(String[] args) {
        Student s = new Student("Мадина Бекова", 3.9);
        System.out.println(s.describe());
    }
}
`,
  'Student.java': `public class Student {
    private final String name;
    private final double gpa;

    public Student(String name, double gpa) {
        this.name = name;
        this.gpa = gpa;
    }

    public String describe() {
        return name + " — GPA: " + gpa;
    }
}
`,
};

const tokenizerCpp: FileSpec = {
  'main.cpp': `#include <iostream>
#include <string>
#include <vector>

// Қазақ мәтінін сөздерге бөлетін қарапайым токенизатор
std::vector<std::string> tokenize(const std::string& text) {
    std::vector<std::string> tokens;
    std::string current;
    for (unsigned char ch : text) {
        if (ch == ' ' || ch == '\\n' || ch == '\\t') {
            if (!current.empty()) { tokens.push_back(current); current.clear(); }
        } else {
            current.push_back(static_cast<char>(ch));
        }
    }
    if (!current.empty()) tokens.push_back(current);
    return tokens;
}

int main() {
    auto words = tokenize("Қазақ тілі — көркем тіл");
    std::cout << "Сөз саны: " << words.size() << std::endl;
    return 0;
}
`,
  'tokenizer.md': `# Токенизатор

Келесі қадам: UTF-8 кодтауын дұрыс өңдеу (Ә, Ғ, Қ, Ң, Ө, Ұ, Ү, Һ, І).
`,
};

const phpShop: FileSpec = {
  'index.php': `<?php
$products = [
    ["name" => "Қымыз, 1 л", "price" => 1500],
    ["name" => "Құрт, 200 г", "price" => 1200],
];

foreach ($products as $p) {
    echo $p["name"] . " — " . $p["price"] . " ₸" . PHP_EOL;
}
`,
};

const musicPy: FileSpec = {
  'playlist.py': `tracks = ["Адай", "Қара жорға", "Балбырауын"]

for number, title in enumerate(tracks, start=1):
    print(f"{number}. {title}")
`,
};

export const seedProjectFiles: Record<string, FileSpec> = {
  'almaty-aqi': almatyAqi,
  'cafe-site': cafeSite,
  'sql-practice': sqlPractice,
  'pay-gateway': payGateway,
  'rust-logger': rustLogger,
  'inventory-ts': inventoryTs,
  'java-uni': javaUni,
  'tokenizer-cpp': tokenizerCpp,
  'php-shop': phpShop,
  'music-py': musicPy,
};
