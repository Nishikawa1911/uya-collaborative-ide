import type {
  ChatMessage, ChatPage, CreateProjectInput, CreatedProject, FsNode, ProjectMember, ProjectScope,
  PreviewResult, ProjectSettings, ProjectSummary, RegisterInput, Role, RunEventOut, RunView, Runtime, StartRunInput, UpdateProfileInput, User,
} from './types';

/**
 * REST интеграция нүктесі. Нақты іске асыру: `api/http/httpApi.ts` (бэкэнд — `server/`).
 * `api/mock` тек визуалды сынақ үшін (`apiMode: 'mock'`).
 */
export interface IdeApi {
  auth: {
    /** POST /auth/login */
    login(identifier: string, password: string): Promise<User>;
    /** POST /auth/register */
    register(input: RegisterInput): Promise<User>;
    /** POST /auth/logout */
    logout(): Promise<void>;
    /** GET /me — белсенді сессия болмаса null */
    me(): Promise<User | null>;
    /** PATCH /me, POST /me/avatar */
    updateProfile(input: UpdateProfileInput): Promise<User>;
    /** POST /me/password */
    changePassword(current: string, next: string): Promise<void>;
  };
  projects: {
    /** GET /projects?scope=mine|shared|recent */
    list(scope: ProjectScope): Promise<ProjectSummary[]>;
    /** GET /projects/:id */
    get(id: string): Promise<ProjectSummary>;
    /** POST /projects */
    create(input: CreateProjectInput): Promise<CreatedProject>;
    /** POST /projects/join — қате болса ApiError('project.invalid_invite' | 'project.invite_rate_limited') */
    join(code: string): Promise<{ project: ProjectSummary; role: Role }>;
    /** POST /projects/:id/invite/rotate (тек иесі) */
    rotateInvite(id: string): Promise<{ inviteCode: string }>;
    /** GET /projects/:id/members */
    members(id: string): Promise<ProjectMember[]>;
    /** PATCH /projects/:id/members/:userId */
    setMemberRole(id: string, userId: string, role: Role): Promise<void>;
    /** DELETE /projects/:id/members/:userId */
    removeMember(id: string, userId: string): Promise<void>;
    /** GET /projects/:id/settings (тек иесі) */
    getSettings(id: string): Promise<ProjectSettings>;
    /** PATCH /projects/:id/settings (тек иесі) */
    updateSettings(id: string, patch: Partial<ProjectSettings>): Promise<ProjectSettings>;
    /** DELETE /projects/:id (тек иесі; растау үшін жоба атауы жіберіледі) */
    remove(id: string, confirmName: string): Promise<void>;
  };
  files: {
    /** GET /projects/:id/tree */
    tree(projectId: string): Promise<FsNode[]>;
    /** GET /projects/:id/files/:nodeId/content (кейін — Yjs құжаты) */
    read(projectId: string, nodeId: string): Promise<string>;
    /** PUT /projects/:id/files/:nodeId/content («Сақтау» түймесі) */
    save(projectId: string, nodeId: string, content: string): Promise<void>;
    /** POST /projects/:id/nodes */
    create(projectId: string, parentId: string | null, name: string, kind: FsNode['kind']): Promise<FsNode>;
    /** PATCH /projects/:id/nodes/:nodeId */
    rename(projectId: string, nodeId: string, name: string): Promise<FsNode>;
    /** DELETE /projects/:id/nodes/:nodeId */
    remove(projectId: string, nodeId: string): Promise<void>;
  };
  runs: {
    /** GET /runtime — runner күйі және әр тілдің қолжетімділігі */
    runtime(): Promise<Runtime>;
    /** POST /projects/:id/runs (editor/owner). Қате: run.unavailable | run.language_unavailable | run.too_many_active … */
    start(projectId: string, input: StartRunInput): Promise<RunView>;
    /** GET /projects/:id/runs/:runId?after=N — күй + шығыс оқиғалары */
    poll(projectId: string, runId: string, after: number): Promise<{ run: RunView; events: RunEventOut[]; next: number }>;
    /** POST /projects/:id/runs/:runId/cancel */
    cancel(projectId: string, runId: string): Promise<RunView>;
    /** GET /projects/:id/preview?path= — код орындамай біріктірілген HTML */
    preview(projectId: string, path?: string): Promise<PreviewResult>;
  };
  chat: {
    /** GET /projects/:id/messages */
    history(projectId: string, before?: number): Promise<ChatPage>;
  };
}
