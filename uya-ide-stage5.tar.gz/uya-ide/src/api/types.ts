/** Домен үлгілері. Атаулар спецификациядағы дерекқор/API атауларына сәйкес (ағылшынша). */

export type Role = 'owner' | 'editor' | 'viewer';

export type LanguageId =
  | 'python' | 'java' | 'go' | 'cpp' | 'csharp' | 'rust' | 'php'
  | 'typescript' | 'html' | 'css' | 'javascript' | 'sql';

/** Файлдарға арналған қосымша «тілдер» (жоба тілі ретінде таңдалмайды). */
export type FileLanguageId = LanguageId | 'json' | 'markdown' | 'plaintext';

export const PROJECT_LANGUAGES: LanguageId[] = [
  'python', 'java', 'go', 'cpp', 'csharp', 'rust', 'php',
  'typescript', 'html', 'css', 'javascript', 'sql',
];

export interface User {
  id: string;
  username: string;
  email: string;
  displayName: string;
  avatarColor: string;
  avatarUrl?: string;
  locale: 'kk';
  createdAt: string;
}

export interface ProjectSummary {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  ownerName: string;
  memberCount: number;
  languages: LanguageId[];
  updatedAt: string;
  lastOpenedAt?: string;
  myRole: Role;
  entryPoint: string;
}

export interface ProjectMember {
  userId: string;
  displayName: string;
  username: string;
  avatarColor: string;
  avatarUrl?: string;
  role: Role;
  /** Awareness күйі (Yjs). Прототипте — үлгі деректер. */
  online: boolean;
  activeFile?: string;
  cursorColor: string;
}

export type NodeKind = 'file' | 'folder';

export interface FsNode {
  id: string;
  parentId: string | null;
  name: string;
  kind: NodeKind;
}

export interface ChatMessage {
  id: string;
  userId: string;
  body: string;
  createdAt: string;
  /** Серверлік реттік нөмір (тарихты беттеу үшін) */
  seq?: number;
  /** Жіберу кезіндегі автор аты (қатысушы кейін шығып кетсе де көрінеді) */
  authorName?: string;
  /** true = тек осы құрылғыда (серверге жіберілмеген) */
  local?: boolean;
  /** Нақты уақыт режимінде: жіберілуде / жіберілмеді */
  state?: 'sending' | 'failed';
}

export interface ChatPage { messages: ChatMessage[]; hasMore: boolean }

export interface CreateProjectInput {
  name: string;
  description: string;
  languages: LanguageId[];
  entryPoint: string;
  joinRole: Exclude<Role, 'owner'>;
  template: 'empty' | 'hello';
}

export interface CreatedProject {
  project: ProjectSummary;
  /** Шақыру коды тек бір рет қайтарылады; серверде тек хэш сақталады. */
  inviteCode: string;
}

export interface RegisterInput {
  displayName: string;
  username: string;
  email: string;
  password: string;
}

export interface UpdateProfileInput {
  displayName?: string;
  username?: string;
  email?: string;
  avatarColor?: string;
  avatarUrl?: string | null;
}

/** Жоба баптаулары (тек иесі көреді/өзгертеді). */
export interface ProjectSettings {
  name: string;
  description: string;
  languages: LanguageId[];
  entryPoint: string;
  joinRole: Exclude<Role, 'owner'>;
  inviteEnabled: boolean;
  maxMembers: number;
}

export type ProjectScope = 'mine' | 'shared' | 'recent';

/** API қатесі: `code` тұрақты, мәтінді интерфейс қазақша көрсетеді. */
export class ApiError extends Error {
  constructor(
    public code: string,
    public params?: Record<string, string | number>,
    public status = 400,
  ) {
    super(code);
    this.name = 'ApiError';
  }
}

/* ───────── Кодты орындау (5-кезең) ───────── */
export type RunStatus = 'queued' | 'running' | 'ok' | 'error' | 'compile_error' | 'timeout' | 'killed' | 'memory_limit' | 'output_limit' | 'internal_error';
export type RunMode = 'file' | 'project' | 'sql';
export interface RunView {
  id: string; projectId: string; userId: string | null; mode: RunMode; entryPath: string; language: string;
  status: RunStatus; phase: string | null; exitCode: number | null; signal: string | null; durationMs: number | null;
  truncated: boolean; message: string | null; createdAt: string; startedAt: string | null; finishedAt: string | null; queuePosition?: number;
}
export interface RunEventOut { n: number; stream: 'build' | 'stdout' | 'stderr'; chunk: string }
export interface RuntimeLanguage { id: string; label: string; enabled: boolean; reason?: string }
export interface Runtime { available: boolean; languages: RuntimeLanguage[]; web: boolean; limits: { concurrency: number; perUserActive: number } }
export interface PreviewResult { html: string; entry: string; csp: string; external: string[]; missing: string[] }
export interface StartRunInput { mode: RunMode; fileId?: string; sql?: string; stdin?: string }
