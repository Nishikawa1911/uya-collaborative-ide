import { useSyncExternalStore, type AnchorHTMLAttributes, type MouseEvent, type ReactNode } from 'react';

/**
 * Жеңіл hash-router: статикалық хостингте қосымша серверсіз жұмыс істейді.
 * Кейін BrowserRouter-ге ауыстыру үшін тек осы файл өзгереді (navigate, useRoute, Link интерфейсі сақталады).
 */
export type RouteName = 'login' | 'register' | 'dashboard' | 'project.new' | 'project.join' | 'workspace' | 'profile' | 'notFound';

export interface RouteMatch {
  name: RouteName;
  params: Record<string, string>;
  query: URLSearchParams;
  path: string;
}

const table: Array<{ name: RouteName; pattern: string }> = [
  { name: 'login', pattern: '/login' },
  { name: 'register', pattern: '/register' },
  { name: 'dashboard', pattern: '/dashboard' },
  { name: 'project.new', pattern: '/projects/new' },
  { name: 'project.join', pattern: '/projects/join' },
  { name: 'workspace', pattern: '/projects/:id' },
  { name: 'profile', pattern: '/profile' },
];

function parse(hash: string): RouteMatch {
  const raw = hash.replace(/^#/, '') || '/dashboard';
  const [pathname, search = ''] = raw.split('?');
  const query = new URLSearchParams(search);
  const segs = pathname.split('/').filter(Boolean);
  for (const r of table) {
    const pSegs = r.pattern.split('/').filter(Boolean);
    if (pSegs.length !== segs.length) continue;
    const params: Record<string, string> = {};
    const ok = pSegs.every((p, i) => {
      if (p.startsWith(':')) {
        params[p.slice(1)] = decodeURIComponent(segs[i]);
        return true;
      }
      return p === segs[i];
    });
    if (ok) return { name: r.name, params, query, path: pathname };
  }
  return { name: 'notFound', params: {}, query, path: pathname };
}

let cached: { hash: string; match: RouteMatch } | null = null;
function getSnapshot(): RouteMatch {
  const hash = window.location.hash;
  if (!cached || cached.hash !== hash) cached = { hash, match: parse(hash) };
  return cached.match;
}
function subscribe(cb: () => void) {
  window.addEventListener('hashchange', cb);
  return () => window.removeEventListener('hashchange', cb);
}

export function useRoute(): RouteMatch {
  return useSyncExternalStore(subscribe, getSnapshot);
}

export function navigate(path: string, opts: { replace?: boolean } = {}) {
  const target = `#${path}`;
  if (opts.replace) window.location.replace(target);
  else window.location.hash = path;
}

export const paths = {
  login: () => '/login',
  register: () => '/register',
  dashboard: () => '/dashboard',
  newProject: () => '/projects/new',
  joinProject: (code?: string) => (code ? `/projects/join?code=${encodeURIComponent(code)}` : '/projects/join'),
  workspace: (id: string) => `/projects/${encodeURIComponent(id)}`,
  profile: () => '/profile',
};

interface LinkProps extends Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  to: string;
  children?: ReactNode;
}
export function Link({ to, onClick, children, ...rest }: LinkProps) {
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e);
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
    // hash сілтемесі өздігінен жұмыс істейді; қосымша ештеңе қажет емес
  };
  return (
    <a href={`#${to}`} onClick={handle} {...rest}>
      {children}
    </a>
  );
}
