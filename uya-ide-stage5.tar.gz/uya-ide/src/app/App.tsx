import { useEffect, type ReactNode } from 'react';
import { ToastRegion, Spinner, EmptyState, Button } from '../components/ui';
import { AppShell } from '../components/layout/AppShell';
import { LoginPage } from '../features/auth/LoginPage';
import { RegisterPage } from '../features/auth/RegisterPage';
import { DashboardPage } from '../features/dashboard/DashboardPage';
import { CreateProjectPage } from '../features/projects/CreateProjectPage';
import { JoinProjectPage } from '../features/projects/JoinProjectPage';
import { ProfilePage } from '../features/profile/ProfilePage';
import { WorkspacePage } from '../features/workspace/WorkspacePage';
import { useT } from '../i18n';
import { useAuth } from '../state/auth';
import { navigate, paths, useRoute, type RouteName } from './router';

const PUBLIC_ROUTES: RouteName[] = ['login', 'register'];

/** Беттің атауын (document.title) маршрутқа қарай жаңартады. */
function useDocumentTitle(route: RouteName) {
  const t = useT();
  useEffect(() => {
    const titles: Partial<Record<RouteName, string>> = {
      login: t('auth.login.title'),
      register: t('auth.register.title'),
      dashboard: t('nav.projects'),
      'project.new': t('create.title'),
      'project.join': t('join.title'),
      profile: t('profile.title'),
      workspace: t('ws.panel.editor'),
    };
    const page = titles[route];
    document.title = page ? `${page} · ${t('app.name')}` : t('app.name');
  }, [route, t]);
}

function FullPageSpinner() {
  return (
    <div className="boot" aria-busy="true">
      <Spinner size={28} />
    </div>
  );
}

/** Кіру күйіне қарай бағыттау: кірмегендер — /login, кіргендер /login-ге бармайды. */
function Guard({ children, name }: { children: ReactNode; name: RouteName }) {
  const auth = useAuth();
  const route = useRoute();
  const isPublic = PUBLIC_ROUTES.includes(name);

  useEffect(() => {
    if (auth.status === 'anonymous' && !isPublic) {
      const next = route.path === '/dashboard' ? '' : `?next=${encodeURIComponent(route.path)}`;
      navigate(`${paths.login()}${next}`, { replace: true });
    } else if (auth.status === 'authenticated' && isPublic) {
      navigate(paths.dashboard(), { replace: true });
    }
  }, [auth.status, isPublic, route.path]);

  if (auth.status === 'loading') return <FullPageSpinner />;
  if (auth.status === 'anonymous' && !isPublic) return <FullPageSpinner />;
  if (auth.status === 'authenticated' && isPublic) return <FullPageSpinner />;
  return <>{children}</>;
}

function NotFound() {
  const t = useT();
  return (
    <AppShell>
      <div className="page">
        <EmptyState
          icon="search"
          title={t('ws.notFound')}
          text={t('ws.notFoundText')}
          action={<Button variant="primary" onClick={() => navigate(paths.dashboard())}>{t('nav.toDashboard')}</Button>}
        />
      </div>
    </AppShell>
  );
}

export function App() {
  const route = useRoute();
  useDocumentTitle(route.name);

  let page: ReactNode;
  switch (route.name) {
    case 'login': page = <LoginPage />; break;
    case 'register': page = <RegisterPage />; break;
    case 'dashboard': page = <DashboardPage />; break;
    case 'project.new': page = <CreateProjectPage />; break;
    case 'project.join': page = <JoinProjectPage />; break;
    case 'profile': page = <ProfilePage />; break;
    case 'workspace': page = <WorkspacePage key={route.params.id} projectId={route.params.id} />; break;
    default: page = <NotFound />;
  }

  return (
    <>
      <Guard name={route.name}>{page}</Guard>
      <ToastRegion />
    </>
  );
}
