import { createStore } from './createStore';

export type ToastKind = 'success' | 'error' | 'info' | 'warning';
export interface Toast {
  id: number;
  kind: ToastKind;
  message: string;
}

export const toastStore = createStore<Toast[]>([]);
let seq = 0;

export function dismissToast(id: number) {
  toastStore.set((list) => list.filter((t) => t.id !== id));
}

export function toast(message: string, kind: ToastKind = 'info', ms = 4500) {
  const id = ++seq;
  toastStore.set((list) => [...list.slice(-3), { id, kind, message }]);
  if (ms > 0) window.setTimeout(() => dismissToast(id), ms);
  return id;
}
