import { api } from '../api';
import type { RegisterInput, UpdateProfileInput, User } from '../api/types';
import { createStore, useStore } from './createStore';

/** Сессия күйі. `loading` — бастапқы /me сұрауы аяқталғанша. */
export type AuthState =
  | { status: 'loading'; user: null }
  | { status: 'anonymous'; user: null }
  | { status: 'authenticated'; user: User };

export const authStore = createStore<AuthState>({ status: 'loading', user: null });

export async function initAuth(): Promise<void> {
  try {
    const user = await api.auth.me();
    authStore.set(user ? { status: 'authenticated', user } : { status: 'anonymous', user: null });
  } catch {
    authStore.set({ status: 'anonymous', user: null });
  }
}

export async function login(identifier: string, password: string) {
  const user = await api.auth.login(identifier, password);
  authStore.set({ status: 'authenticated', user });
}

export async function register(input: RegisterInput) {
  const user = await api.auth.register(input);
  authStore.set({ status: 'authenticated', user });
}

export async function logout() {
  await api.auth.logout();
  authStore.set({ status: 'anonymous', user: null });
}

export async function updateProfile(input: UpdateProfileInput) {
  const user = await api.auth.updateProfile(input);
  authStore.set({ status: 'authenticated', user });
  return user;
}

export const useAuth = () => useStore(authStore, (s) => s);
export const useCurrentUser = (): User => {
  const s = useAuth();
  if (s.status !== 'authenticated') throw new Error('Пайдаланушы кірген жоқ');
  return s.user;
};
