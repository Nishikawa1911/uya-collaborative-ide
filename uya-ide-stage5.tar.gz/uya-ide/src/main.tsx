import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from './app/App';
import { setLocale, DEFAULT_LOCALE } from './i18n';
import { setUnauthenticatedHandler } from './api';
import { authStore, initAuth } from './state/auth';
import { applyTheme, getTheme } from './theme/theme';
import './styles/index.css';

// Тақырып пен тіл React іске қосылмай тұрып қойылады (жыпылықтауды болдырмау).
applyTheme(getTheme());
setLocale(DEFAULT_LOCALE);
// Сессия мерзімі өтсе (бэкэнд 401), интерфейс кіру бетіне бағытталады
setUnauthenticatedHandler(() => { if (authStore.get().status === 'authenticated') authStore.set({ status: 'anonymous', user: null }); });
void initAuth();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
