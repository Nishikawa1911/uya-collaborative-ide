import { createStore, useStore } from '../state/createStore';

export type Theme = 'dark' | 'light';
const KEY = 'uya.theme';

function readInitial(): Theme {
  try {
    return localStorage.getItem(KEY) === 'light' ? 'light' : 'dark'; // әдепкі — қараңғы
  } catch {
    return 'dark';
  }
}

const store = createStore<Theme>(readInitial());

export function applyTheme(theme: Theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.documentElement.style.colorScheme = theme;
}

export function setTheme(theme: Theme) {
  store.set(theme);
  applyTheme(theme);
  try {
    localStorage.setItem(KEY, theme);
  } catch {
    /* жеке режимде сақтау мүмкін емес — қауіпсіз елемейміз */
  }
}

export const toggleTheme = () => setTheme(store.get() === 'dark' ? 'light' : 'dark');
export const getTheme = () => store.get();
export const useTheme = () => useStore(store, (t) => t);
export const themeStore = store;
